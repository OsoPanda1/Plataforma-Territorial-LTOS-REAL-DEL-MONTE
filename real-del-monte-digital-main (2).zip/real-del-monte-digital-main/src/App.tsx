import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RdmLayout } from "./layouts/RdmLayout";
import { PublicLayout } from "./layouts/PublicLayout";
import { CinematicIntro } from "./components/rdm/CinematicIntro";
import { useState, useCallback } from "react";
import Index from "./pages/Index";
import Historia from "./pages/Historia";
import Gastronomia from "./pages/Gastronomia";
import Lugares from "./pages/Lugares";
import Mapa from "./pages/Mapa";
import Rutas from "./pages/Rutas";
import Comunidad from "./pages/Comunidad";
import Comercios from "./pages/Comercios";
import Recorridos from "./pages/Recorridos";
import Mitos from "./pages/Mitos";
import Perfil from "./pages/Perfil";
import RegistrarComercio from "./pages/RegistrarComercio";
import RutaDelPaste from "./pages/RutaDelPaste";
import Music from "./pages/Music";
import MusicDetail from "./pages/MusicDetail";
import Juegos from "./pages/Juegos";
import Dashboard from "./pages/Dashboard";
import GamePortal from "./pages/GamePortal";
import B2BPortal from "./pages/B2BPortal";
import RealitoAI from "./pages/RealitoAI";
import ControlCenter from "./pages/ControlCenter";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";
import { RouteTracker } from "./modules/tracking/RouteTracker";

const queryClient = new QueryClient();

const App = () => {
  const [introComplete, setIntroComplete] = useState(() => {
    if (sessionStorage.getItem("rdm_intro_seen")) return true;
    return false;
  });

  const handleIntroComplete = useCallback(() => {
    sessionStorage.setItem("rdm_intro_seen", "1");
    setIntroComplete(true);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        {!introComplete && <CinematicIntro onComplete={handleIntroComplete} />}
        <BrowserRouter>
          <RouteTracker />
          <Routes>
            <Route element={<PublicLayout />}>
              <Route path="/" element={<Index />} />
              <Route path="/historia" element={<Historia />} />
              <Route path="/gastronomia" element={<Gastronomia />} />
              <Route path="/lugares" element={<Lugares />} />
              <Route path="/mapa" element={<Mapa />} />
              <Route path="/rutas" element={<Rutas />} />
              <Route path="/ruta-del-paste" element={<RutaDelPaste />} />
              <Route path="/recorridos" element={<Recorridos />} />
              <Route path="/comercios" element={<Comercios />} />
              <Route path="/mitos" element={<Mitos />} />
              <Route path="/registrar-comercio" element={<RegistrarComercio />} />
              <Route path="/perfil" element={<Perfil />} />
              <Route path="/comunidad" element={<Comunidad />} />
              <Route path="/music" element={<Music />} />
              <Route path="/music/:slug" element={<MusicDetail />} />
              <Route path="/juegos" element={<Juegos />} />
            </Route>
            <Route path="/auth" element={<Auth />} />
            <Route element={<RdmLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/control" element={<ControlCenter />} />
              <Route path="/game" element={<GamePortal />} />
              <Route path="/b2b" element={<B2BPortal />} />
              <Route path="/realito" element={<RealitoAI />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
