export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      analytics: {
        Row: {
          created_at: string
          data: Json | null
          event_type: string
          id: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          data?: Json | null
          event_type: string
          id?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          data?: Json | null
          event_type?: string
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      audit_signatures: {
        Row: {
          id: string
          metadata: Json
          resource_id: string
          resource_type: string
          sha256: string
          signed_at: string
          signed_by: string | null
        }
        Insert: {
          id?: string
          metadata?: Json
          resource_id: string
          resource_type: string
          sha256: string
          signed_at?: string
          signed_by?: string | null
        }
        Update: {
          id?: string
          metadata?: Json
          resource_id?: string
          resource_type?: string
          sha256?: string
          signed_at?: string
          signed_by?: string | null
        }
        Relationships: []
      }
      businesses: {
        Row: {
          address: string | null
          category: string
          commerce_type: string
          created_at: string
          description: string
          email: string | null
          facebook: string | null
          id: string
          image_url: string | null
          image_url_2: string | null
          image_url_3: string | null
          instagram: string | null
          is_featured: boolean
          is_premium: boolean
          is_verified: boolean
          latitude: number | null
          longitude: number | null
          monthly_fee_cents: number
          name: string
          next_payment_due: string | null
          owner_id: string | null
          payment_status: string
          phone: string | null
          price_range: string | null
          rating: number | null
          schedule_display: string | null
          short_description: string | null
          status: string
          tiktok: string | null
          updated_at: string
          video_url: string | null
          views_count: number
          website: string | null
          whatsapp: string | null
        }
        Insert: {
          address?: string | null
          category?: string
          commerce_type?: string
          created_at?: string
          description?: string
          email?: string | null
          facebook?: string | null
          id?: string
          image_url?: string | null
          image_url_2?: string | null
          image_url_3?: string | null
          instagram?: string | null
          is_featured?: boolean
          is_premium?: boolean
          is_verified?: boolean
          latitude?: number | null
          longitude?: number | null
          monthly_fee_cents?: number
          name: string
          next_payment_due?: string | null
          owner_id?: string | null
          payment_status?: string
          phone?: string | null
          price_range?: string | null
          rating?: number | null
          schedule_display?: string | null
          short_description?: string | null
          status?: string
          tiktok?: string | null
          updated_at?: string
          video_url?: string | null
          views_count?: number
          website?: string | null
          whatsapp?: string | null
        }
        Update: {
          address?: string | null
          category?: string
          commerce_type?: string
          created_at?: string
          description?: string
          email?: string | null
          facebook?: string | null
          id?: string
          image_url?: string | null
          image_url_2?: string | null
          image_url_3?: string | null
          instagram?: string | null
          is_featured?: boolean
          is_premium?: boolean
          is_verified?: boolean
          latitude?: number | null
          longitude?: number | null
          monthly_fee_cents?: number
          name?: string
          next_payment_due?: string | null
          owner_id?: string | null
          payment_status?: string
          phone?: string | null
          price_range?: string | null
          rating?: number | null
          schedule_display?: string | null
          short_description?: string | null
          status?: string
          tiktok?: string | null
          updated_at?: string
          video_url?: string | null
          views_count?: number
          website?: string | null
          whatsapp?: string | null
        }
        Relationships: []
      }
      events: {
        Row: {
          category: string
          created_at: string
          created_by: string | null
          description: string
          end_date: string | null
          id: string
          image_url: string | null
          is_featured: boolean
          latitude: number | null
          location: string | null
          longitude: number | null
          start_date: string
          title: string
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string
          end_date?: string | null
          id?: string
          image_url?: string | null
          is_featured?: boolean
          latitude?: number | null
          location?: string | null
          longitude?: number | null
          start_date: string
          title: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          created_by?: string | null
          description?: string
          end_date?: string | null
          id?: string
          image_url?: string | null
          is_featured?: boolean
          latitude?: number | null
          location?: string | null
          longitude?: number | null
          start_date?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      federations: {
        Row: {
          active: boolean
          color_hex: string | null
          created_at: string
          description: string | null
          domain: string | null
          icon: string | null
          id: string
          modules: Json
          motto: string | null
          name: string
        }
        Insert: {
          active?: boolean
          color_hex?: string | null
          created_at?: string
          description?: string | null
          domain?: string | null
          icon?: string | null
          id: string
          modules?: Json
          motto?: string | null
          name: string
        }
        Update: {
          active?: boolean
          color_hex?: string | null
          created_at?: string
          description?: string | null
          domain?: string | null
          icon?: string | null
          id?: string
          modules?: Json
          motto?: string | null
          name?: string
        }
        Relationships: []
      }
      forum_comments: {
        Row: {
          author_email: string | null
          author_name: string
          content: string
          created_at: string
          id: string
          likes: number
          post_id: string
        }
        Insert: {
          author_email?: string | null
          author_name?: string
          content: string
          created_at?: string
          id?: string
          likes?: number
          post_id: string
        }
        Update: {
          author_email?: string | null
          author_name?: string
          content?: string
          created_at?: string
          id?: string
          likes?: number
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "forum_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "forum_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "forum_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "public_forum_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      forum_posts: {
        Row: {
          author_avatar: string | null
          author_email: string | null
          author_name: string
          category: string
          content: string
          created_at: string
          id: string
          image_url: string | null
          is_approved: boolean
          likes: number
          place_name: string | null
          title: string
          updated_at: string
          video_url: string | null
        }
        Insert: {
          author_avatar?: string | null
          author_email?: string | null
          author_name?: string
          category?: string
          content: string
          created_at?: string
          id?: string
          image_url?: string | null
          is_approved?: boolean
          likes?: number
          place_name?: string | null
          title: string
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          author_avatar?: string | null
          author_email?: string | null
          author_name?: string
          category?: string
          content?: string
          created_at?: string
          id?: string
          image_url?: string | null
          is_approved?: boolean
          likes?: number
          place_name?: string | null
          title?: string
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      pois: {
        Row: {
          altitude_m: number | null
          category: string
          created_at: string
          description: string | null
          federation_id: string | null
          id: string
          lat: number
          lng: number
          municipality: string
          name: string
          significance: string | null
        }
        Insert: {
          altitude_m?: number | null
          category: string
          created_at?: string
          description?: string | null
          federation_id?: string | null
          id?: string
          lat: number
          lng: number
          municipality?: string
          name: string
          significance?: string | null
        }
        Update: {
          altitude_m?: number | null
          category?: string
          created_at?: string
          description?: string | null
          federation_id?: string | null
          id?: string
          lat?: number
          lng?: number
          municipality?: string
          name?: string
          significance?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pois_federation_id_fkey"
            columns: ["federation_id"]
            isOneToOne: false
            referencedRelation: "federations"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          id: string
          is_active: boolean
          name: string
          role: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          id: string
          is_active?: boolean
          name?: string
          role?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean
          name?: string
          role?: string
          updated_at?: string
        }
        Relationships: []
      }
      repositories: {
        Row: {
          classification: string | null
          default_branch: string | null
          description: string | null
          federation_id: string | null
          forks: number
          full_name: string
          github_id: number | null
          homepage: string | null
          id: string
          is_core: boolean
          language: string | null
          name: string
          pushed_at: string | null
          size_kb: number
          stars: number
          topics: Json
          updated_at: string
          url: string
        }
        Insert: {
          classification?: string | null
          default_branch?: string | null
          description?: string | null
          federation_id?: string | null
          forks?: number
          full_name: string
          github_id?: number | null
          homepage?: string | null
          id: string
          is_core?: boolean
          language?: string | null
          name: string
          pushed_at?: string | null
          size_kb?: number
          stars?: number
          topics?: Json
          updated_at?: string
          url: string
        }
        Update: {
          classification?: string | null
          default_branch?: string | null
          description?: string | null
          federation_id?: string | null
          forks?: number
          full_name?: string
          github_id?: number | null
          homepage?: string | null
          id?: string
          is_core?: boolean
          language?: string | null
          name?: string
          pushed_at?: string | null
          size_kb?: number
          stars?: number
          topics?: Json
          updated_at?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "repositories_federation_id_fkey"
            columns: ["federation_id"]
            isOneToOne: false
            referencedRelation: "federations"
            referencedColumns: ["id"]
          },
        ]
      }
      routes: {
        Row: {
          active: boolean
          category: string
          created_at: string
          description: string | null
          distance_km: number | null
          duration_min: number | null
          federation_id: string | null
          geometry: Json | null
          id: string
          name: string
        }
        Insert: {
          active?: boolean
          category?: string
          created_at?: string
          description?: string | null
          distance_km?: number | null
          duration_min?: number | null
          federation_id?: string | null
          geometry?: Json | null
          id?: string
          name: string
        }
        Update: {
          active?: boolean
          category?: string
          created_at?: string
          description?: string | null
          distance_km?: number | null
          duration_min?: number | null
          federation_id?: string | null
          geometry?: Json | null
          id?: string
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "routes_federation_id_fkey"
            columns: ["federation_id"]
            isOneToOne: false
            referencedRelation: "federations"
            referencedColumns: ["id"]
          },
        ]
      }
      system_logs: {
        Row: {
          created_at: string
          data: Json | null
          id: string
          log_type: string
          message: string | null
        }
        Insert: {
          created_at?: string
          data?: Json | null
          id?: string
          log_type: string
          message?: string | null
        }
        Update: {
          created_at?: string
          data?: Json | null
          id?: string
          log_type?: string
          message?: string | null
        }
        Relationships: []
      }
      tamvcrums_logs: {
        Row: {
          created_at: string
          ecg_rhythm: number
          emotional_state: string
          federation_id: string | null
          id: string
          impact_score: number
          payload: Json
          source: string | null
        }
        Insert: {
          created_at?: string
          ecg_rhythm?: number
          emotional_state?: string
          federation_id?: string | null
          id?: string
          impact_score?: number
          payload?: Json
          source?: string | null
        }
        Update: {
          created_at?: string
          ecg_rhythm?: number
          emotional_state?: string
          federation_id?: string | null
          id?: string
          impact_score?: number
          payload?: Json
          source?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      public_forum_comments: {
        Row: {
          author_name: string | null
          content: string | null
          created_at: string | null
          id: string | null
          likes: number | null
          post_id: string | null
        }
        Insert: {
          author_name?: string | null
          content?: string | null
          created_at?: string | null
          id?: string | null
          likes?: number | null
          post_id?: string | null
        }
        Update: {
          author_name?: string | null
          content?: string | null
          created_at?: string | null
          id?: string | null
          likes?: number | null
          post_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "forum_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "forum_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "forum_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "public_forum_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      public_forum_posts: {
        Row: {
          author_avatar: string | null
          author_name: string | null
          category: string | null
          content: string | null
          created_at: string | null
          id: string | null
          image_url: string | null
          likes: number | null
          place_name: string | null
          title: string | null
          updated_at: string | null
          video_url: string | null
        }
        Insert: {
          author_avatar?: string | null
          author_name?: string | null
          category?: string | null
          content?: string | null
          created_at?: string | null
          id?: string | null
          image_url?: string | null
          likes?: number | null
          place_name?: string | null
          title?: string | null
          updated_at?: string | null
          video_url?: string | null
        }
        Update: {
          author_avatar?: string | null
          author_name?: string | null
          category?: string | null
          content?: string | null
          created_at?: string | null
          id?: string | null
          image_url?: string | null
          likes?: number | null
          place_name?: string | null
          title?: string | null
          updated_at?: string | null
          video_url?: string | null
        }
        Relationships: []
      }
      public_profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          id: string | null
          is_active: boolean | null
          name: string | null
          role: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          id?: string | null
          is_active?: boolean | null
          name?: string | null
          role?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          id?: string | null
          is_active?: boolean | null
          name?: string | null
          role?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
