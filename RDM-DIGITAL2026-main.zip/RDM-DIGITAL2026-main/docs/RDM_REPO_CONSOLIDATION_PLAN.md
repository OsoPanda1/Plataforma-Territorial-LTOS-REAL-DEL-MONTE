# Plan de consolidación de RDM Digital en un solo repositorio

## Objetivo
Consolidar el conocimiento técnico y funcional de los 10 repositorios fuente en este repositorio (`/workspace/RDM-DIGITAL2026`) para construir una versión única, trazable y mantenible de **RDM Digital**.

## Repositorios objetivo
1. `citemesh-roots`
2. `RDM-Digital-X`
3. `civilizational-core`
4. `real-del-monte-elevated`
5. `real-del-monte-explorer`
6. `real-del-monte-twin`
7. `rdm-smart-city-os`
8. `rdm-digital-2dbd42b0`
9. `genesis-digytamv-nexus`
10. `Anubisgram`

## Estado de análisis en este entorno
Se intentó clonar los 10 repositorios para extraer:
- estructura de carpetas,
- stack técnico,
- dependencias,
- módulos reutilizables,
- conflictos de naming/arquitectura,
- y plan de migración incremental.

### Bloqueo detectado
En este entorno, todos los intentos de acceso a GitHub devolvieron:

- `CONNECT tunnel failed, response 403`

Esto impide completar el análisis de contenido fuente (código, historial, issues y documentación externa) directamente desde los remotos.

## Información ya disponible dentro de este repo
Para no detener la consolidación, se toma como base interna:

- `docs/UNIFIED_TAMV_ECOSYSTEM.md` como documento unificado de visión, dominios y mapeo conceptual.
- `docs/architecture/TAMV-Core-Architecture.md` para arquitectura técnica de referencia.
- `docs/architecture/TAMV-Wiki-Integration-Manual.md` para integración de wiki/knowledge graph.
- `prisma/schema.prisma` para frontera de datos actual.

## Estrategia de consolidación (ejecutable)

### Fase 1 — Intake reproducible de repos externos
Crear un intake automatizado para cada repo con salida normalizada:

- `repo-metadata.json` (default branch, últimos commits, tags)
- `tech-stack.json` (frameworks, lenguajes, librerías)
- `module-index.json` (módulos exportables por dominio)
- `data-contracts.json` (esquemas, modelos, endpoints)
- `risk-report.md` (riesgos de merge, licencias, breaking changes)

### Fase 2 — Matriz de convergencia
Consolidar todo en una matriz única:

- **Dominio funcional**
- **Repo origen**
- **Activo reutilizable**
- **Destino en monorepo**
- **Compatibilidad (alta/media/baja)**
- **Acción (adoptar/refactor/reemplazar/descartar)**

### Fase 3 — Integración por dominios
Orden sugerido de integración para minimizar regresiones:

1. Núcleo (`civilizational-core`, `citemesh-roots`)
2. Territorio RDM (`RDM-Digital-X`, `rdm-digital-2dbd42b0`)
3. Gemelos y exploración (`real-del-monte-*`)
4. Sistema operativo urbano (`rdm-smart-city-os`)
5. Capa social y génesis (`Anubisgram`, `genesis-digytamv-nexus`)

### Fase 4 — Hardening
- pruebas de regresión por dominio,
- versionado semántico de módulos integrados,
- changelog de migración,
- checklist de observabilidad y seguridad.

## Estructura de destino recomendada para monorepo

```text
/apps
  /rdm-web
  /rdm-admin
  /rdm-api
/packages
  /core-domain
  /identity
  /social-core
  /geo-twin
  /smart-city
  /ai-orchestration
  /shared-ui
  /shared-types
/docs
  /consolidation
  /architecture
/tools
  /repo-intake
```

## Criterios de aceptación para “RDM Digital unificado”
- Un solo `package manager lockfile` activo.
- Un solo contrato de datos versionado.
- Build green en CI para apps y paquetes.
- Trazabilidad repo-origen → módulo-destino documentada.
- Deuda técnica clasificada por severidad y fecha objetivo.

## Siguiente paso operativo
Cuando exista acceso a GitHub (o mirrors locales), ejecutar intake automatizado con `tools/repo-intake/README.md` y registrar hallazgos en `docs/consolidation/`.
