# Repo Intake (RDM)

Script para analizar repositorios fuente y producir artefactos normalizados de consolidación.

## Uso

```bash
bash tools/repo-intake/intake.sh
```

Opcionalmente puedes definir `BASE_DIR` para controlar dónde se clonan los repos:

```bash
BASE_DIR=/tmp/rdm-intake bash tools/repo-intake/intake.sh
```

## Salida
Los resultados se guardan en:

- `docs/consolidation/intake-summary.md`
- `docs/consolidation/repos/<repo>/repo-metadata.txt`
- `docs/consolidation/repos/<repo>/tree.txt`
- `docs/consolidation/repos/<repo>/package-files.txt`

## Nota
Si no hay acceso de red al remoto, el script deja evidencia de error por repo para auditoría.
