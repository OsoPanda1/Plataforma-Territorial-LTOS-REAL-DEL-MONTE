#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="${BASE_DIR:-/tmp/rdm-intake}"
OUT_DIR="docs/consolidation/repos"
SUMMARY="docs/consolidation/intake-summary.md"

repos=(
  "https://github.com/OsoPanda1/citemesh-roots.git"
  "https://github.com/OsoPanda1/RDM-Digital-X.git"
  "https://github.com/OsoPanda1/civilizational-core.git"
  "https://github.com/OsoPanda1/real-del-monte-elevated.git"
  "https://github.com/OsoPanda1/real-del-monte-explorer.git"
  "https://github.com/OsoPanda1/real-del-monte-twin.git"
  "https://github.com/OsoPanda1/rdm-smart-city-os.git"
  "https://github.com/OsoPanda1/rdm-digital-2dbd42b0.git"
  "https://github.com/OsoPanda1/genesis-digytamv-nexus.git"
  "https://github.com/OsoPanda1/Anubisgram.git"
)

mkdir -p "$BASE_DIR" "$OUT_DIR"

{
  echo "# Intake Summary"
  echo
  echo "Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")"
  echo
} > "$SUMMARY"

for url in "${repos[@]}"; do
  repo_name="$(basename "$url" .git)"
  target="$BASE_DIR/$repo_name"
  repo_out="$OUT_DIR/$repo_name"
  mkdir -p "$repo_out"

  echo "## $repo_name" >> "$SUMMARY"

  if git clone --depth 1 "$url" "$target" >"$repo_out/clone.log" 2>&1; then
    echo "- status: ✅ cloned" >> "$SUMMARY"
    (
      cd "$target"
      {
        echo "remote: $url"
        git rev-parse --abbrev-ref HEAD | sed 's/^/branch: /'
        git rev-parse HEAD | sed 's/^/commit: /'
        echo "latest_tag: $(git describe --tags --abbrev=0 2>/dev/null || echo n/a)"
      } > "$OLDPWD/$repo_out/repo-metadata.txt"

      git ls-files > "$OLDPWD/$repo_out/tree.txt" || true
      git ls-files | grep -E "(package\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb|Dockerfile|docker-compose|README|AGENTS\.md)$" > "$OLDPWD/$repo_out/package-files.txt" || true
    )
  else
    echo "- status: ❌ clone_failed" >> "$SUMMARY"
    echo "- error: $(tail -n 1 "$repo_out/clone.log" | sed 's/^\s*//')" >> "$SUMMARY"
  fi

  echo >> "$SUMMARY"
done

echo "Intake complete. See $SUMMARY"
