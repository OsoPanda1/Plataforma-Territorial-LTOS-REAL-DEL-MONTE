-- TAMV Knowledge Graph Foundation (PostgreSQL + pgvector)
-- Date: 2026-04-23
-- Scope: core graph entities, semantic search support, and initial TAMV seed.

create extension if not exists pgcrypto;
create extension if not exists vector;

-- 1) Catalogs
create table if not exists node_types (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  label text not null,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists relation_types (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  label text not null,
  description text,
  created_at timestamptz not null default now()
);

-- 2) Documents and sources
create table if not exists documents (
  id uuid primary key default gen_random_uuid(),
  project_code text not null default 'TAMV',
  slug text unique not null,
  title text not null,
  doc_type text not null, -- README | manifiesto | blueprint | entrevista | nota | pdf
  content text not null,
  source_url text,
  author text,
  status text not null default 'raw',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists sources (
  id uuid primary key default gen_random_uuid(),
  project_code text not null default 'TAMV',
  source_type text not null, -- pdf | url | note | audio | interview
  title text not null,
  locator text, -- path, url, or bibliographic locator
  reliability_score numeric(3,2) not null default 1.0
    check (reliability_score >= 0 and reliability_score <= 1),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- 3) Graph entities
create table if not exists nodes (
  id uuid primary key default gen_random_uuid(),
  project_code text not null default 'TAMV',
  type_code text not null references node_types(code),
  slug text unique not null,
  title text not null,
  summary text,
  body text,
  status text not null default 'draft' check (status in ('draft', 'active', 'archived', 'vision')),
  importance int not null default 50 check (importance >= 0 and importance <= 100),
  source_doc_id uuid null references documents(id) on delete set null,
  metadata jsonb not null default '{}'::jsonb,
  embedding vector(1536),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists edges (
  id uuid primary key default gen_random_uuid(),
  project_code text not null default 'TAMV',
  from_node_id uuid not null references nodes(id) on delete cascade,
  to_node_id uuid not null references nodes(id) on delete cascade,
  relation_type text not null references relation_types(code),
  strength numeric(3,2) not null default 1.0
    check (strength >= 0 and strength <= 1),
  rationale text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(from_node_id, to_node_id, relation_type)
);

create table if not exists document_chunks (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references documents(id) on delete cascade,
  chunk_index int not null,
  content text not null,
  node_id uuid null references nodes(id) on delete set null,
  metadata jsonb not null default '{}'::jsonb,
  embedding vector(1536),
  created_at timestamptz not null default now(),
  unique(document_id, chunk_index)
);

-- 4) Tags
create table if not exists tags (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  label text not null
);

create table if not exists node_tags (
  node_id uuid not null references nodes(id) on delete cascade,
  tag_id uuid not null references tags(id) on delete cascade,
  primary key (node_id, tag_id)
);

-- 5) Updated-at trigger
create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_documents_updated_at on documents;
create trigger trg_documents_updated_at
before update on documents
for each row execute function set_updated_at();

drop trigger if exists trg_nodes_updated_at on nodes;
create trigger trg_nodes_updated_at
before update on nodes
for each row execute function set_updated_at();

-- 6) Performance indexes
create index if not exists idx_nodes_project_type on nodes(project_code, type_code);
create index if not exists idx_nodes_status_importance on nodes(status, importance desc);
create index if not exists idx_edges_from on edges(from_node_id);
create index if not exists idx_edges_to on edges(to_node_id);
create index if not exists idx_documents_project_type on documents(project_code, doc_type);
create index if not exists idx_document_chunks_document on document_chunks(document_id);

create index if not exists idx_nodes_metadata_gin on nodes using gin(metadata);
create index if not exists idx_edges_metadata_gin on edges using gin(metadata);
create index if not exists idx_documents_metadata_gin on documents using gin(metadata);

create index if not exists idx_nodes_embedding_cosine
  on nodes using ivfflat (embedding vector_cosine_ops) with (lists = 100);
create index if not exists idx_chunks_embedding_cosine
  on document_chunks using ivfflat (embedding vector_cosine_ops) with (lists = 100);

-- 7) Operational view
create or replace view v_nodes_by_type as
select
  n.project_code,
  n.type_code,
  nt.label as type_label,
  count(*) as total_nodes,
  count(*) filter (where n.status = 'active') as active_nodes,
  round(avg(n.importance)::numeric, 2) as avg_importance
from nodes n
join node_types nt on nt.code = n.type_code
group by n.project_code, n.type_code, nt.label;

-- 8) Seed taxonomy: node types
insert into node_types (code, label, description) values
('identity', 'Identidad', 'Personas, roles, firmas y figuras simbólicas'),
('concept', 'Concepto', 'Ideas, principios, marcos y definiciones'),
('system', 'Sistema', 'Subsistemas y plataformas principales'),
('asset', 'Activo', 'NFT, producto, servicio o recurso'),
('process', 'Proceso', 'Secuencia operativa o flujo de trabajo'),
('protocol', 'Protocolo', 'Reglas, normas y procedimientos de seguridad'),
('territory', 'Territorio', 'Lugar físico, digital o nodal'),
('document', 'Documento', 'Fuente textual maestra o derivada'),
('event', 'Evento', 'Hito, lanzamiento, fecha o suceso'),
('model', 'Modelo', 'Estructura económica, técnica o de gobernanza')
on conflict (code) do nothing;

-- 9) Seed taxonomy: relation types
insert into relation_types (code, label, description) values
('defines', 'Define', 'Establece la definición o marco del nodo destino'),
('represents', 'Representa', 'Simboliza o personifica al nodo destino'),
('contains', 'Contiene', 'Incluye al nodo destino como parte del sistema'),
('depends_on', 'Depende de', 'Necesita al nodo destino para operar'),
('connected_to', 'Conectado con', 'Conexión genérica entre nodos'),
('governs', 'Gobierna', 'Establece reglas o guía al nodo destino'),
('generates_value_for', 'Genera valor para', 'Aporta valor directo al nodo destino'),
('implemented_in', 'Implementado en', 'Se implementa dentro del nodo destino'),
('evolves_into', 'Evoluciona hacia', 'Transformación temporal o versión futura'),
('documents', 'Documenta', 'Actúa como documentación del nodo destino'),
('is_same_as', 'Es igual a', 'Identidad equivalente o alias canónico'),
('embodies', 'Encarna', 'Expresa un principio dentro del nodo destino'),
('preserves', 'Preserva', 'Conserva memoria, cultura o trazabilidad'),
('implements', 'Implementa', 'Materializa operativamente al nodo destino')
on conflict (code) do nothing;

-- 10) Seed nodes
insert into nodes (type_code, slug, title, summary, status, importance, metadata) values
('system', 'tamv-core', 'TAMV Core', 'Núcleo cognitivo e institucional del ecosistema TAMV.', 'active', 100, '{"domain":"ecosystem"}'),
('system', 'tamv-online-network', 'TAMV Online Network', 'Ecosistema digital y civilizatorio del proyecto TAMV.', 'active', 100, '{"domain":"network"}'),
('identity', 'anubis-villasenor', 'Anubis Villaseñor', 'Figura simbólica y narrativa central del proyecto.', 'active', 95, '{"role":"Arquitecto Raíz"}'),
('identity', 'edwin-oswaldo-castillo-trejo', 'Edwin Oswaldo Castillo Trejo', 'Nombre legal asociado al Arquitecto Raíz.', 'active', 90, '{"role":"Fundador"}'),
('document', 'manifiesto-tamv', 'Manifiesto TAMV', 'Documento rector de visión, propósito y principios.', 'active', 100, '{"doc_kind":"manifesto"}'),
('model', 'md-x4', 'MD-X4', 'Arquitectura de 7 capas civilizatorias y técnicas.', 'active', 98, '{"layers":7}'),
('concept', 'territorio-autonomo-de-memoria-viva', 'Territorio Autónomo de Memoria Viva', 'Definición conceptual del TAMV.', 'active', 100, '{"type":"canonical_definition"}'),
('system', 'utamv', 'UTAMV', 'Universidad del ecosistema TAMV.', 'vision', 92, '{"domain":"education"}'),
('territory', 'rdm-digital', 'RDM Digital', 'Nodo territorial del proyecto en Real del Monte.', 'active', 95, '{"location":"Real del Monte, México"}'),
('system', 'isabella-ia', 'Isabella IA', 'Sistema de inteligencia ética y asistencia cognitiva.', 'active', 96, '{"role":"ethical_ai"}'),
('protocol', 'tenochtitlan-security', 'Sistema TENOCHTITLAN', 'Arquitectura de seguridad, vigilancia y antifraude.', 'active', 94, '{"domain":"security"}'),
('asset', 'nft-el-regalo-del-alma', 'NFT El Regalo del Alma', 'Colección o activo simbólico y económico del ecosistema.', 'vision', 85, '{"asset_type":"nft"}'),
('model', 'fairsplit', 'FairSplit', 'Modelo de distribución económica y monetización justa.', 'active', 90, '{"domain":"economics"}'),
('concept', 'soberania-digital', 'Soberanía Digital', 'Principio rector de control, autonomía y memoria.', 'active', 98, '{"category":"principle"}'),
('concept', 'memoria-historica', 'Memoria Histórica', 'Preservación y activación de identidad y territorio.', 'active', 97, '{"category":"cultural"}')
on conflict (slug) do nothing;

-- 11) Seed relationships
with n as (
  select slug, id from nodes
)
insert into edges (from_node_id, to_node_id, relation_type, strength, rationale)
select a.id, b.id, 'defines', 1.0, 'Nodo rector define al ecosistema'
from n a, n b
where a.slug = 'manifiesto-tamv' and b.slug = 'tamv-core'
union all
select a.id, b.id, 'represents', 1.0, 'Figura simbólica central del proyecto'
from n a, n b
where a.slug = 'anubis-villasenor' and b.slug = 'tamv-core'
union all
select a.id, b.id, 'is_same_as', 1.0, 'Nombre legal asociado al Arquitecto Raíz'
from n a, n b
where a.slug = 'edwin-oswaldo-castillo-trejo' and b.slug = 'anubis-villasenor'
union all
select a.id, b.id, 'implements', 1.0, 'Arquitectura operativa del sistema'
from n a, n b
where a.slug = 'md-x4' and b.slug = 'tamv-core'
union all
select a.id, b.id, 'contains', 1.0, 'UTAMV como subsistema'
from n a, n b
where a.slug = 'tamv-core' and b.slug = 'utamv'
union all
select a.id, b.id, 'contains', 1.0, 'RDM Digital como nodo territorial'
from n a, n b
where a.slug = 'tamv-core' and b.slug = 'rdm-digital'
union all
select a.id, b.id, 'contains', 1.0, 'Isabella IA como subsistema cognitivo'
from n a, n b
where a.slug = 'tamv-core' and b.slug = 'isabella-ia'
union all
select a.id, b.id, 'depends_on', 0.9, 'Seguridad base del ecosistema'
from n a, n b
where a.slug = 'tamv-core' and b.slug = 'tenochtitlan-security'
union all
select a.id, b.id, 'generates_value_for', 0.9, 'Modelo económico del ecosistema'
from n a, n b
where a.slug = 'fairsplit' and b.slug = 'tamv-core'
union all
select a.id, b.id, 'embodies', 1.0, 'Principio rector de autonomía'
from n a, n b
where a.slug = 'soberania-digital' and b.slug = 'tamv-core'
union all
select a.id, b.id, 'preserves', 1.0, 'Memoria como base del ecosistema'
from n a, n b
where a.slug = 'memoria-historica' and b.slug = 'tamv-core'
union all
select a.id, b.id, 'generates_value_for', 0.8, 'Activo económico y simbólico'
from n a, n b
where a.slug = 'nft-el-regalo-del-alma' and b.slug = 'tamv-core'
on conflict (from_node_id, to_node_id, relation_type) do nothing;
