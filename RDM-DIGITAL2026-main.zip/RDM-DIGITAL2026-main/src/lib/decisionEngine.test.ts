import { describe, expect, it } from "vitest";
import { DecisionEngine } from "@/lib/decisionEngine";

describe("DecisionEngine", () => {
  it("sanitiza y clasifica recomendaciones", () => {
    const engine = new DecisionEngine({ maxResponses: 20 });
    engine.addResponse("<script>alert(1)</script> Riesgo de latencia en gateway");

    const [rec] = engine.getRecommendations();
    expect(rec.recommendation).not.toContain("<script>");
    expect(rec.category).toBe("risk");
    expect(rec.confidence).toBeGreaterThan(0);
  });

  it("respeta límite de memoria", () => {
    const engine = new DecisionEngine({ maxResponses: 10 });
    for (let i = 0; i < 40; i += 1) {
      engine.addResponse(`response ${i} because it includes details`);
    }

    expect(engine.getRecommendations()).toHaveLength(10);
  });

  it("permite limpiar estado", () => {
    const engine = new DecisionEngine();
    engine.addResponse("arquitectura federada");
    engine.clear();
    expect(engine.getRecommendations()).toHaveLength(0);
  });
});
