import { INTEGRATION_PHASES, PROTOCOLS, SOURCE_REPOS } from "@/data/rdmConsolidation";

export type IntegrationKPI = {
  readiness: number;
  avgMaturity: number;
  protocolCoverage: number;
  totalModules: number;
};

export type ProtocolContract = {
  protocol: string;
  publisher: string;
  consumers: string[];
  schemaVersion: string;
  qos: "realtime" | "near-realtime" | "batch";
};

export const PROTOCOL_CONTRACTS: ProtocolContract[] = [
  {
    protocol: "IdentitySync/v1",
    publisher: "@rdm/identity",
    consumers: ["@rdm/core-domain", "@rdm/social-core"],
    schemaVersion: "1.0.0",
    qos: "realtime",
  },
  {
    protocol: "GeoTwinSignal/v1",
    publisher: "@rdm/geo-twin",
    consumers: ["@rdm/rdm-web", "@rdm/smart-city"],
    schemaVersion: "1.1.0",
    qos: "near-realtime",
  },
  {
    protocol: "GovernanceVote/v1",
    publisher: "@rdm/core-domain",
    consumers: ["@rdm/rdm-admin", "@rdm/social-core"],
    schemaVersion: "1.0.0",
    qos: "batch",
  },
  {
    protocol: "TelemetryFrame/v1",
    publisher: "@rdm/smart-city",
    consumers: ["@rdm/rdm-admin", "@rdm/ai-orchestration"],
    schemaVersion: "1.2.0",
    qos: "realtime",
  },
];

export function calculateIntegrationKPI(): IntegrationKPI {
  const avgMaturity = SOURCE_REPOS.length > 0
    ? Math.round(SOURCE_REPOS.reduce((acc, repo) => acc + repo.maturity, 0) / SOURCE_REPOS.length)
    : 0;

  const readiness = INTEGRATION_PHASES.length > 0
    ? Math.round(
      INTEGRATION_PHASES.reduce((acc, phase) => acc + phase.completion, 0) / INTEGRATION_PHASES.length,
    )
    : 0;

  const allRepoProtocols = new Set(SOURCE_REPOS.flatMap((repo) => repo.protocols));
  const standardizedProtocols = PROTOCOLS.filter(({ name }) => allRepoProtocols.has(name));
  const protocolCoverage = allRepoProtocols.size > 0
    ? Math.round((standardizedProtocols.length / allRepoProtocols.size) * 100)
    : 0;

  const totalModules = SOURCE_REPOS.reduce((acc, repo) => acc + repo.modules.length, 0);

  return {
    readiness,
    avgMaturity,
    protocolCoverage,
    totalModules,
  };
}

export function buildTargetPackageLoad() {
  return SOURCE_REPOS.reduce<Record<string, number>>((acc, repo) => {
    acc[repo.targetPackage] = (acc[repo.targetPackage] ?? 0) + repo.modules.length;
    return acc;
  }, {});
}
