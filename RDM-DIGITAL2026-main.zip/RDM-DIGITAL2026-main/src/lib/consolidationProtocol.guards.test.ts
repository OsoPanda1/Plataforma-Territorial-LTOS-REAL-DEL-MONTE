import { describe, expect, it, vi } from "vitest";

describe("calculateIntegrationKPI guardrails", () => {
  it("retorna ceros cuando no hay datos de entrada", async () => {
    vi.resetModules();
    vi.doMock("@/data/rdmConsolidation", () => ({
      SOURCE_REPOS: [],
      INTEGRATION_PHASES: [],
      PROTOCOLS: [],
    }));

    const { calculateIntegrationKPI } = await import("@/lib/consolidationProtocol");
    expect(calculateIntegrationKPI()).toEqual({
      readiness: 0,
      avgMaturity: 0,
      protocolCoverage: 0,
      totalModules: 0,
    });

    vi.doUnmock("@/data/rdmConsolidation");
  });
});
