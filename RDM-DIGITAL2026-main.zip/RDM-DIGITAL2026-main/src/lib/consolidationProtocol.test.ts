import { describe, expect, it } from "vitest";
import { buildTargetPackageLoad, calculateIntegrationKPI, PROTOCOL_CONTRACTS } from "@/lib/consolidationProtocol";

describe("consolidationProtocol", () => {
  it("calcula KPIs dentro de rangos válidos", () => {
    const kpi = calculateIntegrationKPI();

    expect(kpi.readiness).toBeGreaterThan(0);
    expect(kpi.readiness).toBeLessThanOrEqual(100);
    expect(kpi.avgMaturity).toBeGreaterThan(0);
    expect(kpi.avgMaturity).toBeLessThanOrEqual(100);
    expect(kpi.protocolCoverage).toBeGreaterThan(0);
    expect(kpi.totalModules).toBeGreaterThan(10);
  });

  it("construye carga por paquete destino", () => {
    const load = buildTargetPackageLoad();

    expect(load["@rdm/core-domain"]).toBeGreaterThan(0);
    expect(load["@rdm/geo-twin"]).toBeGreaterThan(0);
    expect(Object.keys(load).length).toBeGreaterThan(4);
  });

  it("define contratos con schema y qos", () => {
    for (const contract of PROTOCOL_CONTRACTS) {
      expect(contract.schemaVersion).toMatch(/^\d+\.\d+\.\d+$/);
      expect(["realtime", "near-realtime", "batch"]).toContain(contract.qos);
      expect(contract.consumers.length).toBeGreaterThan(0);
    }
  });
});
