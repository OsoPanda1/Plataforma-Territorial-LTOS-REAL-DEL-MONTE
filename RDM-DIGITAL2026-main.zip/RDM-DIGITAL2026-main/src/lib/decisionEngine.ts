export interface DecisionRecommendation {
  recommendation: string;
  confidence: number;
  category: "operational" | "strategic" | "risk";
}

export interface DecisionEngineOptions {
  maxResponses?: number;
}

/**
 * DecisionEngine stores AI responses and converts them into
 * normalized user-facing recommendations with bounded memory.
 */
export class DecisionEngine {
  private aiResponses: string[] = [];
  private readonly maxResponses: number;

  constructor(options: DecisionEngineOptions = {}) {
    this.maxResponses = Math.max(10, Math.min(500, options.maxResponses ?? 120));
  }

  addResponse(response: string): void {
    const normalized = this.sanitize(response);
    if (!normalized) return;

    this.aiResponses.push(normalized);
    if (this.aiResponses.length > this.maxResponses) {
      this.aiResponses.splice(0, this.aiResponses.length - this.maxResponses);
    }
  }

  getRecommendations(): DecisionRecommendation[] {
    return this.aiResponses.map((response) => {
      const lower = response.toLowerCase();
      const category: DecisionRecommendation["category"] =
        /(risk|riesgo|alert|warning|fallback)/.test(lower)
          ? "risk"
          : /(strategy|estrateg|roadmap|arquitectura|governanza)/.test(lower)
            ? "strategic"
            : "operational";

      const confidence = this.scoreConfidence(response, category);

      return {
        recommendation: `Basado en el contexto: ${response}`,
        confidence,
        category,
      };
    });
  }

  clear(): void {
    this.aiResponses = [];
  }

  private sanitize(input: string): string {
    return input
      .replace(/[<>`{}$\\]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 400);
  }

  private scoreConfidence(response: string, category: DecisionRecommendation["category"]): number {
    let score = 0.55;
    if (response.length > 90) score += 0.1;
    if (/\d/.test(response)) score += 0.08;
    if (/(because|porque|due to|therefore|por lo tanto)/i.test(response)) score += 0.1;
    if (category === "risk") score -= 0.05;
    return Math.max(0.15, Math.min(0.98, Number(score.toFixed(2))));
  }
}
