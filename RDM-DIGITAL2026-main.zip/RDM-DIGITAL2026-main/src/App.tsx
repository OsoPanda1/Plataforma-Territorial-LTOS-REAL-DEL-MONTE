import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { RDMLayout } from "@/components/rdm/RDMLayout";
import { GuiaDigital } from "@/components/rdm/GuiaDigital";
import { WikiLayout } from "@/components/WikiLayout";
import { IsabellaChat } from "@/components/IsabellaChat";
import CinematicIntro from "@/components/CinematicIntro";
import { useCinematicIntro } from "@/hooks/useCinematicIntro";

const RDMHome = lazy(() => import("./pages/rdm/RDMHome"));
const RDMCultura = lazy(() => import("./pages/rdm/RDMCultura"));
const RDMGastronomia = lazy(() => import("./pages/rdm/RDMGastronomia"));
const RDMDichosMineros = lazy(() => import("./pages/rdm/RDMDichosMineros"));
const RDMComercios = lazy(() => import("./pages/rdm/RDMComercios"));
const RDMComercioDetalle = lazy(() => import("./pages/rdm/RDMComercioDetalle"));
const RDMRutas = lazy(() => import("./pages/rdm/RDMRutas"));
const RDMRutaDetalle = lazy(() => import("./pages/rdm/RDMRutaDetalle"));
const RDMQueVisitar = lazy(() => import("./pages/rdm/RDMQueVisitar"));
const RDMMuro = lazy(() => import("./pages/rdm/RDMMuro"));
const RDMMapa = lazy(() => import("./pages/rdm/RDMMapa"));
const Index = lazy(() => import("./pages/Index"));
const Introduccion = lazy(() => import("./pages/Introduccion"));
const Filosofia = lazy(() => import("./pages/Filosofia"));
const Arquitectura = lazy(() => import("./pages/Arquitectura"));
const DomainPage = lazy(() => import("./pages/DomainPage"));
const IAAgentes = lazy(() => import("./pages/IAAgentes"));
const Timeline = lazy(() => import("./pages/Timeline"));
const Documentacion = lazy(() => import("./pages/Documentacion"));
const Gobernanza = lazy(() => import("./pages/Gobernanza"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const SistemasAvanzados = lazy(() => import("./pages/SistemasAvanzados"));
const Manuales = lazy(() => import("./pages/Manuales"));
const Despliegue = lazy(() => import("./pages/Despliegue"));
const BiografiaCEO = lazy(() => import("./pages/BiografiaCEO"));
const CasosDeUso = lazy(() => import("./pages/CasosDeUso"));
const KitAPIs = lazy(() => import("./pages/KitAPIs"));
const Estrategia = lazy(() => import("./pages/Estrategia"));
const WikiTAMV = lazy(() => import("./pages/WikiTAMV"));
const RedSocial = lazy(() => import("./pages/RedSocial"));
const SeguridadTenochtitlan = lazy(() => import("./pages/SeguridadTenochtitlan"));
const BlockchainMSR = lazy(() => import("./pages/BlockchainMSR"));
const XRTecnologia = lazy(() => import("./pages/XRTecnologia"));
const EconomiaFederada = lazy(() => import("./pages/EconomiaFederada"));
const QuantumComputing = lazy(() => import("./pages/QuantumComputing"));
const EnciclopediaUniversal = lazy(() => import("./pages/EnciclopediaUniversal"));
const IsabellaAI = lazy(() => import("./pages/IsabellaAI"));
const ImpactoCivilizatorio = lazy(() => import("./pages/ImpactoCivilizatorio"));
const RealDelMonteDigital = lazy(() => import("./pages/RealDelMonteDigital"));
const ConsolidacionRDM = lazy(() => import("./pages/ConsolidacionRDM"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

const App = () => {
  const { showIntro, completeIntro } = useCinematicIntro();

  return (
    <>
      <CinematicIntro show={showIntro} onComplete={completeIntro} />
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-muted-foreground">Cargando TAMV…</div>}>
              <Routes>
                {/* ─── RDM Digital (main experience) ─── */}
                <Route element={<RDMLayout><RDMHome /></RDMLayout>} path="/" />
                <Route element={<RDMLayout><RDMCultura /></RDMLayout>} path="/cultura" />
                <Route element={<RDMLayout><RDMCultura /></RDMLayout>} path="/cultura/:tab" />
                <Route element={<RDMLayout><RDMGastronomia /></RDMLayout>} path="/gastronomia" />
                <Route element={<RDMLayout><RDMDichosMineros /></RDMLayout>} path="/dichos-mineros" />
                <Route element={<RDMLayout><RDMComercios /></RDMLayout>} path="/comercios" />
                <Route element={<RDMLayout><RDMComercioDetalle /></RDMLayout>} path="/comercios/:id" />
                <Route element={<RDMLayout><RDMRutas /></RDMLayout>} path="/rutas" />
                <Route element={<RDMLayout><RDMRutaDetalle /></RDMLayout>} path="/rutas/:id" />
                <Route element={<RDMLayout><RDMQueVisitar /></RDMLayout>} path="/que-visitar" />
                <Route element={<RDMLayout><RDMMuro /></RDMLayout>} path="/muro" />
                <Route element={<RDMLayout><RDMMapa /></RDMLayout>} path="/mapa" />

                {/* ─── Wiki TAMV ─── */}
                <Route path="/wiki" element={<WikiLayout><Index /></WikiLayout>} />
                <Route path="/wiki/introduccion" element={<WikiLayout><Introduccion /></WikiLayout>} />
                <Route path="/wiki/filosofia" element={<WikiLayout><Filosofia /></WikiLayout>} />
                <Route path="/wiki/arquitectura" element={<WikiLayout><Arquitectura /></WikiLayout>} />
                <Route path="/wiki/dominios/:slug" element={<WikiLayout><DomainPage /></WikiLayout>} />
                <Route path="/wiki/ia-agentes" element={<WikiLayout><IAAgentes /></WikiLayout>} />
                <Route path="/wiki/timeline" element={<WikiLayout><Timeline /></WikiLayout>} />
                <Route path="/wiki/documentacion" element={<WikiLayout><Documentacion /></WikiLayout>} />
                <Route path="/wiki/gobernanza" element={<WikiLayout><Gobernanza /></WikiLayout>} />
                <Route path="/wiki/dashboard" element={<WikiLayout><Dashboard /></WikiLayout>} />
                <Route path="/wiki/sistemas-avanzados" element={<WikiLayout><SistemasAvanzados /></WikiLayout>} />
                <Route path="/wiki/manuales" element={<WikiLayout><Manuales /></WikiLayout>} />
                <Route path="/wiki/despliegue" element={<WikiLayout><Despliegue /></WikiLayout>} />
                <Route path="/wiki/biografia-ceo" element={<WikiLayout><BiografiaCEO /></WikiLayout>} />
                <Route path="/wiki/casos-de-uso" element={<WikiLayout><CasosDeUso /></WikiLayout>} />
                <Route path="/wiki/kit-apis" element={<WikiLayout><KitAPIs /></WikiLayout>} />
                <Route path="/wiki/estrategia" element={<WikiLayout><Estrategia /></WikiLayout>} />
                <Route path="/wiki/wikitamv" element={<WikiLayout><WikiTAMV /></WikiLayout>} />
                <Route path="/wiki/red-social" element={<WikiLayout><RedSocial /></WikiLayout>} />
                <Route path="/wiki/seguridad-tenochtitlan" element={<WikiLayout><SeguridadTenochtitlan /></WikiLayout>} />
                <Route path="/wiki/blockchain-msr" element={<WikiLayout><BlockchainMSR /></WikiLayout>} />
                <Route path="/wiki/xr-tecnologia" element={<WikiLayout><XRTecnologia /></WikiLayout>} />
                <Route path="/wiki/economia-federada" element={<WikiLayout><EconomiaFederada /></WikiLayout>} />
                <Route path="/wiki/quantum-computing" element={<WikiLayout><QuantumComputing /></WikiLayout>} />
                <Route path="/wiki/enciclopedia" element={<WikiLayout><EnciclopediaUniversal /></WikiLayout>} />
                <Route path="/wiki/isabella-ai" element={<WikiLayout><IsabellaAI /></WikiLayout>} />
                <Route path="/wiki/impacto-civilizatorio" element={<WikiLayout><ImpactoCivilizatorio /></WikiLayout>} />
                <Route path="/wiki/real-del-monte" element={<WikiLayout><RealDelMonteDigital /></WikiLayout>} />
                <Route path="/wiki/consolidacion-rdm" element={<WikiLayout><ConsolidacionRDM /></WikiLayout>} />

                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
            <GuiaDigital />
            <IsabellaChat />
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </>
  );
};

export default App;
