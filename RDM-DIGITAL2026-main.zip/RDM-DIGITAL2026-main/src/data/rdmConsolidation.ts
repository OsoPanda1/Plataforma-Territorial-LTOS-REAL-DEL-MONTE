export type SourceRepo = {
  name: string;
  role: string;
  stack: string[];
  maturity: number;
  modules: string[];
  protocols: string[];
  targetPackage: string;
};

export const SOURCE_REPOS: SourceRepo[] = [
  {
    name: "citemesh-roots",
    role: "Núcleo de orquestación TAMV",
    stack: ["React", "TypeScript", "Supabase"],
    maturity: 91,
    modules: ["wiki-core", "identity-shell", "domain-router"],
    protocols: ["IdentitySync/v1", "KnowledgeMesh/v1"],
    targetPackage: "@rdm/core-domain",
  },
  {
    name: "RDM-Digital-X",
    role: "Experiencia de territorio digital",
    stack: ["React", "Tailwind", "Recharts"],
    maturity: 88,
    modules: ["territory-ui", "events-engine", "tourism-map"],
    protocols: ["TerritoryEvent/v1", "GeoTwinSignal/v1"],
    targetPackage: "@rdm/rdm-web",
  },
  {
    name: "civilizational-core",
    role: "Modelo civilizatorio y gobernanza",
    stack: ["TypeScript", "Prisma", "PostgreSQL"],
    maturity: 93,
    modules: ["governance-kernel", "reputation-core", "eoct-ledger"],
    protocols: ["GovernanceVote/v1", "ReputationDelta/v1"],
    targetPackage: "@rdm/core-domain",
  },
  {
    name: "real-del-monte-elevated",
    role: "Capa inmersiva y narrativa",
    stack: ["React", "Framer Motion", "WebGL"],
    maturity: 79,
    modules: ["immersive-story", "cinematic-sequences"],
    protocols: ["NarrativeScene/v1"],
    targetPackage: "@rdm/geo-twin",
  },
  {
    name: "real-del-monte-explorer",
    role: "Exploración guiada del territorio",
    stack: ["React", "Maps", "TypeScript"],
    maturity: 84,
    modules: ["route-explorer", "poi-system"],
    protocols: ["RouteIntent/v1", "VisitorFlow/v1"],
    targetPackage: "@rdm/rdm-web",
  },
  {
    name: "real-del-monte-twin",
    role: "Gemelo digital de Real del Monte",
    stack: ["Three.js", "WebXR", "TypeScript"],
    maturity: 86,
    modules: ["geo-twin-engine", "sensor-fusion"],
    protocols: ["TwinState/v1", "GeoTwinSignal/v1"],
    targetPackage: "@rdm/geo-twin",
  },
  {
    name: "rdm-smart-city-os",
    role: "Kernel operativo urbano",
    stack: ["Node.js", "Prisma", "Supabase"],
    maturity: 82,
    modules: ["city-kernel", "urban-telemetry", "compliance-rules"],
    protocols: ["TelemetryFrame/v1", "CivicAlert/v1"],
    targetPackage: "@rdm/smart-city",
  },
  {
    name: "rdm-digital-2dbd42b0",
    role: "Instancia de despliegue funcional",
    stack: ["React", "Vite", "Tailwind"],
    maturity: 77,
    modules: ["deployment-profiles", "feature-flags"],
    protocols: ["DeploymentSnapshot/v1"],
    targetPackage: "@rdm/rdm-admin",
  },
  {
    name: "genesis-digytamv-nexus",
    role: "Nodo de génesis y evolución",
    stack: ["TypeScript", "Event Bus", "CRDT"],
    maturity: 74,
    modules: ["genesis-flow", "nexus-relations"],
    protocols: ["NexusPulse/v1", "KnowledgeMesh/v1"],
    targetPackage: "@rdm/ai-orchestration",
  },
  {
    name: "Anubisgram",
    role: "Capa social de alta interacción",
    stack: ["React", "Media Pipeline", "Realtime"],
    maturity: 80,
    modules: ["social-feed", "creator-economy", "trust-signals"],
    protocols: ["SocialActivity/v1", "ReputationDelta/v1"],
    targetPackage: "@rdm/social-core",
  },
];

export const INTEGRATION_PHASES = [
  {
    phase: "Fase 1",
    title: "Núcleo y contratos",
    repos: ["civilizational-core", "citemesh-roots"],
    completion: 62,
  },
  {
    phase: "Fase 2",
    title: "Territorio RDM",
    repos: ["RDM-Digital-X", "rdm-digital-2dbd42b0"],
    completion: 48,
  },
  {
    phase: "Fase 3",
    title: "Gemelos y exploración",
    repos: ["real-del-monte-elevated", "real-del-monte-explorer", "real-del-monte-twin"],
    completion: 40,
  },
  {
    phase: "Fase 4",
    title: "Smart City OS",
    repos: ["rdm-smart-city-os"],
    completion: 31,
  },
  {
    phase: "Fase 5",
    title: "Social + Génesis",
    repos: ["Anubisgram", "genesis-digytamv-nexus"],
    completion: 26,
  },
];

export const PROTOCOLS = [
  { name: "IdentitySync/v1", layer: "identity", criticality: "alta" },
  { name: "KnowledgeMesh/v1", layer: "knowledge", criticality: "alta" },
  { name: "GovernanceVote/v1", layer: "governanza", criticality: "alta" },
  { name: "TelemetryFrame/v1", layer: "observabilidad", criticality: "media" },
  { name: "GeoTwinSignal/v1", layer: "espacial", criticality: "alta" },
  { name: "SocialActivity/v1", layer: "social", criticality: "media" },
  { name: "DeploymentSnapshot/v1", layer: "devops", criticality: "media" },
];
