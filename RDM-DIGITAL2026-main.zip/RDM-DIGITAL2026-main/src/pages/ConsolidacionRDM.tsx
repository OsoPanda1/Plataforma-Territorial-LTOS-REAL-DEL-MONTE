import { WikiPage } from "@/components/WikiPage";
import { Section } from "@/components/WikiElements";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { INTEGRATION_PHASES, PROTOCOLS, SOURCE_REPOS } from "@/data/rdmConsolidation";
import { buildTargetPackageLoad, calculateIntegrationKPI, PROTOCOL_CONTRACTS } from "@/lib/consolidationProtocol";
import { Activity, Blocks, Network, ShieldCheck } from "lucide-react";
import type { ComponentType, SVGProps } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const COLORS = ["#22d3ee", "#818cf8", "#34d399", "#fbbf24", "#f472b6", "#fb7185"];

const kpi = calculateIntegrationKPI();
const packageLoad = buildTargetPackageLoad();
const packageChartData = Object.entries(packageLoad).map(([name, modules]) => ({ name, modules }));

const maturityData = SOURCE_REPOS.map((repo) => ({
  repo: repo.name,
  madurez: repo.maturity,
}));

const PRODUCTION_GATES = [
  { gate: "CI/CD immutable", status: "en progreso", score: 72 },
  { gate: "Observabilidad (SLO + alertas)", status: "en progreso", score: 68 },
  { gate: "Seguridad runtime y secretos", status: "parcial", score: 64 },
  { gate: "Pruebas E2E + contrato", status: "parcial", score: 58 },
  { gate: "Runbooks y rollback", status: "en progreso", score: 70 },
];

const ConsolidacionRDM = () => {
  return (
    <WikiPage
      title="Consolidación Técnica RDM"
      subtitle="Execution Hub · Integración de código, protocolos y visualizaciones para converger en un solo repositorio"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
        <MetricCard title="Readiness global" value={`${kpi.readiness}%`} icon={Activity} helper="Promedio de avance por fase" />
        <MetricCard title="Madurez promedio" value={`${kpi.avgMaturity}%`} icon={ShieldCheck} helper="Calidad de módulos por repositorio" />
        <MetricCard title="Cobertura de protocolos" value={`${kpi.protocolCoverage}%`} icon={Network} helper="Protocolos homologados" />
        <MetricCard title="Módulos trazados" value={`${kpi.totalModules}`} icon={Blocks} helper="Activos modelados para merge" />
      </div>

      <Section title="Pipeline de integración por fases" icon={Activity}>
        <div className="space-y-4">
          {INTEGRATION_PHASES.map((phase) => (
            <div key={phase.phase} className="rounded-xl border border-border/60 bg-card/60 p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-foreground">{phase.phase} · {phase.title}</h4>
                <Badge variant="secondary">{phase.completion}%</Badge>
              </div>
              <Progress value={phase.completion} className="mb-2" />
              <p className="text-xs text-muted-foreground">Repos involucrados: {phase.repos.join(", ")}</p>
            </div>
          ))}
        </div>
      </Section>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 my-8">
        <Section title="Madurez por repositorio" icon={ShieldCheck}>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={maturityData} margin={{ top: 12, right: 24, left: 0, bottom: 48 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="repo" angle={-25} textAnchor="end" interval={0} height={80} tick={{ fontSize: 11 }} />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="madurez" radius={[8, 8, 0, 0]} fill="hsl(var(--primary))" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Section>

        <Section title="Carga de módulos por paquete destino" icon={Blocks}>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={packageChartData} dataKey="modules" nameKey="name" innerRadius={55} outerRadius={105} paddingAngle={3}>
                  {packageChartData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {packageChartData.map((item, index) => (
              <Badge key={item.name} variant="outline" style={{ borderColor: COLORS[index % COLORS.length] }}>
                {item.name}: {item.modules}
              </Badge>
            ))}
          </div>
        </Section>
      </div>

      <Section title="Protocolos de interoperabilidad" icon={Network}>
        <div className="rounded-lg border border-border/60 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/40 border-b border-border/60">
              <tr>
                <th className="text-left px-4 py-2">Protocolo</th>
                <th className="text-left px-4 py-2">Capa</th>
                <th className="text-left px-4 py-2">Criticidad</th>
              </tr>
            </thead>
            <tbody>
              {PROTOCOLS.map((protocol) => (
                <tr key={protocol.name} className="border-b last:border-0 border-border/50">
                  <td className="px-4 py-2 font-medium text-foreground">{protocol.name}</td>
                  <td className="px-4 py-2 text-muted-foreground">{protocol.layer}</td>
                  <td className="px-4 py-2">
                    <Badge variant={protocol.criticality === "alta" ? "default" : "secondary"}>{protocol.criticality}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      <Section title="Contratos técnicos activos" icon={ShieldCheck}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {PROTOCOL_CONTRACTS.map((contract) => (
            <div key={contract.protocol} className="rounded-xl border border-border/60 bg-card/60 p-4">
              <div className="flex items-center justify-between mb-1">
                <h4 className="font-semibold text-foreground">{contract.protocol}</h4>
                <Badge variant="outline">{contract.qos}</Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-2">Schema {contract.schemaVersion}</p>
              <p className="text-sm"><span className="text-muted-foreground">Publisher:</span> {contract.publisher}</p>
              <p className="text-sm"><span className="text-muted-foreground">Consumers:</span> {contract.consumers.join(" · ")}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Production Gate 100%" icon={ShieldCheck}>
        <div className="rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card/70 to-secondary/10 p-5">
          <p className="text-sm text-muted-foreground mb-4">
            Esta vista ejecuta una pista de hardening para mover el ecosistema a despliegue de producción auditable.
          </p>
          <div className="space-y-3">
            {PRODUCTION_GATES.map((item) => (
              <div key={item.gate} className="rounded-lg border border-border/60 bg-background/40 p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-medium text-foreground">{item.gate}</p>
                  <Badge variant={item.score >= 70 ? "default" : "secondary"}>{item.status}</Badge>
                </div>
                <Progress value={item.score} />
              </div>
            ))}
          </div>
        </div>
      </Section>
    </WikiPage>
  );
};

type MetricCardProps = {
  title: string;
  value: string;
  helper: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
};

const MetricCard = ({ title, value, helper, icon: Icon }: MetricCardProps) => (
  <div className="rounded-xl border border-border/60 bg-card/70 p-4">
    <div className="flex items-center justify-between mb-3">
      <p className="text-sm text-muted-foreground">{title}</p>
      <Icon className="h-4 w-4 text-primary" />
    </div>
    <p className="text-2xl font-bold text-foreground">{value}</p>
    <p className="text-xs text-muted-foreground mt-1">{helper}</p>
  </div>
);

export default ConsolidacionRDM;
