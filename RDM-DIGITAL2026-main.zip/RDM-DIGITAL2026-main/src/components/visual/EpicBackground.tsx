import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

interface EpicBackgroundProps {
  className?: string;
  intensity?: "subtle" | "immersive";
}

export function EpicBackground({ className, intensity = "subtle" }: EpicBackgroundProps) {
  const reduceMotion = useReducedMotion();
  const immersive = intensity === "immersive";

  return (
    <div
      aria-hidden="true"
      className={cn(
        "pointer-events-none absolute inset-0 overflow-hidden",
        className,
      )}
    >
      <div className="absolute inset-0 bg-[radial-gradient(1200px_500px_at_10%_-10%,hsl(var(--secondary)/0.16),transparent_60%),radial-gradient(900px_420px_at_90%_0%,hsl(var(--primary)/0.14),transparent_55%),linear-gradient(180deg,hsl(var(--background)),hsl(220_28%_4%))]" />
      <div className="absolute inset-0 bg-[radial-gradient(600px_280px_at_20%_100%,hsl(var(--primary)/0.08),transparent_70%),radial-gradient(700px_260px_at_80%_100%,hsl(var(--secondary)/0.08),transparent_72%)]" />

      <motion.div
        className="absolute -top-24 -left-20 h-96 w-96 rounded-full bg-cyan-300/14 blur-3xl"
        animate={
          reduceMotion
            ? undefined
            : { x: [0, 30, -20, 0], y: [0, 15, -10, 0], scale: [1, 1.1, 0.96, 1] }
        }
        transition={{ duration: immersive ? 14 : 20, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className="absolute -right-16 top-24 h-[22rem] w-[22rem] rounded-full bg-primary/12 blur-3xl"
        animate={
          reduceMotion
            ? undefined
            : { x: [0, -25, 18, 0], y: [0, -14, 10, 0], scale: [1, 0.93, 1.08, 1] }
        }
        transition={{ duration: immersive ? 16 : 24, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className="absolute left-1/3 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-secondary/10 blur-3xl"
        animate={
          reduceMotion
            ? undefined
            : { scale: [0.92, 1.08, 0.95], opacity: [0.25, 0.5, 0.25], rotate: [0, 12, -6, 0] }
        }
        transition={{ duration: immersive ? 18 : 26, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="aurora-beam aurora-beam-primary" />
      <div className="aurora-beam aurora-beam-secondary" />
      <div className="absolute inset-0 opacity-[0.2] bg-[radial-gradient(circle_at_20%_20%,hsl(var(--foreground)/0.2)_1px,transparent_1px)] bg-[size:3px_3px] [mask-image:radial-gradient(circle_at_center,black,transparent_72%)]" />
      <div className="absolute inset-0 opacity-[0.16] [mask-image:radial-gradient(circle_at_center,black,transparent_78%)] bg-[linear-gradient(to_right,hsl(var(--border)/0.45)_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border)/0.35)_1px,transparent_1px)] bg-[size:46px_46px]" />
      <div className="absolute inset-0 bg-noise-soft mix-blend-soft-light opacity-[0.2]" />
    </div>
  );
}
