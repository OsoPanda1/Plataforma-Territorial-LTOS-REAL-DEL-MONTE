import {
  BookOpen, Landmark, Layers, Shield, Brain, Clock, FileText,
  Home, Network, GraduationCap, Globe, Coins, ChevronDown,
  Activity, Cpu, BookMarked, Rocket, Crown, Briefcase, Plug, Target, Library,
  Users, Link2, Monitor, Atom, Search, Heart, Award, MapPin, GitMerge,
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const mainNav = [
  { title: "Inicio", url: "/wiki", icon: Home },
  { title: "Introducción", url: "/wiki/introduccion", icon: BookOpen },
  { title: "Filosofía y Códice", url: "/wiki/filosofia", icon: Landmark },
  { title: "Arquitectura", url: "/wiki/arquitectura", icon: Layers },
  { title: "WikiTAMV", url: "/wiki/wikitamv", icon: Library },
];

const dominios = [
  { title: "ID‑NVIDA", url: "/wiki/dominios/id-nvida", icon: Shield },
  { title: "UTAMV", url: "/wiki/dominios/utamv", icon: GraduationCap },
  { title: "Metaverso MD‑X4", url: "/wiki/dominios/metaverso", icon: Globe },
  { title: "Economía TAMV", url: "/wiki/dominios/economia", icon: Coins },
  { title: "Seguridad", url: "/wiki/dominios/seguridad", icon: Shield },
];

const ecosistema = [
  { title: "Red Social Avanzada", url: "/wiki/red-social", icon: Users },
  { title: "Seguridad TENOCHTITLAN", url: "/wiki/seguridad-tenochtitlan", icon: Shield },
  { title: "Blockchain MSR", url: "/wiki/blockchain-msr", icon: Link2 },
  { title: "XR/VR/3D/4D", url: "/wiki/xr-tecnologia", icon: Monitor },
  { title: "Economía Federada", url: "/wiki/economia-federada", icon: Coins },
  { title: "Quantum Computing", url: "/wiki/quantum-computing", icon: Atom },
  { title: "Enciclopedia Universal", url: "/wiki/enciclopedia", icon: Search },
  { title: "Isabella AI", url: "/wiki/isabella-ai", icon: Heart },
  { title: "Impacto & Expansión", url: "/wiki/impacto-civilizatorio", icon: Award },
  { title: "Real del Monte Digital", url: "/wiki/real-del-monte", icon: MapPin },
  { title: "Consolidación RDM", url: "/wiki/consolidacion-rdm", icon: GitMerge },
];

const extras = [
  { title: "IA & Agentes", url: "/wiki/ia-agentes", icon: Brain },
  { title: "Sistemas Avanzados", url: "/wiki/sistemas-avanzados", icon: Cpu },
  { title: "Dashboard", url: "/wiki/dashboard", icon: Activity },
  { title: "Línea de Tiempo", url: "/wiki/timeline", icon: Clock },
  { title: "Documentación", url: "/wiki/documentacion", icon: FileText },
  { title: "Manuales", url: "/wiki/manuales", icon: BookMarked },
  { title: "Gobernanza", url: "/wiki/gobernanza", icon: Shield },
  { title: "Despliegue", url: "/wiki/despliegue", icon: Rocket },
  { title: "Biografía CEO", url: "/wiki/biografia-ceo", icon: Crown },
  { title: "Casos de Uso", url: "/wiki/casos-de-uso", icon: Briefcase },
  { title: "Kit APIs", url: "/wiki/kit-apis", icon: Plug },
  { title: "Estrategia", url: "/wiki/estrategia", icon: Target },
];

export function WikiSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();

  const renderItems = (items: typeof mainNav) => (
    <SidebarMenu>
      {items.map((item) => (
        <SidebarMenuItem key={item.url}>
          <SidebarMenuButton asChild>
            <NavLink
              to={item.url}
              end
              className="hover:bg-sidebar-accent/50 transition-colors"
              activeClassName="bg-sidebar-accent text-primary font-medium"
            >
              <item.icon className="mr-2 h-4 w-4 shrink-0" />
              {!collapsed && <span>{item.title}</span>}
            </NavLink>
          </SidebarMenuButton>
        </SidebarMenuItem>
      ))}
    </SidebarMenu>
  );

  return (
    <Sidebar collapsible="icon" className="border-r border-border/50">
      <SidebarContent className="pt-4">
        <SidebarGroup>
          <SidebarGroupLabel className="text-primary/70 uppercase text-xs tracking-widest">
            General
          </SidebarGroupLabel>
          <SidebarGroupContent>{renderItems(mainNav)}</SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <Collapsible defaultOpen>
            <CollapsibleTrigger className="w-full">
              <SidebarGroupLabel className="text-primary/70 uppercase text-xs tracking-widest flex items-center justify-between cursor-pointer">
                <span className="flex items-center gap-1">
                  <Network className="h-3 w-3" /> Dominios
                </span>
                {!collapsed && <ChevronDown className="h-3 w-3" />}
              </SidebarGroupLabel>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <SidebarGroupContent>{renderItems(dominios)}</SidebarGroupContent>
            </CollapsibleContent>
          </Collapsible>
        </SidebarGroup>

        <SidebarGroup>
          <Collapsible defaultOpen>
            <CollapsibleTrigger className="w-full">
              <SidebarGroupLabel className="text-primary/70 uppercase text-xs tracking-widest flex items-center justify-between cursor-pointer">
                <span className="flex items-center gap-1">
                  <Globe className="h-3 w-3" /> Ecosistema NextGen
                </span>
                {!collapsed && <ChevronDown className="h-3 w-3" />}
              </SidebarGroupLabel>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <SidebarGroupContent>{renderItems(ecosistema)}</SidebarGroupContent>
            </CollapsibleContent>
          </Collapsible>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-primary/70 uppercase text-xs tracking-widest">
            Más
          </SidebarGroupLabel>
          <SidebarGroupContent>{renderItems(extras)}</SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
