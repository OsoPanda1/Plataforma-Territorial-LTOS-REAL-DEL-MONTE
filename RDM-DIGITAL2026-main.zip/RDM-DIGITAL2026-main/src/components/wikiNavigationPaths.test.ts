import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

function extractUrls(source: string) {
  return [...source.matchAll(/url:\s*"([^"]+)"/g)].map((match) => match[1]);
}

describe("wiki navigation paths", () => {
  it("usa prefijo /wiki en el sidebar", () => {
    const source = readFileSync(path.resolve(process.cwd(), "src/components/WikiSidebar.tsx"), "utf8");
    const urls = extractUrls(source);

    expect(urls.length).toBeGreaterThan(30);
    expect(urls.every((url) => url.startsWith("/wiki"))).toBe(true);
  });

  it("usa prefijo /wiki en el índice de búsqueda", () => {
    const source = readFileSync(path.resolve(process.cwd(), "src/components/WikiSearch.tsx"), "utf8");
    const urls = extractUrls(source);

    expect(urls.length).toBeGreaterThan(25);
    expect(urls.every((url) => url.startsWith("/wiki"))).toBe(true);
  });
});
