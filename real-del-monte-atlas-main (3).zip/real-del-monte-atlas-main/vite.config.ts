// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import { type ViteDevServer, type PluginOption } from "vite";

// ============================================================================
// SEGURIDAD: Content Security Policy (CSP) Generador
// ============================================================================

const CSPdirectives = {
  "default-src": ["'self'"],
  "script-src": [
    "'self'",
    "'unsafe-eval'", // Necesario para SSR/TanStack
    "'strict-dynamic'",
    "https://cdn.jsdelivr.net",
    "https://unpkg.com",
  ],
  "style-src": ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
  "img-src": ["'self'", "data:", "blob:", "https:", "https://images.unsplash.com"],
  "font-src": ["'self'", "data:", "https://fonts.gstatic.com"],
  "connect-src": [
    "'self'",
    "https://api.github.com",
    "https://zenodo.org",
    "https://figshare.com",
    "https://www.openaire.eu",
    "https://datacite.org",
    "https://loops.academy",
    "https://www.frontiersin.org",
    "https://avixa.org",
    "https://xcange.io",
    "https://orcid.org",
    "wss://",
    "ws://",
  ],
  "frame-ancestors": ["'none'"], // Prevención de clickjacking
  "form-action": ["'self'"],
  "base-uri": ["'self'"],
  "object-src": ["'none'"], // Desactivar plugins obsoletos
  "upgrade-insecure-requests": [],
} as const;

function generateCSP(): string {
  return Object.entries(CSPdirectives)
    .map(([key, values]) => {
      if (values.length === 0) return key;
      return `${key} ${values.join(" ")}`;
    })
    .join("; ");
}

// ============================================================================
// PLUGIN: Security Headers Middleware
// ============================================================================

const securityHeadersPlugin = (): PluginOption => {
  return {
    name: "security-headers",
    configureServer(server: ViteDevServer) {
      server.middlewares.use((req, res, next) => {
        // HTTP Strict Transport Security (HSTS)
        res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");

        // Content Security Policy
        res.setHeader("Content-Security-Policy", generateCSP());

        // X-Content-Type-Options (Prevención MIME sniffing)
        res.setHeader("X-Content-Type-Options", "nosniff");

        // X-Frame-Options (Clickjacking protection)
        res.setHeader("X-Frame-Options", "DENY");

        // X-XSS-Protection (Legacy browser support)
        res.setHeader("X-XSS-Protection", "1; mode=block");

        // Referrer-Policy
        res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");

        // Permissions-Policy (Feature Policy)
        res.setHeader(
          "Permissions-Policy",
          [
            "accelerometer=()",
            "camera=()",
            "geolocation=()",
            "gyroscope=()",
            "magnetometer=()",
            "microphone=()",
            "payment=()",
            "usb=()",
            "fullscreen=(self)",
            "autoplay=()",
          ].join(", "),
        );

        // Cross-Origin policies
        res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
        res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
        res.setHeader("Cross-Origin-Resource-Policy", "same-origin");

        // Cache-Control para recursos sensibles
        if (req.url?.includes(".") && !req.url?.includes("assets/")) {
          res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
          res.setHeader("Pragma", "no-cache");
          res.setHeader("Expires", "0");
        }

        next();
      });
    },
  };
};

// ============================================================================
// PLUGIN:_ROBOTS.txt Dinámico
// ============================================================================

const robotsPlugin = (): PluginOption => {
  return {
    name: "robots-txt",
    writeBundle() {
      const isProduction = process.env.NODE_ENV === "production";
      const robots = isProduction
        ? `User-agent: *
Allow: /
Disallow: /api/
Disallow: /admin/
Disallow: /_internal/
Sitemap: https://atlas.tamv-online.network/sitemap.xml

# Academic crawlers
User-agent: Googlebot-Scholar
Allow: /

User-agent: SemanticScholar
Allow: /

User-agent: CORE
Allow: /

# Soberanía Digital - MD-X4
# DOI: 10.5281/zenodo.19436662
# ORCID: 0009-0008-5050-1539
# Version: TAMV-MD-X4-CORE
`
        : `User-agent: *
Disallow: /

# Development environment - no indexing
`;

      writeFileSync(join(process.cwd(), "dist", "robots.txt"), robots);
    },
  };
};

// ============================================================================
// PLUGIN: Identificadores Persistentes en Meta Tags
// ============================================================================

const persistentIdPlugin = (): PluginOption => {
  return {
    name: "persistent-identifiers",
    transformIndexHtml(html: string) {
      const metaIdentifiers = `
<!-- Persistent Academic Identifiers - MD-X4 Ecosystem -->
<meta name="doi" content="10.5281/zenodo.19436662" />
<meta name="citation_doi" content="10.5281/zenodo.19436662" />
<meta name="orcid" content="0009-0008-5050-1539" />
<meta name="citation_orcid" content="0009-0008-5050-1539" />
<meta name="version" content="TAMV-MD-X4-CORE" />
<meta name="author" content="Edwin Oswaldo Castillo Trejo" />
<meta name="citation_author" content="Edwin Oswaldo Castillo Trejo" />
<meta name="citation_author_orcid" content="0009-0008-5050-1539" />
<meta name="citation_publication_date" content="2026/01/01" />
<meta name="citation_online_date" content="2026/01/01" />
<meta name="citation_pdf_url" content="https://zenodo.org/doi/10.5281/zenodo.19436662" />
<meta name="citation_journal_title" content="TAMV Online Network | RDM Digital" />
<meta name="citation_title" content="Atlas Territorial MD-X4: Arquitectura Federada de Real del Monte" />
<meta name="citation_language" content="es" />
<meta name="citation_abstract" content="Arquitectura federada de Real del Monte. 7 capas, minas, nodos y soberanía digital para América Latina." />
<meta name="citation_keywords" content="soberanía digital, metaverso 4D, gemelos digitales, smart destinations, Real del Monte, Hidalgo, México, IA cuántica-emocional" />
<meta name="citation_publisher" content="TAMV Online Network | RDM Digital" />
<meta name="citation_license" content="https://creativecommons.org/licenses/by/4.0/" />

<!-- Zenodo Integration -->
<link rel="alternate" type="application/json" href="https://zenodo.org/api/records/19436662" title="Zenodo API" />
<link rel="cite" href="https://zenodo.org/doi/10.5281/zenodo.19436662" title="Citar este trabajo" />

<!-- OpenAIRE Compliance -->
<meta name="openaire" content="true" />
<meta name="openaire_type" content="dataset" />

<!-- DataCite Metadata -->
<meta name="datacite_doi" content="10.5281/zenodo.19436662" />
<meta name="datacite_version" content="TAMV-MD-X4-CORE" />

<!-- Academic Networks -->
<meta name="loops_academy" content="true" />
<meta name="frontiers_in Research" content="true" />

<!-- Technical Sovereignty -->
<meta name="sovereignty_model" content="7_Federations" />
<meta name="ai_kernel" content="Isabella_AI_Quantum_Emotional" />
<meta name="control_interface" content="DM-X4_Quantum_Control" />
`;

      return html.replace("</head>", `${metaIdentifiers}</head>`);
    },
  };
};

// ============================================================================
// PLUGIN: Performance Optimization - Preload Critical Assets
// ============================================================================

const preloadPlugin = (): PluginOption => {
  return {
    name: "preload-critical",
    transformIndexHtml(html: string) {
      const preloads = `
<!-- Critical Preloads - MD-X4 Performance -->
<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="dns-prefetch" href="https://zenodo.org" />
<link rel="dns-prefetch" href="https://figshare.com" />
<link rel="dns-prefetch" href="https://cdn.jsdelivr.net" />
<link rel="modulepreload" href="/src/main.tsx" />
<link rel="modulepreload" href="/src/routes/atlas.tsx" />
`;

      return html.replace("</head>", `${preloads}</head>`);
    },
  };
};

// ============================================================================
// PLUGIN: Build Manifest para Soberanía
// ============================================================================

const sovereigntyManifestPlugin = (): PluginOption => {
  return {
    name: "sovereignty-manifest",
    writeBundle(options, bundle) {
      const manifest = {
        name: "MD-X4 Ecosystem - Atlas Territorial",
        version: "TAMV-MD-X4-CORE",
        doi: "10.5281/zenodo.19436662",
        orcid: "0009-0008-5050-1539",
        author: {
          name: "Edwin Oswaldo Castillo Trejo",
          alternateName: "Anubis Villaseñor",
          orcid: "0009-0008-5050-1539",
          organization: "TAMV Online Network | RDM Digital",
          location: {
            city: "Real del Monte",
            state: "Hidalgo",
            country: "MX",
          },
        },
        sovereignty: {
          model: "7_Federations",
          aiKernel: "Isabella_AI_Quantum_Emotional",
          controlInterface: "DM-X4_Quantum_Control",
          built: new Date().toISOString(),
        },
        repositories: {
          zenodo: "https://zenodo.org/doi/10.5281/zenodo.19436662",
          figshare: "https://figshare.com",
          openaire: "https://www.openaire.eu",
          datacite: "https://datacite.org",
          loops: "https://loops.academy",
          frontiers: "https://www.frontiersin.org",
          avixa: "https://avixa.org",
          xcange: "https://xcange.io",
        },
        licenses: {
          code: "MIT",
          content: "CC-BY-4.0",
          data: "ODC-By-1.0",
        },
        performance: {
          chunks: Object.keys(bundle).length,
          totalSize: Object.values(bundle).reduce(
            (acc, chunk) => acc + (chunk.type === "chunk" ? chunk.code.length : 0),
            0,
          ),
        },
      };

      writeFileSync(
        join(options.dir || "dist", "sovereignty-manifest.json"),
        JSON.stringify(manifest, null, 2),
      );
    },
  };
};

// ============================================================================
// CONFIGURACIÓN PRINCIPAL
// ============================================================================

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },

  // Vite configuración adicional
  vite: {
    // Optimización de dependencias
    optimizeDeps: {
      include: ["react", "react-dom", "@tanstack/react-router", "zod"],
      exclude: ["@lovable.dev/vite-tanstack-config"],
      esbuildOptions: {
        target: "es2022",
      },
    },

    // Build configuración de alta performance
    build: {
      target: "es2022",
      polyfillModulePreload: false,
      modulePreload: {
        polyfill: false,
      },
      cssCodeSplit: true,
      rollupOptions: {
        output: {
          entryFileNames: "assets/[name]-[hash].js",
          chunkFileNames: "assets/[name]-[hash].js",
          assetFileNames: "assets/[name]-[hash].[ext]",
        },
      },
      minify: "esbuild",
      sourcemap: process.env.NODE_ENV === "production",
      cssMinify: true,
      reportCompressedSize: true,
      chunkSizeWarningLimit: 1000,
    },

    // SSR configuración
    ssr: {
      external: ["nitropack"],
      noExternal: ["@tanstack/react-router"],
      optimizeDeps: {
        include: ["react", "react-dom/server"],
      },
    },

    // сервер configuración de seguridad
    server: {
      headers: {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Referrer-Policy": "strict-origin-when-cross-origin",
      },
      cors: {
        origin: [/^https:\/\/.*\.tamv-online\.network$/],
        methods: ["GET", "HEAD", "OPTIONS"],
        credentials: false,
        exposedHeaders: ["X-DOI", "X-ORCID"],
        maxAge: 86400,
      },
    },

    // Preview configuración
    preview: {
      headers: {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
      },
    },

    // Plugins adicionales
    plugins: [
      securityHeadersPlugin(),
      persistentIdPlugin(),
      preloadPlugin(),
      robotsPlugin(),
      sovereigntyManifestPlugin(),
    ],

    // Variables de entorno seguras
    envDir: process.cwd(),
    envPrefix: ["VITE_", "TAMV_"],

    // Especificaciones
    esbuild: {
      target: "es2022",
      sourcemap: true,
      minifyIdentifiers: process.env.NODE_ENV === "production",
      minifySyntax: true,
      minifyWhitespace: true,
      legalComments: "none",
    },
  },

  // Nitro configuración para Cloudflare
  nitro: {
    preset: "cloudflare-pages",
    output: {
      publicDir: "dist",
    },
  },
});
