import type { ButtonHTMLAttributes, CSSProperties, HTMLAttributes, ReactNode } from "react";
import { forwardRef } from "react";

type MotionStyle = CSSProperties & Record<string, string | number | undefined>;

type MotionExtras = {
  initial?: MotionStyle | false;
  animate?: MotionStyle;
  exit?: MotionStyle;
  whileHover?: MotionStyle;
  whileTap?: MotionStyle;
  transition?: Record<string, unknown>;
};

type MotionDivProps = HTMLAttributes<HTMLDivElement> & MotionExtras;
type MotionButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & MotionExtras;

type AnimatePresenceProps = {
  children?: ReactNode;
  mode?: "sync" | "wait" | "popLayout";
};

const toCssValue = (value: string | number | undefined) => {
  if (value === undefined) return undefined;
  if (typeof value === "number") return value;
  return value;
};

const mergeMotionStyle = (
  base: CSSProperties | undefined,
  initial: MotionStyle | false | undefined,
  animate: MotionStyle | undefined,
): CSSProperties => {
  const resolved: CSSProperties = { ...base };
  const source = animate ?? (initial || undefined);

  if (!source) return resolved;

  if (source.opacity !== undefined) resolved.opacity = Number(source.opacity);
  if (source.scale !== undefined || source.x !== undefined || source.y !== undefined) {
    const transforms = [
      source.x !== undefined ? `translateX(${toCssValue(source.x)}px)` : undefined,
      source.y !== undefined ? `translateY(${toCssValue(source.y)}px)` : undefined,
      source.scale !== undefined ? `scale(${source.scale})` : undefined,
    ].filter(Boolean);
    resolved.transform = [resolved.transform, ...transforms].filter(Boolean).join(" ");
  }

  return resolved;
};

const MotionDiv = forwardRef<HTMLDivElement, MotionDivProps>(function MotionDiv(
  {
    initial,
    animate,
    exit: _exit,
    whileHover: _whileHover,
    whileTap: _whileTap,
    transition: _transition,
    style,
    ...props
  },
  ref,
) {
  return <div ref={ref} style={mergeMotionStyle(style, initial, animate)} {...props} />;
});

const MotionButton = forwardRef<HTMLButtonElement, MotionButtonProps>(function MotionButton(
  {
    initial,
    animate,
    exit: _exit,
    whileHover: _whileHover,
    whileTap: _whileTap,
    transition: _transition,
    style,
    ...props
  },
  ref,
) {
  return <button ref={ref} style={mergeMotionStyle(style, initial, animate)} {...props} />;
});

export const motion = {
  div: MotionDiv,
  button: MotionButton,
};

export function AnimatePresence({ children }: AnimatePresenceProps) {
  return <>{children}</>;
}
