// src/lib/security.ts

/**
 * MD-X4 Security & Sovereignty Kernel
 *
 * Esta unidad define:
 * - Modelo de soberanía (DOI, ORCID, VERSION)
 * - Política CSP avanzada (base + perfiles por entorno + reporting)
 * - Orígenes permitidos y sanitización de URLs
 * - Validación de identificadores persistentes
 * - Pequeña capa de telemetría/observabilidad de eventos de seguridad
 *
 * Pensado como contrato común front/back: NO importa si se ejecuta en
 * Vite dev server, Nitro, Cloudflare o React en el cliente.
 */

//
// Tipos base
//

export type AllowedOrigin =
  | "https://atlas.tamv-online.network"
  | "https://zenodo.org"
  | "https://figshare.com"
  | "https://www.openaire.eu"
  | "https://datacite.org"
  | "https://loops.academy"
  | "https://www.frontiersin.org"
  | "https://avixa.org"
  | "https://xcange.io"
  | "https://orcid.org";

export type CspDirectiveKey =
  | "default-src"
  | "script-src"
  | "style-src"
  | "img-src"
  | "font-src"
  | "connect-src"
  | "frame-ancestors"
  | "form-action"
  | "base-uri"
  | "object-src"
  | "report-uri"
  | "report-to";

export type CspDirectives = Partial<Record<CspDirectiveKey, string[]>>;

export interface PermanentIdentifiers {
  DOI: string;
  ORCID: string;
  VERSION: string;
}

export type SecurityEnvironment = "development" | "staging" | "production";

export type SecurityEventType =
  | "url_blocked"
  | "csp_generated"
  | "identifier_invalid"
  | "identifier_valid"
  | "origin_check";

export interface SecurityEvent {
  ts: string;
  type: SecurityEventType;
  message: string;
  meta?: Record<string, unknown>;
}

//
// Configuración inmutable de soberanía
//

export const PERMANENT_IDENTIFIERS: Readonly<PermanentIdentifiers> = {
  DOI: "10.5281/zenodo.19436662",
  ORCID: "0009-0008-5050-1539",
  VERSION: "TAMV-MD-X4-CORE",
} as const;

export const ALLOWED_ORIGINS: Readonly<AllowedOrigin[]> = [
  "https://atlas.tamv-online.network",
  "https://zenodo.org",
  "https://figshare.com",
  "https://www.openaire.eu",
  "https://datacite.org",
  "https://loops.academy",
  "https://www.frontiersin.org",
  "https://avixa.org",
  "https://xcange.io",
  "https://orcid.org",
] as const;

//
// Perfiles CSP según entorno
//

const CSP_BASE: Readonly<CspDirectives> = {
  "default-src": ["'self'"],
  "script-src": ["'self'", "'unsafe-eval'", "'strict-dynamic'", "https://cdn.jsdelivr.net"],
  "style-src": ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
  "img-src": ["'self'", "data:", "blob:", "https:"],
  "font-src": ["'self'", "data:", "https://fonts.gstatic.com"],
  "connect-src": [
    "'self'",
    "https://zenodo.org",
    "https://figshare.com",
    "https://www.openaire.eu",
    "https://datacite.org",
    "https://loops.academy",
    "https://www.frontiersin.org",
    "https://avixa.org",
    "https://xcange.io",
    "https://orcid.org",
    "wss:",
    "ws:",
  ],
  "frame-ancestors": ["'none'"],
  "form-action": ["'self'"],
  "base-uri": ["'self'"],
  "object-src": ["'none'"],
};

const CSP_ENV_OVERLAY: Record<SecurityEnvironment, CspDirectives> = {
  development: {
    // En dev puedes ser un poco más laxo si lo necesitas
  },
  staging: {
    // Staging imita producción, pero puedes habilitar más logging si quisieras
  },
  production: {
    // La lógica de report-uri / report-to se añade dinámicamente
  },
};

//
// Telemetría mínima de eventos (se puede enchufar a un logger real)
//

type SecurityEventSink = (event: SecurityEvent) => void;

let securitySink: SecurityEventSink | null = (event) => {
  // Default: log a consola solo en no-prod
  if (typeof process !== "undefined" && process.env.NODE_ENV === "production") {
    return;
  }

  console.warn("[MDX4-SECURITY]", event);
};

/**
 * Permite acoplar un sink externo (Sentry, Supabase logs, etc.)
 */
export function registerSecurityEventSink(sink: SecurityEventSink | null) {
  securitySink = sink;
}

function emitSecurityEvent(event: Omit<SecurityEvent, "ts">) {
  if (!securitySink) return;
  const payload: SecurityEvent = {
    ts: new Date().toISOString(),
    ...event,
  };
  securitySink(payload);
}

//
// Funciones utilitarias principales
//

/**
 * Genera la cadena CSP a partir de la base, overlay de entorno y directivas extra.
 */
export function generateCSP(env: SecurityEnvironment, extra: CspDirectives = {}): string {
  const merged: CspDirectives = {
    ...CSP_BASE,
    ...CSP_ENV_OVERLAY[env],
    ...extra,
  };

  const csp = Object.entries(merged)
    .filter(([, values]) => Array.isArray(values))
    .map(([k, values]) => {
      const v = values as string[];
      return v.length ? `${k} ${v.join(" ")}` : k;
    })
    .join("; ");

  emitSecurityEvent({
    type: "csp_generated",
    message: `CSP generada para entorno=${env}`,
    meta: { env, cspLength: csp.length },
  });

  return csp;
}

/**
 * Construye una CSP de producción incluyendo report-uri/report-to.
 */
export function buildProdCspWithReporting(reportEndpoint: string): string {
  const safe = sanitizeUrl(reportEndpoint);
  const extra: CspDirectives = {};

  if (safe !== "#") {
    extra["report-uri"] = [safe];
    extra["report-to"] = ["csp-endpoint"];
  }

  return generateCSP("production", extra);
}

/**
 * Sanitiza una URL para que solo pueda ir a orígenes permitidos.
 */
export function sanitizeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    if (!ALLOWED_ORIGINS.includes(parsed.origin as AllowedOrigin)) {
      emitSecurityEvent({
        type: "url_blocked",
        message: "URL bloqueada por origen no permitido",
        meta: { url, origin: parsed.origin },
      });
      return "#";
    }
    return url;
  } catch {
    emitSecurityEvent({
      type: "url_blocked",
      message: "URL inválida bloqueada",
      meta: { url },
    });
    return "#";
  }
}

/**
 * Abre una URL externa de forma segura (solo en cliente).
 */
export function openSafeExternal(url: string): void {
  if (typeof window === "undefined") return;
  const safe = sanitizeUrl(url);
  if (safe === "#") return;
  window.open(safe, "_blank", "noopener,noreferrer");
}

/**
 * Comprueba si un origin está permitido.
 */
export function isAllowedOrigin(origin: string | null | undefined): boolean {
  if (!origin) return false;
  try {
    const parsed = new URL(origin);
    const allowed = ALLOWED_ORIGINS.includes(parsed.origin as AllowedOrigin);
    emitSecurityEvent({
      type: "origin_check",
      message: `Comprobación de origen (URL-completa): ${allowed ? "permitido" : "rechazado"}`,
      meta: { origin: parsed.origin },
    });
    return allowed;
  } catch {
    const allowed = ALLOWED_ORIGINS.includes(origin as AllowedOrigin);
    emitSecurityEvent({
      type: "origin_check",
      message: `Comprobación de origen (origin-directo): ${allowed ? "permitido" : "rechazado"}`,
      meta: { origin },
    });
    return allowed;
  }
}

/**
 * Valida sintácticamente un DOI.
 */
export function isValidDOI(doi: string): boolean {
  const ok = /^10\.\d{4,}\/.+$/.test(doi);
  emitSecurityEvent({
    type: ok ? "identifier_valid" : "identifier_invalid",
    message: ok ? "DOI válido" : "DOI inválido",
    meta: { doi },
  });
  return ok;
}

/**
 * Valida sintácticamente un ORCID.
 */
export function isValidORCID(orcid: string): boolean {
  const ok = /^0\d{3}-\d{4}-\d{4}-\d{4}$/.test(orcid);
  emitSecurityEvent({
    type: ok ? "identifier_valid" : "identifier_invalid",
    message: ok ? "ORCID válido" : "ORCID inválido",
    meta: { orcid },
  });
  return ok;
}
