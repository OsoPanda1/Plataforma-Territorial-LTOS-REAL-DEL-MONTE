import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="relative mt-40 overflow-hidden border-t border-border/40 bg-card/20 backdrop-blur-xl">
      {/* Background Atmosphere */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-signal/5 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 py-20">
        {/* Top Section */}
        <div className="grid gap-16 lg:grid-cols-[1.5fr_1fr_1fr_1fr]">
          {/* Identity */}
          <div>
            <div className="eyebrow text-signal">TAMV ONLINE</div>

            <h2 className="display-territory mt-3">Nodo Cero</h2>

            <p className="mt-6 max-w-md text-sm leading-relaxed text-muted-foreground">
              Primer territorio integrado al Living Territorial Operating System. Una
              infraestructura territorial que conecta patrimonio, comunidad, conocimiento, economía
              e inteligencia contextual en una experiencia viva y evolutiva.
            </p>

            <div className="mt-8 flex flex-wrap gap-2">
              <span className="rounded-full border border-border/50 px-3 py-1 text-xs text-muted-foreground">
                Patrimonio
              </span>

              <span className="rounded-full border border-border/50 px-3 py-1 text-xs text-muted-foreground">
                Comunidad
              </span>

              <span className="rounded-full border border-border/50 px-3 py-1 text-xs text-muted-foreground">
                Conocimiento
              </span>

              <span className="rounded-full border border-border/50 px-3 py-1 text-xs text-muted-foreground">
                Inteligencia
              </span>
            </div>
          </div>

          {/* Explore */}
          <div>
            <div className="eyebrow">Explorar</div>

            <ul className="mt-5 space-y-3 text-sm">
              <li>
                <Link
                  to="/atlas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Atlas Territorial
                </Link>
              </li>

              <li>
                <Link
                  to="/rutas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Rutas
                </Link>
              </li>

              <li>
                <Link
                  to="/minas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Patrimonio Minero
                </Link>
              </li>

              <li>
                <Link
                  to="/cementerio"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Cementerio Inglés
                </Link>
              </li>

              <li>
                <Link
                  to="/pastes"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Gastronomía
                </Link>
              </li>
            </ul>
          </div>

          {/* Knowledge */}
          <div>
            <div className="eyebrow">Comprender</div>

            <ul className="mt-5 space-y-3 text-sm">
              <li>
                <Link
                  to="/leyendas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Leyendas
                </Link>
              </li>

              <li>
                <Link
                  to="/calles"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Historia Urbana
                </Link>
              </li>

              <li>
                <Link
                  to="/eventos"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Eventos
                </Link>
              </li>

              <li>
                <Link
                  to="/atlas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Atlas de evidencias
                </Link>
              </li>
            </ul>
          </div>

          {/* System */}
          <div>
            <div className="eyebrow">Sistema</div>

            <ul className="mt-5 space-y-3 text-sm">
              <li>
                <Link
                  to="/manifiesto"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Manifiesto LTOS
                </Link>
              </li>

              <li>
                <Link
                  to="/manifiesto"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Manifiesto operativo
                </Link>
              </li>

              <li>
                <Link
                  to="/atlas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Atlas público
                </Link>
              </li>

              <li>
                <Link
                  to="/rutas"
                  className="transition-colors text-foreground/70 hover:text-foreground"
                >
                  Rutas territoriales
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Middle Divider */}

        <div className="mt-20 border-t border-border/40 pt-10">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="font-display text-2xl">Real del Monte</div>

              <p className="mt-2 text-sm text-muted-foreground">Hidalgo · México</p>
            </div>

            <div className="text-center">
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
                Living Territorial Operating System
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Section */}

        <div className="mt-10 border-t border-border/40 pt-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} TAMV Online · Nodo Cero · RDM Digital
            </div>

            <div className="text-xs font-mono text-muted-foreground">
              LTOS v1.0 • Territorio Vivo
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="font-display text-2xl italic text-foreground/90">
              Orgullosamente Realmontenses
            </p>

            <p className="mt-3 text-xs uppercase tracking-[0.35em] text-muted-foreground">
              Patrimonio · Comunidad · Conocimiento · Inteligencia
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
