import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, Compass, Building2, Cpu, ArrowUpRight } from "lucide-react";

type NavItem = { to: string; label: string; hint?: string };
type Plano = {
  key: "experiencia" | "plataforma" | "sistema";
  label: string;
  tag: string;
  caption: string;
  icon: typeof Compass;
  columns: { title: string; items: NavItem[] }[];
};

const planos: Plano[] = [
  {
    key: "experiencia",
    label: "Experiencia",
    tag: "Plano 01",
    caption: "Real del Monte como territorio vivo. Lo que se camina, se prueba y se recuerda.",
    icon: Compass,
    columns: [
      {
        title: "Territorio",
        items: [
          { to: "/atlas", label: "Atlas", hint: "Mapa integral del Nodo Cero" },
          { to: "/minas", label: "Minas", hint: "El subsuelo que sostiene el pueblo" },
          { to: "/calles", label: "Calles", hint: "Trazado, inclinación, memoria" },
          { to: "/cementerio", label: "Cementerio Inglés", hint: "El otro lado del puerto" },
          { to: "/ecoturismo", label: "Ecoturismo", hint: "Rutas naturales y miradores" },
        ],
      },
      {
        title: "Memoria",
        items: [
          { to: "/historia", label: "Historia", hint: "Línea de tiempo del pueblo" },
          { to: "/cultura-arte", label: "Cultura & Arte", hint: "Tradición, oficio, artistas" },
          { to: "/leyendas", label: "Mitos y leyendas", hint: "Narrativa anclada al mapa" },
          { to: "/dichos", label: "Dichos mineros", hint: "Lengua viva del territorio" },
          { to: "/pastes", label: "Pastes", hint: "Cornualles cruzando el océano" },
        ],
      },
      {
        title: "Vida",
        items: [
          { to: "/rutas", label: "Rutas curadas", hint: "Recorridos temáticos" },
          { to: "/eventos", label: "Eventos", hint: "Lo que está pasando" },
          { to: "/calendario", label: "Calendario", hint: "Festividades y ferias" },
          { to: "/comercios", label: "Comercios", hint: "Economía local viva" },
          { to: "/comunidad", label: "Comunidad", hint: "Habitantes, colectivos, voces" },
        ],
      },
    ],
  },
  {
    key: "plataforma",
    label: "Plataforma",
    tag: "Plano 02",
    caption: "Qué es RDM Digital, para quién opera, cómo se sostiene.",
    icon: Building2,
    columns: [
      {
        title: "Identidad",
        items: [
          { to: "/acerca-de", label: "Acerca de", hint: "Resumen institucional" },
          { to: "/que-es-rdm-digital", label: "¿Qué es RDM Digital?", hint: "Qué, cómo, por qué, para quién" },
          { to: "/mision-vision", label: "Misión y visión", hint: "Filosofía LTOS aplicada" },
          { to: "/fundador", label: "Arquitecto raíz", hint: "Edwin O. Castillo Trejo" },
        ],
      },
      {
        title: "Acceso",
        items: [
          { to: "/membresias", label: "Membresías", hint: "Visitantes, comercios, guardianes" },
          { to: "/perfil", label: "Perfil", hint: "Tu recorrido, tus preferencias" },
          { to: "/donaciones", label: "Donaciones", hint: "Patrimonio y fondos soberanos" },
        ],
      },
      {
        title: "Contacto",
        items: [
          { to: "/faq", label: "Preguntas frecuentes" },
          { to: "/contacto", label: "Contacto institucional" },
          { to: "/ecosistema-oficial", label: "Ecosistema oficial", hint: "Sitios y redes verificadas" },
        ],
      },
    ],
  },
  {
    key: "sistema",
    label: "Sistema",
    tag: "Plano 03",
    caption: "El núcleo técnico y documental. Para quien construye, audita o investiga.",
    icon: Cpu,
    columns: [
      {
        title: "Arquitectura",
        items: [
          { to: "/manifiesto", label: "Manifiesto LTOS", hint: "Cinco principios fundacionales" },
          { to: "/arquitectura", label: "Arquitectura MDX4", hint: "Capas L0–L7, 7 federaciones" },
          { to: "/sistemas-nucleo", label: "Sistemas núcleo", hint: "OS · Nexus · Twin · Atlas" },
          { to: "/ecosistema", label: "Ecosistema técnico", hint: "Visión integrada" },
        ],
      },
      {
        title: "Operación",
        items: [
          { to: "/isabella", label: "Isabella & Realito", hint: "IA contextual auditable" },
          { to: "/economia", label: "Economía soberana", hint: "Cattleya Pay · MSR · Phoenix" },
          { to: "/federacion", label: "Federación Viva", hint: "100+ repos coordinados" },
        ],
      },
      {
        title: "Canon",
        items: [
          { to: "/canon-academico", label: "Canon académico", hint: "DOI · ORCID · DataCite" },
          { to: "/wiki", label: "Wiki RDM", hint: "Índice general de la plataforma" },
        ],
      },
    ],
  },
];

const allNav = planos.flatMap((p) => p.columns.flatMap((c) => c.items));

export function Header() {
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState<Plano["key"] | null>(null);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setMenu(null);
    setOpen(false);
  }, [pathname]);

  const isActive = (to: string) => pathname === to;
  const groupActive = (p: Plano) =>
    p.columns.some((c) => c.items.some((i) => isActive(i.to)));

  return (
    <header className="sticky top-0 z-50 border-b border-border/40 bg-background/70 backdrop-blur-xl">
      {/* Signal line */}
      <div className="h-px w-full bg-gradient-to-r from-transparent via-copper-500/40 to-transparent" />

      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        {/* Brand */}
        <Link to="/" className="group flex items-center gap-3">
          <span className="relative grid h-8 w-8 place-items-center rounded-md border border-border/60 bg-card/60 font-mono text-[10px] tracking-widest text-foreground/80">
            <span className="absolute inset-0 rounded-md bg-gradient-to-br from-copper-500/10 to-transparent" />
            <span className="relative">RDM</span>
          </span>
          <div className="hidden flex-col leading-none sm:flex">
            <span className="font-display text-lg italic text-foreground">Real del Monte</span>
            <span className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.32em] text-muted-foreground">
              Digital · Nodo Cero LTOS
            </span>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex" onMouseLeave={() => setMenu(null)}>
          {planos.map((p) => {
            const Icon = p.icon;
            const active = groupActive(p);
            const isOpen = menu === p.key;
            return (
              <div key={p.key} className="relative" onMouseEnter={() => setMenu(p.key)}>
                <button
                  className={`group flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors ${
                    active || isOpen
                      ? "text-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  aria-expanded={isOpen}
                >
                  <Icon className="h-3.5 w-3.5 opacity-60 transition group-hover:opacity-100" />
                  <span>{p.label}</span>
                  <span
                    className={`h-px w-4 transition-all ${
                      isOpen ? "bg-copper-400" : "bg-transparent"
                    }`}
                  />
                </button>
              </div>
            );
          })}

          <Link
            to="/atlas"
            className="ml-3 inline-flex items-center gap-2 rounded-full border border-foreground/20 bg-foreground px-4 py-1.5 text-xs font-medium text-background transition hover:opacity-90"
          >
            Abrir Atlas
            <ArrowUpRight className="h-3 w-3" />
          </Link>
        </nav>

        <button
          onClick={() => setOpen((o) => !o)}
          className="rounded-md border border-border/60 p-2 text-foreground lg:hidden"
          aria-label="Menú"
        >
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>

      {/* Mega-menu (desktop) */}
      {menu && (
        <div
          className="absolute left-0 right-0 top-full hidden lg:block"
          onMouseEnter={() => setMenu(menu)}
          onMouseLeave={() => setMenu(null)}
        >
          <div className="mx-auto max-w-7xl px-6">
            <div className="relative overflow-hidden rounded-b-2xl border border-t-0 border-border/50 bg-background/95 shadow-2xl backdrop-blur-2xl">
              <div className="pointer-events-none absolute inset-0">
                <div className="absolute -top-32 right-12 h-64 w-64 rounded-full bg-copper-500/[0.04] blur-3xl" />
                <div className="absolute -bottom-24 left-24 h-48 w-48 rounded-full bg-signal/[0.04] blur-3xl" />
              </div>

              {(() => {
                const p = planos.find((x) => x.key === menu)!;
                return (
                  <div className="relative grid grid-cols-[1fr_2.4fr] gap-10 p-8">
                    {/* Caption */}
                    <div className="border-r border-border/40 pr-8">
                      <div className="font-mono text-[10px] uppercase tracking-[0.32em] text-copper-600">
                        {p.tag}
                      </div>
                      <h3 className="mt-3 font-display text-3xl italic leading-tight">{p.label}</h3>
                      <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                        {p.caption}
                      </p>
                      <div className="mt-6 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-foreground/50">
                        <span className="h-1 w-1 rounded-full bg-copper-500" />
                        {p.columns.length} ejes · {p.columns.reduce((a, c) => a + c.items.length, 0)} entradas
                      </div>
                    </div>

                    {/* Columns */}
                    <div className="grid grid-cols-3 gap-6">
                      {p.columns.map((col) => (
                        <div key={col.title}>
                          <div className="mb-3 font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                            {col.title}
                          </div>
                          <ul className="space-y-1">
                            {col.items.map((it) => (
                              <li key={it.to}>
                                <Link
                                  to={it.to}
                                  className={`group block rounded-md px-3 py-2 transition-colors ${
                                    isActive(it.to)
                                      ? "bg-muted/70 text-foreground"
                                      : "text-foreground/85 hover:bg-muted/50"
                                  }`}
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-sm font-medium">{it.label}</span>
                                    <ArrowUpRight className="h-3 w-3 opacity-0 transition group-hover:opacity-60" />
                                  </div>
                                  {it.hint && (
                                    <div className="mt-0.5 text-xs text-muted-foreground/80">
                                      {it.hint}
                                    </div>
                                  )}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Mobile drawer */}
      {open && (
        <div className="border-t border-border/60 bg-background lg:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-6">
            {planos.map((p) => (
              <div key={p.key}>
                <div className="mb-2 flex items-center gap-2">
                  <p.icon className="h-3.5 w-3.5 text-copper-600" />
                  <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                    {p.tag} · {p.label}
                  </span>
                </div>
                <div className="grid grid-cols-1 gap-x-4 sm:grid-cols-2">
                  {p.columns.flatMap((c) => c.items).map((n) => (
                    <Link
                      key={n.to}
                      to={n.to}
                      className="rounded-md px-2 py-2 text-sm text-foreground/85 hover:bg-muted"
                    >
                      {n.label}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
            <Link
              to="/atlas"
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-foreground px-4 py-2.5 text-sm font-medium text-background"
            >
              Abrir Atlas <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}

export const __navAll = allNav;
