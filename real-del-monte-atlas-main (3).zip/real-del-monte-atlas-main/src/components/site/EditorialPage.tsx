import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";

type Stat = { k: string; v: string };
type Related = { to: string; label: string; hint?: string };

type Props = {
  plano: string;
  kicker: string;
  title: ReactNode;
  lead?: string;
  stats?: Stat[];
  children: ReactNode;
  related?: Related[];
};

export function EditorialPage({ plano, kicker, title, lead, stats, children, related }: Props) {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border/40">
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -left-32 top-0 h-[520px] w-[520px] rounded-full bg-copper-500/[0.05] blur-[120px]" />
          <div className="absolute right-0 top-40 h-[460px] w-[460px] rounded-full bg-signal/[0.04] blur-[140px]" />
          <div
            className="absolute inset-0 opacity-[0.04]"
            style={{
              backgroundImage:
                "linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)",
              backgroundSize: "64px 64px",
            }}
          />
        </div>

        <div className="relative mx-auto max-w-7xl px-6 pb-20 pt-24 md:pt-32">
          <div className="grid gap-10 md:grid-cols-12">
            <div className="md:col-span-3">
              <div className="font-mono text-[10px] uppercase tracking-[0.32em] text-copper-600">
                {plano}
              </div>
              <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/60 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground backdrop-blur">
                <span className="h-1 w-1 rounded-full bg-copper-500" />
                {kicker}
              </div>
            </div>
            <div className="md:col-span-9">
              <h1 className="font-display text-5xl italic leading-[1.05] text-foreground md:text-7xl">
                {title}
              </h1>
              {lead && (
                <p className="mt-8 max-w-2xl text-lg leading-relaxed text-foreground/80">{lead}</p>
              )}
            </div>
          </div>

          {stats && stats.length > 0 && (
            <div className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-4">
              {stats.map((s) => (
                <div key={s.k} className="bg-background/80 p-6 backdrop-blur">
                  <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                    {s.k}
                  </div>
                  <div className="mt-2 font-display text-2xl text-foreground">{s.v}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Body */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-12 md:grid-cols-12">
          <aside className="md:col-span-3">
            <div className="sticky top-24 space-y-2 border-l border-border/40 pl-4 font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              <div>{plano}</div>
              <div className="text-foreground/60">{kicker}</div>
            </div>
          </aside>
          <div className="prose prose-neutral max-w-none md:col-span-9">{children}</div>
        </div>
      </section>

      {/* Related */}
      {related && related.length > 0 && (
        <section className="border-t border-border/40 bg-card/20">
          <div className="mx-auto max-w-7xl px-6 py-16">
            <div className="font-mono text-[10px] uppercase tracking-[0.32em] text-muted-foreground">
              Continuar el recorrido
            </div>
            <div className="mt-6 grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-3">
              {related.map((r) => (
                <Link
                  key={r.to}
                  to={r.to}
                  className="group bg-background/80 p-6 backdrop-blur transition hover:bg-background"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-display text-2xl italic text-foreground">{r.label}</div>
                      {r.hint && (
                        <div className="mt-2 text-sm text-muted-foreground">{r.hint}</div>
                      )}
                    </div>
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-foreground" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  );
}

export function EditorialSection({
  eyebrow,
  title,
  children,
}: {
  eyebrow?: string;
  title?: string;
  children: ReactNode;
}) {
  return (
    <section className="mt-12 border-t border-border/40 pt-12 first:mt-0 first:border-0 first:pt-0">
      {eyebrow && (
        <div className="font-mono text-[10px] uppercase tracking-[0.32em] text-copper-600">
          {eyebrow}
        </div>
      )}
      {title && (
        <h2 className="mt-3 font-display text-3xl italic text-foreground md:text-4xl">{title}</h2>
      )}
      <div className="mt-6 text-base leading-relaxed text-foreground/85">{children}</div>
    </section>
  );
}
