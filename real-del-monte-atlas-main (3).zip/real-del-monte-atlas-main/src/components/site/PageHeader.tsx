type Props = {
  kicker: string;
  title: string;
  intro?: string;
  image?: string;
};

export function PageHeader({ kicker, title, intro, image }: Props) {
  return (
    <section className="relative isolate overflow-hidden">
      {image && (
        <div className="absolute inset-0 -z-10">
          <img
            src={image}
            alt=""
            className="h-full w-full object-cover opacity-40"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-fog" />
        </div>
      )}
      <div className="container-prose pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="eyebrow">{kicker}</div>
        <h1 className="display-lg mt-4 max-w-3xl">{title}</h1>
        {intro && (
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground leading-relaxed">{intro}</p>
        )}
      </div>
    </section>
  );
}
