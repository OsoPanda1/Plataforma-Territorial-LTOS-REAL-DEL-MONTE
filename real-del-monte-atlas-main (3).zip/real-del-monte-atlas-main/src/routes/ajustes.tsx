import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/ajustes")({
  head: () => ({ meta: [{ title: "Ajustes — RDM Digital" }] }),
  component: Ajustes,
});

function Ajustes() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Configuración"
      title={<>Tu sistema, <span className="text-copper-700">tus reglas.</span></>}
      lead="Preferencias de idioma, accesibilidad, notificaciones y manejo de datos personales."
      related={[{ to: "/perfil", label: "Perfil" }, { to: "/faq", label: "FAQ" }]}
    >
      <EditorialSection>
        <p>Módulo en preparación. La capa de identidad se publicará junto con la activación de membresías Raíz.</p>
      </EditorialSection>
    </EditorialPage>
  );
}
