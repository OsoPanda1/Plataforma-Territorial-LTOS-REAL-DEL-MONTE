import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/membresias")({
  head: () => ({
    meta: [{ title: "Membresías — RDM Digital" }, { name: "description", content: "Tres niveles de membresía LTOS para visitantes, comercios y guardianes." }],
  }),
  component: Membresias,
});

const tiers = [
  {
    t: "Visitante",
    p: "Gratuito",
    d: "Acceso al atlas, rutas curadas y eventos públicos. Tu recorrido queda registrado en tu perfil.",
    b: ["Atlas completo", "Rutas curadas", "Muro de experiencias"],
  },
  {
    t: "Raíz",
    p: "MX$249 / año",
    d: "Para comercios y habitantes. Visibilidad en el directorio, panel básico y participación en decisiones barriales.",
    b: ["Ficha verificada", "Panel de métricas", "Voz en consultas locales"],
    featured: true,
  },
  {
    t: "Guardián",
    p: "Por invitación",
    d: "Instituciones, colectivos y residentes de larga trayectoria. Acceso al BookPI y consolas de gobernanza HITL.",
    b: ["Auditoría BookPI", "Consola guardian", "Llaves de federación"],
  },
];

function Membresias() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Acceso"
      title={<>Tres niveles, <span className="text-copper-700">una sola red.</span></>}
      lead="No es un sistema de pago. Es una arquitectura de responsabilidad: cuanto más participas, más capas del sistema se abren."
      related={[
        { to: "/perfil", label: "Tu perfil" },
        { to: "/comercios", label: "Comercios LTOS" },
        { to: "/donaciones", label: "Donaciones" },
      ]}
    >
      <EditorialSection eyebrow="Niveles" title="Visitante · Raíz · Guardián.">
        <div className="grid gap-6 md:grid-cols-3">
          {tiers.map((t) => (
            <div
              key={t.t}
              className={`rounded-2xl border p-6 ${
                t.featured
                  ? "border-copper-500/50 bg-card shadow-lg"
                  : "border-border/50 bg-card/40"
              }`}
            >
              <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-copper-700">
                {t.t}
              </div>
              <div className="mt-2 font-display text-3xl italic">{t.p}</div>
              <p className="mt-3 text-sm text-muted-foreground">{t.d}</p>
              <ul className="mt-5 space-y-1.5 text-sm">
                {t.b.map((x) => (
                  <li key={x} className="flex gap-2"><span className="text-copper-600">·</span>{x}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
