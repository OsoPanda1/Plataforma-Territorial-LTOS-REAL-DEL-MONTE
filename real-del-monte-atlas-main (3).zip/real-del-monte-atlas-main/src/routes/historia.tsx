import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/historia")({
  head: () => ({
    meta: [
      { title: "Historia — Real del Monte" },
      { name: "description", content: "Línea de tiempo del pueblo minero más alto de México: origen, auge, huelga del 66, migración cornish y memoria viva." },
      { property: "og:title", content: "Historia — Real del Monte" },
    ],
  }),
  component: Historia,
});

const timeline = [
  { year: "1552", title: "Primer denuncio minero", body: "Se reporta plata en las laderas. El pueblo nace como Real de Minas." },
  { year: "1739", title: "Bonanza del Conde de Regla", body: "Pedro Romero de Terreros consolida la mina más rica del mundo." },
  { year: "1766", title: "Primera huelga de América", body: "Los barreteros se levantan contra el reparto de partido. Hito laboral global." },
  { year: "1824", title: "Llegada cornish", body: "Mineros de Cornualles traen tecnología de vapor, futbol y, con los años, el paste." },
  { year: "1906", title: "Compañía mexicana de Real del Monte", body: "El distrito se mexicaniza. Migración, ferrocarril, fundición." },
  { year: "2015", title: "Pueblo Mágico", body: "Reconocimiento federal. El territorio comienza a leerse como patrimonio." },
  { year: "2025", title: "Nodo Cero LTOS", body: "Real del Monte se vuelve el primer territorio operado por un sistema operativo soberano." },
];

function Historia() {
  return (
    <EditorialPage
      plano="Plano 01 · Experiencia"
      kicker="Memoria"
      title={<>Una línea de tiempo<br/><span className="text-copper-700">que aún no termina.</span></>}
      lead="Real del Monte no es un museo. Es un pueblo que sigue ocurriendo. Esta línea reúne los hitos que explican por qué cada calle, cada apellido y cada hornilla saben a otra cosa."
      stats={[
        { k: "Fundación", v: "1552" },
        { k: "Altitud", v: "2 760 m" },
        { k: "Primera huelga", v: "1766" },
        { k: "Pueblo Mágico", v: "2015" },
      ]}
      related={[
        { to: "/minas", label: "Las minas", hint: "El subsuelo que sostiene todo." },
        { to: "/pastes", label: "Los pastes", hint: "Lo que dejó Cornualles." },
        { to: "/cementerio", label: "Cementerio inglés", hint: "El otro lado del puerto." },
      ]}
    >
      <EditorialSection eyebrow="Cronología" title="Siete momentos que dieron forma al territorio.">
        <ol className="relative space-y-10 border-l border-border/60 pl-8">
          {timeline.map((t) => (
            <li key={t.year} className="relative">
              <span className="absolute -left-[37px] top-1 grid h-4 w-4 place-items-center rounded-full border border-copper-500/50 bg-background">
                <span className="h-1.5 w-1.5 rounded-full bg-copper-500" />
              </span>
              <div className="font-mono text-xs uppercase tracking-[0.3em] text-copper-700">{t.year}</div>
              <div className="mt-1 font-display text-2xl italic text-foreground">{t.title}</div>
              <p className="mt-2 text-base text-foreground/80">{t.body}</p>
            </li>
          ))}
        </ol>
      </EditorialSection>
    </EditorialPage>
  );
}
