import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import {
  chapters,
  events,
  legends,
  mines,
  pastes,
  routes,
  streets,
  territoryStats,
} from "@/data/territory";
import React, { Suspense, useMemo, useCallback, ReactNode } from "react";
import { z } from "zod";

// ============================================================================
// SEGURIDAD: Content Security Policy & Validaciones
// ============================================================================

const ALLOWED_ORIGINS = [
  "https://zenodo.org",
  "https://figshare.com",
  "https://www.openaire.eu",
  "https://datacite.org",
  "https://loops.academy",
  "https://www.frontiersin.org",
  "https://avixa.org",
  "https://xcange.io",
  "https://github.com",
  "https://gitlab.com",
] as const;

const ORCID_PATTERN = /^0\d{3}-\d{4}-\d{4}-\d{4}$/;
const DOI_PATTERN = /^10\.\d{4,}\/.+$/;

// ============================================================================
// VALIDACIÓN ZOD: Tipos seguros en tiempo de compilación
// ============================================================================

const ChapterSchema = z.object({
  slug: z.string().min(1).max(100),
  href: z.string().url(),
  image: z.string().url(),
  kicker: z.string().min(1).max(50),
  title: z.string().min(1).max(200),
  blurb: z.string().min(1).max(500),
});

const MineSchema = z.object({
  id: z.string().min(1).max(100),
  name: z.string().min(1).max(200),
  founded: z.string().min(1).max(20),
  status: z.string().min(1).max(100),
  description: z.string().min(1).max(1000),
});

const TerritoryStatsSchema = z.record(z.string(), z.number().min(0).max(10000));

const MetadataSchema = z.object({
  DOI: z.string().regex(DOI_PATTERN, "DOI inválido"),
  ORCID: z.string().regex(ORCID_PATTERN, "ORCID inválido"),
  VERSION: z.string().min(1).max(50),
  Zenodo: z.string().url(),
  Figshare: z.string().url(),
  OpenAIRE: z.string().url(),
  DataCite: z.string().url(),
  Loops: z.string().url(),
  Frontiers: z.string().url(),
  AVIXA: z.string().url(),
  XCANGE: z.string().url(),
});

// ============================================================================
// IDENTIFICADORES DE SOBERANÍA ACADÉMICA Y TÉCNICA
// ============================================================================

const META_DATA = MetadataSchema.parse({
  DOI: "10.5281/zenodo.19436662",
  ORCID: "0009-0008-5050-1539",
  VERSION: "TAMV-MD-X4-CORE",
  Zenodo: "https://zenodo.org/doi/10.5281/zenodo.19436662",
  Figshare: "https://figshare.com",
  OpenAIRE: "https://www.openaire.eu",
  DataCite: "https://datacite.org",
  Loops: "https://loops.academy",
  Frontiers: "https://www.frontiersin.org",
  AVIXA: "https://avixa.org",
  XCANGE: "https://xcange.io",
});

const FEDERATIONS = ["1ª", "2ª", "3ª", "4ª", "5ª", "6ª", "7ª"] as const;
const FEDERATION_COUNTS = [
  mines.length,
  pastes.length,
  legends.length,
  streets.length,
  routes.length,
  events.length,
  chapters.length,
] as const;

// ============================================================================
// UTILIDADES DE SEGURIDAD
// ============================================================================

function sanitizeUrl(url: string): string {
  try {
    const parsed = new URL(url);
    if (!ALLOWED_ORIGINS.includes(parsed.origin as (typeof ALLOWED_ORIGINS)[number])) {
      console.warn(`URL bloqueada: ${url}`);
      return "#";
    }
    return url;
  } catch {
    return "#";
  }
}

function validateChapter(chapter: unknown): chapter is z.infer<typeof ChapterSchema> {
  return ChapterSchema.safeParse(chapter).success;
}

function validateMine(mine: unknown): mine is z.infer<typeof MineSchema> {
  return MineSchema.safeParse(mine).success;
}

// ============================================================================
// COMPONENTES DE ERROR BOUNDARY
// ============================================================================

class ErrorBoundary extends React.Component<{ children: ReactNode }, { hasError: boolean }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("ErrorBoundary caught:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black flex items-center justify-center p-8">
          <div className="max-w-md text-center">
            <h1 className="text-3xl font-display text-pearl-white mb-4">Error crítico</h1>
            <p className="text-gray-400 mb-6">
              Ha ocurrido un error en la arquitectura del sistema.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-turquoise text-black font-bold rounded-lg hover:bg-turquoise/90 transition"
            >
              Recargar sistema
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-turquoise border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-pearl-white font-mono text-sm">Cargando MD-X4 Core...</p>
        <p className="text-gray-500 text-xs mt-2">DOI: {META_DATA.DOI}</p>
      </div>
    </div>
  );
}

// ============================================================================
// METADATOS ESTRUCTURADOS (JSON-LD)
// ============================================================================

function StructuredData() {
  const json = useMemo(
    () => ({
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Dataset",
          name: "Atlas Territorial | MD-X4 Ecosystem — RDM Digital",
          description:
            "Arquitectura federada de Real del Monte. 7 capas, minas, nodos y soberanía digital.",
          version: META_DATA.VERSION,
          identifier: META_DATA.DOI,
          url: META_DATA.Zenodo,
          license: "https://creativecommons.org/licenses/by/4.0/",
          author: {
            "@type": "Person",
            name: "Edwin Oswaldo Castillo Trejo",
            alternateName: "Anubis Villaseñor",
            identifier: META_DATA.ORCID,
            jobTitle: "Chief Executive Officer & Lead Systems Architect",
            worksFor: {
              "@type": "Organization",
              name: "TAMV Online Network | RDM Digital",
              url: "https://tamv-online.network",
            },
          },
          provider: { "@type": "Organization", name: "Zenodo", sameAs: META_DATA.Zenodo },
          sameAs: [
            META_DATA.Figshare,
            META_DATA.OpenAIRE,
            META_DATA.DataCite,
            META_DATA.Loops,
            META_DATA.Frontiers,
            META_DATA.AVIXA,
            META_DATA.XCANGE,
          ],
          keywords: [
            "soberanía digital",
            "metaverso 4D",
            "gemelos digitales",
            "smart destinations",
            "Real del Monte",
            "Hidalgo",
            "México",
          ],
          datePublished: "2026-01-01",
          dateModified: new Date().toISOString(),
        },
        {
          "@type": "Person",
          name: "Edwin Oswaldo Castillo Trejo",
          alternateName: "Anubis Villaseñor",
          identifier: META_DATA.ORCID,
          jobTitle: "Chief Executive Officer & Lead Systems Architect",
          worksFor: {
            "@type": "Organization",
            name: "TAMV Online Network | RDM Digital",
          },
          sameAs: [
            `https://orcid.org/${META_DATA.ORCID}`,
            META_DATA.Zenodo,
            META_DATA.Figshare,
            META_DATA.Loops,
            META_DATA.Frontiers,
          ],
          address: {
            "@type": "PostalAddress",
            addressLocality: "Real del Monte",
            addressRegion: "Hidalgo",
            addressCountry: "MX",
          },
        },
        {
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "Inicio",
              item: "/",
            },
            {
              "@type": "ListItem",
              position: 2,
              name: "Atlas Territorial",
              item: "/atlas",
            },
          ],
        },
      ],
    }),
    [],
  );

  return (
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(json) }} />
  );
}

// ============================================================================
// COMPONENTE: Card de Datos Abiertos
// ============================================================================

function DataCard({
  title,
  kicker,
  href,
  description,
  meta,
}: {
  title: string;
  kicker: string;
  href: string;
  description: string;
  meta?: string;
}) {
  const safeHref = sanitizeUrl(href);

  return (
    <a
      href={safeHref}
      target="_blank"
      rel="noopener noreferrer nofollow"
      className="group rounded-xl border border-navy-deep bg-navy-deep/40 p-6 transition-all hover:border-turquoise hover:bg-navy-deep/60 focus:outline-none focus:ring-2 focus:ring-turquoise focus:ring-offset-2 focus:ring-offset-black"
      aria-label={`${kicker}: ${title}`}
    >
      <div className="eyebrow text-turquoise">{kicker}</div>
      <div className="font-display mt-2 text-lg text-pearl-white group-hover:text-turquoise transition-colors">
        {title}
      </div>
      <p className="mt-2 text-sm text-gray-400">{description}</p>
      {meta && <div className="mt-2 text-xs font-mono text-gray-500">{meta}</div>}
    </a>
  );
}

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

export const Route = createFileRoute("/atlas")({
  head: () => ({
    meta: [
      { title: "Atlas Territorial | MD-X4 Ecosystem — RDM Digital" },
      {
        name: "description",
        content:
          "Arquitectura federada de Real del Monte. 7 capas, minas, nodos y soberanía digital. DOI: 10.5281/zenodo.19436662 ORCID: 0009-0008-5050-1539",
      },
      { name: "robots", content: "index, follow, max-image-preview:large, max-snippet:-1" },
      { name: "author", content: "Edwin Oswaldo Castillo Trejo" },
      { name: "orcid", content: META_DATA.ORCID },
      { name: "doi", content: META_DATA.DOI },
      { name: "version", content: META_DATA.VERSION },
      { property: "og:title", content: "Atlas Territorial | MD-X4 Ecosystem" },
      {
        property: "og:description",
        content: "7 federaciones, minas y nodos para soberanía digital en Real del Monte.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://atlas.tamv-online.network/atlas" },
      { property: "og:site_name", content: "MD-X4 Ecosystem" },
      { property: "article:author", content: `https://orcid.org/${META_DATA.ORCID}` },
      { property: "article:published_time", content: "2026-01-01T00:00:00Z" },
      { property: "article:modified_time", content: new Date().toISOString() },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Atlas Territorial | MD-X4 Ecosystem" },
      {
        name: "twitter:description",
        content: "Arquitectura federada de Real del Monte — Soberanía Digital LATAM",
      },
      { name: "doi", content: META_DATA.DOI },
      { name: "citation_doi", content: META_DATA.DOI },
    ],
    link: [
      {
        rel: "alternate",
        type: "application/json",
        title: "Dataset API",
        href: META_DATA.Zenodo,
      },
      { rel: "canonical", href: "https://atlas.tamv-online.network/atlas" },
      { rel: "author", href: `https://orcid.org/${META_DATA.ORCID}` },
    ],
    script: [
      {
        type: "text/javascript",
        src: "https://cdn.jsdelivr.net/npm/zod@3/lib/index.umd.js",
        strategy: "lazyOnload",
      },
    ],
  }),
  component: AtlasComponent,
});

function AtlasComponent() {
  const navigate = useNavigate();

  const totalNodes = useMemo(() => FEDERATION_COUNTS.reduce((a, b) => a + b, 0), []);

  const handleExternalLink = useCallback((url: string) => {
    const safeUrl = sanitizeUrl(url);
    if (safeUrl !== "#") {
      window.open(safeUrl, "_blank", "noopener,noreferrer");
    }
  }, []);

  return (
    <ErrorBoundary>
      <StructuredData />
      <main
        className="animate-in fade-in duration-700 min-h-screen bg-black"
        role="main"
        aria-label="Atlas Territorial MD-X4"
      >
        {/* Security Banner */}
        <div
          className="border-b border-navy-deep bg-navy-deep/20 px-4 py-2"
          role="banner"
          aria-label="Security and sovereignty information"
        >
          <div className="container mx-auto flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
            <span className="text-gray-500">
              [v{META_DATA.VERSION}] | [DOI: {META_DATA.DOI}]
            </span>
            <span className="text-turquoise">
              ORCID: {META_DATA.ORCID} • Soberanía Digital • Real del Monte, Hidalgo, MX
            </span>
          </div>
        </div>

        <PageHeader
          kicker="MD-X4: Arquitectura de 7 Capas"
          title="El atlas es una forma de mirar dos veces."
          intro="Más allá de la cartografía: una estructura antifrágil. La convergencia entre el subsuelo minero y la red digital de Real del Monte."
        />

        <section className="container-prose pb-24" id="main-content">
          {/* Estadísticas de Federaciones (7 nodos) */}
          <section
            className="grid gap-x-12 gap-y-8 border-y border-platinum/20 py-10 md:grid-cols-4"
            aria-labelledby="federations-stats"
          >
            <h2 id="federations-stats" className="sr-only">
              Estadísticas de las 7 Federaciones
            </h2>
            {FEDERATIONS.map((f, i) => {
              const key = `f-${i + 1}`;
              const value = FEDERATION_COUNTS[i] ?? 0;
              return (
                <div
                  key={key}
                  className="group cursor-default"
                  role="region"
                  aria-label={`${f} Federación`}
                >
                  <div className="eyebrow text-turquoise">{f}</div>
                  <div className="font-display mt-2 text-2xl text-pearl-white tracking-tight">
                    {value.toLocaleString()}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">nodos activos</div>
                </div>
              );
            })}
          </section>

          {/* CTA de Datos Abiertos y Soberanía */}
          <section
            className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4"
            aria-labelledby="open-data-heading"
          >
            <h2 id="open-data-heading" className="sr-only">
              Datos Abiertos y Soberanía
            </h2>
            <DataCard
              kicker="Zenodo / DOI"
              title="Dataset y artefactos"
              href={META_DATA.Zenodo}
              description="Repositorio académico con DOI persistente"
              meta={`DOI: ${META_DATA.DOI}`}
            />
            <DataCard
              kicker="Figshare"
              title="Datasets visuales"
              href={META_DATA.Figshare}
              description="Modelos 3D, dashboards, metadatos"
            />
            <DataCard
              kicker="OpenAIRE"
              title="Visibilidad FAIR"
              href={META_DATA.OpenAIRE}
              description="Metadatos enlazados europeos"
            />
            <DataCard
              kicker="DataCite"
              title="DOI persistente"
              href={META_DATA.DataCite}
              description="Identificación inmortal de datos"
            />
          </section>

          {/* Capítulos Expandidos con validación */}
          <section className="mt-20 grid gap-8 md:grid-cols-2" aria-labelledby="chapters-heading">
            <h2 id="chapters-heading" className="sr-only">
              Capítulos del Atlas
            </h2>
            {chapters.filter(validateChapter).map((c) => (
              <Link
                key={c.slug}
                to={c.href}
                className="group relative flex flex-col overflow-hidden rounded-2xl border border-navy-deep bg-gradient-to-br from-navy-deep to-black p-1 transition-all hover:border-turquoise focus:outline-none focus:ring-2 focus:ring-turquoise"
                aria-label={`Leer capítulo: ${c.title}`}
              >
                <div className="aspect-[16/9] w-full overflow-hidden rounded-xl">
                  <img
                    src={c.image}
                    alt={c.title}
                    loading="lazy"
                    width="800"
                    height="450"
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                    decoding="async"
                  />
                </div>
                <div className="p-6">
                  <span className="text-xs font-bold uppercase tracking-widest text-turquoise">
                    {c.kicker}
                  </span>
                  <h3 className="font-display mt-3 text-3xl text-pearl-white">{c.title}</h3>
                  <p className="mt-4 text-base leading-relaxed text-gray-400 line-clamp-3">
                    {c.blurb}
                  </p>
                </div>
              </Link>
            ))}
          </section>

          {/* Nodos de Profundidad (Minas) */}
          <section className="mt-32" aria-labelledby="mines-heading">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="eyebrow text-turquoise">Red de Nodos Subterráneos</div>
                <h2 id="mines-heading" className="text-5xl font-display mt-4 text-pearl-white">
                  Geometría de Extracción
                </h2>
              </div>
              <div
                className="text-right text-xs font-mono text-gray-500"
                aria-label="Identificadores académicos"
              >
                [DOI: {META_DATA.DOI}] | [ORCID: {META_DATA.ORCID}] | [v{META_DATA.VERSION}]
              </div>
            </div>

            <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-navy-deep bg-navy-deep md:grid-cols-2">
              {mines.filter(validateMine).map((m) => (
                <article
                  key={m.id}
                  className="bg-black p-8 transition-colors hover:bg-navy-deep/50 focus-within:bg-navy-deep/50"
                  aria-labelledby={`mine-${m.id}`}
                >
                  <header className="flex items-center justify-between">
                    <h3 id={`mine-${m.id}`} className="font-display text-2xl text-pearl-white">
                      {m.name}
                    </h3>
                    <span className="font-mono text-xs text-turquoise border border-turquoise px-2 py-1 rounded">
                      {m.founded}
                    </span>
                  </header>
                  <div className="mt-4 text-sm uppercase tracking-wider text-gray-500">
                    {m.status}
                  </div>
                  <p className="mt-4 text-gray-300 leading-relaxed">{m.description}</p>
                </article>
              ))}
            </div>
          </section>

          {/* AVIXA & XCANGE */}
          <section className="mt-32" aria-labelledby="phygital-heading">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="eyebrow text-turquoise">Experiencias Inmersivas y Activos</div>
                <h2 id="phygital-heading" className="text-5xl font-display mt-4 text-pearl-white">
                  AVIXA × XCANGE — Phygital
                </h2>
              </div>
              <div className="text-right text-xs font-mono text-gray-500">
                Standards: AVIXA | Interoperabilidad: XCANGE
              </div>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-2">
              <DataCard
                kicker="AVIXA"
                title="Estándares inmersivos"
                href={META_DATA.AVIXA}
                description="Experiencias audiovisuales y entornos sensoriales"
              />
              <DataCard
                kicker="XCANGE"
                title="Activos digitales"
                href={META_DATA.XCANGE}
                description="Interoperabilidad phygital y mercados de contenido"
              />
            </div>
          </section>

          {/* Loops & Frontiers */}
          <section
            className="mt-32 border-t border-platinum/20 pt-12"
            aria-labelledby="academic-heading"
          >
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="eyebrow text-turquoise">Colaboración y Revisión por Pares</div>
                <h2 id="academic-heading" className="text-5xl font-display mt-4 text-pearl-white">
                  Loops × Frontiers
                </h2>
              </div>
              <div className="text-right text-xs font-mono text-gray-500">
                Publicación y trazabilidad académica
              </div>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-2">
              <DataCard
                kicker="Loops"
                title="Colaboración académica"
                href={META_DATA.Loops}
                description="Redes de investigación y trazabilidad de versiones"
              />
              <DataCard
                kicker="Frontiers"
                title="Publicación peer-review"
                href={META_DATA.Frontiers}
                description="IA, sistemas distribuidos y patrimonio digital"
              />
            </div>
          </section>

          {/* Soberanía de Metadatos */}
          <section className="mt-32" aria-labelledby="metadata-heading">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="eyebrow text-turquoise">Soberanía de Metadatos</div>
                <h2 id="metadata-heading" className="text-5xl font-display mt-4 text-pearl-white">
                  DataCite & Metadatos Enlazados
                </h2>
              </div>
              <div className="text-right text-xs font-mono text-gray-500">Principios FAIR</div>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-3">
              <div
                className="rounded-xl border border-navy-deep bg-navy-deep/40 p-6"
                role="region"
                aria-label="DOI persistente"
              >
                <div className="eyebrow text-turquoise">DOI Persistente</div>
                <div className="font-mono mt-2 text-sm text-pearl-white break-all">
                  {META_DATA.DOI}
                </div>
                <p className="mt-2 text-sm text-gray-400">
                  Identificador inmortal para datasets y publicaciones.
                </p>
              </div>
              <div
                className="rounded-xl border border-navy-deep bg-navy-deep/40 p-6"
                role="region"
                aria-label="Perfil ORCID"
              >
                <div className="eyebrow text-turquoise">ORCID</div>
                <div className="font-mono mt-2 text-sm text-pearl-white">{META_DATA.ORCID}</div>
                <p className="mt-2 text-sm text-gray-400">
                  Perfil único para trazabilidad académica.
                </p>
              </div>
              <div
                className="rounded-xl border border-navy-deep bg-navy-deep/40 p-6"
                role="region"
                aria-label="Total de nodos"
              >
                <div className="eyebrow text-turquoise">Nodos Totales</div>
                <div className="font-display mt-2 text-2xl text-pearl-white">
                  {totalNodes.toLocaleString()}
                </div>
                <p className="mt-2 text-sm text-gray-400">Nodos activos en las 7 federaciones.</p>
              </div>
            </div>
          </section>

          {/* Footer de Soberanía */}
          <footer className="mt-32 border-t border-platinum/20 pt-12 pb-24" role="contentinfo">
            <div className="grid gap-8 md:grid-cols-3">
              <div>
                <div className="eyebrow text-turquoise">Soberanía Digital</div>
                <p className="mt-2 text-sm text-gray-400">
                  "Innovation is only authentic when it is sovereign."
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  Engineering the OS of a new digital civilization from Real del Monte.
                </p>
              </div>
              <div>
                <div className="eyebrow text-turquoise">Autor</div>
                <p className="mt-2 text-sm text-pearl-white">Edwin Oswaldo Castillo Trejo</p>
                <p className="mt-1 text-xs text-gray-500">p.k.a. "Anubis Villaseñor"</p>
                <p className="mt-1 text-xs text-gray-500">Real del Monte, Hidalgo, México</p>
              </div>
              <div>
                <div className="eyebrow text-turquoise">Infraestructura</div>
                <p className="mt-2 text-xs text-gray-500 font-mono">
                  TAMV Online Network | RDM Digital
                </p>
                <p className="mt-1 text-xs text-gray-500 font-mono">
                  MD-X4 Core v{META_DATA.VERSION}
                </p>
              </div>
            </div>
          </footer>
        </section>
      </main>
    </ErrorBoundary>
  );
}
