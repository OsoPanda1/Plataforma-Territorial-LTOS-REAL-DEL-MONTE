import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/donaciones")({
  head: () => ({ meta: [{ title: "Donaciones — RDM Digital" }] }),
  component: Donaciones,
});

const destinos = [
  { t: "Patrimonio", d: "Restauración de fachadas, atrios y cementerios." },
  { t: "Fondos Phoenix", d: "Reservas territoriales para emergencias y resiliencia." },
  { t: "Comunidad", d: "Becas para guías locales, oficios y cultura viva." },
];

function Donaciones() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Aportes"
      title={<>Sostener el territorio <span className="text-copper-700">también es habitarlo.</span></>}
      lead="Cada aporte se asigna a un fondo soberano con reglas públicas y auditadas. La trazabilidad llega hasta el último centavo."
      related={[{ to: "/economia", label: "Economía soberana" }, { to: "/membresias", label: "Membresías" }]}
    >
      <EditorialSection eyebrow="Destinos">
        <div className="grid gap-6 md:grid-cols-3">
          {destinos.map((d) => (
            <div key={d.t} className="rounded-xl border border-border/50 bg-card/40 p-6">
              <div className="font-display text-2xl italic">{d.t}</div>
              <p className="mt-2 text-sm text-muted-foreground">{d.d}</p>
            </div>
          ))}
        </div>
      </EditorialSection>
      <EditorialSection eyebrow="Distribución">
        <p>Cada donación se reparte bajo la regla <strong>20/30/50</strong> codificada en Cattleya Pay: 20% fondos Phoenix, 30% infraestructura del Nodo, 50% destino seleccionado por el donante.</p>
      </EditorialSection>
    </EditorialPage>
  );
}
