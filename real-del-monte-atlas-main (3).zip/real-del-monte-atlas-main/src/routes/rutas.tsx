import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { routes as territorialRoutes } from "@/data/territory";

export const Route = createFileRoute("/rutas")({
  head: () => ({
    meta: [
      { title: "Rutas — Real del Monte" },
      {
        name: "description",
        content:
          "Recorridos curados por Real del Monte: patrimonio minero, calles y pastes, leyendas al atardecer.",
      },
      { property: "og:title", content: "Rutas — Real del Monte" },
      { property: "og:description", content: "Hay más de una forma de recorrer este lugar." },
    ],
  }),
  component: Rutas,
});

const difficultyTone: Record<string, string> = {
  ligera: "bg-forest/10 text-forest",
  media: "bg-copper/10 text-copper",
  alta: "bg-destructive/10 text-destructive",
};

function Rutas() {
  return (
    <>
      <PageHeader
        kicker="Recorridos"
        title="Hay más de una forma de recorrer este lugar."
        intro="Estas rutas no son itinerarios cerrados. Son sugerencias de mirada. Cada una atraviesa una capa distinta del territorio."
      />

      <section className="container-prose pb-24">
        <div className="space-y-8">
          {territorialRoutes.map((r, i) => (
            <article
              key={r.id}
              className="rounded-xl border border-border bg-card p-8 shadow-soft transition hover:shadow-lift"
            >
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <div>
                  <div className="font-mono text-xs text-muted-foreground">Ruta 0{i + 1}</div>
                  <h2 className="font-display mt-1 text-3xl">{r.title}</h2>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <span className="text-muted-foreground">{r.duration}</span>
                  <span
                    className={`rounded-full px-3 py-1 text-xs uppercase tracking-widest ${difficultyTone[r.difficulty]}`}
                  >
                    {r.difficulty}
                  </span>
                </div>
              </div>

              <ol className="mt-6 space-y-3">
                {r.steps.map((s, idx) => (
                  <li
                    key={s}
                    className="flex gap-4 border-t border-border pt-3 first:border-t-0 first:pt-0"
                  >
                    <span className="font-mono text-xs text-muted-foreground">
                      {String(idx + 1).padStart(2, "0")}
                    </span>
                    <span className="text-foreground/85">{s}</span>
                  </li>
                ))}
              </ol>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
