import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/comunidad")({
  head: () => ({
    meta: [{ title: "Comunidad — Real del Monte" }, { name: "description", content: "Habitantes, colectivos e iniciativas que sostienen el pueblo." }],
  }),
  component: Comunidad,
});

const voces = [
  { n: "Doña Eulalia", r: "Pastera, 3ª generación", q: "Aquí el paste no se vende, se entrega." },
  { n: "Mtro. Rosalío", r: "Guía de mina Acosta", q: "Adentro el silencio se oye con las manos." },
  { n: "Colectivo Niebla", r: "Cultura comunitaria", q: "Documentamos lo que el municipio olvida." },
  { n: "Familia Treviño", r: "Hospedaje patrimonio", q: "Restauramos casas, no las inventamos." },
];

function Comunidad() {
  return (
    <EditorialPage
      plano="Plano 01 · Experiencia"
      kicker="Comunidad"
      title={<>El pueblo es <span className="text-copper-700">su gente.</span></>}
      lead="RDM Digital existe gracias a quienes habitan, trabajan y cuidan el territorio. Cuatro voces que ya son parte del Nodo Cero."
      related={[
        { to: "/muro-experiencias", label: "Muro de experiencias" },
        { to: "/cultura-arte", label: "Cultura y arte" },
        { to: "/membresias", label: "Membresías" },
      ]}
    >
      <EditorialSection eyebrow="Voces" title="Cuatro testimonios del territorio.">
        <div className="grid gap-6 md:grid-cols-2">
          {voces.map((v) => (
            <blockquote key={v.n} className="rounded-xl border border-border/50 bg-card/40 p-6">
              <p className="font-display text-xl italic leading-snug">"{v.q}"</p>
              <footer className="mt-4 font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                {v.n} · {v.r}
              </footer>
            </blockquote>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
