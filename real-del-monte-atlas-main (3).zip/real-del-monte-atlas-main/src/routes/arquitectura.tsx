import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/arquitectura")({
  head: () => ({
    meta: [{ title: "Arquitectura MDX4 — Kernel Heptafederado" }, { name: "description", content: "Capas L0-L7 y siete federaciones del kernel territorial soberano." }],
  }),
  component: Arquitectura,
});

const capas = [
  { l: "L0", n: "Infraestructura física", d: "Nodos locales, conectividad, hardware soberano." },
  { l: "L1", n: "Memoria / Registro", d: "MSR · ledger SQL · Cattleya Pay · BookPI." },
  { l: "L2", n: "Protocolos controlados", d: "EOCT · motor de decisiones auditables." },
  { l: "L3", n: "Guardianía / Observabilidad", d: "Consolas, paneles ECG, monitoreo HITL." },
  { l: "L4", n: "XR / Gemelos", d: "Mapas 3D, Real del Monte Twin, Atlas territorial." },
  { l: "L5", n: "Servicios de dominio", d: "IDNVIDA, turismo, economía, comercio." },
  { l: "L6", n: "UX / Shell", d: "Portales, SPA, paneles comercio." },
  { l: "L7", n: "Civilizacional", d: "Legado, narrativa, federación de 100+ repos." },
];

const fed = ["Tecnológica", "Cultural", "Gubernamental", "Económica", "Educativa", "Salud", "Comunicación"];

function Arquitectura() {
  return (
    <EditorialPage
      plano="Plano 03 · Sistema"
      kicker="Kernel MDX4"
      title={<>Ocho capas. <span className="text-copper-700">Siete federaciones. Un kernel.</span></>}
      lead="El Kernel Heptafederado MDX4 organiza todo el ecosistema RDM Digital en capas funcionales y dominios soberanos. Cada repositorio, tabla y módulo encuentra aquí su coordenada."
      stats={[
        { k: "Capas", v: "L0 → L7" },
        { k: "Federaciones", v: "7" },
        { k: "Repos coordinados", v: "100+" },
        { k: "Estándar", v: "Open + Auditable" },
      ]}
      related={[
        { to: "/sistemas-nucleo", label: "Sistemas núcleo" },
        { to: "/manifiesto", label: "Manifiesto LTOS" },
        { to: "/federacion", label: "Federación Viva" },
      ]}
    >
      <EditorialSection eyebrow="Capas" title="L0 — L7 · Del suelo al legado.">
        <div className="space-y-2">
          {capas.map((c) => (
            <div key={c.l} className="grid grid-cols-[80px_1fr] gap-6 rounded-lg border border-border/40 bg-card/30 p-5">
              <div className="font-mono text-2xl text-copper-700">{c.l}</div>
              <div>
                <div className="font-display text-xl italic">{c.n}</div>
                <p className="mt-1 text-sm text-muted-foreground">{c.d}</p>
              </div>
            </div>
          ))}
        </div>
      </EditorialSection>
      <EditorialSection eyebrow="Federaciones" title="Siete dominios soberanos.">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {fed.map((f) => (
            <div key={f} className="rounded-lg border border-border/40 bg-card/30 px-4 py-3 text-center font-display text-lg italic">
              {f}
            </div>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
