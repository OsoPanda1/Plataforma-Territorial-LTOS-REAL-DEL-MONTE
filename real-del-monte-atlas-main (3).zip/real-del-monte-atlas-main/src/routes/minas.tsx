import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { mines } from "@/data/territory";
import img from "@/assets/chapter-minas.jpg";

export const Route = createFileRoute("/minas")({
  head: () => ({
    meta: [
      { title: "Las minas — Real del Monte" },
      {
        name: "description",
        content:
          "Las minas que sostienen el suelo de Real del Monte: Acosta, Dolores, Santa Inés, San Juan Pachuca. Memoria viva del ciclo de la plata.",
      },
      { property: "og:title", content: "Las minas — Real del Monte" },
      { property: "og:description", content: "Bajo el pueblo respira una segunda geografía." },
      { property: "og:image", content: img },
    ],
  }),
  component: Minas,
});

function Minas() {
  return (
    <>
      <PageHeader
        kicker="Capa I · Subsuelo"
        title="Bajo el pueblo respira una segunda geografía."
        intro="Galerías que sostuvieron la plata del mundo y dieron forma a todo lo que está arriba: el idioma, la cocina, los apellidos, el silencio que cae al atardecer."
        image={img}
      />

      <section className="container-prose pb-24">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <div className="eyebrow">Memoria operacional</div>
          </div>
          <div className="md:col-span-8">
            <p className="text-lg leading-relaxed text-foreground/85">
              Real del Monte fue, durante más de dos siglos, uno de los distritos mineros más
              importantes del mundo. La huelga de 1766 — la primera de América — comenzó aquí, entre
              estos túneles. Hoy las minas siguen siendo el corazón silencioso del pueblo: algunas
              son patrimonio, otras se recorren, otras se recuerdan.
            </p>
          </div>
        </div>

        <div className="mt-16 space-y-12">
          {mines.map((m, i) => (
            <article key={m.id} className="grid gap-6 border-t border-border pt-12 md:grid-cols-12">
              <div className="md:col-span-4">
                <div className="font-mono text-xs text-muted-foreground">
                  0{i + 1} · {m.founded}
                </div>
                <h2 className="font-display mt-2 text-4xl">{m.name}</h2>
                <span className="mt-3 inline-flex rounded-full border border-border bg-muted/50 px-3 py-1 text-xs text-muted-foreground">
                  {m.status}
                </span>
              </div>
              <div className="md:col-span-8">
                <p className="text-foreground/85 leading-relaxed">{m.description}</p>
                <div className="mt-6">
                  <div className="eyebrow">Conexiones</div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {m.connections.map((c) => (
                      <span
                        key={c}
                        className="rounded-md border border-border bg-card px-3 py-1 text-xs"
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
