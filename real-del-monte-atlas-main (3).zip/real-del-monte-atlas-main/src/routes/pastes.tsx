import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { pastes } from "@/data/territory";
import img from "@/assets/chapter-pastes.jpg";

export const Route = createFileRoute("/pastes")({
  head: () => ({
    meta: [
      { title: "Los pastes — Memoria comestible" },
      {
        name: "description",
        content:
          "Los pastes de Real del Monte: la negociación cotidiana entre Cornualles y la sierra de Hidalgo. Tradición, mestizaje y cocina viva.",
      },
      { property: "og:title", content: "Los pastes — Memoria comestible" },
      {
        property: "og:description",
        content: "Llegaron en bolsillos de mineros y se quedaron como ofrenda diaria.",
      },
      { property: "og:image", content: img },
    ],
  }),
  component: Pastes,
});

const tags: Record<string, string> = {
  tradicional: "Tradicional",
  mestizo: "Mestizo",
  contemporáneo: "Contemporáneo",
};

function Pastes() {
  return (
    <>
      <PageHeader
        kicker="Capa II · Memoria comestible"
        title="Una receta es también un tratado."
        intro="El paste cruzó el Atlántico en el bolsillo de un minero cornish, se cocinó al carbón en la sierra, recibió el chile y el mole, y aprendió a quedarse."
        image={img}
      />

      <section className="container-prose pb-24">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {pastes.map((p) => (
            <div
              key={p.name}
              className="rounded-xl border border-border bg-card p-6 shadow-soft transition hover:shadow-lift"
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-display text-2xl">{p.name}</h3>
                <span className="shrink-0 rounded-full border border-border bg-muted/50 px-2 py-0.5 text-[10px] uppercase tracking-widest text-muted-foreground">
                  {tags[p.origin]}
                </span>
              </div>
              <div className="eyebrow mt-3">Relleno</div>
              <p className="mt-1 text-sm text-foreground/85">{p.filling}</p>
              <p className="mt-5 border-t border-border pt-4 text-sm italic text-muted-foreground">
                {p.note}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-20 rounded-2xl bg-gradient-copper p-10 text-primary-foreground md:p-16">
          <div className="eyebrow text-primary-foreground/70">Festival</div>
          <h2 className="display-lg mt-3 text-balance">Cada octubre el pueblo huele a horno.</h2>
          <p className="mt-4 max-w-2xl text-primary-foreground/85">
            El Festival Internacional del Paste reúne a cocineros, panaderos y a delegaciones de
            Cornualles. Es la conversación culinaria más antigua entre Inglaterra y México, servida
            en una sola pieza hojaldrada.
          </p>
        </div>
      </section>
    </>
  );
}
