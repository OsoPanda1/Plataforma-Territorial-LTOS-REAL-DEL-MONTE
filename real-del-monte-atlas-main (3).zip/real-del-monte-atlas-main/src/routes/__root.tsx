import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";

import { reportLovableError } from "../lib/lovable-error-reporting";

import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";

/* -------------------------------------------------------------------------- */
/*                              SEMIÓTICA ATMOSFÉRICA                         */
/* -------------------------------------------------------------------------- */

/**
 * LTOS v4 — Living Territorial Operating System
 *
 * Filosofía:
 * Las plataformas memorables no describen. Sugieren.
 * La interfaz induce conclusiones sin declararlas.
 *
 * Capas de atmósfera que comunican sin palabras:
 *
 * - Heritage (cobre oxidado): Memoria profunda, peso histórico
 * - Intelligence (señal azul): Pulso cognitivo, sistema vivo
 * - Nature (bosque verde): Raíz territorial, organismo conectado
 * - Federation (púrpura): Red latente, nodos dormidos
 *
 * No se explica qué es el sistema.
 * Se induce la sensación de estar dentro de algo más grande.
 *
 * El usuario no lee "somos una infraestructura territorial".
 * El usuario SIENTE que acaba de entrar a un organismo vivo.
 */

/* -------------------------------------------------------------------------- */
/*                                   404                                      */
/* -------------------------------------------------------------------------- */

function NotFoundComponent() {
  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden">
      <Header />

      {/* Atmospheric disruption — señal de desconexión */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-32 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-signal-500/[0.03] blur-[140px] opacity-60" />
        <div className="absolute right-1/4 top-1/2 h-[400px] w-[400px] rounded-full bg-copper-500/[0.02] blur-[120px]" />
      </div>

      <div className="container-narrow relative flex flex-1 flex-col items-center justify-center py-40 text-center">
        {/* Semiótica: "ruta sin cartografiar" >> territorio en expansión */}
        <div className="inline-flex items-center gap-2 rounded-full border border-border/30 bg-card/40 px-4 py-1.5 backdrop-blur-xl">
          <div className="h-1.5 w-1.5 rounded-full bg-signal-400 opacity-60" />
          <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-muted-foreground">
            Ruta sin cartografiar
          </span>
        </div>

        <h1 className="mt-8 font-display text-5xl italic leading-[1.1] text-foreground/95 md:text-6xl">
          Este punto aún no existe
          <span className="block mt-2 text-3xl font-sans not-italic text-muted-foreground/80 md:text-4xl">
            en el mapa conocido.
          </span>
        </h1>

        <p className="mt-6 max-w-lg text-sm leading-relaxed text-muted-foreground/80">
          El territorio está en constante expansión. Algunas coordenadas todavía están siendo
          trazadas.
        </p>

        <Link
          to="/"
          className="group mt-10 inline-flex items-center gap-2 rounded-full border border-border/40 bg-card/60 px-6 py-3 text-sm font-medium backdrop-blur-xl transition-all hover:border-foreground/20 hover:bg-card/80"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="transition-transform group-hover:-translate-x-0.5"
          >
            <path d="m12 19-7-7 7-7" />
            <path d="M19 12H5" />
          </svg>
          Punto de origen
        </Link>
      </div>

      <Footer />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                 ERROR                                      */
/* -------------------------------------------------------------------------- */

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();

  useEffect(() => {
    console.error(error);

    reportLovableError(error, {
      boundary: "tanstack_root_error_component",
    });
  }, [error]);

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-6">
      {/* Atmospheric disturbance — señal rota */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 animate-pulse rounded-full bg-signal-500/[0.02] blur-[180px] opacity-40" />
        <div className="absolute bottom-1/4 right-1/3 h-[500px] w-[500px] rounded-full bg-copper-500/[0.02] blur-[160px] opacity-30" />
      </div>

      <div className="container-narrow relative text-center">
        {/* Semiótica: "conexión interrumpida" >> sistema auto-reparable */}
        <div className="inline-flex items-center gap-2 rounded-full border border-border/30 bg-card/40 px-4 py-1.5 backdrop-blur-xl">
          <div className="h-1.5 w-1.5 animate-pulse rounded-full bg-signal-400" />
          <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-muted-foreground">
            Conexión interrumpida
          </span>
        </div>

        <h1 className="mt-8 font-display text-5xl italic leading-[1.1] text-foreground/95 md:text-6xl">
          Esta capa dejó
          <span className="block mt-2 text-3xl font-sans not-italic text-muted-foreground/80 md:text-4xl">
            de responder.
          </span>
        </h1>

        <p className="mt-6 text-sm leading-relaxed text-muted-foreground/80">
          La señal con este punto territorial se perdió temporalmente.
        </p>

        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="group inline-flex items-center gap-2 rounded-full border border-border/40 bg-card/60 px-6 py-3 text-sm font-medium backdrop-blur-xl transition-all hover:border-foreground/20 hover:bg-card/80"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="transition-transform group-hover:rotate-180"
            >
              <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
              <path d="M21 3v5h-5" />
              <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
              <path d="M8 16H3v5" />
            </svg>
            Reconectar señal
          </button>

          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-full border border-border/40 bg-transparent px-6 py-3 text-sm font-medium backdrop-blur-xl transition-all hover:bg-card/40"
          >
            Punto de origen
          </Link>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                                   ROUTE                                   */
/* -------------------------------------------------------------------------- */

export const Route = createRootRouteWithContext<{
  queryClient: QueryClient;
}>()({
  head: () => ({
    meta: [
      {
        charSet: "utf-8",
      },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1",
      },

      /* SEO Semiótico — No describe, sugiere */
      {
        title: "Nodo Cero · TAMV",
      },
      {
        name: "description",
        content:
          "Un territorio que existe en dos dimensiones. Una física, una digital. Ambas conectadas.",
      },
      {
        name: "author",
        content: "TAMV",
      },

      /* Open Graph — Narrativa de misterio controlado */
      {
        property: "og:title",
        content: "Nodo Cero",
      },
      {
        property: "og:description",
        content:
          "Primer nodo de una infraestructura territorial que no se limita a mostrar información. La convierte en experiencia.",
      },
      {
        property: "og:type",
        content: "website",
      },
      {
        property: "og:site_name",
        content: "TAMV",
      },

      /* Twitter Card */
      {
        name: "twitter:card",
        content: "summary_large_image",
      },
      {
        name: "twitter:title",
        content: "Nodo Cero · TAMV",
      },
      {
        name: "twitter:description",
        content: "Un territorio vivo. Un sistema operativo territorial. Una red en expansión.",
      },

      /* Theme — Oscuridad profunda como base */
      {
        name: "theme-color",
        content: "#0a0d12",
      },

      /* Keywords semióticos — No literales */
      {
        name: "keywords",
        content:
          "infraestructura territorial, sistema vivo, conocimiento conectado, inteligencia contextual, federación territorial",
      },
    ],

    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      {
        rel: "preconnect",
        href: "https://fonts.googleapis.com",
      },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
    ],
  }),

  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

/* -------------------------------------------------------------------------- */
/*                                   SHELL                                   */
/* -------------------------------------------------------------------------- */

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>

      <body className="bg-background text-foreground antialiased">
        {children}
        <Scripts />
      </body>
    </html>
  );
}

/* -------------------------------------------------------------------------- */
/*                          ROOT COMPONENT — LTOS v4                         */
/* -------------------------------------------------------------------------- */

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="relative flex min-h-screen flex-col overflow-hidden">
        {/* 
          ═══════════════════════════════════════════════════════════════════
          ATMOSPHERIC INTELLIGENCE LAYER
          ═══════════════════════════════════════════════════════════════════
          
          Semiótica visual — Comunicación sin palabras:
          
          1. Señal central (azul/signal): Sistema nervioso activo
             → Usuario infiere: "Esto está vivo, no es estático"
          
          2. Cobre inferior izquierdo: Memoria histórica profunda
             → Usuario infiere: "Hay capas de tiempo aquí"
          
          3. Verde inferior derecho: Raíz territorial
             → Usuario infiere: "Está conectado con algo físico"
          
          4. Púrpura superior derecho: Nodos federados latentes
             → Usuario infiere: "Hay más de esto en otro lugar"
          
          NO SE MENCIONA QUÉ SIGNIFICAN.
          SE EXPERIMENTA COMO PRESENCIA MULTI-DIMENSIONAL.
          
          La diferencia entre describir y sugerir.
        */}
        <div className="pointer-events-none fixed inset-0 -z-10">
          {/* Intelligence pulse — sistema vivo */}
          <div
            className="absolute left-1/2 top-0 h-[900px] w-[900px] -translate-x-1/2 rounded-full bg-signal-500/[0.035] blur-[220px]"
            style={{
              animation: "breathe 12s ease-in-out infinite",
            }}
          />

          {/* Heritage depth — memoria profunda */}
          <div
            className="absolute bottom-0 left-0 h-[600px] w-[600px] rounded-full bg-copper-500/[0.025] blur-[180px]"
            style={{
              animation: "breathe 14s ease-in-out infinite",
              animationDelay: "2s",
            }}
          />

          {/* Nature root — raíz territorial */}
          <div
            className="absolute bottom-0 right-0 h-[500px] w-[500px] rounded-full bg-forest-500/[0.02] blur-[160px]"
            style={{
              animation: "breathe 16s ease-in-out infinite",
              animationDelay: "4s",
            }}
          />

          {/* Federation latent — red dormida */}
          <div
            className="absolute right-0 top-1/4 h-[400px] w-[400px] rounded-full bg-federation-500/[0.015] blur-[140px]"
            style={{
              animation: "breathe 18s ease-in-out infinite",
              animationDelay: "6s",
            }}
          />
        </div>

        {/* 
          ═══════════════════════════════════════════════════════════════════
          PERSISTENT NODE IDENTITY
          ═══════════════════════════════════════════════════════════════════
          
          Semiótica de posición:
          - Bottom right: punto de referencia constante
          - Señal pulsante: indica sistema operativo, no página web
          - "Nodo Cero": punto de origen, no "primer territorio"
          
          NO EXPLICA FEDERACIÓN.
          SUGIERE QUE HAY MÁS NODOS POR VENIR.
        */}
        <div className="pointer-events-none fixed bottom-6 right-6 z-50 hidden xl:block">
          <div className="group rounded-full border border-border/30 bg-card/40 px-4 py-2 backdrop-blur-xl transition-all hover:border-signal-400/40">
            <div className="flex items-center gap-2.5">
              {/* Señal viva — sistema activo */}
              <div className="relative flex h-2 w-2 items-center justify-center">
                <div className="absolute h-2 w-2 animate-ping rounded-full bg-signal-400 opacity-75" />
                <div className="relative h-1.5 w-1.5 rounded-full bg-signal-500" />
              </div>

              <div className="font-mono text-[10px] uppercase tracking-[0.35em] text-muted-foreground transition-colors group-hover:text-foreground">
                Nodo Cero
              </div>
            </div>
          </div>
        </div>

        {/* 
          ═══════════════════════════════════════════════════════════════════
          TERRITORIAL COORDINATE SYSTEM
          ═══════════════════════════════════════════════════════════════════
          
          Semiótica de ubicación:
          - NO dice "Real del Monte, Hidalgo"
          - DICE coordenadas como sistema de referencia espacial
          - Sugiere infraestructura científica, no turismo
          
          Mobile hidden — información para usuarios avanzados.
        */}
        <div className="pointer-events-none fixed bottom-6 left-6 z-50 hidden 2xl:block">
          <div className="rounded-lg border border-border/20 bg-card/30 px-3 py-2 backdrop-blur-xl">
            <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-muted-foreground/60">
              20°08'N · 98°44'W
            </div>
          </div>
        </div>

        {/* 
          ═══════════════════════════════════════════════════════════════════
          SYSTEM STATUS INDICATOR
          ═══════════════════════════════════════════════════════════════════
          
          Semiótica de estado:
          - Top left: información de sistema, no branding
          - "LTOS v2.0": versión como software, no como web
          - "Operativo": estado de infraestructura
          
          NO DICE "BIENVENIDO".
          DICE "EL SISTEMA ESTÁ FUNCIONANDO".
        */}
        <div className="pointer-events-none fixed left-6 top-6 z-50 hidden 2xl:block">
          <div className="rounded-lg border border-border/20 bg-card/30 px-3 py-2 backdrop-blur-xl">
            <div className="flex items-center gap-2">
              <div className="h-1 w-1 rounded-full bg-pulse-500 animate-pulse" />
              <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-muted-foreground/60">
                LTOS v2.0 · Operativo
              </div>
            </div>
          </div>
        </div>

        {/* 
          ═══════════════════════════════════════════════════════════════════
          FEDERATION NETWORK HINT
          ═══════════════════════════════════════════════════════════════════
          
          Semiótica de escala:
          - Top right: sugiere red más grande
          - "1/∞": primer nodo de infinitos posibles
          - NO EXPLICA QUÉ ES FEDERACIÓN
          - INDUCE CURIOSIDAD SOBRE LO QUE VENDRÁ
        */}
        <div className="pointer-events-none fixed right-6 top-6 z-50 hidden 2xl:block">
          <div className="rounded-lg border border-border/20 bg-card/30 px-3 py-2 backdrop-blur-xl">
            <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-muted-foreground/60">
              Nodo 1/∞
            </div>
          </div>
        </div>

        <Header />

        <main className="relative flex-1">
          <Outlet />
        </main>

        <Footer />
      </div>
    </QueryClientProvider>
  );
}

/* 
  ═════════════════════════════════════════════════════════════════════════
  KEYFRAMES — Añadir al final de styles.css
  ═════════════════════════════════════════════════════════════════════════
*/

/*
@keyframes breathe {
  0%, 100% {
    opacity: 0.035;
    transform: scale(1);
  }
  50% {
    opacity: 0.05;
    transform: scale(1.05);
  }
}

@keyframes signal-pulse {
  0%, 100% {
    opacity: 0.75;
    box-shadow: 0 0 0 0 oklch(0.62 0.22 280 / 0.4);
  }
  50% {
    opacity: 1;
    box-shadow: 0 0 0 6px oklch(0.62 0.22 280 / 0);
  }
}

@keyframes node-emerge {
  from {
    opacity: 0;
    transform: translateY(10px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}
*/
