import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/muro-experiencias")({
  head: () => ({ meta: [{ title: "Muro de experiencias — RDM Digital" }] }),
  component: Muro,
});

const experiencias = [
  { a: "Marina · CDMX", q: "Bajé a la mina Acosta y entendí por qué este pueblo se mide en silencios.", d: "Hace 3 días" },
  { a: "Familia Ortega · Pachuca", q: "El paste de don Beto es un acto de fe. Volvimos por tercera vez.", d: "Hace 1 semana" },
  { a: "Lucía · Madrid", q: "Cementerio inglés al amanecer. Niebla, lápidas en cornish y un pueblo abajo.", d: "Hace 2 semanas" },
];

function Muro() {
  return (
    <EditorialPage
      plano="Plano 01 · Experiencia"
      kicker="Voces visitantes"
      title={<>Lo que el territorio <span className="text-copper-700">les dejó.</span></>}
      lead="Reseñas curadas por guardianes del Nodo. Cada experiencia queda anclada al lugar y la fecha en el atlas."
      related={[{ to: "/comunidad", label: "Comunidad" }, { to: "/atlas", label: "Atlas" }, { to: "/perfil", label: "Tu perfil" }]}
    >
      <EditorialSection>
        <div className="space-y-6">
          {experiencias.map((e) => (
            <article key={e.a} className="rounded-xl border border-border/50 bg-card/40 p-6">
              <p className="font-display text-xl italic">"{e.q}"</p>
              <footer className="mt-4 flex items-center justify-between font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                <span>{e.a}</span><span>{e.d}</span>
              </footer>
            </article>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
