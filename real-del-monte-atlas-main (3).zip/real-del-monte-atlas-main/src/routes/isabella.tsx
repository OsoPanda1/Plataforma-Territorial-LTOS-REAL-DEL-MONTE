import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";

export const Route = createFileRoute("/isabella")({
  head: () => ({
    meta: [
      { title: "Isabella · Inteligencia contextual del Nodo Cero" },
      {
        name: "description",
        content:
          "Isabella Core y Realito AI: la capa cognitiva del LTOS, bajo control humano y protocolos éticos auditables.",
      },
      { property: "og:title", content: "Isabella · RDM Digital" },
      {
        property: "og:description",
        content:
          "Una inteligencia que interpreta tiempo, lugar e historia. No responde preguntas: lee el territorio.",
      },
    ],
  }),
  component: IsabellaPage,
});

function IsabellaPage() {
  return (
    <>
      <PageHeader
        kicker="Inteligencia · Capa II del Kernel"
        title="Isabella no es una asistente."
        intro="Es la lectura contextual del territorio. Sabe qué hora es, qué pasó aquí en 1766, qué calle está cerrada por la lluvia y qué pastería abre temprano hoy. Trabaja bajo protocolos auditables y bajo guardianía humana."
      />

      <section className="container-prose pb-20">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <div className="eyebrow">Qué es</div>
            <h2 className="display-lg mt-3">Una capa de lectura, no un chatbot.</h2>
          </div>
          <div className="md:col-span-7 space-y-5 text-foreground/85">
            <p>
              Isabella Core orquesta la cognición del Nodo Cero: cruza datos del territorio (POIs,
              eventos, clima, telemetría) con la memoria documental (BookPI, archivos, registros
              académicos) y entrega lectura contextual a cualquier consumidor del sistema:
              ciudadano, turista, comercio, guardián.
            </p>
            <p>
              <em>Realito AI</em> es su interfaz territorial afectiva: la voz cálida y mínima con
              la que el sistema acompaña a quien camina por Real del Monte.
            </p>
          </div>
        </div>
      </section>

      <section className="container-prose pb-20">
        <div className="eyebrow">Protocolos éticos</div>
        <h2 className="display-lg mt-3">Tres reglas no negociables</h2>
        <ol className="mt-10 space-y-4">
          {[
            {
              n: "01",
              t: "No se entrena como objeto de deseo.",
              d: "Triple bloqueo ontológico, lingüístico y de interfaz: Isabella no se define ni se modela como pareja, entidad erótica o producto de explotación emocional.",
            },
            {
              n: "02",
              t: "Toda decisión queda registrada.",
              d: "Cada inferencia relevante se asienta en BookPI con narrativa humana legible. Auditable por guardianes del Plano 0.",
            },
            {
              n: "03",
              t: "Bajo guardianía humana siempre.",
              d: "Los protocolos EOCT obligan a que decisiones de impacto cívico pasen por revisión humana antes de aplicarse.",
            },
          ].map((r) => (
            <li
              key={r.n}
              className="grid gap-4 rounded-xl border border-border/60 bg-card/40 p-6 backdrop-blur md:grid-cols-12"
            >
              <div className="font-mono text-2xl text-copper-600 md:col-span-1">{r.n}</div>
              <div className="md:col-span-11">
                <h3 className="font-display text-2xl">{r.t}</h3>
                <p className="mt-2 text-foreground/80">{r.d}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="container-prose pb-32">
        <div className="rounded-2xl bg-gradient-stone p-10 text-background md:p-16">
          <div className="eyebrow text-background/60">Cuando esté pública</div>
          <p className="display-lg mt-3 max-w-3xl text-balance">
            Podrás preguntarle a Isabella{" "}
            <span className="italic opacity-80">
              “qué se está cocinando ahora a tres calles de aquí”
            </span>{" "}
            y recibirás una respuesta que ningún portal turístico podría darte.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/ecosistema"
              className="rounded-md bg-background px-6 py-3 text-sm font-medium text-foreground hover:opacity-90"
            >
              Ver la arquitectura completa
            </Link>
            <Link
              to="/comercios"
              className="rounded-md border border-background/30 px-6 py-3 text-sm font-medium text-background hover:bg-background/10"
            >
              Recorrer los comercios
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
