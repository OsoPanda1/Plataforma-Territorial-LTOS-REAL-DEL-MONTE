import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/perfil")({
  head: () => ({ meta: [{ title: "Perfil — RDM Digital" }] }),
  component: Perfil,
});

function Perfil() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Identidad"
      title={<>Tu recorrido <span className="text-copper-700">queda registrado.</span></>}
      lead="El perfil es tu copia soberana del territorio: rutas caminadas, lugares marcados, comercios visitados, experiencias publicadas."
      related={[
        { to: "/membresias", label: "Membresías" },
        { to: "/muro-experiencias", label: "Muro de experiencias" },
        { to: "/ajustes", label: "Ajustes" },
      ]}
    >
      <EditorialSection>
        <p>
          Tus datos son tuyos. Puedes exportarlos, eliminarlos o donarlos a la memoria colectiva en
          cualquier momento desde <strong>ajustes</strong>. Ninguna métrica personal se vende ni se
          comparte fuera del Nodo Cero.
        </p>
        <p className="mt-4 text-sm text-muted-foreground">
          Inicia sesión para activar tu perfil — el módulo de autenticación se habilitará en la
          próxima iteración pública.
        </p>
      </EditorialSection>
    </EditorialPage>
  );
}
