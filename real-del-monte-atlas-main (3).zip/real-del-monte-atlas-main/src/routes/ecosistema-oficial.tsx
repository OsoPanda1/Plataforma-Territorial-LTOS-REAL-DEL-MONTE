import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/ecosistema-oficial")({
  head: () => ({ meta: [{ title: "Ecosistema oficial — RDM Digital" }] }),
  component: EcoOf,
});

const sitios = [
  { k: "RDM Digital · Nodo Cero", v: "rdm.digital", t: "Portal oficial" },
  { k: "TAMV ONLINE", v: "tamv.online", t: "Marco federativo" },
  { k: "Real del Monte Atlas", v: "atlas.rdm.digital", t: "Cartografía viva" },
  { k: "RDM·X · Nexus turístico", v: "nexus.rdm.digital", t: "Hub de turismo" },
  { k: "Wiki TAMV", v: "wiki.tamv.online", t: "Documentación abierta" },
];

function EcoOf() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Verificación"
      title={<>Sitios y canales <span className="text-copper-700">verificados.</span></>}
      lead="Toda comunicación oficial pasa por estos dominios. Cualquier otro canal no representa al Nodo Cero."
      related={[
        { to: "/contacto", label: "Contacto" },
        { to: "/federacion", label: "Federación Viva" },
        { to: "/canon-academico", label: "Canon académico" },
      ]}
    >
      <EditorialSection>
        <div className="overflow-hidden rounded-xl border border-border/50">
          <table className="w-full text-left text-sm">
            <thead className="bg-card/40 font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              <tr><th className="p-4">Plataforma</th><th className="p-4">Dominio</th><th className="p-4">Tipo</th></tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {sitios.map((s) => (
                <tr key={s.k}>
                  <td className="p-4 font-display text-lg">{s.k}</td>
                  <td className="p-4 font-mono text-copper-700">{s.v}</td>
                  <td className="p-4 text-muted-foreground">{s.t}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
