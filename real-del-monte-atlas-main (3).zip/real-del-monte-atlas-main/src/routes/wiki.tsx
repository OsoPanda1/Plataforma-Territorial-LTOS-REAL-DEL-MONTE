import { createFileRoute, Link } from "@tanstack/react-router";
import { EditorialPage } from "@/components/site/EditorialPage";
import { ArrowUpRight } from "lucide-react";

export const Route = createFileRoute("/wiki")({
  head: () => ({ meta: [{ title: "Wiki RDM Digital — Índice general" }, { name: "description", content: "Índice general de la Wiki Oficial del Nodo Cero LTOS." }] }),
  component: Wiki,
});

const planos = [
  {
    n: "01",
    t: "Experiencia turística",
    d: "La cara pública del Nodo Cero. Lo que cualquier visitante encuentra primero.",
    items: [
      ["/", "Portada"],
      ["/historia", "Historia"],
      ["/cultura-arte", "Cultura & Arte"],
      ["/ecoturismo", "Ecoturismo"],
      ["/leyendas", "Mitos y leyendas"],
      ["/dichos", "Dichos mineros"],
      ["/comunidad", "Comunidad"],
      ["/muro-experiencias", "Muro de experiencias"],
      ["/atlas", "Mapa interactivo"],
      ["/comercios", "Comercios"],
      ["/calendario", "Calendario"],
      ["/eventos", "Eventos"],
      ["/rutas", "Rutas"],
      ["/perfil", "Perfil"],
      ["/membresias", "Membresías"],
      ["/donaciones", "Donaciones"],
    ],
  },
  {
    n: "02",
    t: "Capa institucional",
    d: "Quiénes somos, por qué existimos, a quién servimos.",
    items: [
      ["/acerca-de", "Acerca de"],
      ["/que-es-rdm-digital", "¿Qué es RDM Digital?"],
      ["/mision-vision", "Misión y visión"],
      ["/fundador", "Arquitecto raíz"],
      ["/faq", "FAQ"],
      ["/ajustes", "Ajustes"],
      ["/contacto", "Contacto"],
      ["/ecosistema-oficial", "Ecosistema oficial"],
    ],
  },
  {
    n: "03",
    t: "Núcleo documental y tecnológico",
    d: "Arquitectura, sistemas, repos, canon académico. Para expertos.",
    items: [
      ["/manifiesto", "Manifiesto LTOS"],
      ["/arquitectura", "Arquitectura MDX4"],
      ["/sistemas-nucleo", "Sistemas núcleo"],
      ["/economia", "Economía soberana"],
      ["/isabella", "Isabella & Realito"],
      ["/ecosistema", "Ecosistema técnico"],
      ["/federacion", "Federación Viva"],
      ["/canon-academico", "Canon académico"],
    ],
  },
];

function Wiki() {
  return (
    <EditorialPage
      plano="Wiki oficial · Nodo Cero"
      kicker="Índice general"
      title={<>Tres planos. <span className="text-copper-700">Un solo territorio.</span></>}
      lead="La Wiki RDM Digital organiza toda la plataforma en tres planos coherentes. Empieza por donde resuene tu pregunta."
      stats={[
        { k: "Planos", v: "3" },
        { k: "Entradas", v: "32+" },
        { k: "Federación", v: "TAMV · MDX4" },
        { k: "Versión", v: "v2026.01" },
      ]}
    >
      <div className="space-y-16">
        {planos.map((p) => (
          <section key={p.n}>
            <div className="flex items-baseline gap-4">
              <span className="font-mono text-3xl text-copper-700">{p.n}</span>
              <div>
                <h2 className="font-display text-3xl italic">{p.t}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{p.d}</p>
              </div>
            </div>
            <div className="mt-6 grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {p.items.map(([to, label]) => (
                <Link key={to} to={to} className="group flex items-center justify-between bg-background/80 px-5 py-4 transition hover:bg-card">
                  <span className="text-sm">{label}</span>
                  <ArrowUpRight className="h-3 w-3 opacity-30 transition group-hover:opacity-80" />
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </EditorialPage>
  );
}
