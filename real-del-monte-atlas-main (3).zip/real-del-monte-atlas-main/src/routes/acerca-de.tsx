import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/acerca-de")({
  head: () => ({ meta: [{ title: "Acerca de — RDM Digital" }, { name: "description", content: "Qué es RDM Digital y por qué Real del Monte es el primer nodo de un sistema territorial soberano." }] }),
  component: Acerca,
});

function Acerca() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Identidad"
      title={<>Un pueblo. Un sistema. <span className="text-copper-700">Una infraestructura.</span></>}
      lead="RDM Digital es la primera implementación pública de un Living Territorial Operating System. Une turismo inteligente, identidad ciudadana, gemelos digitales y economía local en una sola capa auditable."
      related={[
        { to: "/que-es-rdm-digital", label: "¿Qué es RDM Digital?" },
        { to: "/mision-vision", label: "Misión y visión" },
        { to: "/manifiesto", label: "Manifiesto LTOS" },
      ]}
    >
      <EditorialSection>
        <p>
          No somos una app turística ni un portal municipal. Somos un sistema operativo territorial que
          convierte la ciudad física en infraestructura digital interoperable, documentada con estándares
          académicos abiertos y gobernada por principios éticos explícitos.
        </p>
        <p className="mt-4">
          Real del Monte es el <strong>Nodo Cero</strong>: el primer territorio que opera su propio
          sistema operativo urbano. Lo que aquí se prueba puede después federarse a otros pueblos
          mágicos y municipios.
        </p>
      </EditorialSection>
    </EditorialPage>
  );
}
