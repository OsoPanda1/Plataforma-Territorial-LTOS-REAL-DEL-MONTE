import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const BASE_URL = "";

const paths = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/atlas", changefreq: "weekly", priority: "0.9" },
  { path: "/minas", changefreq: "monthly", priority: "0.8" },
  { path: "/pastes", changefreq: "monthly", priority: "0.8" },
  { path: "/cementerio", changefreq: "monthly", priority: "0.7" },
  { path: "/calles", changefreq: "monthly", priority: "0.7" },
  { path: "/leyendas", changefreq: "monthly", priority: "0.7" },
  { path: "/rutas", changefreq: "monthly", priority: "0.8" },
  { path: "/eventos", changefreq: "weekly", priority: "0.7" },
  { path: "/manifiesto", changefreq: "yearly", priority: "0.5" },
] as const;

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const urls = paths
          .map(
            (e) =>
              `  <url>\n    <loc>${BASE_URL}${e.path}</loc>\n    <changefreq>${e.changefreq}</changefreq>\n    <priority>${e.priority}</priority>\n  </url>`,
          )
          .join("\n");
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;
        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
