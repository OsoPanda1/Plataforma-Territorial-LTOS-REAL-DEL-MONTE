import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/contacto")({
  head: () => ({ meta: [{ title: "Contacto — RDM Digital" }] }),
  component: Contacto,
});

const canales = [
  { k: "General", v: "hola@rdm.digital" },
  { k: "Comercios y membresías", v: "comercio@rdm.digital" },
  { k: "Prensa y medios", v: "prensa@rdm.digital" },
  { k: "Investigación y academia", v: "research@rdm.digital" },
  { k: "Federación territorial", v: "federacion@rdm.digital" },
];

function Contacto() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Contacto"
      title={<>Canales abiertos. <span className="text-copper-700">Voz directa.</span></>}
      lead="Cada interacción se enruta a la federación correspondiente. Respondemos en menos de 72 horas hábiles."
      related={[
        { to: "/faq", label: "FAQ" },
        { to: "/ecosistema-oficial", label: "Ecosistema oficial" },
        { to: "/membresias", label: "Membresías" },
      ]}
    >
      <EditorialSection eyebrow="Canales">
        <div className="grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-2">
          {canales.map((c) => (
            <div key={c.k} className="bg-background/80 p-6">
              <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-copper-700">
                {c.k}
              </div>
              <div className="mt-2 font-display text-xl text-foreground">{c.v}</div>
            </div>
          ))}
        </div>
      </EditorialSection>
      <EditorialSection eyebrow="Presencia física" title="Real del Monte, Hidalgo.">
        <p>Punto de referencia: Plaza Principal. Coordenadas: 20.143°N, 98.671°W · Altitud 2 760 m.</p>
      </EditorialSection>
    </EditorialPage>
  );
}
