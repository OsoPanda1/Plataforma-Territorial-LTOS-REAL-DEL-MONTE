import { createFileRoute, Link } from "@tanstack/react-router";
import heroImg from "@/assets/hero-realdelmonte.jpg";
import { chapters, territoryStats } from "@/data/territory";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RDM Digital · Real del Monte como territorio vivo" },
      {
        name: "description",
        content:
          "Cada calle guarda una historia. Cada historia conecta con algo más. Explora Real del Monte como territorio vivo: minas, pastes, leyendas, rutas y memoria.",
      },
      { property: "og:title", content: "RDM Digital · Real del Monte como territorio vivo" },
      {
        property: "og:description",
        content: "Cada calle guarda una historia. Cada historia conecta con algo más.",
      },
      { property: "og:image", content: heroImg },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      {/* HERO */}
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img
            src={heroImg}
            alt="Real del Monte al amanecer, niebla entre la sierra"
            className="h-full w-full object-cover"
            width={1920}
            height={1080}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/60 to-background" />
        </div>

        <div className="mx-auto max-w-7xl px-6 pt-24 pb-32 md:pt-40 md:pb-48">
          <div className="max-w-3xl">
            <div className="eyebrow">Primer nodo · Living Territorial OS</div>
            <h1 className="display-xl mt-6 text-balance">
              Cada calle guarda una historia.
              <span className="block italic text-copper">Cada historia conecta con algo más.</span>
            </h1>
            <p className="mt-8 max-w-xl text-lg leading-relaxed text-foreground/80">
              Real del Monte no es un destino. Es un territorio que se sigue escribiendo. Aquí
              puedes recorrer sus capas: las minas que sostienen el suelo, los pastes que cruzaron
              un océano, las calles que aprendieron a inclinarse contra la lluvia.
            </p>

            <div className="mt-10 flex flex-wrap gap-3">
              <Link
                to="/atlas"
                className="inline-flex items-center rounded-md bg-foreground px-6 py-3 text-sm font-medium text-background transition hover:opacity-90"
              >
                Abrir el atlas
              </Link>
              <Link
                to="/rutas"
                className="inline-flex items-center rounded-md border border-border bg-background/60 px-6 py-3 text-sm font-medium backdrop-blur transition hover:bg-background"
              >
                Recorrer una ruta
              </Link>
            </div>
          </div>
        </div>

        {/* Stats strip */}
        <div className="border-y border-border/60 bg-background/80 backdrop-blur">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-y-6 px-6 py-6 md:grid-cols-4">
            {[
              { k: "Altitud", v: territoryStats.altitude },
              { k: "Fundación", v: territoryStats.founded },
              { k: "Habitantes", v: territoryStats.population },
              { k: "Desde CDMX", v: territoryStats.klmFromCDMX },
            ].map((s) => (
              <div key={s.k}>
                <div className="eyebrow">{s.k}</div>
                <div className="mt-1 font-display text-2xl">{s.v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INTRO */}
      <section className="container-prose py-24 md:py-32">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-4">
            <div className="eyebrow">El territorio es la interfaz</div>
          </div>
          <div className="md:col-span-8">
            <p className="display-lg text-balance">
              La historia no está detrás de ti.{" "}
              <span className="text-muted-foreground">Sigue ocurriendo aquí.</span>
            </p>
            <p className="mt-8 text-lg leading-relaxed text-foreground/80">
              RDM Digital representa, conecta y preserva la realidad física, cultural y humana de
              Real del Monte. No es una guía turística ni un portal municipal: es un sistema
              operativo territorial diseñado para que un lugar pueda mirarse, recordarse y
              evolucionar.
            </p>
          </div>
        </div>
      </section>

      {/* CHAPTERS */}
      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="flex items-end justify-between">
          <div>
            <div className="eyebrow">Capas del territorio</div>
            <h2 className="display-lg mt-3">Por dónde empezar</h2>
          </div>
          <Link
            to="/atlas"
            className="hidden text-sm text-muted-foreground hover:text-foreground md:inline"
          >
            Ver el atlas completo →
          </Link>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {chapters.map((c, i) => (
            <Link
              key={c.slug}
              to={c.href}
              className={`group relative isolate overflow-hidden rounded-xl border border-border bg-card shadow-soft transition hover:shadow-lift ${
                i % 3 === 0 ? "md:col-span-2" : ""
              }`}
            >
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={c.image}
                  alt={c.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                />
              </div>
              <div className="p-8">
                <div className="eyebrow">{c.kicker}</div>
                <h3 className="font-display mt-3 text-3xl">{c.title}</h3>
                <p className="mt-3 max-w-lg text-foreground/75 leading-relaxed">{c.blurb}</p>
                <span className="mt-6 inline-block text-sm text-copper transition group-hover:translate-x-1">
                  Descubrir →
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* MÁS CAPAS */}
      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="eyebrow">Más allá del recorrido</div>
        <h2 className="display-lg mt-3">El sistema completo</h2>
        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[
            { to: "/comercios", k: "Capa V", t: "Comercios", d: "Pasterías, cafés, posadas y guías que sostienen la vida cotidiana." },
            { to: "/dichos", k: "Capa III", t: "Dichos", d: "Archivo histórico de jerga realmontense. Cada apellido es una contraseña." },
            { to: "/isabella", k: "Cognición", t: "Isabella", d: "Lectura contextual del territorio. No es un chatbot." },
            { to: "/ecosistema", k: "Arquitectura", t: "Ecosistema", d: "Las 7 federaciones y 8 capas L0–L7 del LTOS." },
          ].map((c) => (
            <Link
              key={c.to}
              to={c.to}
              className="group flex flex-col rounded-xl border border-border/60 bg-card/60 p-6 backdrop-blur transition hover:border-foreground/30 hover:bg-card"
            >
              <div className="eyebrow">{c.k}</div>
              <h3 className="font-display mt-3 text-2xl">{c.t}</h3>
              <p className="mt-2 text-sm text-foreground/75">{c.d}</p>
              <span className="mt-auto pt-6 text-xs text-copper-600 transition group-hover:translate-x-1">
                Abrir →
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* CTA / Principle */}
      <section className="mx-auto max-w-7xl px-6 pb-32">
        <div className="rounded-2xl bg-gradient-stone p-12 text-background md:p-20">
          <div className="eyebrow text-background/60">Un principio</div>
          <p className="display-lg mt-4 max-w-3xl text-balance">
            Un lugar no se define por su descripción.
            <span className="block italic opacity-75">
              Se define por aquello con lo que está conectado.
            </span>
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link
              to="/manifiesto"
              className="inline-flex items-center rounded-md bg-background px-6 py-3 text-sm font-medium text-foreground hover:opacity-90"
            >
              Leer el manifiesto
            </Link>
            <Link
              to="/ecosistema"
              className="inline-flex items-center rounded-md border border-background/30 px-6 py-3 text-sm font-medium text-background hover:bg-background/10"
            >
              Ver el ecosistema
            </Link>
          </div>
        </div>
      </section>

    </>
  );
}
