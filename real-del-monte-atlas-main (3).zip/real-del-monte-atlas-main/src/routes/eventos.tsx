import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { events } from "@/data/territory";

export const Route = createFileRoute("/eventos")({
  head: () => ({
    meta: [
      { title: "Eventos — Real del Monte" },
      {
        name: "description",
        content:
          "Los encuentros que mantienen vivo a Real del Monte: Festival del Paste, Día del Minero, Noche del Panteón Inglés.",
      },
      { property: "og:title", content: "Eventos — Real del Monte" },
      {
        property: "og:description",
        content: "El territorio se vuelve más visible cuando se reúne.",
      },
    ],
  }),
  component: Eventos,
});

function Eventos() {
  return (
    <>
      <PageHeader
        kicker="El territorio se reúne"
        title="Cuando el pueblo se junta, la historia se vuelve presente."
        intro="Los eventos no son solo celebraciones: son los momentos en los que Real del Monte recuerda en voz alta."
      />

      <section className="container-prose pb-24">
        <div className="grid gap-6 md:grid-cols-3">
          {events.map((e) => (
            <article
              key={e.id}
              className="flex flex-col rounded-xl border border-border bg-card p-6 shadow-soft transition hover:shadow-lift"
            >
              <div className="font-mono text-xs uppercase tracking-widest text-copper">
                {e.date}
              </div>
              <h2 className="font-display mt-3 text-2xl">{e.name}</h2>
              <div className="mt-2 text-sm text-muted-foreground">{e.place}</div>
              <p className="mt-5 text-sm text-foreground/80 leading-relaxed">{e.description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
