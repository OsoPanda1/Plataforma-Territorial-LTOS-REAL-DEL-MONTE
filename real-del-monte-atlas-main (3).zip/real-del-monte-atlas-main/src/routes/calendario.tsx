import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/calendario")({
  head: () => ({
    meta: [{ title: "Calendario — Real del Monte" }, { name: "description", content: "Festividades, ferias y eventos del Pueblo Mágico." }],
  }),
  component: Calendario,
});

const meses = [
  { m: "Enero", e: ["Día de Reyes en el atrio", "Fin de temporada de niebla densa"] },
  { m: "Febrero", e: ["Carnaval de minas — concurso de carros", "Aniversario fundacional"] },
  { m: "Marzo", e: ["Equinoccio en Peña del Zumate"] },
  { m: "Abril", e: ["Semana Santa silenciosa"] },
  { m: "Mayo", e: ["Día de la Santa Cruz — bendición de tiros"] },
  { m: "Julio", e: ["Día del Minero (11)", "Festival del Paste"] },
  { m: "Septiembre", e: ["Fiestas patrias", "Aniversario huelga 1766"] },
  { m: "Octubre", e: ["Festival Internacional del Paste"] },
  { m: "Noviembre", e: ["Día de Muertos en panteón inglés y civil"] },
  { m: "Diciembre", e: ["Posadas barriales", "Pastorelas mineras"] },
];

function Calendario() {
  return (
    <EditorialPage
      plano="Plano 01 · Experiencia"
      kicker="Calendario"
      title={<>Doce meses, <span className="text-copper-700">una sola memoria.</span></>}
      lead="Eventos que se repiten porque sostienen el pueblo. Filtra mentalmente por mes y planea tu visita alrededor de lo que importa."
      related={[
        { to: "/eventos", label: "Eventos puntuales" },
        { to: "/cultura-arte", label: "Tradiciones" },
        { to: "/rutas", label: "Rutas curadas" },
      ]}
    >
      <EditorialSection eyebrow="Anual" title="Lo que ocurre cada año.">
        <div className="grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-2">
          {meses.map((mo) => (
            <div key={mo.m} className="bg-background/80 p-6">
              <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-copper-700">
                {mo.m}
              </div>
              <ul className="mt-3 space-y-1 text-foreground/85">
                {mo.e.map((ev) => (
                  <li key={ev} className="text-sm">· {ev}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
