import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { streets } from "@/data/territory";
import img from "@/assets/chapter-calles.jpg";

export const Route = createFileRoute("/calles")({
  head: () => ({
    meta: [
      { title: "Las calles — Real del Monte" },
      {
        name: "description",
        content:
          "Las calles de Real del Monte: nombres, esquinas y memoria. Cada calle recuerda algo que casi nadie pronuncia ya.",
      },
      { property: "og:title", content: "Las calles — Real del Monte" },
      {
        property: "og:description",
        content: "Bajan en pendientes imposibles. Cada esquina recuerda un nombre.",
      },
      { property: "og:image", content: img },
    ],
  }),
  component: Calles,
});

function Calles() {
  return (
    <>
      <PageHeader
        kicker="Capa IV · Superficie"
        title="La ciudad se inclina contra la sierra."
        intro="Real del Monte es un pueblo que se aprendió a sí mismo en pendiente. Las calles bajan donde la roca lo permitió y guardan, en sus nombres, un siglo de personas."
        image={img}
      />

      <section className="container-prose pb-24">
        <div className="overflow-hidden rounded-xl border border-border">
          {streets.map((s, i) => (
            <div
              key={s.name}
              className={`grid grid-cols-12 gap-6 p-6 md:p-8 ${
                i < streets.length - 1 ? "border-b border-border" : ""
              } hover:bg-muted/40`}
            >
              <div className="col-span-12 md:col-span-3">
                <div className="font-mono text-xs text-muted-foreground">{s.era}</div>
                <h2 className="font-display mt-1 text-2xl">{s.name}</h2>
              </div>
              <p className="col-span-12 text-foreground/80 leading-relaxed md:col-span-9">
                {s.story}
              </p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
