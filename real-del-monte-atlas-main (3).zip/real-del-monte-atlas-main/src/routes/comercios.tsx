import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import {
  comercios,
  comercioCategoriaLabel,
  membresiaLabel,
  type ComercioCategoria,
} from "@/data/comercios";
import { useState } from "react";

export const Route = createFileRoute("/comercios")({
  head: () => ({
    meta: [
      { title: "Comercios · RDM Digital" },
      {
        name: "description",
        content:
          "Directorio vivo de pasterías, cafés, hospedaje, artesanías y guías de Real del Monte. Capa de economía local del LTOS.",
      },
      { property: "og:title", content: "Comercios · RDM Digital" },
      {
        property: "og:description",
        content:
          "Pasterías, cafés, posadas, talleres y guías que sostienen la vida cotidiana del territorio.",
      },
    ],
  }),
  component: ComerciosPage,
});

const CATEGORIAS: (ComercioCategoria | "todos")[] = [
  "todos",
  "paste",
  "cafe",
  "restaurante",
  "hospedaje",
  "artesania",
  "guia",
  "experiencia",
  "mercado",
];

function ComerciosPage() {
  const [filtro, setFiltro] = useState<ComercioCategoria | "todos">("todos");

  const lista = filtro === "todos" ? comercios : comercios.filter((c) => c.categoria === filtro);

  return (
    <>
      <PageHeader
        kicker="Capa V · Economía local"
        title="Comercios del Nodo Cero"
        intro="No es un catálogo: es la economía cotidiana del pueblo. Cada lugar aquí sostiene un oficio, una familia, una historia. Cuando consumes acá, financias la memoria territorial."
      />

      <section className="container-prose pb-24">
        {/* Filtros */}
        <div className="mb-10 flex flex-wrap gap-2">
          {CATEGORIAS.map((c) => (
            <button
              key={c}
              onClick={() => setFiltro(c)}
              className={`rounded-full border px-4 py-1.5 text-xs uppercase tracking-wider transition ${
                filtro === c
                  ? "border-foreground bg-foreground text-background"
                  : "border-border/60 text-muted-foreground hover:border-foreground/40 hover:text-foreground"
              }`}
            >
              {c === "todos" ? "Todos" : comercioCategoriaLabel[c]}
            </button>
          ))}
        </div>

        <ul className="grid gap-6 md:grid-cols-2">
          {lista.map((com) => (
            <li
              key={com.id}
              className="group flex flex-col rounded-xl border border-border/60 bg-card/60 p-6 backdrop-blur transition hover:border-foreground/30 hover:bg-card"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="eyebrow">
                    {comercioCategoriaLabel[com.categoria]} · {membresiaLabel[com.membresia]}
                  </div>
                  <h3 className="font-display mt-2 text-2xl leading-tight">{com.nombre}</h3>
                  <p className="mt-1 text-sm italic text-copper-600">{com.tagline}</p>
                </div>
                <span className="font-mono text-xs text-muted-foreground">{com.rangoPrecio}</span>
              </div>

              <p className="mt-4 text-sm leading-relaxed text-foreground/80">{com.descripcion}</p>

              {com.sello && (
                <blockquote className="mt-4 border-l-2 border-copper-500/60 pl-4 text-sm italic text-muted-foreground">
                  “{com.sello}”
                </blockquote>
              )}

              <dl className="mt-6 grid grid-cols-2 gap-3 text-xs">
                <div>
                  <dt className="eyebrow">Dirección</dt>
                  <dd className="mt-1 text-foreground/85">{com.direccion}</dd>
                </div>
                <div>
                  <dt className="eyebrow">Horario</dt>
                  <dd className="mt-1 font-mono text-foreground/85">{com.horario}</dd>
                </div>
              </dl>

              <div className="mt-5 flex flex-wrap gap-1.5">
                {com.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded-full border border-border/50 px-2 py-0.5 text-[10px] uppercase tracking-wider text-muted-foreground"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-16 rounded-2xl border border-border/60 bg-card/40 p-8 backdrop-blur">
          <div className="eyebrow">¿Tienes un comercio en Real del Monte?</div>
          <h2 className="font-display mt-2 text-3xl">Inscríbete en el directorio</h2>
          <p className="mt-3 max-w-2xl text-foreground/75">
            El directorio del Nodo Cero es libre para comercios locales. Los niveles{" "}
            <em>Comunidad</em>, <em>Raíz</em> y <em>Guardián</em> reflejan participación, no costo
            de entrada.
          </p>
          <Link
            to="/manifiesto"
            className="mt-6 inline-flex rounded-md border border-border px-5 py-2 text-sm hover:bg-muted"
          >
            Leer el manifiesto antes de inscribirte →
          </Link>
        </div>
      </section>
    </>
  );
}
