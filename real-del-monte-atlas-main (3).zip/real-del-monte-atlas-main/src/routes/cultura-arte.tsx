import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/cultura-arte")({
  head: () => ({
    meta: [
      { title: "Cultura y Arte — Real del Monte" },
      { name: "description", content: "Tradiciones, oficios, fiestas y artistas que sostienen la identidad del pueblo." },
    ],
  }),
  component: Cultura,
});

const tradiciones = [
  { t: "Día del Minero", d: "11 de julio. Procesión con cascos y carburos rumbo a Santa Bárbara." },
  { t: "Festival del Paste", d: "Cuatro días de hornadas, concursos y memoria cornish." },
  { t: "Día de Muertos", d: "Ofrendas en panteones civil e inglés. El pueblo se vuelve umbral." },
  { t: "Semana Santa silenciosa", d: "Viacrucis por las calles inclinadas, sin música, solo paso." },
];

const oficios = [
  { t: "Pasteros", d: "Tercera y cuarta generación. Receta de masa que viaja por familia." },
  { t: "Barreteros y guías de mina", d: "Saber técnico convertido en relato." },
  { t: "Talabarteros y plateros", d: "Memoria del metal que sigue trabajándose en taller." },
  { t: "Músicos de viento", d: "Bandas que acompañan fiestas, procesiones y velorios." },
];

function Cultura() {
  return (
    <EditorialPage
      plano="Plano 01 · Experiencia"
      kicker="Cultura"
      title={<>La identidad se cocina, <span className="text-copper-700">se canta y se talla.</span></>}
      lead="La cultura de Real del Monte no se exhibe: se practica. Aquí cada oficio sostiene una pieza del relato y cada fiesta confirma quiénes somos cuando nadie nos mira."
      related={[
        { to: "/dichos", label: "Dichos mineros", hint: "Lengua viva del territorio." },
        { to: "/leyendas", label: "Mitos y leyendas" },
        { to: "/comunidad", label: "Comunidad" },
      ]}
    >
      <EditorialSection eyebrow="Tradiciones" title="Lo que el calendario sostiene.">
        <div className="grid gap-6 md:grid-cols-2">
          {tradiciones.map((x) => (
            <div key={x.t} className="rounded-xl border border-border/50 bg-card/40 p-6">
              <div className="font-display text-xl italic">{x.t}</div>
              <p className="mt-2 text-sm text-muted-foreground">{x.d}</p>
            </div>
          ))}
        </div>
      </EditorialSection>
      <EditorialSection eyebrow="Oficios vivos" title="Manos que siguen escribiendo el pueblo.">
        <div className="grid gap-6 md:grid-cols-2">
          {oficios.map((x) => (
            <div key={x.t} className="rounded-xl border border-border/50 bg-card/40 p-6">
              <div className="font-display text-xl italic">{x.t}</div>
              <p className="mt-2 text-sm text-muted-foreground">{x.d}</p>
            </div>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
