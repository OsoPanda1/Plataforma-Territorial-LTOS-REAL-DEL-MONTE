import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { federations, layers, ecosystemNodes, principiosLTOS } from "@/data/ecosystem";

export const Route = createFileRoute("/ecosistema")({
  head: () => ({
    meta: [
      { title: "Ecosistema TAMV · Arquitectura LTOS" },
      {
        name: "description",
        content:
          "Las 7 federaciones, las 8 capas L0–L7 y los nodos operativos del Living Territorial Operating System.",
      },
      { property: "og:title", content: "Ecosistema TAMV · RDM Digital" },
      {
        property: "og:description",
        content:
          "Heptafederado, en capas, soberano: la arquitectura que sostiene al Nodo Cero y a los territorios que vendrán.",
      },
    ],
  }),
  component: EcosistemaPage,
});

function EcosistemaPage() {
  return (
    <>
      <PageHeader
        kicker="Arquitectura · MD-X4"
        title="El ecosistema, desde dentro"
        intro="RDM Digital no es una aplicación. Es el Nodo Cero de una infraestructura territorial diseñada para federarse. Aquí están sus federaciones, sus capas y sus piezas activas."
      />

      <section className="container-prose pb-20">
        <div className="eyebrow">Cinco principios</div>
        <h2 className="display-lg mt-3">El manifiesto, en una página</h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-2">
          {principiosLTOS.map((p) => (
            <li
              key={p.numero}
              className="rounded-xl border border-border/60 bg-card/60 p-6 backdrop-blur"
            >
              <div className="font-mono text-xs text-copper-600">PRINCIPIO 0{p.numero}</div>
              <h3 className="font-display mt-2 text-2xl">{p.titulo}</h3>
              <p className="mt-2 text-foreground/80">{p.cuerpo}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="container-prose pb-20">
        <div className="eyebrow">Siete federaciones</div>
        <h2 className="display-lg mt-3">Dominios soberanos</h2>
        <p className="mt-4 max-w-2xl text-foreground/75">
          Cada repositorio, tabla y módulo del ecosistema se clasifica en una de estas siete
          federaciones. La gobernanza es distribuida; la trazabilidad, obligatoria.
        </p>

        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {federations.map((f) => (
            <article
              key={f.id}
              className="rounded-lg border border-border/60 bg-card/40 p-5 backdrop-blur"
            >
              <div className="flex items-baseline justify-between gap-3">
                <h3 className="font-display text-xl">{f.nombre}</h3>
                <span className="eyebrow">{f.dominio}</span>
              </div>
              <p className="mt-2 text-sm text-foreground/80">{f.proposito}</p>
              <ul className="mt-3 flex flex-wrap gap-1.5">
                {f.modulos.map((m) => (
                  <li
                    key={m}
                    className="rounded-full border border-border/50 px-2 py-0.5 font-mono text-[10px] text-muted-foreground"
                  >
                    {m}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="container-prose pb-20">
        <div className="eyebrow">Capas L0 – L7</div>
        <h2 className="display-lg mt-3">El stack territorial</h2>
        <div className="mt-10 overflow-hidden rounded-xl border border-border/60">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/60 text-left">
                <th className="px-4 py-3 font-mono text-xs uppercase tracking-wider">Capa</th>
                <th className="px-4 py-3 font-mono text-xs uppercase tracking-wider">Nombre</th>
                <th className="px-4 py-3 font-mono text-xs uppercase tracking-wider">
                  Descripción
                </th>
              </tr>
            </thead>
            <tbody>
              {layers.map((l) => (
                <tr key={l.id} className="border-t border-border/40">
                  <td className="px-4 py-3 font-mono text-copper-600">{l.codigo}</td>
                  <td className="px-4 py-3 font-display text-base">{l.nombre}</td>
                  <td className="px-4 py-3 text-muted-foreground">{l.descripcion}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="container-prose pb-32">
        <div className="eyebrow">Nodos activos</div>
        <h2 className="display-lg mt-3">Lo que ya está corriendo</h2>
        <ul className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {ecosystemNodes.map((n) => (
            <li
              key={n.id}
              className="rounded-lg border border-border/60 bg-card/40 p-5 backdrop-blur"
            >
              <div className="font-mono text-xs text-copper-600">{n.rol}</div>
              <h3 className="font-display mt-2 text-lg">{n.nombre}</h3>
              <p className="mt-2 text-sm text-foreground/80">{n.descripcion}</p>
            </li>
          ))}
        </ul>

        <div className="mt-16 rounded-2xl bg-gradient-stone p-10 text-background">
          <div className="eyebrow text-background/60">Pregunta abierta</div>
          <p className="display-lg mt-3 max-w-3xl text-balance">
            ¿Quién controla el valor y la narrativa de tu territorio en la era de la digitalización
            masiva?
          </p>
          <Link
            to="/manifiesto"
            className="mt-8 inline-flex rounded-md bg-background px-6 py-3 text-sm font-medium text-foreground hover:opacity-90"
          >
            Leer el manifiesto completo →
          </Link>
        </div>
      </section>
    </>
  );
}
