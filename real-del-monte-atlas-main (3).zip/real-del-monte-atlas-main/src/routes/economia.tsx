import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/economia")({
  head: () => ({ meta: [{ title: "Economía soberana — Cattleya Pay & MSR" }] }),
  component: Eco,
});

function Eco() {
  return (
    <EditorialPage
      plano="Plano 03 · Sistema"
      kicker="Economía soberana"
      title={<>Dinero que <span className="text-copper-700">no abandona al pueblo.</span></>}
      lead="La capa económica de RDM Digital combina Stripe (MXN), un ledger SQL idempotente y reglas de distribución públicas. El comercio local recibe la mayor parte; el resto sostiene la infraestructura y reservas."
      stats={[
        { k: "Comercio local", v: "50%" },
        { k: "Infraestructura", v: "30%" },
        { k: "Fondos Phoenix", v: "20%" },
        { k: "Ledger", v: "Idempotente" },
      ]}
      related={[
        { to: "/donaciones", label: "Donaciones" },
        { to: "/membresias", label: "Membresías" },
        { to: "/arquitectura", label: "Arquitectura MDX4" },
      ]}
    >
      <EditorialSection eyebrow="Cattleya Pay" title="Ledger SQL idempotente.">
        <p>Cada transacción se registra una sola vez, con prueba criptográfica y trazabilidad pública. La idempotencia garantiza que nunca se duplique un cobro ni se pierda un aporte.</p>
      </EditorialSection>
      <EditorialSection eyebrow="MSR" title="Mercado Soberano de Registro.">
        <p>Bitácora de decisiones económicas y flujos. Cualquier auditor puede reconstruir la historia financiera del Nodo desde su origen.</p>
      </EditorialSection>
      <EditorialSection eyebrow="Phoenix Funds" title="Reservas territoriales.">
        <p>20% de cada operación se asigna a un fondo de emergencia y resiliencia gobernado por consejo guardian con quorum HITL.</p>
      </EditorialSection>
    </EditorialPage>
  );
}
