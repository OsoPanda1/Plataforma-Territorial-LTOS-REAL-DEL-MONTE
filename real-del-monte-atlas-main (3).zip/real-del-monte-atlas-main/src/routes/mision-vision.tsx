import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/mision-vision")({
  head: () => ({ meta: [{ title: "Misión y visión — RDM Digital" }] }),
  component: MV,
});

function MV() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Filosofía aplicada"
      title={<>Misión, visión <span className="text-copper-700">y objetivos.</span></>}
      lead="LTOS no es retórica: es un compromiso operativo. Cada decisión técnica se mide contra esta brújula."
      related={[
        { to: "/manifiesto", label: "Manifiesto LTOS" },
        { to: "/fundador", label: "Arquitecto raíz" },
        { to: "/acerca-de", label: "Acerca de" },
      ]}
    >
      <EditorialSection eyebrow="Misión">
        <p>
          Construir una infraestructura digital soberana para Real del Monte que desacople su presencia
          digital de plataformas externas, proteja su memoria cultural y económica, y ofrezca a
          ciudadanos, comercios e instituciones una capa común de servicios auditables.
        </p>
      </EditorialSection>
      <EditorialSection eyebrow="Visión">
        <p>
          Ser un referente civilizatorio de cómo un Pueblo Mágico puede operar su propio sistema
          operativo urbano: territorio como interfaz, gemelos digitales como base de decisiones públicas,
          IA contextual bajo control humano, economía federada que favorece al comercio local.
        </p>
      </EditorialSection>
      <EditorialSection eyebrow="Objetivos">
        <ul className="space-y-3">
          <li><strong>Corto plazo.</strong> Atlas turístico completo y directorio LTOS de comercios.</li>
          <li><strong>Mediano plazo.</strong> Gemelo digital con telemetría en tiempo casi-real.</li>
          <li><strong>Largo plazo.</strong> Federar el protocolo a 12 territorios mexicanos en 5 años.</li>
        </ul>
      </EditorialSection>
    </EditorialPage>
  );
}
