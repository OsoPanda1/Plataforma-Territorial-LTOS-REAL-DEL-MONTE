import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { legends } from "@/data/territory";

export const Route = createFileRoute("/leyendas")({
  head: () => ({
    meta: [
      { title: "Leyendas — Real del Monte" },
      {
        name: "description",
        content:
          "Las leyendas de Real del Monte: la novia de la mina, la campana de Cornualles, el conde y la veta perdida.",
      },
      { property: "og:title", content: "Leyendas — Real del Monte" },
      {
        property: "og:description",
        content: "Cuando el pueblo se queda quieto, las historias siguen ocurriendo.",
      },
    ],
  }),
  component: Leyendas,
});

function Leyendas() {
  return (
    <>
      <PageHeader
        kicker="Memoria oral"
        title="Hay cosas que el mapa no registra."
        intro="Las leyendas de Real del Monte no se enseñan en la escuela. Se cuentan al atardecer, cuando la niebla baja y los nombres antiguos vuelven a pesar."
      />

      <section className="container-prose pb-24">
        <div className="space-y-16">
          {legends.map((l, i) => (
            <article key={l.title} className="grid gap-8 md:grid-cols-12">
              <div className="md:col-span-3">
                <div className="font-mono text-xs text-muted-foreground">0{i + 1}</div>
                <div className="eyebrow mt-2">{l.era}</div>
              </div>
              <div className="md:col-span-9">
                <h2 className="font-display text-4xl text-balance">{l.title}</h2>
                <p className="mt-6 text-lg leading-relaxed text-foreground/85">{l.body}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
