import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/ecoturismo")({
  head: () => ({
    meta: [
      { title: "Ecoturismo — Real del Monte" },
      { name: "description", content: "Rutas naturales, miradores y caminatas con criterios de respeto territorial." },
    ],
  }),
  component: Eco,
});

const rutas = [
  { t: "Peña del Zumate", n: "Alta", km: "6.4 km", d: "Mirador a 360°. Se entra por niebla y se sale con la sierra clara." },
  { t: "Bosque del Hiloche", n: "Media", km: "3.1 km", d: "Pino-encino con corredor de musgo, ideal al amanecer." },
  { t: "Mirador Acosta", n: "Baja", km: "1.8 km", d: "El pueblo visto desde donde antes se bajaba mineral." },
  { t: "Ruta del Agua", n: "Media", km: "5.2 km", d: "Manantiales y canaletas que aún corren bajo la calle." },
];

function Eco() {
  return (
    <EditorialPage
      plano="Plano 01 · Experiencia"
      kicker="Ecoturismo"
      title={<>La sierra sostiene el pueblo. <span className="text-copper-700">Caminarla es entenderlo.</span></>}
      lead="Cuatro rutas curadas con guardabosques locales. Cada una traza una manera distinta de leer el territorio: por arriba, por dentro, por debajo."
      stats={[
        { k: "Altitud máx.", v: "3 050 m" },
        { k: "Rutas activas", v: "4" },
        { k: "Bioma", v: "Pino-encino" },
        { k: "Protocolo", v: "Sin huella" },
      ]}
      related={[
        { to: "/rutas", label: "Rutas curadas" },
        { to: "/atlas", label: "Atlas territorial" },
        { to: "/comercios", label: "Comercios aliados" },
      ]}
    >
      <EditorialSection eyebrow="Senderos" title="Cuatro maneras de caminar la sierra.">
        <div className="grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-2">
          {rutas.map((r) => (
            <article key={r.t} className="bg-background/80 p-6">
              <div className="flex items-baseline justify-between">
                <div className="font-display text-2xl italic">{r.t}</div>
                <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                  {r.km} · {r.n}
                </div>
              </div>
              <p className="mt-3 text-sm text-foreground/80">{r.d}</p>
            </article>
          ))}
        </div>
      </EditorialSection>
      <EditorialSection eyebrow="Protocolo" title="Cómo se camina aquí.">
        <ul className="grid gap-3 text-base text-foreground/85 md:grid-cols-2">
          <li>· Cero residuos: lo que entra contigo, sale contigo.</li>
          <li>· Fuego solo en zonas marcadas.</li>
          <li>· Respeta santuarios de fauna y los muros antiguos.</li>
          <li>· Reporta cualquier hallazgo arqueológico al guardian.</li>
        </ul>
      </EditorialSection>
    </EditorialPage>
  );
}
