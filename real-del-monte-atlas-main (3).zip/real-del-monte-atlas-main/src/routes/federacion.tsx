import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/federacion")({
  head: () => ({ meta: [{ title: "Federación Viva — 100+ repos RDM Digital" }] }),
  component: Fed,
});

const repos = [
  { c: "Smart City OS", r: "rdm-digital-os", f: "src/lib/sovereign-operating-system.ts" },
  { c: "Nexus / RDM·X", r: "RDM-Digital-X", f: "docs/rdmx-evolucion-mega-analisis.md" },
  { c: "Turismo Digital", r: "rdm-turismodigital", f: "supabase/functions/" },
  { c: "Atlas territorial", r: "real-del-monte-explorer", f: "src/data/territory.ts" },
  { c: "Twin 4D", r: "rdm-twin", f: "src/engine/twin-core.ts" },
  { c: "Wiki TAMV", r: "wiki-tamv", f: "content/*.mdx" },
];

function Fed() {
  return (
    <EditorialPage
      plano="Plano 03 · Sistema"
      kicker="Federación Viva"
      title={<>Cien repos. <span className="text-copper-700">Una sola disciplina.</span></>}
      lead="Más de 100 repositorios coordinados bajo el mismo protocolo de versionado, observabilidad y gobernanza distribuida. La Federación Viva es el sustrato técnico de la soberanía territorial."
      stats={[
        { k: "Repos activos", v: "100+" },
        { k: "Stack base", v: "TS · Bun · Supabase" },
        { k: "Tests", v: "Vitest · Playwright" },
        { k: "Auditoría", v: "BookPI" },
      ]}
      related={[
        { to: "/arquitectura", label: "Arquitectura MDX4" },
        { to: "/sistemas-nucleo", label: "Sistemas núcleo" },
        { to: "/canon-academico", label: "Canon académico" },
      ]}
    >
      <EditorialSection eyebrow="Referencias" title="Concepto → repo → archivo principal.">
        <div className="overflow-hidden rounded-xl border border-border/50">
          <table className="w-full text-left text-sm">
            <thead className="bg-card/40 font-mono text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              <tr><th className="p-4">Concepto</th><th className="p-4">Repo</th><th className="p-4">Archivo</th></tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {repos.map((r) => (
                <tr key={r.c}>
                  <td className="p-4 font-display text-lg italic">{r.c}</td>
                  <td className="p-4 font-mono text-copper-700">{r.r}</td>
                  <td className="p-4 font-mono text-xs text-muted-foreground">{r.f}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
