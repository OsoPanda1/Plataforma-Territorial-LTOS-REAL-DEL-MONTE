import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/fundador")({
  head: () => ({ meta: [{ title: "Arquitecto raíz — Edwin Oswaldo Castillo Trejo" }] }),
  component: Fundador,
});

function Fundador() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Arquitecto raíz"
      title={<>Edwin Oswaldo <span className="text-copper-700">Castillo Trejo.</span></>}
      lead="Conocido también como Anubis Villaseñor. Diseñador y ensamblador del Kernel Heptafederado MDX4 y del ecosistema TAMV ONLINE."
      related={[
        { to: "/manifiesto", label: "Manifiesto LTOS" },
        { to: "/arquitectura", label: "Arquitectura MDX4" },
        { to: "/ecosistema", label: "Ecosistema técnico" },
      ]}
    >
      <EditorialSection>
        <p>
          Arquitecto soberano. Más de 100 repositorios federados, kernel de protocolos EOCT, sistemas
          de auditoría BookPI y motor cognitivo Isabella. Su trabajo combina ingeniería de sistemas
          distribuidos con una postura ética explícita: la tecnología debe servir al territorio, no
          extraerlo.
        </p>
        <p className="mt-4">
          Real del Monte es la primera implementación pública de esa postura. El Nodo Cero es,
          literalmente, el sistema operativo de un pueblo que decidió no rentarle su digitalidad a
          nadie.
        </p>
      </EditorialSection>
    </EditorialPage>
  );
}
