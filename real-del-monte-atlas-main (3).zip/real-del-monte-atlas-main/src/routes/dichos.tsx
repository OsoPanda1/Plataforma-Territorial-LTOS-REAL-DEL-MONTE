import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";
import { dichos, dichosPorInicial } from "@/data/dichos";

export const Route = createFileRoute("/dichos")({
  head: () => ({
    meta: [
      { title: "Dichos realmontenses · Archivo histórico" },
      {
        name: "description",
        content:
          "Índice alfabético de dichos y jerga viva de Real del Monte. Cada nombre propio es la cifra de una palabra cotidiana.",
      },
      { property: "og:title", content: "Dichos realmontenses · RDM Digital" },
      {
        property: "og:description",
        content:
          "Memoria oral del pueblo: nombres propios convertidos en código compartido entre vecinos.",
      },
    ],
  }),
  component: DichosPage,
});

function DichosPage() {
  const iniciales = Object.keys(dichosPorInicial).sort();

  return (
    <>
      <PageHeader
        kicker="Capa III · Memoria silenciosa"
        title="Dichos realmontenses"
        intro="Aquí cada apellido es una contraseña. El pueblo aprendió a esconder sus quejas, sus invitaciones y sus diagnósticos detrás del nombre de alguien. Esto es un archivo, no un catálogo: si nunca fuiste vecino, no terminarás de entenderlo."
      />

      <section className="container-prose pb-24">
        <div className="mb-12 flex flex-wrap gap-2">
          {iniciales.map((l) => (
            <a
              key={l}
              href={`#letra-${l}`}
              className="font-display rounded-md border border-border/60 px-3 py-1 text-xl hover:bg-muted"
            >
              {l}
            </a>
          ))}
        </div>

        {iniciales.map((letra) => (
          <section key={letra} id={`letra-${letra}`} className="mb-16 scroll-mt-24">
            <h2 className="font-display border-b border-border/40 pb-2 text-5xl text-copper-600">
              {letra}
            </h2>
            <ul className="mt-6 divide-y divide-border/40">
              {dichosPorInicial[letra].map((d) => (
                <li key={d.id} className="grid gap-2 py-5 md:grid-cols-12 md:gap-6">
                  <div className="md:col-span-3">
                    <div className="font-display text-xl">{d.personaje}</div>
                    <div className="eyebrow mt-1">Dicho #{d.id}</div>
                  </div>
                  <blockquote className="text-foreground/90 italic md:col-span-5">
                    “{d.jerga}”
                  </blockquote>
                  <p className="text-sm text-muted-foreground md:col-span-4">{d.significado}</p>
                </li>
              ))}
            </ul>
          </section>
        ))}

        <div className="mt-12 rounded-xl border border-border/60 bg-card/40 p-6 text-sm text-muted-foreground">
          Archivo curado a partir del índice alfabético de dichos realmontenses recopilado por el
          archivo comunitario. {dichos.length} entradas registradas. Si conoces un dicho que falte,
          puedes proponerlo en el siguiente cierre del archivo.
        </div>
      </section>
    </>
  );
}
