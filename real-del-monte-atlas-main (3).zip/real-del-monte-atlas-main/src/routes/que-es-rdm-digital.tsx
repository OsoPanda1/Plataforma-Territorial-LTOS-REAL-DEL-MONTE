import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/que-es-rdm-digital")({
  head: () => ({ meta: [{ title: "¿Qué es RDM Digital?" }, { name: "description", content: "Qué hace, cómo lo hace, por qué existe y para quién opera." }] }),
  component: Que,
});

const cuatro = [
  { k: "Qué hace", v: "Opera un sistema digital que integra turismo, comunidad, comercio e identidad bajo un solo protocolo." },
  { k: "Cómo lo hace", v: "Combina mapas vivos, IA contextual, gemelos digitales y economía local auditable." },
  { k: "Por qué existe", v: "Para proteger y amplificar la memoria, la economía y la soberanía digital del pueblo." },
  { k: "Para quién", v: "Ciudadanos, visitantes, comercios e instituciones de Real del Monte." },
];

function Que() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="Definición"
      title={<>Cuatro preguntas, <span className="text-copper-700">cuatro respuestas.</span></>}
      lead="Si solo tienes un minuto para entender el proyecto, estas son las cuatro coordenadas que lo definen."
      related={[
        { to: "/acerca-de", label: "Acerca de" },
        { to: "/manifiesto", label: "Manifiesto LTOS" },
        { to: "/sistemas-nucleo", label: "Sistemas núcleo" },
      ]}
    >
      <EditorialSection>
        <div className="grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-2">
          {cuatro.map((c) => (
            <div key={c.k} className="bg-background/80 p-8">
              <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-copper-700">
                {c.k}
              </div>
              <p className="mt-4 text-lg leading-relaxed text-foreground/90">{c.v}</p>
            </div>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
