import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/faq")({
  head: () => ({ meta: [{ title: "Preguntas frecuentes — RDM Digital" }] }),
  component: FAQ,
});

const items = [
  { q: "¿Usar RDM Digital cuesta?", a: "No. La capa de visitante es gratuita. Las membresías Raíz y Guardián son aportes opcionales que sostienen la infraestructura." },
  { q: "¿Quién es dueño de los datos?", a: "El territorio. Los datos personales son del usuario; los datos colectivos se gobiernan por la comunidad bajo protocolo EOCT." },
  { q: "¿Cómo entra mi comercio al directorio?", a: "Regístrate como Raíz, completa tu ficha y un guardian la verifica en menos de 72h." },
  { q: "¿Esto reemplaza al municipio?", a: "No. Es una capa complementaria, abierta y federable que cualquier institución puede integrar." },
  { q: "¿Es replicable en otros pueblos?", a: "Sí, esa es la apuesta. El protocolo está diseñado para federarse." },
  { q: "¿Cómo se audita la IA Isabella?", a: "Cada interacción relevante queda registrada en BookPI con narrativa humana y trazabilidad técnica." },
];

function FAQ() {
  return (
    <EditorialPage
      plano="Plano 02 · Plataforma"
      kicker="FAQ"
      title={<>Las preguntas <span className="text-copper-700">que más nos hacen.</span></>}
      lead="Respuestas directas. Si falta alguna, escríbenos desde la página de contacto."
      related={[
        { to: "/contacto", label: "Contacto" },
        { to: "/membresias", label: "Membresías" },
        { to: "/que-es-rdm-digital", label: "¿Qué es RDM Digital?" },
      ]}
    >
      <EditorialSection>
        <div className="divide-y divide-border/50 overflow-hidden rounded-xl border border-border/50">
          {items.map((it) => (
            <details key={it.q} className="group bg-background/70 p-6 open:bg-card/60">
              <summary className="cursor-pointer list-none">
                <div className="flex items-baseline justify-between gap-4">
                  <span className="font-display text-xl italic text-foreground">{it.q}</span>
                  <span className="font-mono text-xs text-copper-700 transition group-open:rotate-45">+</span>
                </div>
              </summary>
              <p className="mt-3 text-base text-foreground/80">{it.a}</p>
            </details>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
