import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/site/PageHeader";

export const Route = createFileRoute("/manifiesto")({
  head: () => ({
    meta: [
      { title: "Manifiesto LTOS — RDM Digital" },
      {
        name: "description",
        content:
          "Living Territorial Operating System: una infraestructura territorial cognitiva para representar, conectar y preservar Real del Monte.",
      },
      { property: "og:title", content: "Manifiesto LTOS — RDM Digital" },
      { property: "og:description", content: "El territorio es la interfaz." },
    ],
  }),
  component: Manifiesto,
});

const principles = [
  {
    n: "01",
    t: "El territorio es la interfaz",
    b: "La unidad central no es el usuario. Es el territorio. Todo elemento existe porque forma parte de una realidad territorial.",
  },
  {
    n: "02",
    t: "Las relaciones valen más que los contenidos",
    b: "Un lugar no se define por su descripción. Se define por aquello con lo que está conectado: historia, personas, rutas, eventos, memoria.",
  },
  {
    n: "03",
    t: "La evidencia precede a la narrativa",
    b: "Toda afirmación relevante debe poder vincularse a fuentes, registros, documentos y trazabilidad verificable.",
  },
  {
    n: "04",
    t: "La inteligencia surge del contexto",
    b: "La IA no existe para responder preguntas: existe para interpretar situaciones. Tiempo, lugar, intereses, clima, historia.",
  },
  {
    n: "05",
    t: "Todo territorio debe poder federarse",
    b: "Real del Monte es el primer nodo. La arquitectura permite incorporar otros territorios bajo un mismo protocolo de interoperabilidad.",
  },
];

function Manifiesto() {
  return (
    <>
      <PageHeader
        kicker="Living Territorial OS"
        title="Una infraestructura para que un territorio pueda mirarse."
        intro="RDM Digital no es una aplicación, ni un portal municipal, ni una guía turística. Es una infraestructura territorial cognitiva. Real del Monte constituye su primer nodo operativo."
      />

      <section className="container-prose pb-32">
        <div className="grid gap-12 md:grid-cols-12">
          <aside className="md:col-span-4">
            <div className="sticky top-24">
              <div className="eyebrow">Categoría</div>
              <p className="font-display mt-3 text-3xl leading-tight">
                Living Territorial
                <br />
                Operating System
              </p>
              <p className="mt-4 text-sm text-muted-foreground">
                Un sistema operativo territorial vivo capaz de integrar patrimonio, memoria,
                economía, identidad e inteligencia contextual.
              </p>
            </div>
          </aside>

          <div className="md:col-span-8">
            <div className="space-y-12">
              {principles.map((p) => (
                <article key={p.n} className="border-t border-border pt-8">
                  <div className="font-mono text-xs text-muted-foreground">Principio {p.n}</div>
                  <h2 className="font-display mt-3 text-3xl">{p.t}</h2>
                  <p className="mt-4 text-foreground/85 leading-relaxed">{p.b}</p>
                </article>
              ))}
            </div>

            <div className="mt-20 rounded-2xl bg-gradient-stone p-10 text-background">
              <div className="eyebrow text-background/60">Fórmula</div>
              <p className="font-display mt-4 text-3xl leading-tight text-balance">
                Elegancia patrimonial,
                <br />
                inteligencia silenciosa,
                <br />
                <span className="italic opacity-80">descubrimiento constante.</span>
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
