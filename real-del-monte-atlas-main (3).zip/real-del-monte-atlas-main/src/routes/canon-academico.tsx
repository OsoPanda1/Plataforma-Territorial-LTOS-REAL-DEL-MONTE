import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/canon-academico")({
  head: () => ({ meta: [{ title: "Canon académico — DOI · ORCID · DataCite" }] }),
  component: Canon,
});

const regs = [
  { k: "Zenodo", v: "DOI por publicación y dataset" },
  { k: "Figshare", v: "DOI por colección documental" },
  { k: "ORCID", v: "Identidad académica del arquitecto raíz" },
  { k: "DataCite", v: "Metadatos persistentes y citables" },
  { k: "OpenAIRE", v: "Federación europea de ciencia abierta" },
  { k: "ISNI / groups.io", v: "Identidad institucional y archivo" },
];

function Canon() {
  return (
    <EditorialPage
      plano="Plano 03 · Sistema"
      kicker="Canon académico"
      title={<>Memoria con <span className="text-copper-700">DOI permanente.</span></>}
      lead="RDM Digital no es solo código: es un caso de estudio trazable, registrado en infraestructuras académicas globales. Cada decisión técnica relevante se publica con DOI persistente."
      related={[{ to: "/manifiesto", label: "Manifiesto LTOS" }, { to: "/federacion", label: "Federación Viva" }]}
    >
      <EditorialSection eyebrow="Registros internacionales">
        <div className="grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-2">
          {regs.map((r) => (
            <div key={r.k} className="bg-background/80 p-6">
              <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-copper-700">{r.k}</div>
              <div className="mt-2 text-foreground/85">{r.v}</div>
            </div>
          ))}
        </div>
      </EditorialSection>
      <EditorialSection eyebrow="Citación recomendada">
        <pre className="overflow-x-auto rounded-lg border border-border/50 bg-card/40 p-4 font-mono text-xs">
{`Castillo Trejo, E. O. (2026). RDM Digital · Living Territorial Operating System.
Nodo Cero — Real del Monte, Hidalgo. TAMV ONLINE / Kernel MDX4.
DOI: 10.5281/zenodo.XXXXXXX`}
        </pre>
      </EditorialSection>
    </EditorialPage>
  );
}
