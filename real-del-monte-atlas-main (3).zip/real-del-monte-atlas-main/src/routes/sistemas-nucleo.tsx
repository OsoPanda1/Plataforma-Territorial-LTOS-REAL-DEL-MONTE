import { createFileRoute } from "@tanstack/react-router";
import { EditorialPage, EditorialSection } from "@/components/site/EditorialPage";

export const Route = createFileRoute("/sistemas-nucleo")({
  head: () => ({ meta: [{ title: "Sistemas núcleo — RDM Digital" }] }),
  component: Sistemas,
});

const sist = [
  { t: "RDM Digital OS", r: "Smart City OS · kernel operativo soberano", s: "Supabase · Edge Functions · TanStack" },
  { t: "RDM Digital Nexus (RDM·X)", r: "Hub turístico y narrativa civilizatoria", s: "React · Next · MapLibre" },
  { t: "Real del Monte Atlas", r: "Cartografía viva del Nodo Cero", s: "Leaflet · TanStack · RLS E2E" },
  { t: "Real del Monte Twin", r: "Gemelo digital 4D del territorio", s: "MapLibre GL · WebGL · telemetría" },
  { t: "RDM Turismo Digital", r: "Front cívico-turístico con Edge soberanas", s: "Vite · Bun · Supabase" },
  { t: "Wiki TAMV", r: "Documentación abierta y memoria operacional", s: "MDX · Zenodo · ORCID" },
];

function Sistemas() {
  return (
    <EditorialPage
      plano="Plano 03 · Sistema"
      kicker="Núcleo"
      title={<>Seis sistemas, <span className="text-copper-700">una sola arquitectura.</span></>}
      lead="El Nodo Cero se compone de seis sistemas interoperables. Cada uno cumple un rol específico en la operación del Living Territorial OS."
      related={[
        { to: "/arquitectura", label: "Arquitectura MDX4" },
        { to: "/federacion", label: "Federación Viva" },
        { to: "/isabella", label: "Isabella & Realito" },
      ]}
    >
      <EditorialSection>
        <div className="grid gap-px overflow-hidden rounded-xl border border-border/50 bg-border/40 md:grid-cols-2">
          {sist.map((s) => (
            <article key={s.t} className="bg-background/80 p-6">
              <div className="font-display text-2xl italic">{s.t}</div>
              <p className="mt-2 text-sm text-foreground/80">{s.r}</p>
              <div className="mt-4 font-mono text-[10px] uppercase tracking-[0.28em] text-copper-700">
                {s.s}
              </div>
            </article>
          ))}
        </div>
      </EditorialSection>
    </EditorialPage>
  );
}
