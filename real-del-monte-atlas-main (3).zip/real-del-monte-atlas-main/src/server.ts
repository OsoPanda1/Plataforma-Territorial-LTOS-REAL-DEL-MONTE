// src/server.ts

import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import {
  buildProdCspWithReporting,
  generateCSP,
  isAllowedOrigin,
  registerSecurityEventSink,
  type SecurityEnvironment,
} from "./lib/security";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

/**
 * Determina el entorno lógico de seguridad a partir de NODE_ENV o env de Worker.
 */
function getSecurityEnv(env: unknown): SecurityEnvironment {
  // Cloudflare Workers pasan env con bindings; aquí puedes mapear si lo necesitas.
  const nodeEnv =
    (typeof process !== "undefined" && process.env.NODE_ENV) ||
    (typeof env === "object" && env !== null && "NODE_ENV" in env
      ? String((env as { NODE_ENV?: unknown }).NODE_ENV)
      : undefined) ||
    "production";

  if (nodeEnv === "development" || nodeEnv === "dev") return "development";
  if (nodeEnv === "test" || nodeEnv === "staging") return "staging";
  return "production";
}

/**
 * Aplica cabeceras de seguridad transversales a todas las respuestas HTTP.
 */
function applySecurityHeaders(request: Request, response: Response, env: unknown): Response {
  const envName = getSecurityEnv(env);
  const url = new URL(request.url);

  const headers = new Headers(response.headers);

  // CSP:
  // - en prod: usa policy con report-uri/report-to
  // - en otros entornos: policy base (puedes ajustarla si quieres)
  const csp =
    envName === "production"
      ? buildProdCspWithReporting(`${url.origin}/api/csp-report`)
      : generateCSP(envName);

  headers.set("Content-Security-Policy", csp);

  // HSTS solo en HTTPS y en prod
  if (url.protocol === "https:" && envName === "production") {
    headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
  }

  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("X-Frame-Options", "DENY");
  headers.set("X-XSS-Protection", "1; mode=block");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  headers.set("Cross-Origin-Opener-Policy", "same-origin");
  headers.set("Cross-Origin-Embedder-Policy", "require-corp");
  headers.set("Cross-Origin-Resource-Policy", "same-origin");

  // Cache policy básica:
  // - assets: alta cacheabilidad (lo puedes mover a Nitro routeRules)
  // - resto: no-store para HTML / SSR
  if (url.pathname.startsWith("/assets/")) {
    headers.set("Cache-Control", "public, max-age=31536000, immutable");
  } else if (headers.get("content-type")?.includes("text/html")) {
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Expires", "0");
  }

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

/**
 * Normaliza la respuesta en caso de error SSR catastrófico swalloweado por h3/Nitro.
 * Mantiene tu lógica original pero preparada para extensiones futuras.
 */
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!body.includes('"unhandled":true') || !body.includes('"message":"HTTPError"')) {
    return response;
  }

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));

  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

/**
 * Pequeño router para rutas especiales (por ahora, solo puedes extender aquí):
 * - /api/csp-report => endpoint de reportes CSP (si lo montas)
 * - /healthz       => healthcheck simple
 */
async function edgeRouter(request: Request, env: unknown): Promise<Response | undefined> {
  const url = new URL(request.url);

  // Healthcheck muy simple (útil para monitorización)
  if (url.pathname === "/healthz") {
    return new Response(
      JSON.stringify({
        status: "ok",
        env: getSecurityEnv(env),
        ts: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: {
          "content-type": "application/json; charset=utf-8",
          "cache-control": "no-store",
        },
      },
    );
  }

  // Ruta reservada para futuros endpoints edge (CSP report, etc.)
  // if (url.pathname === "/api/csp-report") {
  //   return handleCspReport(request, env);
  // }

  return undefined;
}

// Registrar sink básico de seguridad (puedes enchufar aquí Sentry, Supabase, etc.)
registerSecurityEventSink((event) => {
  // En producción, podrías enviar esto a log drains.
  if (typeof process !== "undefined" && process.env.NODE_ENV === "production") {
    console.log(JSON.stringify({ channel: "mdx4-security", ...event }));
  } else {
    console.warn("[MDX4-SECURITY]", event);
  }
});

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const url = new URL(request.url);

      // Capa rápida de protección a nivel de borde para métodos y orígenes
      const method = request.method.toUpperCase();
      const origin = request.headers.get("origin") || request.headers.get("referer");

      // Bloquea métodos sospechosos que no usas (puedes ajustar)
      if (!["GET", "HEAD", "OPTIONS"].includes(method) && !url.pathname.startsWith("/api/")) {
        return new Response("Method Not Allowed", { status: 405 });
      }

      // Opcional: chequeo simple de origen para rutas sensibles
      if (url.pathname.startsWith("/api/") && !isAllowedOrigin(origin)) {
        return new Response("Forbidden", { status: 403 });
      }

      // Router edge para rutas especiales
      const edgeResponse = await edgeRouter(request, env);
      if (edgeResponse) {
        return applySecurityHeaders(request, edgeResponse, env);
      }

      // Delegar a TanStack Start server-entry
      const handler = await getServerEntry();
      const rawResponse = await handler.fetch(request, env, ctx);
      const normalized = await normalizeCatastrophicSsrResponse(rawResponse);
      return applySecurityHeaders(request, normalized, env);
    } catch (error) {
      console.error(error);
      const response = new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
      return applySecurityHeaders(request, response, env);
    }
  },
};
