import * as React from "react";

const MOBILE_BREAKPOINT = 768;

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    mql.addEventListener("change", onChange);
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return !!isMobile;
}

export function useMembership() {
  const isMobile = useIsMobile();
  const [loading, setLoading] = React.useState(true);
  const [isActive, setIsActive] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === "undefined") return;

    const stored = window.localStorage.getItem("rdm:membership:active");
    const activation = stored === null ? true : stored === "true";
    setIsActive(activation);
    setLoading(false);
  }, []);

  const activate = React.useCallback(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("rdm:membership:active", "true");
    }
    setIsActive(true);
  }, []);

  return { isMobile, isActive, loading, activate };
}
