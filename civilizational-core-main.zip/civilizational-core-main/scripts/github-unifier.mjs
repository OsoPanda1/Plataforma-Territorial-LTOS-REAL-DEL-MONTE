#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';

const OWNER = process.env.GH_OWNER || 'OsoPanda1';
const OUT_DIR = path.resolve(process.cwd(), 'data', 'knowledge-absorption');
const TOKEN = process.env.GITHUB_TOKEN;

async function ghFetch(url) {
  const headers = {
    'User-Agent': 'tamv-digital-nexus-unifier',
    Accept: 'application/vnd.github+json',
  };

  if (TOKEN) headers.Authorization = `Bearer ${TOKEN}`;

  const res = await fetch(url, { headers });
  if (!res.ok) throw new Error(`GitHub API error ${res.status} @ ${url}`);
  return res.json();
}

function topicBuckets(topics = []) {
  const buckets = {
    ai: ['ai', 'llm', 'ml', 'agent'],
    xr: ['xr', 'vr', 'ar', 'threejs', '3d'],
    backend: ['api', 'server', 'backend', 'supabase', 'database'],
    frontend: ['react', 'vite', 'frontend', 'ui'],
    infra: ['docker', 'devops', 'infra', 'kubernetes'],
  };

  return Object.entries(buckets)
    .filter(([, words]) => words.some((w) => topics.includes(w)))
    .map(([k]) => k);
}

async function run() {
  await fs.mkdir(OUT_DIR, { recursive: true });

  const repos = await ghFetch(`https://api.github.com/users/${OWNER}/repos?per_page=100&sort=updated`);

  const normalized = repos.map((repo) => ({
    id: repo.id,
    name: repo.name,
    full_name: repo.full_name,
    description: repo.description,
    language: repo.language,
    topics: repo.topics ?? [],
    stars: repo.stargazers_count,
    forks: repo.forks_count,
    open_issues: repo.open_issues_count,
    size_kb: repo.size,
    updated_at: repo.updated_at,
    html_url: repo.html_url,
    buckets: topicBuckets(repo.topics ?? []),
  }));

  const manifest = {
    owner: OWNER,
    captured_at: new Date().toISOString(),
    total_repos: normalized.length,
    repos: normalized,
  };

  const byLanguage = normalized.reduce((acc, repo) => {
    const key = repo.language || 'Unknown';
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  const byBucket = normalized.reduce((acc, repo) => {
    for (const bucket of repo.buckets) acc[bucket] = (acc[bucket] || 0) + 1;
    return acc;
  }, {});

  const summary = {
    owner: OWNER,
    generated_at: manifest.captured_at,
    total_repos: manifest.total_repos,
    by_language: byLanguage,
    by_bucket: byBucket,
  };

  await fs.writeFile(path.join(OUT_DIR, 'repos-manifest.json'), JSON.stringify(manifest, null, 2));
  await fs.writeFile(path.join(OUT_DIR, 'repos-summary.json'), JSON.stringify(summary, null, 2));

  console.log(`✅ Generated knowledge absorption snapshot for ${OWNER} (${manifest.total_repos} repos)`);
}

run().catch((err) => {
  console.error('❌ Unifier failed:', err.message);
  process.exit(1);
});
