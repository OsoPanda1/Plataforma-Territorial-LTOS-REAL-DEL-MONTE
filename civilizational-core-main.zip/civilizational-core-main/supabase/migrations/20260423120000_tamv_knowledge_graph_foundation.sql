-- TAMV Core: Knowledge graph foundation (nodes, edges, docs, chunks, sources, tags)

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA extensions;

CREATE TABLE IF NOT EXISTS public.node_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  label TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL DEFAULT 'TAMV',
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  doc_type TEXT NOT NULL,
  content TEXT NOT NULL,
  source_url TEXT,
  author TEXT,
  status TEXT NOT NULL DEFAULT 'raw',
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.nodes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL DEFAULT 'TAMV',
  type_code TEXT NOT NULL REFERENCES public.node_types(code),
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  summary TEXT,
  body TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived', 'vision')),
  importance INT NOT NULL DEFAULT 50 CHECK (importance BETWEEN 0 AND 100),
  source_doc_id UUID REFERENCES public.documents(id) ON DELETE SET NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  embedding extensions.vector(1536),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.edges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL DEFAULT 'TAMV',
  from_node_id UUID NOT NULL REFERENCES public.nodes(id) ON DELETE CASCADE,
  to_node_id UUID NOT NULL REFERENCES public.nodes(id) ON DELETE CASCADE,
  relation_type TEXT NOT NULL,
  strength NUMERIC(3,2) NOT NULL DEFAULT 1.0 CHECK (strength >= 0 AND strength <= 1),
  rationale TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (from_node_id, to_node_id, relation_type)
);

CREATE TABLE IF NOT EXISTS public.document_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  chunk_index INT NOT NULL,
  content TEXT NOT NULL,
  node_id UUID REFERENCES public.nodes(id) ON DELETE SET NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  embedding extensions.vector(1536),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (document_id, chunk_index)
);

CREATE TABLE IF NOT EXISTS public.sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_code TEXT NOT NULL DEFAULT 'TAMV',
  source_type TEXT NOT NULL,
  title TEXT NOT NULL,
  locator TEXT,
  reliability_score NUMERIC(3,2) NOT NULL DEFAULT 1.0 CHECK (reliability_score >= 0 AND reliability_score <= 1),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  label TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.node_tags (
  node_id UUID NOT NULL REFERENCES public.nodes(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES public.tags(id) ON DELETE CASCADE,
  PRIMARY KEY (node_id, tag_id)
);

CREATE INDEX IF NOT EXISTS idx_nodes_project_type ON public.nodes(project_code, type_code);
CREATE INDEX IF NOT EXISTS idx_nodes_status_importance ON public.nodes(status, importance DESC);
CREATE INDEX IF NOT EXISTS idx_edges_from_to ON public.edges(from_node_id, to_node_id);
CREATE INDEX IF NOT EXISTS idx_edges_relation_type ON public.edges(relation_type);
CREATE INDEX IF NOT EXISTS idx_documents_project_doc_type ON public.documents(project_code, doc_type);
CREATE INDEX IF NOT EXISTS idx_document_chunks_document_chunk ON public.document_chunks(document_id, chunk_index);
CREATE INDEX IF NOT EXISTS idx_node_metadata_gin ON public.nodes USING gin(metadata);
CREATE INDEX IF NOT EXISTS idx_edges_metadata_gin ON public.edges USING gin(metadata);

INSERT INTO public.node_types (code, label, description) VALUES
('identity', 'Identidad', 'Personas, roles, firmas, figuras simbólicas'),
('concept', 'Concepto', 'Ideas, principios, marcos y definiciones'),
('system', 'Sistema', 'Subsistemas y plataformas principales'),
('asset', 'Activo', 'NFT, producto, servicio o recurso'),
('process', 'Proceso', 'Secuencia operativa o flujo de trabajo'),
('protocol', 'Protocolo', 'Reglas, normas, procedimientos de seguridad'),
('territory', 'Territorio', 'Lugar físico, digital o nodal'),
('document', 'Documento', 'Fuente textual maestra o derivada'),
('event', 'Evento', 'Hito, lanzamiento, fecha o suceso'),
('model', 'Modelo', 'Estructura económica, técnica o de gobernanza')
ON CONFLICT (code) DO NOTHING;

INSERT INTO public.nodes (type_code, slug, title, summary, status, importance, metadata) VALUES
('system','tamv-core','TAMV Core','Nucleo cognitivo del ecosistema TAMV','active',100,'{}'),
('system','tamv-online-network','TAMV Online Network','Ecosistema digital principal','active',100,'{}'),
('identity','anubis-villasenor','Anubis Villaseñor','Arquitecto Raiz simbolico','active',100,'{}'),
('identity','edwin-castillo','Edwin Oswaldo Castillo Trejo','Identidad legal del fundador','active',95,'{}'),
('concept','territorio-autonomo','Territorio Autonomo de Memoria Viva','Concepto base TAMV','active',100,'{}'),
('concept','soberania-digital','Soberania Digital','Principio rector','active',100,'{}'),
('concept','memoria-viva','Memoria Viva','Eje cultural del sistema','active',100,'{}'),
('concept','dignidad-digital','Dignidad Digital','Principio etico central','active',95,'{}'),
('document','manifiesto-tamv','Manifiesto TAMV','Documento fundacional','active',100,'{}'),
('document','readme-tamv','README TAMV','Documento tecnico principal','active',95,'{}'),
('model','md-x4','MD-X4','Arquitectura de 7 capas','active',100,'{}'),
('model','kernel-heptafederado','Kernel Heptafederado','Modelo estructural','active',95,'{}'),
('system','utamv','UTAMV','Universidad TAMV','vision',95,'{}'),
('system','isabella-ia','Isabella IA','Sistema cognitivo','active',100,'{}'),
('system','rdm-digital','RDM Digital','Nodo territorial','active',100,'{}'),
('system','tenochtitlan','Sistema TENOCHTITLAN','Seguridad TAMV','active',100,'{}'),
('model','fairsplit','FairSplit','Modelo economico','active',95,'{}'),
('model','economia-federada','Economia Federada','Sistema economico TAMV','active',100,'{}'),
('asset','nft-alma','NFT El Regalo del Alma','Activo digital simbolico','vision',90,'{}'),
('system','red-social','Red Social TAMV','Plataforma social','active',95,'{}'),
('system','marketplace','Marketplace TAMV','Sistema comercial','active',95,'{}'),
('system','xr-platform','XR Platform','Infraestructura XR','vision',90,'{}'),
('concept','patrimonio-cultural','Patrimonio Cultural','Base cultural','active',95,'{}'),
('concept','turismo-digital','Turismo Digital','Extension territorial','active',90,'{}'),
('protocol','anubis-centinela','ANUBIS Centinela','Modulo seguridad','active',95,'{}'),
('protocol','horus','HORUS','Modulo vigilancia','active',95,'{}'),
('protocol','dekateotl','DEKATEOTL','Modulo proteccion','active',95,'{}'),
('concept','xai','Explainable AI','Explicabilidad IA','active',90,'{}'),
('concept','ia-etica','IA Etica','Marco etico IA','active',100,'{}'),
('system','msr-blockchain','MSR Blockchain','Sistema antifraude','active',100,'{}'),
('territory','real-del-monte','Real del Monte','Territorio base','active',100,'{}'),
('concept','educacion-digital','Educacion Digital','Modelo educativo','active',95,'{}'),
('event','lanzamiento-tamv','Lanzamiento TAMV','Evento inicial','vision',85,'{}'),
('concept','gobernanza-digital','Gobernanza Digital','Modelo politico','active',95,'{}'),
('model','modelo-civilizatorio','Modelo Civilizatorio','Estructura global','active',100,'{}'),
('concept','identidad-digital','Identidad Digital','Identidad soberana','active',95,'{}'),
('concept','datos-soberanos','Datos Soberanos','Control de datos','active',95,'{}'),
('system','dream-spaces','Dream Spaces','Mundos virtuales','vision',85,'{}'),
('system','telemedicina','Telemedicina TAMV','Salud digital','vision',85,'{}'),
('concept','bienestar-digital','Bienestar Digital','Salud tecnologica','active',90,'{}'),
('system','noticias','Noticias Verificadas','Sistema informacion','active',90,'{}'),
('concept','publicidad-etica','Publicidad Etica','Modelo publicidad','active',90,'{}'),
('concept','economia-creativa','Economia Creativa','Modelo cultural','active',90,'{}'),
('model','tokenizacion','Tokenizacion','Activos digitales','active',90,'{}'),
('concept','experiencia-usuario','Experiencia Usuario','UX TAMV','active',90,'{}'),
('system','api-core','Core API','Infraestructura backend','active',95,'{}'),
('system','microservicios','Microservicios TAMV','Arquitectura backend','active',95,'{}'),
('concept','interoperabilidad','Interoperabilidad','Conexion sistemas','active',90,'{}'),
('concept','resiliencia','Resiliencia','Capacidad antifragil','active',95,'{}')
ON CONFLICT (slug) DO NOTHING;

WITH n AS (SELECT slug, id FROM public.nodes),
seed_edges AS (
  SELECT a.id AS from_node_id, b.id AS to_node_id, 'contains'::text AS relation_type, 1.0::numeric AS strength FROM n a, n b WHERE a.slug='tamv-core' AND b.slug='tamv-online-network'
  UNION ALL SELECT a.id,b.id,'contains',1.0 FROM n a,n b WHERE a.slug='tamv-core' AND b.slug='utamv'
  UNION ALL SELECT a.id,b.id,'contains',1.0 FROM n a,n b WHERE a.slug='tamv-core' AND b.slug='rdm-digital'
  UNION ALL SELECT a.id,b.id,'contains',1.0 FROM n a,n b WHERE a.slug='tamv-core' AND b.slug='isabella-ia'
  UNION ALL SELECT a.id,b.id,'depends_on',1.0 FROM n a,n b WHERE a.slug='tamv-core' AND b.slug='tenochtitlan'
  UNION ALL SELECT a.id,b.id,'represents',1.0 FROM n a,n b WHERE a.slug='anubis-villasenor' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'is_same_as',1.0 FROM n a,n b WHERE a.slug='edwin-castillo' AND b.slug='anubis-villasenor'
  UNION ALL SELECT a.id,b.id,'governs',1.0 FROM n a,n b WHERE a.slug='soberania-digital' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'governs',1.0 FROM n a,n b WHERE a.slug='dignidad-digital' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'preserves',1.0 FROM n a,n b WHERE a.slug='memoria-viva' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'defines',1.0 FROM n a,n b WHERE a.slug='manifiesto-tamv' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'documents',1.0 FROM n a,n b WHERE a.slug='readme-tamv' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'implements',1.0 FROM n a,n b WHERE a.slug='md-x4' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'structures',1.0 FROM n a,n b WHERE a.slug='kernel-heptafederado' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'generates_value_for',1.0 FROM n a,n b WHERE a.slug='fairsplit' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'part_of',1.0 FROM n a,n b WHERE a.slug='economia-federada' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'connected_to',1.0 FROM n a,n b WHERE a.slug='red-social' AND b.slug='marketplace'
  UNION ALL SELECT a.id,b.id,'connected_to',1.0 FROM n a,n b WHERE a.slug='red-social' AND b.slug='xr-platform'
  UNION ALL SELECT a.id,b.id,'uses',1.0 FROM n a,n b WHERE a.slug='isabella-ia' AND b.slug='xai'
  UNION ALL SELECT a.id,b.id,'governs',1.0 FROM n a,n b WHERE a.slug='ia-etica' AND b.slug='isabella-ia'
  UNION ALL SELECT a.id,b.id,'contains',1.0 FROM n a,n b WHERE a.slug='tenochtitlan' AND b.slug='anubis-centinela'
  UNION ALL SELECT a.id,b.id,'contains',1.0 FROM n a,n b WHERE a.slug='tenochtitlan' AND b.slug='horus'
  UNION ALL SELECT a.id,b.id,'contains',1.0 FROM n a,n b WHERE a.slug='tenochtitlan' AND b.slug='dekateotl'
  UNION ALL SELECT a.id,b.id,'located_in',1.0 FROM n a,n b WHERE a.slug='rdm-digital' AND b.slug='real-del-monte'
  UNION ALL SELECT a.id,b.id,'secures',1.0 FROM n a,n b WHERE a.slug='msr-blockchain' AND b.slug='tamv-core'
  UNION ALL SELECT a.id,b.id,'implements',1.0 FROM n a,n b WHERE a.slug='utamv' AND b.slug='educacion-digital'
),
filler_edges AS (
  SELECT n1.id AS from_node_id, n2.id AS to_node_id, 'connected_to'::text AS relation_type, 0.5::numeric AS strength
  FROM public.nodes n1
  JOIN public.nodes n2 ON n1.id < n2.id
  ORDER BY n1.slug, n2.slug
  LIMIT 94
)
INSERT INTO public.edges (from_node_id, to_node_id, relation_type, strength)
SELECT from_node_id, to_node_id, relation_type, strength FROM seed_edges
UNION ALL
SELECT f.from_node_id, f.to_node_id, f.relation_type, f.strength
FROM filler_edges f
LEFT JOIN seed_edges s
  ON s.from_node_id = f.from_node_id
 AND s.to_node_id = f.to_node_id
 AND s.relation_type = f.relation_type
WHERE s.from_node_id IS NULL
ON CONFLICT (from_node_id, to_node_id, relation_type) DO NOTHING;
