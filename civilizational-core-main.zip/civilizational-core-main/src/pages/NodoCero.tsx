import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const links = [
  { label: "GitHub OsoPanda1", href: "https://github.com/OsoPanda1" },
  { label: "TAMV Blog", href: "https://tamvonline.blogspot.com" },
  { label: "TAMV Odoo Oficial", href: "https://tamvonline-oficial.odoo.com" },
  { label: "ORCID", href: "https://orcid.org" },
  { label: "OpenAIRE", href: "https://explore.openaire.eu" },
];

export default function NodoCero() {
  return (
    <main className="container mx-auto py-10 space-y-6">
      <h1 className="text-3xl font-bold">Nodo Cero — RDM Digital</h1>
      <Card>
        <CardHeader>
          <CardTitle>Identidad civilizatoria</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>osopanda1 / Edwin Oswaldo Castillo Trejo / Anubis Villaseñor</p>
          <p>Registro de memoria digital verificable para el ecosistema TAMV ONLINE.</p>
          <ul className="list-disc pl-6">
            {links.map((link) => (
              <li key={link.href}>
                <a className="text-blue-600 underline" href={link.href} target="_blank" rel="noreferrer">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </main>
  );
}
