import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fetchOsoPandaRepos } from "@/lib/osopanda-github";

export default function RDMDashboard() {
  const { data } = useQuery({ queryKey: ["osopanda-repos"], queryFn: fetchOsoPandaRepos });

  const total = data?.length ?? 0;
  const grouped = (data ?? []).reduce<Record<string, number>>((acc, repo) => {
    acc[repo.role] = (acc[repo.role] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <main className="container mx-auto py-10 space-y-6">
      <h1 className="text-3xl font-bold">RDM Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader><CardTitle>Repos detectados</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{total}</p></CardContent>
        </Card>
        {Object.entries(grouped).map(([role, qty]) => (
          <Card key={role}>
            <CardHeader><CardTitle>{role}</CardTitle></CardHeader>
            <CardContent><p className="text-2xl font-semibold">{qty}</p></CardContent>
          </Card>
        ))}
      </div>
      <p className="text-sm text-muted-foreground">Pipeline pendiente: Blogspot → nodes/edges, Odoo → nodes/edges, ledger rdm_events.</p>
    </main>
  );
}
