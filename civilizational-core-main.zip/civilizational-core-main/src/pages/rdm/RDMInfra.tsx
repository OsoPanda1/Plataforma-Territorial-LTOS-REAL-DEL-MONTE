import { Link } from "react-router-dom";
import { RDMLayout } from "@/components/rdm/RDMLayout";
import { RDM_INFRASTRUCTURE_PILLARS, RDM_VISUAL_MODULES } from "@/lib/rdm-visual-infrastructure";

const layerLabel: Record<string, string> = {
  experience: "Experiencia",
  data: "Datos",
  commerce: "Economía",
  governance: "Gobernanza",
};

export default function RDMInfra() {
  return (
    <RDMLayout>
      <section className="px-6 md:px-16 lg:px-24 py-16 space-y-12">
        <div className="max-w-4xl space-y-4">
          <p className="text-sm tracking-[0.25em] uppercase text-[hsl(var(--rdm-amber))]">Infraestructura Visual Unificada</p>
          <h1 className="text-4xl md:text-5xl font-bold">RDM Digital Core</h1>
          <p className="text-[hsl(215_13%_42%)]">
            Esta vista operacional concentra la infraestructura visual del ecosistema RDM en código ejecutable,
            eliminando dependencia documental y priorizando módulos funcionales para despliegue rápido.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {RDM_INFRASTRUCTURE_PILLARS.map((pillar) => (
            <article key={pillar.title} className="rdm-glass rounded-xl p-5">
              <h2 className="text-xl font-semibold mb-2">{pillar.title}</h2>
              <p className="text-sm text-[hsl(215_13%_42%)]">{pillar.description}</p>
            </article>
          ))}
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Módulos fusionados</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {RDM_VISUAL_MODULES.map((module) => (
              <Link to={module.route} key={module.id} className="rdm-glass rounded-xl p-5 hover:scale-[1.01] transition-transform">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-semibold">{module.name}</h3>
                  <span className="text-xs px-2 py-1 rounded-full bg-black/10">
                    {module.status === "active" ? "Activo" : "Staging"}
                  </span>
                </div>
                <p className="text-xs uppercase tracking-wider text-[hsl(var(--rdm-amber))] mb-2">{layerLabel[module.layer]}</p>
                <p className="text-sm text-[hsl(215_13%_42%)]">{module.capability}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </RDMLayout>
  );
}
