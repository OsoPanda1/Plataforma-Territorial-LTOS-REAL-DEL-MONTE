import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fetchOsoPandaRepos } from "@/lib/osopanda-github";

export default function TAMVCore() {
  const { data, isLoading, error } = useQuery({ queryKey: ["osopanda-repos"], queryFn: fetchOsoPandaRepos });

  return (
    <main className="container mx-auto py-10 space-y-6">
      <h1 className="text-3xl font-bold">TAMV Core — Grafo Base</h1>
      <p className="text-sm text-muted-foreground">Datos directos desde GitHub API (usuario OsoPanda1).</p>
      {isLoading && <p>Cargando repositorios...</p>}
      {error && <p className="text-red-600">No fue posible leer GitHub API en este entorno.</p>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data?.map((repo) => (
          <Card key={repo.id}>
            <CardHeader>
              <CardTitle className="text-lg">{repo.name}</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-1">
              <p>Rol: <strong>{repo.role}</strong></p>
              <p>{repo.description ?? "Sin descripción pública"}</p>
              <a href={repo.html_url} target="_blank" rel="noreferrer" className="text-blue-600 underline">Repositorio</a>
            </CardContent>
          </Card>
        ))}
      </div>
    </main>
  );
}
