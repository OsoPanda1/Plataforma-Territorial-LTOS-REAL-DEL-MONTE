export type RDMVisualModule = {
  id: string;
  name: string;
  route: string;
  layer: "experience" | "data" | "commerce" | "governance";
  status: "active" | "staging";
  capability: string;
};

export const RDM_VISUAL_MODULES: RDMVisualModule[] = [
  { id: "mapa", name: "Gemelo Territorial", route: "/rdm/mapa", layer: "data", status: "active", capability: "Mapa inteligente con puntos culturales y comerciales" },
  { id: "gastronomia", name: "Gastronomía Viva", route: "/rdm/gastronomia", layer: "commerce", status: "active", capability: "Directorio gastronómico con narrativa local" },
  { id: "historia", name: "Memoria Histórica", route: "/rdm/historia", layer: "experience", status: "active", capability: "Línea histórica de Real del Monte en experiencia inmersiva" },
  { id: "aventura", name: "Aventura y Naturaleza", route: "/rdm/aventura", layer: "experience", status: "active", capability: "Ecoturismo y rutas de montaña" },
  { id: "cultura", name: "Cultura Federada", route: "/rdm/cultura", layer: "governance", status: "active", capability: "Activación de arte, tradición y comunidad" },
  { id: "directorio", name: "Directorio Local", route: "/rdm/directorio", layer: "commerce", status: "active", capability: "Conexión con negocios locales" },
  { id: "eventos", name: "Agenda Hiperlocal", route: "/rdm/eventos", layer: "experience", status: "active", capability: "Eventos con temporalidad dinámica" },
  { id: "comunidad", name: "Nodo Comunitario", route: "/rdm/comunidad", layer: "governance", status: "active", capability: "Participación y coordinación comunitaria" },
  { id: "rutas", name: "Rutas Inteligentes", route: "/rdm/rutas", layer: "data", status: "staging", capability: "Circuitos por intención turística" },
  { id: "arte", name: "Arte Territorial", route: "/rdm/arte", layer: "experience", status: "active", capability: "Visibilidad a creadores locales" },
  { id: "relatos", name: "Relatos Identitarios", route: "/rdm/relatos", layer: "governance", status: "staging", capability: "Archivo vivo de memoria oral" },
  { id: "ecoturismo", name: "Ecoturismo 4D", route: "/rdm/ecoturismo", layer: "data", status: "active", capability: "Capas ambientales y aventura" },
  { id: "apoya", name: "Economía de Apoyo", route: "/rdm/apoya", layer: "commerce", status: "active", capability: "Mecanismos de contribución y compra local" },
];

export const RDM_INFRASTRUCTURE_PILLARS = [
  {
    title: "Capa de Experiencia XR",
    description: "Narrativas visuales y módulos de descubrimiento que unifican turismo, cultura y memoria.",
  },
  {
    title: "Capa de Datos Federados",
    description: "Mapa, rutas y analítica territorial con soberanía local y sincronización continua.",
  },
  {
    title: "Capa de Economía Local",
    description: "Directorio, gastronomía y flujos de apoyo para activar comercio con impacto comunitario.",
  },
  {
    title: "Capa de Gobernanza Comunitaria",
    description: "Participación ciudadana, protocolos cívicos y memoria auditada desde el territorio.",
  },
] as const;
