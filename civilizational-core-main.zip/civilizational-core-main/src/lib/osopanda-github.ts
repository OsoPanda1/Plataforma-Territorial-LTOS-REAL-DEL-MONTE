export type EcosystemRole =
  | "kernel_rdm"
  | "tamv_core"
  | "mdx_infra"
  | "territorial_node"
  | "civilizational_system"
  | "other";

export interface OsoRepo {
  id: number;
  name: string;
  html_url: string;
  description: string | null;
  topics?: string[];
  pushed_at: string;
}

export interface ClassifiedRepo extends OsoRepo {
  role: EcosystemRole;
}

const roleRules: Array<{ role: EcosystemRole; patterns: RegExp[] }> = [
  { role: "kernel_rdm", patterns: [/rdm/i, /digital-x/i] },
  { role: "tamv_core", patterns: [/tamv/i, /nexus/i, /atlas/i, /utamv/i] },
  { role: "mdx_infra", patterns: [/md-x/i, /mdx/i] },
  { role: "civilizational_system", patterns: [/civiliz/i, /kernel/i, /guardian/i, /realito/i] },
  { role: "territorial_node", patterns: [/real-del-monte/i, /smart-city/i, /explorer/i] },
];

export const classifyRepo = (repo: OsoRepo): EcosystemRole => {
  const haystack = `${repo.name} ${repo.description ?? ""} ${(repo.topics ?? []).join(" ")}`;
  const match = roleRules.find((rule) => rule.patterns.some((pattern) => pattern.test(haystack)));
  return match?.role ?? "other";
};

export const fetchOsoPandaRepos = async (): Promise<ClassifiedRepo[]> => {
  const pages = [1, 2];
  const responses = await Promise.all(
    pages.map((page) =>
      fetch(`https://api.github.com/users/OsoPanda1/repos?per_page=100&page=${page}&sort=updated`, {
        headers: { Accept: "application/vnd.github+json" },
      }),
    ),
  );

  responses.forEach((response) => {
    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status}`);
    }
  });

  const merged = (await Promise.all(responses.map((response) => response.json()))).flat() as OsoRepo[];

  return merged
    .map((repo) => ({ ...repo, role: classifyRepo(repo) }))
    .sort((a, b) => +new Date(b.pushed_at) - +new Date(a.pushed_at));
};
