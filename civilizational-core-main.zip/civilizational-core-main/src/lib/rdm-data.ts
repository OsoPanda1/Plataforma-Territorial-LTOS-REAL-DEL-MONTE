// RDM Digital - Core data definitions

export const REAL_DEL_MONTE_SITES = [
  { id: "1", name: "Mina de Acosta", category: "historia", lat: 20.138, lng: -98.671, rating: 4.8, description: "Mina histórica del siglo XVIII con recorridos guiados sobre técnicas de extracción y vida obrera." },
  { id: "2", name: "Museo de Medicina Laboral", category: "cultura", lat: 20.139, lng: -98.673, rating: 4.6, description: "Espacio clave para entender salud ocupacional y evolución hospitalaria." },
  { id: "3", name: "Panteón Inglés", category: "historia", lat: 20.137, lng: -98.67, rating: 4.9, description: "Patrimonio funerario británico con trazos simbólicos de la migración cornish." },
  { id: "4", name: "Pastes El Portal", category: "gastronomia", lat: 20.14, lng: -98.672, rating: 4.7, description: "Pastes tradicionales cornish en rango local de $20 a $25 MXN." },
  { id: "5", name: "Pastes Kikos", category: "gastronomia", lat: 20.139, lng: -98.674, rating: 4.5, description: "Recetas artesanales con línea tradicional desde 1940." },
  { id: "6", name: "Hotel Real del Monte", category: "hospedaje", lat: 20.141, lng: -98.675, rating: 4.3, description: "Hospedaje colonial con atmósfera de niebla." },
  { id: "7", name: "Peña del Cuervo", category: "aventura", lat: 20.135, lng: -98.668, rating: 4.8, description: "Mirador natural para senderismo fotográfico." },
  { id: "8", name: "Iglesia de la Asunción", category: "cultura", lat: 20.14, lng: -98.671, rating: 4.6, description: "Templo emblemático del centro histórico." },
  { id: "9", name: "Centro Cultural Nicolás Zavala", category: "cultura", lat: 20.138, lng: -98.672, rating: 4.4, description: "Galería y foro para arte local y talleres." },
  { id: "10", name: "Sendero de las Minas", category: "aventura", lat: 20.136, lng: -98.669, rating: 4.7, description: "Ruta interpretativa entre vestigios mineros y bosque." },
  { id: "11", name: "Plaza Principal", category: "cultura", lat: 20.1386, lng: -98.6707, rating: 4.5, description: "Nodo urbano para eventos, comercio y vida comunitaria." },
  { id: "12", name: "Restaurante La Estación", category: "gastronomia", lat: 20.1377, lng: -98.6715, rating: 4.4, description: "Cocina regional con menú de temporada." },
  { id: "13", name: "Cabaña del Bosque", category: "hospedaje", lat: 20.1431, lng: -98.6784, rating: 4.6, description: "Refugio de montaña con vistas al corredor forestal." },
  { id: "14", name: "Cascada de la Sierra", category: "aventura", lat: 20.1324, lng: -98.6642, rating: 4.9, description: "Ruta eco-aventura con sendero interpretativo." },
] as const;

export const BUSINESS_CATEGORIES = [
  { id: "gastronomia", name: "Gastronomía", icon: "🍽️" },
  { id: "artesanias", name: "Artesanías", icon: "🧵" },
  { id: "platerias", name: "Platerías", icon: "💍" },
  { id: "servicios-turisticos", name: "Servicios Turísticos", icon: "🧭" },
  { id: "hospedaje", name: "Hospedaje", icon: "🛏️" },
  { id: "otros", name: "Otros", icon: "🏪" },
];

export const CATEGORY_COLORS: Record<string, string> = {
  historia: "hsl(var(--rdm-amber))",
  cultura: "hsl(var(--rdm-blue))",
  gastronomia: "hsl(var(--rdm-green))",
  aventura: "hsl(var(--rdm-red))",
  hospedaje: "hsl(var(--rdm-purple))",
};
