import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import Index from "./pages/Index";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Recover from "./pages/auth/Recover";
import NotFound from "./pages/NotFound";
import DevHub from "./pages/DevHub";
import Guardian from "./pages/Guardian";
import Atlas from "./pages/Atlas";
import Documentation from "./pages/Documentation";
import NodoCero from "./pages/NodoCero";
import TAMVCore from "./pages/TAMVCore";
import RDMDashboard from "./pages/RDMDashboard";
import RDMMapa from "./pages/rdm/RDMMapa";
import RDMGastronomia from "./pages/rdm/RDMGastronomia";
import RDMHistoria from "./pages/rdm/RDMHistoria";
import RDMAventura from "./pages/rdm/RDMAventura";
import RDMCultura from "./pages/rdm/RDMCultura";
import RDMDirectorio from "./pages/rdm/RDMDirectorio";
import RDMEventos from "./pages/rdm/RDMEventos";
import RDMComunidad from "./pages/rdm/RDMComunidad";
import RDMRutas from "./pages/rdm/RDMRutas";
import RDMArte from "./pages/rdm/RDMArte";
import RDMRelatos from "./pages/rdm/RDMRelatos";
import RDMEcoturismo from "./pages/rdm/RDMEcoturismo";
import RDMApoya from "./pages/rdm/RDMApoya";
import RDMInfra from "./pages/rdm/RDMInfra";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/devhub" element={<DevHub />} />
            <Route path="/guardian" element={<Guardian />} />
            <Route path="/atlas" element={<Atlas />} />
            <Route path="/docs" element={<Documentation />} />
            <Route path="/auth/login" element={<Login />} />
            <Route path="/auth/register" element={<Register />} />
            <Route path="/auth/recover" element={<Recover />} />
            {/* RDM Digital */}
            <Route path="/nodo-cero" element={<NodoCero />} />
            <Route path="/tamv-core" element={<TAMVCore />} />
            <Route path="/rdm-dashboard" element={<RDMDashboard />} />
            <Route path="/rdm" element={<RDMDashboard />} />
            <Route path="/rdm/mapa" element={<RDMMapa />} />
            <Route path="/rdm/gastronomia" element={<RDMGastronomia />} />
            <Route path="/rdm/historia" element={<RDMHistoria />} />
            <Route path="/rdm/aventura" element={<RDMAventura />} />
            <Route path="/rdm/cultura" element={<RDMCultura />} />
            <Route path="/rdm/directorio" element={<RDMDirectorio />} />
            <Route path="/rdm/eventos" element={<RDMEventos />} />
            <Route path="/rdm/comunidad" element={<RDMComunidad />} />
            <Route path="/rdm/rutas" element={<RDMRutas />} />
            <Route path="/rdm/arte" element={<RDMArte />} />
            <Route path="/rdm/relatos" element={<RDMRelatos />} />
            <Route path="/rdm/ecoturismo" element={<RDMEcoturismo />} />
            <Route path="/rdm/apoya" element={<RDMApoya />} />
            <Route path="/rdm/infra" element={<RDMInfra />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
