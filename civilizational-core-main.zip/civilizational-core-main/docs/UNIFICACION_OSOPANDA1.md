# Unificación OsoPanda1 → TAMV Digital Nexus

Este documento habilita una base **operativa y ejecutable** para absorber conocimiento desde los repositorios de `OsoPanda1` dentro de este proyecto.

## Qué hace ahora mismo

1. Descubre repos del usuario vía API de GitHub.
2. Normaliza metadatos por repo (lenguaje, tópicos, estado, tamaño, etc.).
3. Clasifica por dominios funcionales (`ai`, `xr`, `frontend`, `backend`, `infra`).
4. Genera una base inicial de absorción en `data/knowledge-absorption/`:
   - `repos-manifest.json`
   - `repos-summary.json`

## Cómo ejecutar

```bash
npm run unify:osopanda
```

Opcional (para mayor cuota/rate limit):

```bash
GITHUB_TOKEN=tu_token GH_OWNER=OsoPanda1 npm run unify:osopanda
```

## Siguiente paso recomendado (despliegue 3h)

- Correr `unify:osopanda` en CI cada 6h.
- Consumir `repos-summary.json` en Atlas para tablero de convergencia tecnológica.
- Activar pipeline incremental de clonación selectiva (top N por prioridad) para indexado semántico.

## Nota realista

GitHub API `/users/{owner}/repos` devuelve hasta 100 por página; para unificación total de 177 repos se debe implementar paginación (`page=2`, etc.).
La base ya queda preparada para extender ese flujo sin romper compatibilidad de salida.
