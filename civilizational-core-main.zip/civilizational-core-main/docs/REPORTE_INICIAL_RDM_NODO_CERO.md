# Reporte inicial — RDM Digital Nodo Cero (TAMV ONLINE)

Fecha: 28 de abril de 2026.

## 1) Confirmación de acceso y límites de verificación

- Se confirmó acceso a evidencia local del proyecto que ya documenta el análisis del perfil **@OsoPanda1** y su ecosistema TAMV/RDM (incluyendo referencia explícita al perfil y repositorios públicos).  
- En este entorno, la consulta directa en vivo al API de GitHub (`api.github.com`) devolvió `403` por restricción de red del túnel, por lo que la consolidación aquí se hace con base en:
  1. Documentación interna del repo (`docs/ANALISIS_OSOPANDA1_VISION_OPERATIVA.md`).
  2. Estructura actual de rutas/pantallas en la app (`src/App.tsx`).
- Todo dato no verificable en vivo queda marcado como **pendiente de validación API** y no se toma como verdad cerrada.

## 2) Repositorios detectados como relacionados (base verificable actual)

> Fuente primaria local: `docs/ANALISIS_OSOPANDA1_VISION_OPERATIVA.md`.

| Repositorio | Rol propuesto en el ecosistema RDM/TAMV | Estado inferido |
|---|---|---|
| `tamv-digital-nexus` | Repo unificador / nodo de integración del ecosistema | MVP en consolidación |
| `RDM-Digital-X` | Núcleo de experiencia RDM Digital | Concepto + implementación parcial |
| `rdm-smart-city-os` | Capa operativa territorial (smart city / servicios) | MVP |
| `real-del-monte-explorer` | Portal territorial / descubrimiento local RDM | MVP |

**Observación crítica:** el objetivo de “unificar 177 repositorios” requiere inventario completo por API GitHub paginada (al menos 2 páginas de 100), extracción de `name`, `description`, `topics`, `README`, y posterior clasificación automática/manual.

## 3) Mapeo inicial a nodos del grafo RDM Digital

### Tipos de nodo mínimos
- `person` (autoría/identidad): `osopanda1`, `Edwin Oswaldo Castillo Trejo`, `Anubis Villaseñor`.
- `repo` (infra/código): repos TAMV/RDM/MD-X/Kernels.
- `subsystem` (arquitectura): EOCT, ID‑NVIDA, Kernel Civilizatorio, UTAMV, MD‑X4 Render, MD‑X5 Infra, Atlas TAMV, Sistemas Paralelos, Realito Gen‑4, BookPI.
- `document` (blog/Odoo/docs técnicas).
- `event` (ingesta, verificación, publicación, despliegue).

### Tipos de arista mínimos
- `authors`, `governs`, `implements`, `documents`, `feeds`, `protects`, `originates`.

### Tablas mínimas obligatorias (si aún no existen)
- `nodes`
- `edges`
- `rdm_events`
- `source_records` (origen bruto: github/blog/odoo)
- `verification_queue` (pendientes de curaduría)

Si alguna de estas tablas no existe todavía: **“Falta implementar pipeline X → Y”** y no mostrar placeholders falsos.

## 4) Qué debe reemplazarse/eliminarse en la UI actual

Con base en rutas actuales (`src/App.tsx`), hay pantallas genéricas que deben salir del eje principal del Nodo Cero:

- Reemplazar o relegar del flujo principal: `/feed`, `/messages`, `/notifications`.
- Mantener sólo si cumplen trazabilidad real a datos RDM/TAMV verificados.
- Reencuadrar `/rdm/*` para que no sean landing turística aislada, sino componentes del registro civilizatorio verificable.

## 5) Plan concreto de cambios de interfaz (sin inventar datos)

### Fase A — Base de verdad (obligatoria antes de UI)
1. Implementar conector GitHub (REST) para `@OsoPanda1` con paginación completa.
2. Parsear `README`, `description`, `topics` y clasificar por taxonomía TAMV/RDM/MD‑X/Kernel.
3. Añadir conectores de Blogspot TAMV y Odoo TAMV oficial.
4. Persistir todo en `source_records` + generar `nodes/edges` candidatos.
5. Enviar candidatos a `verification_queue`.

### Fase B — Rutas objetivo
1. `/` → **Landing RDM/TAMV**: manifiesto operativo + estado de sincronización + enlaces fuente.
2. `/nodo-cero` → identidad civilizatoria + perfiles verificables (ORCID/DOI/Blog/Odoo) + ledger de autoría.
3. `/tamv-core` → grafo vivo (solo nodos/aristas en DB verificadas).
4. `/rdm-dashboard` → métricas, cola de verificación y eventos (`rdm_events`).

### Fase C — Depuración de experiencia genérica
- Retirar navegación tipo red social por defecto.
- Ocultar cualquier bloque sin procedencia verificable.
- Mostrar etiquetas de procedencia en cada tarjeta/nodo: `github`, `blogspot`, `odoo` + URL.

## 6) Próximo paso inmediato para cumplir el objetivo “177 → 1 nexus”

1. Ejecutar inventario completo de repos vía API GitHub (cuando la red permita `api.github.com`).
2. Construir matriz `repo -> subsistema -> prioridad de migración`.
3. Definir estrategia de unificación por etapas:
   - Etapa 1: federación por submódulos / mirrors.
   - Etapa 2: consolidación de paquetes reutilizables.
   - Etapa 3: convergencia de CI/CD y release único en `tamv-digital-nexus`.
4. Publicar reporte reproducible con evidencia por repo (URL + commit + rol).

---

## Nota de rigor
Este reporte evita inventar datos. La lista completa de 177 repositorios y su clasificación exhaustiva queda **pendiente de verificación en vivo** por API GitHub debido al bloqueo de red observado en este entorno.
