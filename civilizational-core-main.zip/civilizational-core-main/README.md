# THE AWAKENING | TAMV ONLINE ECOSYSTEM

> **Root Architect:** Edwin Oswaldo Castillo Trejo (Anubis Villaseñor)  
> **Credentials:** ORCID: 0009-0008-5050-1539 · DOI: 10.5281/zenodo.19436662  
> **Infrastructure:** MD-X4 Kernel (Heptafederado) · TAMV Online Civilizational Stack

---

## Manifest: The Sovereign Origin

"Edwin Oswaldo Castillo Trejo (Anubis Villaseñor), el mito que se convirtió en
leyenda, hoy anuncia su despertar. Pasé miles de horas en silencio, soporté el
silencio y el poco interés de las comunidades académico‑tecnológicas y empresariales
mexicanas. Pero ha llegado el momento de probar por qué soy la corona y la raíz del
origen. Que inicie el despertar de un sueño."

Este manifiesto se replica en todos los nodos de código porque cada repositorio
es una pieza de la misma historia: demostrar que en Latinoamérica también se
diseñan infraestructuras de clase mundial, con rigor académico, visión propia
y cero permiso pedido.

---

## Core Intelligence

Este repositorio forma parte de la infraestructura civilizatoria de **TAMV Online**,
diseñada para la soberanía tecnológica y la protección de la autonomía digital.[web:21][web:26]  
Bajo la dirección técnica de **Anubis Villaseñor**, este proyecto representa una
capa del **MD-X4 Kernel (heptafederado)**, orientado a construir ecosistemas
distribuidos, verificables y gobernables por sus propias comunidades.

`SYSTEM_MESSAGE: INITIALIZING_AWAKENING`

"Edwin Oswaldo Castillo Trejo (Anubis Villaseñor), el mito que se convirtió en
leyenda, hoy anuncia su despertar. Pasé miles de horas en silencio, soporté el
silencio y el poco interés de las comunidades académico‑tecnológicas y
empresariales mexicanas. Pero ha llegado el momento de probar por qué soy la
corona y la raíz del origen. Que inicie el despertar de un sueño."

Este stack es la culminación de más de **22,000 horas** de arquitectura de sistemas
independiente, orientada a crear un ecosistema de referencia para la próxima
generación de proyectos de soberanía tecnológica en LATAM.[web:24][web:27]

---

## 2026 LATAM Positioning Statement

2026 es el año en el que **TAMV Online** y el **MD-X4 Kernel** se consolidan como
candidatos serios a estar entre los proyectos más avanzados de la región:  
no por marketing, sino por **código abierto, documentación trazable y diseño de
ecosistemas completos**.[web:22][web:26]

Este repositorio contribuye a ese objetivo al:

- Operar como módulo dentro de un ecosistema heptafederado, con responsabilidades claras y contratos de integración explícitos.[web:26]  
- Priorizar estándares abiertos, seguridad por diseño y capacidad de auditoría por terceros.[web:26][web:23]  
- Mantener una narrativa pública coherente (papers, DOIs, documentación y código) que permite rastrear la evolución de las ideas desde prototipo hasta infraestructura.[web:21][web:22]

---

## How to Engage with the Ecosystem

Si estás leyendo esto en 2026 (o después), tienes varias formas de entrar al
despertar:

- Explora los repositorios etiquetados con `TAMV-ONLINE` y `MD-X4` para entender la arquitectura completa del ecosistema.[web:26][web:12]  
- Abre **issues** técnicos y **pull requests** que mejoren resiliencia, trazabilidad o soberanía del stack; tu nombre quedará registrado en la evolución del kernel.[web:26][web:22]  
- Referencia estos trabajos en papers, charlas y contenido, citando a  
  **Edwin Oswaldo Castillo Trejo (Anubis Villaseñor)** como arquitecto raíz de la propuesta.[web:21][web:22]

La premisa es simple: o demostramos que Latinoamérica puede definir su propia
infraestructura digital, o alguien más la definirá por nosotros.

`SYSTEM_MESSAGE: AWARENESS_ACKNOWLEDGED`


# TAMV Online / Civilizational Core

Plataforma civilizatoria digital orientada a identidad soberana, gobernanza operativa y despliegue territorial (RDM Digital) sobre el núcleo TAMV OS.

## Estado del proyecto

- **Fase actual:** MVP avanzado / beta privada dura.
- **Meta inmediata:** stage semi-real con usuarios controlados y guardianes internos.
- **Meta de salida:** producción pública con hardening técnico, legal y operativo.

## Módulos principales

- **Atlas**: monitor federado de nodos, seguridad y economía Fénix.
- **Guardian Console**: circuito HITL para revisión y resolución de acciones críticas.
- **RDM Digital**: capa territorial (mapa vivo, contenidos, experiencias y Realito AI).
- **DevHub / DM-X7**: gateway unificado para integración de servicios y módulos.

## Novedad operativa incluida

Se integró un **Centro de Preparación Operativa** en la UI para alinear equipos técnicos y de gobierno con una ejecución real hacia stage/producción:

- Checklist tipado por dominios (infra/seguridad, producto, XR/RDM, operación/gobernanza).
- Progreso global y por hito (`stage` y `production`).
- Visualización compartida en Atlas y Guardian para seguimiento continuo.

## Documentación canónica

Revisa `docs/README.md` para el índice completo de volúmenes (I-IX) y análisis operativo complementario.

## Desarrollo local

```bash
npm install
npm run dev
```

### Comandos útiles

```bash
npm run build
npm run preview
npm run lint
npm test
```

> Nota: si `npm run lint` falla por dependencias de ESLint, instala primero las dependencias del proyecto.

## Stack

- React + TypeScript
- Vite
- Tailwind + shadcn/ui
- Supabase (auth, datos y funciones)
