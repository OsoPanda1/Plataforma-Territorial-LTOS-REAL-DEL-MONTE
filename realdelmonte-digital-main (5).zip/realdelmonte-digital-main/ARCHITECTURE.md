# Arquitectura RDM Digital / Nodo Cero TAMV

## 1. Propósito arquitectónico

RDM Digital es una SPA React/Vite conectada a Supabase y Edge Functions. Su objetivo no es solo publicar una landing turística: opera como sistema territorial para turismo, economía local, memoria cultural, IA contextual y módulos TAMV.

## 2. Capas del sistema

```text
L0 Territorio
  Real del Monte físico, rutas, comercios, patrimonio, eventos.

L1 Datos
  Supabase, corpus estático, POIs, directorio, contenido cultural.

L2 Experiencia Web
  React, Vite, Tailwind, shadcn/ui, framer-motion.

L3 IA Territorial
  REALITO / Isabella, prompt especializado, corpus, futura base vectorial.

L4 Operación
  Dashboard, telemetría, auditoría, economía, comunidad.

L5 TAMV
  Nodo Cero, tesis soberana, MSR status, API explorer, operativo, fusión.

L6 Seguridad / Gobernanza
  CORS restringido, secretos en edge runtime, auditoría, guías de producción.
```

## 3. Frontend

Puntos de entrada:

- `src/main.tsx`: bootstrapping React.
- `src/App.tsx`: providers, lazy loading y rutas.
- `src/components/Navbar.tsx`: navegación pública y menú Nodo Cero.
- `src/pages/Index.tsx`: home turístico y Command Center.
- `src/pages/Fusion.tsx`: repos absorbidos y mejoras integradas.
- `src/pages/Operativo.tsx`: madurez operativa por módulo.

Patrones:

- Lazy loading para páginas.
- Providers centralizados: React Query, Tooltip, RDM system state.
- UI componible con shadcn/ui y Tailwind.
- Servicios frontend en `src/services/*` para analítica, telemetría y auditoría.

## 4. Supabase y Edge Functions

Funciones actuales:

| Función | Propósito | Riesgo principal | Control aplicado |
| --- | --- | --- | --- |
| `chat` | REALITO / Isabella AI | abuso de API, CORS abierto, prompt leakage | CORS allowlist, key en runtime, errores controlados |
| `stripe-checkout` | Crear sesiones de pago | URLs maliciosas, montos inválidos, secreto Stripe | CORS allowlist, validación de items, URLs same-origin |
| `ipfs-upload` | Pinning IPFS / Pinata | pinning anónimo, abuso de storage | auth requerida, CORS allowlist, JWT backend |

CORS compartido vive en `supabase/functions/_shared/cors.ts` y debe configurarse con:

```text
RDM_ALLOWED_ORIGINS=https://realdelmonte.digital,https://app.realdelmonte.digital,https://realdelmonte-digital.lovable.app
```

## 5. IA territorial

Estado actual:

```text
REALITO Floating Chat
  -> Supabase Edge Function chat
    -> Prompt especializado
    -> Corpus territorial embebido
    -> Gateway IA
```

Arquitectura objetivo:

```text
Corpus versionado
  -> chunking semántico
  -> embeddings
  -> vector store
  -> retrieval por intención/ubicación/ruta
  -> respuesta REALITO
  -> memoria conversacional
  -> auditoría de decisión
```

Entidades sugeridas:

- `content_documents`
- `content_chunks`
- `content_embeddings`
- `conversation_sessions`
- `conversation_memory`
- `ai_decision_records`

## 6. Datos, telemetría y auditoría

Servicios añadidos:

- `src/services/analytics.ts`: eventos de producto y adopción.
- `src/services/telemetry.ts`: señales de performance, territorio, comercio, IA y seguridad.
- `src/services/audit.ts`: buffer local de auditoría para trazabilidad básica.

Estos servicios están diseñados para trabajar offline/local y luego conectarse a endpoints reales (`VITE_ANALYTICS_ENDPOINT`, `VITE_TELEMETRY_ENDPOINT`).

## 7. Stripe

Flujo:

```text
Frontend donativo / negocio
  -> supabase/functions/stripe-checkout
    -> valida origen
    -> valida line_items
    -> normaliza success/cancel URL al origin permitido
    -> crea Stripe Checkout Session
```

Nunca exponer `STRIPE_SECRET_KEY` en Vite. Debe vivir como Supabase Secret.

## 8. SEO y Knowledge Graph

Estado:

- `scripts/generate-sitemap.ts` genera `public/sitemap.xml`.
- `SEOMeta` soporta title, description, canonical, OG y JSON-LD.

Siguiente paso recomendado:

- JSON-LD por página (`TouristDestination`, `LocalBusiness`, `Event`, `Place`).
- Knowledge Graph territorial en `/corpus` y `/enciclopedia`.
- OpenGraph por rutas turísticas.

## 9. Performance visual

Riesgos:

- Animaciones y efectos cinematic pueden elevar LCP / CLS en móvil.
- Imágenes grandes pueden afectar TTI.

Controles recomendados:

- `prefers-reduced-motion` en efectos pesados.
- IntersectionObserver para inicializar niebla/partículas solo cuando entren al viewport.
- Dynamic imports para componentes no críticos.
- Budget de assets hero por debajo de 250 KB cuando sea posible.

## 10. Diagrama de flujo principal

```text
Visitante
  -> Home / Mapa / Ruta / Catálogo
  -> REALITO sugiere experiencia
  -> Usuario abre comercio/ruta/evento
  -> Analytics + Telemetry registran señal
  -> Si hay pago: Stripe Checkout Edge Function
  -> Si hay aporte documental: IPFS upload autenticado
  -> Dashboard/Operativo consolida madurez y actividad
```

## 11. Deuda técnica priorizada

1. Vector store + RAG para REALITO.
2. Observabilidad remota para servicios `analytics`, `telemetry`, `audit`.
3. Webhooks Stripe y reconciliación de pagos.
4. Event sourcing territorial.
5. Refactor de páginas grandes en containers/components/hooks.
6. JSON-LD avanzado y Knowledge Graph.
