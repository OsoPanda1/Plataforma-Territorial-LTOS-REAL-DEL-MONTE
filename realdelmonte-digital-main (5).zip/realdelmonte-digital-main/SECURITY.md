# Security Policy · RDM Digital

## Principios

RDM Digital opera información turística, comercial, comunitaria y potencialmente transaccional. La seguridad debe tratarse como requisito institucional, no como tarea posterior.

Principios base:

- Menor privilegio.
- Secretos nunca en frontend.
- CORS restringido.
- Validación server-side en pagos y uploads.
- Auditoría de eventos sensibles.
- RLS obligatoria en tablas Supabase con datos privados.

## Secretos

Nunca exponer en variables `VITE_*`:

```text
SUPABASE_SERVICE_ROLE_KEY
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
OPENAI_API_KEY
LOVABLE_API_KEY
PINATA_JWT
```

Estos valores deben vivir en Supabase Secrets o en el proveedor backend.

Permitido en frontend:

```text
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
VITE_API_BASE_URL
VITE_ANALYTICS_ENDPOINT
VITE_TELEMETRY_ENDPOINT
```

## CORS

Las Edge Functions usan `supabase/functions/_shared/cors.ts` y deben recibir:

```text
RDM_ALLOWED_ORIGINS=https://realdelmonte.digital,https://app.realdelmonte.digital,https://realdelmonte-digital.lovable.app
```

Dominios locales permitidos solo para desarrollo:

```text
http://localhost:8080
http://127.0.0.1:8080
```

## Supabase

Requisitos:

- RLS habilitada por defecto.
- Policies separadas para lectura pública, escritura autenticada y administración.
- No usar service role en frontend.
- Edge Functions deben validar `Authorization` cuando escriban datos privados o suban archivos.

## Stripe

`supabase/functions/stripe-checkout/index.ts` debe mantener:

- `STRIPE_SECRET_KEY` en Supabase Secrets.
- Validación de `items`.
- Límites de monto y cantidad.
- URLs de éxito/cancelación same-origin.
- Webhook futuro con `STRIPE_WEBHOOK_SECRET`.

Checklist antes de pagos reales:

- [ ] Webhook con verificación de firma.
- [ ] Tabla `orders` / `payments` con estado reconciliado.
- [ ] Idempotency key.
- [ ] Rate limit por usuario/IP.
- [ ] Logs sin datos de tarjeta.

## IA / REALITO

Riesgos:

- Prompt injection.
- Uso excesivo de API.
- Respuestas fuera de corpus.
- Falta de trazabilidad.

Controles:

- Prompt territorial explícito.
- Corpus curado.
- Futura recuperación RAG con fuentes.
- Auditoría de decisiones relevantes.
- Rate limiting por sesión/IP.

## IPFS / Pinata

`ipfs-upload` requiere token Supabase y `PINATA_JWT` backend.

No permitir:

- Pinning anónimo.
- Archivos sin límites.
- Metadata sin `uploader`.

Pendiente:

- Límite de tamaño.
- Lista de MIME types permitidos.
- Moderación de contenido.

## Reporte de vulnerabilidades

Reportar vulnerabilidades con:

- Descripción.
- Ruta/función afectada.
- Pasos de reproducción.
- Impacto esperado.
- Evidencia mínima sin exponer datos reales.

No publicar secretos, tokens ni información personal en issues públicos.
