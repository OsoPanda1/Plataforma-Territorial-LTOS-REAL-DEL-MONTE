# Production Guide · RDM Digital / Nodo Cero

## 1. Requisitos

- Node.js >= 20
- pnpm 9.x
- Bun >= 1.1
- Proyecto Supabase configurado
- Dominio final definido
- Cuenta Stripe si se activan pagos
- Pinata/IPFS si se activan anclajes documentales

## 2. Variables frontend

Configurar en el proveedor de hosting:

```text
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
VITE_API_BASE_URL=
VITE_ANALYTICS_ENDPOINT=
VITE_TELEMETRY_ENDPOINT=
```

No configurar secretos backend con prefijo `VITE_`.

## 3. Supabase Secrets

Configurar en Supabase:

```text
RDM_ALLOWED_ORIGINS=https://realdelmonte.digital,https://app.realdelmonte.digital,https://realdelmonte-digital.lovable.app
LOVABLE_API_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
PINATA_JWT=
```

## 4. Validación previa

```bash
pnpm install
pnpm lint
pnpm check:types
pnpm test
pnpm build
```

El build ejecuta `scripts/generate-sitemap.ts` y actualiza `public/sitemap.xml`.

## 5. Despliegue frontend

Publicar `dist/` en el proveedor elegido.

Validaciones manuales:

- `/`
- `/mapa`
- `/fusion`
- `/operativo`
- `/tamv`
- `/tamv/status`
- `/tamv/api`
- `/tamv/thesis`
- `/directorio`
- `/negocios`
- `/donar`

## 6. Despliegue Edge Functions

Funciones críticas:

```text
supabase/functions/chat
supabase/functions/stripe-checkout
supabase/functions/ipfs-upload
```

Checklist:

- [ ] `RDM_ALLOWED_ORIGINS` configurado.
- [ ] `chat` responde solo desde dominios permitidos.
- [ ] `stripe-checkout` crea sesión con montos válidos.
- [ ] `ipfs-upload` rechaza solicitudes sin `Authorization`.
- [ ] Logs no exponen secretos.

## 7. IA / REALITO

Antes de producción institucional:

- Validar prompt contra prompt injection.
- Definir rate limit.
- Versionar corpus.
- Planificar vector store/RAG.
- Registrar métricas de latencia y fallback.

## 8. Pagos

Antes de activar dinero real:

- Crear webhook Stripe.
- Verificar firma con `STRIPE_WEBHOOK_SECRET`.
- Registrar órdenes en Supabase.
- Reconciliar estados `pending`, `paid`, `failed`, `refunded`.
- Probar pagos con tarjetas de test.

## 9. Observabilidad

Base actual:

- Auditoría local: `src/services/audit.ts`
- Analytics: `src/services/analytics.ts`
- Telemetry: `src/services/telemetry.ts`

Para producción:

- Crear endpoints persistentes para analytics/telemetry.
- Definir retención.
- Alertar errores críticos.
- Medir LCP/CLS/TTI por dispositivo.

## 10. Rollback

Si una publicación falla:

1. Revertir release en hosting.
2. Revertir Edge Function específica si el problema es backend.
3. Desactivar pagos temporalmente si Stripe falla.
4. Mantener `/tamv/status` en fallback local para comunicar estado.

## 11. Checklist final

- [ ] Build limpio.
- [ ] Sitemap actualizado.
- [ ] Robots revisado.
- [ ] Dominio y canonical correctos.
- [ ] Supabase RLS revisado.
- [ ] CORS restringido.
- [ ] Secretos fuera del frontend.
- [ ] Lighthouse móvil aceptable.
- [ ] Chat REALITO probado.
- [ ] Stripe/IPFS probados o desactivados.
