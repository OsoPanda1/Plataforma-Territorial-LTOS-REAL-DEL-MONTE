# RDM Digital · Nodo Cero TAMV

RDM Digital es el sistema operativo territorial de Real del Monte, Hidalgo: una plataforma turística, comercial, cultural y civilizatoria que unifica el gemelo digital del pueblo, REALITO / Isabella AI, el directorio comercial, la memoria cultural, el mapa vivo y la capa TAMV de soberanía tecnológica.

## Visión

El proyecto busca que Real del Monte deje de depender de plataformas externas para narrarse, operar su economía y preservar su memoria. El repositorio funciona como **Nodo Cero**: el punto donde turismo, comunidad, comercios, IA territorial, telemetría, documentación y gobernanza se convierten en una interfaz pública y auditable.

Principios:

- **Soberanía territorial:** datos, narrativa, identidad y economía se administran desde el territorio.
- **Turismo inteligente:** rutas, mapa, catálogo, eventos y recomendaciones se conectan en una experiencia continua.
- **IA con memoria local:** REALITO / Isabella responde desde corpus cultural, reglas de cuidado y contexto del visitante.
- **Fusión TAMV:** el conocimiento de los repos RDM/TAMV/Smart City se consolida en rutas reales, documentación y tableros operativos.
- **Auditoría institucional:** seguridad, producción, arquitectura y riesgos se documentan para operación seria.

## Superficie funcional

| Área | Rutas principales | Descripción |
| --- | --- | --- |
| Portal turístico | `/`, `/lugares`, `/rutas`, `/mapa` | Descubrimiento del territorio, sitios, rutas y mapa vivo. |
| Cultura y memoria | `/historia`, `/cultura`, `/relatos`, `/dichos`, `/corpus`, `/enciclopedia` | Preservación narrativa e identidad minera. |
| Economía local | `/directorio`, `/catalogo`, `/negocios`, `/donar`, `/apoya` | Directorio, catálogo, onboarding y apoyo económico. |
| TAMV / Nodo Cero | `/tamv`, `/tamv/status`, `/tamv/api`, `/tamv/thesis`, `/operativo`, `/fusion` | Estado MSR, API Explorer, tesis, operativo y repos absorbidos. |
| Administración | `/admin`, `/dashboard` | Telemetría, comunidad, Isabella, economía y perfil técnico. |

## Arquitectura resumida

```text
React/Vite SPA
  ├─ UI turística y cultural
  ├─ REALITO Floating Chat
  ├─ TAMV Hub / Status / API / Thesis / Operativo
  ├─ Servicios frontend: analytics, telemetry, audit
  └─ Supabase client

Supabase
  ├─ Auth + database
  ├─ Edge Function chat
  ├─ Edge Function stripe-checkout
  └─ Edge Function ipfs-upload

Capas futuras
  ├─ Vector store / RAG para corpus territorial
  ├─ Observabilidad centralizada
  ├─ Event sourcing territorial
  └─ Contratos MSR / BookPI / Phoenix 20-30-50
```

Para más detalle consulta [`ARCHITECTURE.md`](./ARCHITECTURE.md), [`SECURITY.md`](./SECURITY.md), [`AUDIT_REPORT.md`](./AUDIT_REPORT.md) y [`PRODUCTION_GUIDE.md`](./PRODUCTION_GUIDE.md).

## IA territorial: estado y siguiente evolución

La función `supabase/functions/chat/index.ts` usa un prompt especializado y corpus territorial. El objetivo institucional es evolucionar hacia:

```text
Corpus estático
+ Base vectorial
+ RAG
+ Memoria conversacional
+ Auditoría de decisiones
```

Contrato recomendado:

1. Ingestar corpus en tablas versionadas.
2. Crear embeddings por fragmento.
3. Recuperar contexto por intención, ruta, ubicación y perfil.
4. Registrar cada respuesta relevante en auditoría local / backend.
5. Medir satisfacción, latencia y cobertura del corpus.

## Instalación local

Requisitos:

- Node.js >= 20
- pnpm 9.x
- Bun >= 1.1 para scripts `bunx tsx`

```bash
pnpm install
pnpm dev
```

Validación completa:

```bash
pnpm lint
pnpm check:types
pnpm test
pnpm build
```

## Variables de entorno

Copia `.env.example` a `.env.local` y configura únicamente valores públicos en Vite. Las claves secretas viven en Supabase Secrets, no en el frontend.

```bash
cp .env.example .env.local
```

Secretos críticos que **no deben exponerse en Vite**:

- `SUPABASE_SERVICE_ROLE_KEY`
- `STRIPE_SECRET_KEY`
- `OPENAI_API_KEY`
- `LOVABLE_API_KEY`
- `PINATA_JWT`

## Despliegue

1. Ejecutar checks locales.
2. Configurar `RDM_ALLOWED_ORIGINS` en Supabase Edge Functions.
3. Configurar secretos de Supabase (`LOVABLE_API_KEY`, `STRIPE_SECRET_KEY`, `PINATA_JWT`, etc.).
4. Ejecutar `pnpm build`.
5. Publicar `dist/` en el proveedor elegido.
6. Validar `/tamv/status`, `/tamv/api`, `/fusion`, `/operativo` y el chat REALITO.

## Gobernanza de cambios

Cada cambio funcional debe indicar:

- Ruta o módulo afectado.
- Riesgo de seguridad.
- Impacto en SEO / performance.
- Si toca IA, cómo afecta corpus, memoria o auditoría.
- Si toca pagos, cómo se validó Stripe y CORS.

## Licencia y autoría

Proyecto impulsado desde Real del Monte, Hidalgo, por Edwin Oswaldo Castillo Trejo / Anubis Villaseñor como Nodo Cero del ecosistema RDM Digital / TAMV.
