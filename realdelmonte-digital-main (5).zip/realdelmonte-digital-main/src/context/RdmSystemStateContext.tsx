import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
} from "react";

// Nivel de riesgo e intensidad percibida en el territorio
export type RdmRiskLevel = "low" | "medium" | "high" | "critical";

export type RdmSystemFlags = {
  threadError: boolean;        // Falla en “hilo” o servicio
  loadBalancing: boolean;     // Sistema redistribuyendo carga
  highRiskZone: boolean;      // Zona en estado de vulnerabilidad
  trafficRecovered: boolean;  // Señal puntual de recuperación
};

export type RdmSystemMeta = {
  riskLevel: RdmRiskLevel;
  lastIncidentAt: number | null;
  lastRecoveryAt: number | null;
  // Podrías mapear aquí territorios: "rdm-digital", "centro-historico", etc.
  activeTerritoryId?: string;
};

type RdmSystemStateContextType = RdmSystemFlags &
  RdmSystemMeta & {
    // Disparadores básicos
    triggerError: (opts?: { territoryId?: string }) => void;
    triggerRecovery: (opts?: { territoryId?: string }) => void;
    setHighRisk: (v: boolean, opts?: { territoryId?: string }) => void;

    // Comandos de alto nivel (para Isabella / CITEMESH)
    markCriticalIncident: (opts?: { territoryId?: string }) => void;
    downgradeRisk: () => void;
  };

const RdmSystemStateContext =
  createContext<RdmSystemStateContextType | null>(null);

// Config centralizada de tiempos (ms)
const DURATIONS = {
  transitionErrorToBalancing: 2500,
  transitionBalancingToRecovered: 2500,
  flashRecovered: 3000,
};

export const RdmSystemStateProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [flags, setFlags] = useState<RdmSystemFlags>({
    threadError: false,
    loadBalancing: false,
    highRiskZone: false,
    trafficRecovered: false,
  });

  const [meta, setMeta] = useState<RdmSystemMeta>({
    riskLevel: "low",
    lastIncidentAt: null,
    lastRecoveryAt: null,
    activeTerritoryId: undefined,
  });

  const triggerError = useCallback(
    (opts?: { territoryId?: string }) => {
      const territoryId = opts?.territoryId;
      const now = Date.now();

      setFlags(f => ({
        ...f,
        threadError: true,
        loadBalancing: false,
        trafficRecovered: false,
      }));
      setMeta(m => ({
        ...m,
        riskLevel: m.riskLevel === "critical" ? "critical" : "high",
        lastIncidentAt: now,
        activeTerritoryId: territoryId ?? m.activeTerritoryId,
      }));

      // Secuencia de transición: error → balanceo → recuperación
      window.setTimeout(() => {
        setFlags(f => ({
          ...f,
          threadError: false,
          loadBalancing: true,
        }));

        window.setTimeout(() => {
          setFlags(f => ({
            ...f,
            loadBalancing: false,
            trafficRecovered: true,
          }));
          setMeta(m => ({
            ...m,
            riskLevel:
              m.riskLevel === "critical" ? "high" : "medium",
            lastRecoveryAt: Date.now(),
          }));

          window.setTimeout(() => {
            setFlags(f => ({ ...f, trafficRecovered: false }));
          }, DURATIONS.flashRecovered);
        }, DURATIONS.transitionBalancingToRecovered);
      }, DURATIONS.transitionErrorToBalancing);
    },
    []
  );

  const triggerRecovery = useCallback(
    (opts?: { territoryId?: string }) => {
      const territoryId = opts?.territoryId;
      const now = Date.now();

      setFlags(f => ({
        ...f,
        trafficRecovered: true,
        threadError: false,
        loadBalancing: false,
      }));
      setMeta(m => ({
        ...m,
        riskLevel:
          m.riskLevel === "critical" ? "high" : "medium",
        lastRecoveryAt: now,
        activeTerritoryId: territoryId ?? m.activeTerritoryId,
      }));

      window.setTimeout(
        () =>
          setFlags(f => ({
            ...f,
            trafficRecovered: false,
          })),
        DURATIONS.flashRecovered
      );
    },
    []
  );

  const setHighRisk = useCallback(
    (v: boolean, opts?: { territoryId?: string }) => {
      const territoryId = opts?.territoryId;

      setFlags(f => ({ ...f, highRiskZone: v }));
      setMeta(m => ({
        ...m,
        riskLevel: v
          ? m.riskLevel === "critical"
            ? "critical"
            : "high"
          : "medium",
        activeTerritoryId: territoryId ?? m.activeTerritoryId,
      }));
    },
    []
  );

  // Comando de incidente crítico (alineado con protocolos de Isabella)
  const markCriticalIncident = useCallback(
    (opts?: { territoryId?: string }) => {
      const territoryId = opts?.territoryId;
      const now = Date.now();

      setFlags(f => ({
        ...f,
        threadError: true,
        highRiskZone: true,
      }));
      setMeta(m => ({
        ...m,
        riskLevel: "critical",
        lastIncidentAt: now,
        activeTerritoryId: territoryId ?? m.activeTerritoryId,
      }));

      // Aquí se podría emitir un evento que IsabellaAI escuche:
      // window.dispatchEvent(new CustomEvent("isabella:critical-incident", { detail: { territoryId } }));
    },
    []
  );

  // Reducir escalamiento de riesgo (por ejemplo, tras intervención humana)
  const downgradeRisk = useCallback(() => {
    setMeta(m => ({
      ...m,
      riskLevel:
        m.riskLevel === "critical"
          ? "high"
          : m.riskLevel === "high"
          ? "medium"
          : "low",
    }));
  }, []);

  // Listener para errores globales (backend / fetch / WebSocket, etc.)
  useEffect(() => {
    const handler = (event: Event) => {
      const customEvent = event as CustomEvent<{
        territoryId?: string;
      }>;
      triggerError(customEvent.detail);
    };

    window.addEventListener("rdm:system-error", handler as EventListener);
    return () =>
      window.removeEventListener(
        "rdm:system-error",
        handler as EventListener
      );
  }, [triggerError]);

  const value = useMemo<RdmSystemStateContextType>(
    () => ({
      ...flags,
      ...meta,
      triggerError,
      triggerRecovery,
      setHighRisk,
      markCriticalIncident,
      downgradeRisk,
    }),
    [flags, meta, triggerError, triggerRecovery, setHighRisk, markCriticalIncident, downgradeRisk]
  );

  return (
    <RdmSystemStateContext.Provider value={value}>
      {children}
    </RdmSystemStateContext.Provider>
  );
};

export const useRdmSystemState = () => {
  const ctx = useContext(RdmSystemStateContext);
  if (!ctx)
    throw new Error(
      "useRdmSystemState must be used within RdmSystemStateProvider"
    );
  return ctx;
};
