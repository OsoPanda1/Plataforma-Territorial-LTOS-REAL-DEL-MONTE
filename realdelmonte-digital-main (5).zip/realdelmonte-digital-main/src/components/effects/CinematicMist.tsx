import { useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

/**
 * CSS-based cinematic mist effect (no WebGL dependency).
 * Fog density increases with scroll. Reacts to cursor position.
 */
export const CinematicMist = ({ intensity = 0.6 }: { intensity?: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();
  const fogOpacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.05, intensity * 0.5, intensity]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const onMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 30;
      const y = (e.clientY / window.innerHeight - 0.5) * 20;
      el.style.setProperty("--mist-x", `${x}px`);
      el.style.setProperty("--mist-y", `${y}px`);
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <motion.div
      ref={ref}
      style={{ opacity: fogOpacity }}
      className="pointer-events-none fixed inset-0 z-[5] overflow-hidden"
    >
      {/* Primary mist layer */}
      <div
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(ellipse 80% 60% at calc(50% + var(--mist-x, 0px)) calc(40% + var(--mist-y, 0px)),
              hsl(220 30% 15% / 0.6) 0%,
              transparent 70%
            )
          `,
          transition: "background 0.3s ease-out",
        }}
      />
      {/* Secondary mist — slower drift */}
      <div
        className="absolute inset-0 animate-breathe"
        style={{
          background: `
            radial-gradient(ellipse 60% 40% at 30% 60%,
              hsl(210 20% 20% / 0.3) 0%,
              transparent 70%
            )
          `,
        }}
      />
      {/* Edge vignette */}
      <div
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(ellipse 80% 70% at 50% 50%,
              transparent 40%,
              hsl(220 30% 5% / 0.5) 100%
            )
          `,
        }}
      />
    </motion.div>
  );
};

/**
 * Scene transition wipe effect — use between major module navigations
 */
export const SceneWipe = ({ active }: { active: boolean }) => {
  if (!active) return null;
  return (
    <motion.div
      initial={{ scaleX: 0 }}
      animate={{ scaleX: [0, 1, 1, 0] }}
      transition={{ duration: 0.8, times: [0, 0.4, 0.6, 1] }}
      className="fixed inset-0 z-[100] origin-left bg-gradient-to-r from-background via-accent/20 to-background"
    />
  );
};
