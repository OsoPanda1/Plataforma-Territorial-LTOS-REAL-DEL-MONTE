import { Link } from "react-router-dom";
import { MapPin, Mail, Sparkles, ExternalLink } from "lucide-react";
import DedicationRibbon from "@/components/DedicationRibbon";

const footerLinks = {
  explorar: [
    { label: "Lugares", path: "/lugares" },
    { label: "Rutas", path: "/rutas" },
    { label: "Mapa Interactivo", path: "/mapa" },
    { label: "Directorio", path: "/directorio" },
  ],
  descubrir: [
    { label: "Historia", path: "/historia" },
    { label: "Cultura", path: "/cultura" },
    { label: "Gastronomía", path: "/gastronomia" },
    { label: "Ecoturismo", path: "/ecoturismo" },
  ],
  comunidad: [
    { label: "Eventos", path: "/eventos" },
    { label: "Comunidad", path: "/comunidad" },
    { label: "Portal de Negocios", path: "/negocios" },
    { label: "Apoya el Proyecto", path: "/apoya" },
  ],
};

export default function Footer() {
  return (
    <footer className="relative" style={{ background: "linear-gradient(180deg, hsl(220,30%,4%) 0%, hsl(220,35%,2%) 100%)" }}>
      {/* Ambient orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-1/4 w-64 h-64 rounded-full animate-orb" style={{ background: "hsl(210 100% 55% / 0.03)", filter: "blur(60px)" }} />
        <div className="absolute bottom-20 right-1/4 w-48 h-48 rounded-full animate-orb-reverse" style={{ background: "hsl(43 80% 55% / 0.03)", filter: "blur(60px)" }} />
      </div>

      <div className="separator-animated w-full" />

      <div className="container mx-auto px-4 md:px-8 py-16">
        <div className="grid md:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center border border-accent/30">
                <span className="font-display text-xl font-bold text-accent">R</span>
              </div>
              <div>
                <span className="font-display text-xl font-bold text-foreground">RDM Digital</span>
                <div className="flex items-center gap-1 text-[10px] tracking-wider text-gold">
                  <Sparkles className="w-3 h-3" />
                  Gemelo Digital Soberano 2026
                </div>
              </div>
            </div>
            <p className="text-sm leading-relaxed mb-4 text-muted-foreground font-body">
              Primer Gemelo Digital soberano de un Pueblo Mágico en Latinoamérica. 
              Creado por Edwin Oswaldo Castillo Trejo (Anubis Villaseñor). 
              Soberanía tecnológica desde el corazón de la montaña.
            </p>
            <div className="flex items-center gap-2 text-xs text-muted-foreground font-body">
              <MapPin className="w-3 h-3 text-gold" />
              Real del Monte, Hidalgo · 2,700 msnm
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-display text-sm font-semibold text-foreground mb-4 capitalize">{title}</h4>
              <ul className="space-y-2">
                {links.map(link => (
                  <li key={link.path}>
                    <Link to={link.path} className="text-sm text-muted-foreground hover:text-accent transition-colors font-body">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground/60 font-body">
            © {new Date().getFullYear()} RDM Digital · TAMV Enterprise — Pachuca, Hidalgo, México. Todos los derechos reservados.
          </p>
          <div className="flex gap-4">
            <a href="https://github.com/OsoPanda1" target="_blank" rel="noopener noreferrer" className="text-xs text-muted-foreground hover:text-accent transition-colors flex items-center gap-1">
              GitHub <ExternalLink className="w-3 h-3" />
            </a>
            <a href="https://tamvonlinenetwork.blogspot.com" target="_blank" rel="noopener noreferrer" className="text-xs text-muted-foreground hover:text-accent transition-colors flex items-center gap-1">
              Blog <ExternalLink className="w-3 h-3" />
            </a>
            <Link to="/reglamento" className="text-xs text-muted-foreground hover:text-accent transition-colors">Reglamento</Link>
          </div>
        </div>
        <DedicationRibbon />
      </div>
    </footer>
  );
}
