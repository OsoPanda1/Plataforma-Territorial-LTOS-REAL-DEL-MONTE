import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Menu,
  X,
  ChevronDown,
  Map,
  Compass,
  Clock,
  BookOpen,
  Utensils,
  Palette,
  TreePine,
  Ghost,
  Quote,
  Store,
  Radio,
  Code2,
  ScrollText,
  Activity,
  Sparkles,
  User,
  CreditCard,
  Settings,
  HelpCircle,
  Info,
  Crown,
  Briefcase,
  Network,
  Database,
  Cpu,
  Layers,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type NavMenuItem = {
  label: string;
  path: string;
  icon?: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  desc?: string;
};

type NavPlane = {
  id: string;
  label: string;
  tagline: string;
  groups: { title: string; items: NavMenuItem[] }[];
};

// ─── PLANO 1 · Turismo & Cultura (el visitante) ──────────────────
const planeTurismo: NavPlane = {
  id: "turismo",
  label: "Visita",
  tagline: "Planea tu estancia en Real del Monte",
  groups: [
    {
      title: "Explora el territorio",
      items: [
        { label: "Mapa interactivo", path: "/mapa", icon: Map, desc: "Gemelo digital del pueblo" },
        { label: "Rutas de paseo", path: "/rutas", icon: Compass, desc: "Itinerarios sugeridos" },
        { label: "Lugares", path: "/lugares", icon: Store, desc: "Puntos imperdibles" },
        { label: "Ecoturismo", path: "/ecoturismo", icon: TreePine, desc: "Naturaleza y aventura" },
      ],
    },
    {
      title: "Historia y cultura",
      items: [
        { label: "Historia", path: "/historia", icon: Clock, desc: "460 años de minería" },
        { label: "Cultura", path: "/cultura", icon: BookOpen, desc: "Tradiciones vivas" },
        { label: "Mitos y leyendas", path: "/relatos", icon: Ghost, desc: "Relatos del pueblo" },
        { label: "Dichos mineros", path: "/dichos", icon: Quote, desc: "Expresiones típicas" },
        { label: "Arte", path: "/arte", icon: Palette, desc: "Artesanías locales" },
      ],
    },
    {
      title: "Sabor y comunidad",
      items: [
        { label: "Gastronomía", path: "/gastronomia", icon: Utensils, desc: "Cuna del paste" },
        { label: "Eventos", path: "/eventos", icon: Sparkles, desc: "Agenda cultural" },
        { label: "Directorio", path: "/directorio", icon: Store, desc: "Negocios locales" },
        { label: "Transporte", path: "/transporte", icon: Compass, desc: "Cómo llegar y moverte" },
      ],
    },
    {
      title: "Realito AI",
      items: [
        { label: "Habla con Realito", path: "/?chat=open", icon: Sparkles, desc: "Asistente turístico IA" },
        { label: "Comunidad", path: "/comunidad", icon: BookOpen, desc: "Voz de los vecinos" },
        { label: "Enciclopedia", path: "/enciclopedia", icon: BookOpen, desc: "Saber del pueblo" },
      ],
    },
  ],
};

// ─── PLANO 2 · Perfil, Negocios & Servicios ──────────────────────
const planePerfil: NavPlane = {
  id: "perfil",
  label: "Mi RDM",
  tagline: "Tu cuenta, tu negocio, tu membresía",
  groups: [
    {
      title: "Cuenta",
      items: [
        { label: "Entrar / Registrarme", path: "/auth", icon: User, desc: "Acceso al ecosistema" },
        { label: "Mi perfil", path: "/dashboard/profile", icon: User, desc: "Datos y preferencias" },
        { label: "Ajustes", path: "/dashboard/profile", icon: Settings, desc: "Configuración" },
      ],
    },
    {
      title: "Negocios y comercios",
      items: [
        { label: "Registra tu negocio", path: "/negocios", icon: Briefcase, desc: "Alta en el directorio" },
        { label: "Catálogo de planes", path: "/catalogo", icon: Layers, desc: "Senda · Veta · Soberano" },
        { label: "Pago de registro", path: "/negocios#pagos", icon: CreditCard, desc: "Activa tu ficha" },
      ],
    },
    {
      title: "Membresías y apoyo",
      items: [
        { label: "Membresía visitante", path: "/apoya", icon: Crown, desc: "Beneficios premium" },
        { label: "Apoya el proyecto", path: "/donar", icon: Sparkles, desc: "Donaciones soberanas" },
      ],
    },
    {
      title: "Acerca de",
      items: [
        { label: "¿Qué es RDM Digital?", path: "/tamv/thesis", icon: Info, desc: "Plataforma LTOS" },
        { label: "Quiénes somos", path: "/apoya", icon: Info, desc: "Equipo y misión" },
        { label: "Biografía del fundador", path: "/tamv/thesis#fundador", icon: User, desc: "Edwin Oswaldo Castillo Trejo" },
        { label: "Preguntas frecuentes", path: "/reglamento", icon: HelpCircle, desc: "Dudas comunes" },
        { label: "Reglamento", path: "/reglamento", icon: ScrollText, desc: "Términos de uso" },
      ],
    },
  ],
};

// ─── PLANO 3 · Tecnología, Federaciones & Nodo Cero ──────────────
const planeTech: NavPlane = {
  id: "tech",
  label: "Nodo Cero",
  tagline: "Infraestructura, federaciones y soberanía técnica",
  groups: [
    {
      title: "Sistema operativo territorial",
      items: [
        { label: "TAMV Hub", path: "/tamv", icon: ScrollText, desc: "Núcleo soberano" },
        { label: "Estado Nodo Cero", path: "/tamv/status", icon: Radio, desc: "MSR / BookPI" },
        { label: "Operativo", path: "/operativo", icon: Activity, desc: "Madurez funcional" },
        { label: "Sovereign Engine", path: "/sovereign", icon: Cpu, desc: "Decisiones auditables" },
      ],
    },
    {
      title: "Federaciones y datos",
      items: [
        { label: "Federación", path: "/federacion", icon: Network, desc: "Nodos hermanos" },
        { label: "Fusión de repos", path: "/fusion", icon: Layers, desc: "Linaje del kernel" },
        { label: "Corpus público", path: "/corpus", icon: Database, desc: "Conocimiento abierto" },
      ],
    },
    {
      title: "Para desarrolladores",
      items: [
        { label: "API Explorer", path: "/tamv/api", icon: Code2, desc: "Contratos vivos" },
        { label: "Tesis soberana", path: "/tamv/thesis", icon: BookOpen, desc: "Documento maestro" },
        { label: "Panel técnico", path: "/admin", icon: Activity, desc: "Centro de control" },
      ],
    },
  ],
};

const PLANES: NavPlane[] = [planeTurismo, planePerfil, planeTech];

const planePillStyles: Record<string, { active: string; idle: string; dot: string }> = {
  turismo: {
    active: "bg-accent/20 border-accent/40 text-accent",
    idle: "border-transparent text-foreground/60 hover:text-accent hover:bg-accent/5",
    dot: "bg-accent",
  },
  perfil: {
    active: "bg-gold/20 border-gold/40 text-gold",
    idle: "border-transparent text-foreground/60 hover:text-gold hover:bg-gold/5",
    dot: "bg-gold",
  },
  tech: {
    active: "bg-electric/20 border-electric/40 text-electric",
    idle: "border-transparent text-foreground/60 hover:text-electric hover:bg-electric/5",
    dot: "bg-electric",
  },
};

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [activePlane, setActivePlane] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [mobilePlane, setMobilePlane] = useState<string>("turismo");
  const location = useLocation();

  useEffect(() => {
    setIsOpen(false);
    setActivePlane(null);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const PlaneTrigger = ({ plane }: { plane: NavPlane }) => {
    const isActive = activePlane === plane.id;
    const styles = planePillStyles[plane.id];
    return (
      <button
        onMouseEnter={() => setActivePlane(plane.id)}
        onFocus={() => setActivePlane(plane.id)}
        className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
          isActive ? styles.active : styles.idle
        }`}
      >
        <span className={`w-1.5 h-1.5 rounded-full ${styles.dot}`} />
        {plane.label}
        <ChevronDown className={`w-3 h-3 transition-transform ${isActive ? "rotate-180" : ""}`} />
      </button>
    );
  };

  const activePlaneData = PLANES.find((p) => p.id === activePlane);
  const mobilePlaneData = PLANES.find((p) => p.id === mobilePlane) ?? planeTurismo;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 glass-dark ${scrolled ? "shadow-lg" : ""}`}
      style={{
        borderBottom: `1px solid hsl(210 100% 55% / ${scrolled ? 0.15 : 0.08})`,
      }}
      onMouseLeave={() => setActivePlane(null)}
    >
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group shrink-0">
            <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center border border-accent/30 group-hover:glow-electric transition-all">
              <span className="font-display text-lg font-bold text-accent">R</span>
            </div>
            <div className="hidden sm:flex flex-col">
              <span className="font-display text-lg font-bold leading-tight text-foreground">
                RDM Digital
              </span>
              <span className="text-[9px] tracking-[0.2em] uppercase leading-none text-gold">
                Pueblo Mágico · Smart City
              </span>
            </div>
          </Link>

          {/* Desktop — 3 planos */}
          <div className="hidden lg:flex items-center gap-2">
            <Link
              to="/"
              className={`px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                location.pathname === "/" ? "text-foreground" : "text-foreground/60 hover:text-foreground"
              }`}
            >
              Inicio
            </Link>
            {PLANES.map((plane) => (
              <PlaneTrigger key={plane.id} plane={plane} />
            ))}
          </div>

          {/* CTA */}
          <div className="hidden lg:flex items-center gap-3 shrink-0">
            <Link
              to="/auth"
              className="text-sm px-5 py-2 rounded-xl bg-accent text-accent-foreground font-body font-medium hover:bg-accent/90 transition-colors glow-electric"
            >
              Entrar
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden text-foreground p-2"
            aria-label="Abrir menú"
          >
            {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Desktop mega-panel */}
        <AnimatePresence>
          {activePlaneData && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
              className="hidden lg:block absolute left-0 right-0 top-full"
              onMouseEnter={() => setActivePlane(activePlaneData.id)}
            >
              <div className="container mx-auto px-4 md:px-8 pb-6">
                <div className="rounded-2xl border border-border bg-card/95 backdrop-blur-xl shadow-2xl p-6">
                  <div className="flex items-center gap-3 mb-5 pb-4 border-b border-border/50">
                    <span className={`w-2 h-2 rounded-full ${planePillStyles[activePlaneData.id].dot}`} />
                    <div>
                      <div className="font-display text-base font-semibold text-foreground">
                        Plano · {activePlaneData.label}
                      </div>
                      <div className="text-xs text-muted-foreground">{activePlaneData.tagline}</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    {activePlaneData.groups.map((group) => (
                      <div key={group.title}>
                        <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
                          {group.title}
                        </div>
                        <div className="space-y-1">
                          {group.items.map((item) => (
                            <Link
                              key={item.path + item.label}
                              to={item.path}
                              className="flex items-start gap-2.5 px-2 py-2 rounded-lg hover:bg-secondary/40 transition-colors group"
                            >
                              {item.icon && (
                                <item.icon className="w-4 h-4 mt-0.5 text-muted-foreground group-hover:text-accent shrink-0" />
                              )}
                              <div className="min-w-0">
                                <div className="text-sm text-foreground leading-tight">{item.label}</div>
                                {item.desc && (
                                  <div className="text-[11px] text-muted-foreground leading-snug">
                                    {item.desc}
                                  </div>
                                )}
                              </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-border bg-card/95 backdrop-blur-xl overflow-hidden"
          >
            <div className="p-4 max-h-[75vh] overflow-y-auto">
              {/* Tabs de planos */}
              <div className="flex gap-2 mb-4">
                {PLANES.map((p) => {
                  const styles = planePillStyles[p.id];
                  const active = mobilePlane === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setMobilePlane(p.id)}
                      className={`flex-1 px-3 py-2 rounded-xl text-xs font-medium border transition-colors ${
                        active ? styles.active : styles.idle
                      }`}
                    >
                      <span className={`inline-block w-1.5 h-1.5 rounded-full mr-1.5 ${styles.dot}`} />
                      {p.label}
                    </button>
                  );
                })}
              </div>
              <div className="text-[11px] text-muted-foreground mb-3 px-1">
                {mobilePlaneData.tagline}
              </div>
              <div className="space-y-4">
                {mobilePlaneData.groups.map((group) => (
                  <div key={group.title}>
                    <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2 px-1">
                      {group.title}
                    </div>
                    <div className="space-y-1">
                      {group.items.map((item) => (
                        <Link
                          key={item.path + item.label}
                          to={item.path}
                          className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-body text-foreground/85 hover:bg-secondary/40"
                        >
                          {item.icon && <item.icon className="w-4 h-4 text-muted-foreground" />}
                          <span>{item.label}</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <div className="pt-4">
                <Link
                  to="/auth"
                  className="block text-center px-4 py-3 rounded-xl bg-accent text-accent-foreground font-body font-medium"
                >
                  Entrar al Ecosistema
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
