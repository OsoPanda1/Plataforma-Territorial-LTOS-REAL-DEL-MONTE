import {
  useState,
  useRef,
  useEffect,
  useCallback,
  useMemo,
} from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, VolumeX, SkipForward } from "lucide-react";
import logoBadge from "@/assets/rdm-logo-badge.png";
import introMountains from "@/assets/rdm-intro-mountains.jpg";
import audiointro from "@/assets/audiointro.mp3";

const ease = [0.22, 0.03, 0.26, 1] as const;

type IntroPhase = "badge" | "lines" | "reveal" | "done";

// Duración total reducida para menor latencia percibida
const INTRO_DURATION_MS = 7000;

const INTRO_LINES = [
  {
    text: "Real del Monte",
    delay: 0.35,
    className:
      "font-display text-4xl sm:text-6xl md:text-8xl font-bold text-gradient-gold tracking-tight",
  },
  {
    text: "Sistema Operativo Territorial Soberano",
    delay: 1.5,
    className:
      "font-body text-[10px] sm:text-xs md:text-sm text-muted-foreground tracking-[0.3em] uppercase",
  },
  {
    text: "Gemelo Digital 4D",
    delay: 2.5,
    className:
      "font-display text-xl sm:text-2xl md:text-4xl font-semibold text-foreground/80",
  },
];

function buildParticles(count: number) {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    delay: Math.random() * 3,
    duration: 8 + Math.random() * 8,
    size: 2 + Math.random() * 3,
    x: Math.random() * 100,
    y: Math.random() * 100,
    color:
      i % 5 === 0
        ? "hsl(43 80% 55%)"
        : i % 5 === 1
        ? "hsl(210 100% 60%)"
        : i % 5 === 2
        ? "hsl(270 50% 60%)"
        : i % 5 === 3
        ? "hsl(180 40% 50%)"
        : "hsl(0 0% 70%)",
    drift: (Math.random() - 0.5) * 40,
    rise: 30 + Math.random() * 50,
  }));
}

interface CinematicIntroProps {
  onComplete: () => void;
}

export default function CinematicIntro({ onComplete }: CinematicIntroProps) {
  const [phase, setPhase] = useState<IntroPhase>("badge");
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [progress, setProgress] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const startTimeRef = useRef<number>(0);
  const rafRef = useRef<number | null>(null);

  const particles = useMemo(() => buildParticles(28), []);

  // Precarga de audio en mount
  useEffect(() => {
    const audio = new Audio(audiointro);
    audio.preload = "auto";
    audio.volume = 0.45;
    audioRef.current = audio;

    startTimeRef.current = performance.now();

    // Iniciar animación de progreso inmediatamente
    const loop = () => {
      const elapsed = performance.now() - startTimeRef.current;
      const ratio = Math.min(elapsed / INTRO_DURATION_MS, 1);
      setProgress(ratio);
      if (ratio < 1) {
        rafRef.current = requestAnimationFrame(loop);
      }
    };
    rafRef.current = requestAnimationFrame(loop);

    const timers = [
      window.setTimeout(() => {
        if (audioRef.current) {
          audioRef.current.play().catch(() => {});
        }
        setAudioEnabled(true);
        setPhase("lines");
      }, 1200),
      window.setTimeout(() => {
        setPhase("reveal");
      }, 4000),
      window.setTimeout(() => {
        setPhase("done");
        onComplete();
      }, INTRO_DURATION_MS),
    ];

    return () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
      timers.forEach(clearTimeout);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    };
  }, [onComplete]);

  const toggleAudio = useCallback(() => {
    if (!audioRef.current) return;
    if (audioEnabled) {
      audioRef.current.pause();
      setAudioEnabled(false);
    } else {
      audioRef.current.play().catch(() => {});
      setAudioEnabled(true);
    }
  }, [audioEnabled]);

  const skip = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setPhase("done");
    onComplete();
  }, [onComplete]);

  if (phase === "done") return null;

  return (
    <AnimatePresence>
      <motion.div
        key="cinematic"
        className="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden"
        style={{ background: "#010208", willChange: "opacity" }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.6, ease }}
        role="dialog"
        aria-modal="true"
        aria-label="Introducción cinematográfica al gemelo digital soberano de Real del Monte"
      >
        {/* Deep gradient base */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 120% 80% at 50% 40%, hsl(220 50% 8%) 0%, hsl(220 30% 3%) 60%, #010208 100%)",
            willChange: "transform",
          }}
        />

        {/* Ken Burns mountain background - optimizado */}
        <motion.div
          className="absolute inset-0"
          initial={{ scale: 1.2, opacity: 0 }}
          animate={{ scale: 1, opacity: phase === "reveal" ? 0.35 : 0.12 }}
          transition={{ duration: 6, ease: "easeOut" }}
          style={{ willChange: "transform, opacity" }}
        >
          <img
            src={introMountains}
            alt=""
            className="w-full h-full object-cover"
            style={{ filter: "saturate(0.7)", willChange: "filter" }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#010208] via-[#010208]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#010208]/80 via-transparent to-[#010208]" />
        </motion.div>

        {/* Volumetric mist - optimizado */}
        <motion.div
          className="absolute inset-0 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.6 }}
          transition={{ duration: 2 }}
        >
          <div
            className="absolute bottom-0 left-0 right-0 h-[50%]"
            style={{
              background:
                "linear-gradient(to top, hsl(210 30% 15% / 0.35), transparent)",
              filter: "blur(50px)",
              animation: "breathe 6s ease-in-out infinite",
            }}
          />
          <div
            className="absolute bottom-0 left-0 right-0 h-[35%]"
            style={{
              background:
                "linear-gradient(to top, hsl(43 50% 20% / 0.15), transparent)",
              filter: "blur(70px)",
              animation: "breathe 9s ease-in-out infinite reverse",
            }}
          />
          <div
            className="absolute top-0 left-0 right-0 h-[40%]"
            style={{
              background:
                "linear-gradient(to bottom, hsl(220 40% 10% / 0.4), transparent)",
              filter: "blur(40px)",
              animation: "breathe 8s ease-in-out infinite",
            }}
          />
        </motion.div>

        {/* Particles - menos cantidad, más rápido */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {particles.map((p) => (
            <motion.div
              key={p.id}
              className="absolute rounded-full"
              style={{
                width: p.size,
                height: p.size,
                left: `${p.x}%`,
                top: `${p.y}%`,
                background: p.color,
                boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
                willChange: "transform, opacity",
              }}
              initial={{ opacity: 0 }}
              animate={{
                opacity: [0, 0.8, 0],
                y: [0, -p.rise],
                x: [0, p.drift],
              }}
              transition={{
                duration: p.duration,
                delay: p.delay,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>

        {/* Central halo - acelerado */}
        <motion.div
          className="absolute pointer-events-none"
          style={{
            width: 700,
            height: 700,
            background:
              "radial-gradient(circle, hsl(210 100% 55% / 0.1), hsl(43 80% 55% / 0.06), hsl(270 50% 50% / 0.03), transparent 70%)",
            filter: "blur(70px)",
            willChange: "transform, opacity",
          }}
          initial={{ scale: 0.2, opacity: 0 }}
          animate={{ scale: [0.2, 1.5, 1.2], opacity: [0, 0.7, 0.5] }}
          transition={{ duration: 3.5, ease: "easeOut" }}
        />

        {/* Orbital rings - acelerados */}
        {phase !== "badge" && (
          <>
            <motion.div
              className="absolute border rounded-full pointer-events-none"
              style={{
                width: 300,
                height: 300,
                borderColor: "hsl(210 100% 55% / 0.12)",
                willChange: "transform",
              }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1, rotate: 360 }}
              transition={{
                duration: 18,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <motion.div
              className="absolute border rounded-full pointer-events-none"
              style={{
                width: 450,
                height: 450,
                borderColor: "hsl(43 80% 55% / 0.06)",
                willChange: "transform",
              }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1, rotate: -360 }}
              transition={{
                duration: 28,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <motion.div
              className="absolute border rounded-full pointer-events-none"
              style={{
                width: 220,
                height: 220,
                borderColor: "hsl(270 50% 55% / 0.08)",
                willChange: "transform",
              }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1, rotate: 180 }}
              transition={{
                duration: 12,
                repeat: Infinity,
                ease: "linear",
              }}
            />
          </>
        )}

        {/* Badge phase - acelerado */}
        <AnimatePresence mode="wait">
          {phase === "badge" && (
            <motion.div
              key="badge"
              className="relative z-10 flex flex-col items-center"
              initial={{ opacity: 0, scale: 0.4 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.4, filter: "blur(12px)" }}
              transition={{ duration: 0.9, ease }}
            >
              <motion.div
                className="w-40 h-40 md:w-48 md:h-48 rounded-full overflow-hidden border-2 border-accent/30"
                animate={{ y: [0, -8, 0] }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                style={{
                  boxShadow:
                    "0 0 100px hsl(210 100% 55% / 0.25), 0 0 200px hsl(43 80% 55% / 0.12)",
                  willChange: "transform",
                }}
              >
                <img
                  src={logoBadge}
                  alt="RDM Digital Nodo Cero"
                  className="w-full h-full object-cover"
                />
              </motion.div>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                transition={{ delay: 0.4 }}
                className="mt-5 text-[10px] font-body tracking-[0.35em] uppercase text-muted-foreground"
              >
                Gemelo Digital Soberano
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Text lines - transiciones más rápidas */}
        {(phase === "lines" || phase === "reveal") && (
          <motion.div
            className="relative z-10 text-center px-6 max-w-4xl mx-auto flex flex-col items-center gap-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            <motion.div
              className="w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border border-accent/20 mb-2"
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, ease }}
              style={{
                boxShadow:
                  "0 0 50px hsl(210 100% 55% / 0.2)",
                willChange: "transform",
              }}
            >
              <img
                src={logoBadge}
                alt="RDM Digital Nodo Cero"
                className="w-full h-full object-cover"
              />
            </motion.div>

            {INTRO_LINES.map((line, index) => (
              <motion.p
                key={index}
                initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{
                  duration: 0.8,
                  delay: line.delay,
                  ease,
                }}
                className={line.className}
              >
                {line.text}
              </motion.p>
            ))}

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.45 }}
              transition={{ delay: 3.2, duration: 1 }}
              className="text-[11px] md:text-xs font-body text-muted-foreground max-w-md leading-relaxed mt-3"
            >
              Un laboratorio vivo donde el territorio, sus historias y su economía
              se sincronizan con una inteligencia local, creada sólo para Real del
              Monte.
            </motion.p>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.25 }}
              transition={{ delay: 3.8, duration: 0.8 }}
              className="text-[9px] font-body text-muted-foreground tracking-widest uppercase mt-1"
            >
              City Intelligence · Isabella AI™ · TAMV Online · 2026
            </motion.p>
          </motion.div>
        )}

        {/* Top-left label */}
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 0.4, x: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className="absolute top-6 left-6 flex items-center gap-2 z-20"
        >
          <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
          <span className="text-[9px] font-body text-muted-foreground tracking-widest uppercase">
            Entrada al gemelo digital
          </span>
        </motion.div>

        {/* Controls - más rápidos en hover */}
        <div className="absolute bottom-6 left-0 right-0 flex items-center justify-center gap-6 z-20">
          <motion.button
            type="button"
            aria-label={
              audioEnabled
                ? "Desactivar audio introductorio"
                : "Activar audio introductorio"
            }
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ delay: 1 }}
            whileHover={{ opacity: 1, scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleAudio}
            className="p-2.5 rounded-full border border-border/40 bg-card/20 backdrop-blur-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {audioEnabled ? (
              <Volume2 className="w-4 h-4" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </motion.button>
          <motion.button
            type="button"
            aria-label="Saltar introducción"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ delay: 1 }}
            whileHover={{ opacity: 1, scale: 1.05 }}
            whileTap={{ scale: 0.92 }}
            onClick={skip}
            className="flex items-center gap-2 px-4 py-2 rounded-full border border-border/40 bg-card/20 backdrop-blur-sm text-muted-foreground hover:text-foreground transition-colors text-xs font-body"
          >
            <SkipForward className="w-3.5 h-3.5" />
            Saltar
          </motion.button>
        </div>

        {/* Progress bar - más fluido */}
        <div className="absolute bottom-0 left-0 right-0 h-[2px] z-20">
          <div
            className="h-full"
            style={{
              width: `${progress * 100}%`,
              background:
                "linear-gradient(90deg, hsl(270 50% 55%), hsl(210 100% 55%), hsl(43 80% 55%))",
              boxShadow:
                "0 0 15px hsl(210 100% 55% / 0.6)",
            }}
          />
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
