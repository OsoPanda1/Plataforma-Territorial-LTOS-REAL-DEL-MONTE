import { motion, useReducedMotion } from "framer-motion";
import { RDM_COMMERCE_TIERS, type RdmTierLevel } from "@/config/commerceTiers";
import { Check, Crown } from "lucide-react";

type Props = {
  value: RdmTierLevel | null;
  onChange: (level: RdmTierLevel) => void;
};

export const TierSelector3D = ({ value, onChange }: Props) => {
  const shouldReduceMotion = useReducedMotion();

  return (
    <div className="w-full">
      <div className="text-center mb-8">
        <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
          Elige tu nivel en la mina digital
        </h2>
        <p className="text-sm text-muted-foreground font-body max-w-xl mx-auto">
          Cada nivel amplifica la visibilidad de tu negocio dentro del gemelo
          territorial RDM‑TOS. Sube de tier, sube en el mapa.
        </p>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4 snap-x snap-mandatory px-2 scrollbar-thin">
        {RDM_COMMERCE_TIERS.map((tier, i) => {
          const isActive = tier.level === value;
          const isSovereign = tier.level === "SOVEREIGN";
          const isRecommended = tier.recommended === true;

          return (
            <motion.button
              key={tier.level}
              onClick={() => onChange(tier.level)}
              type="button"
              initial={shouldReduceMotion ? undefined : { opacity: 0, y: 30 }}
              animate={shouldReduceMotion ? undefined : { opacity: 1, y: 0 }}
              transition={
                shouldReduceMotion
                  ? { duration: 0 }
                  : { delay: i * 0.08, type: "spring", stiffness: 120 }
              }
              whileHover={
                shouldReduceMotion
                  ? undefined
                  : { y: -8, scale: 1.03, boxShadow: "0 18px 45px rgba(0,0,0,0.35)" }
              }
              whileTap={shouldReduceMotion ? undefined : { scale: 0.97 }}
              className={`
                snap-center min-w-[260px] flex-shrink-0 rounded-2xl border-2 p-5 text-left
                transition-all duration-300 relative overflow-hidden group
                ${
                  isActive
                    ? "border-gold/70 bg-card shadow-lg shadow-gold/20"
                    : "border-border bg-card/80 hover:border-accent/30"
                }
                ${isSovereign ? "ring-1 ring-gold/25" : ""}
              `}
            >
              {/* Ribbons / etiquetas */}
              {isRecommended && (
                <div className="absolute top-3 right-3">
                  <span className="rounded-full bg-accent/15 border border-accent/40 px-2 py-0.5 text-[9px] font-semibold tracking-[0.16em] uppercase text-accent-foreground">
                    Recomendado
                  </span>
                </div>
              )}

              {/* Sovereign breathing glow */}
              {isSovereign && !shouldReduceMotion && (
                <motion.div
                  className="absolute inset-0 rounded-2xl pointer-events-none"
                  animate={{
                    boxShadow: [
                      "inset 0 0 20px hsl(43 80% 55% / 0)",
                      "inset 0 0 30px hsl(43 80% 55% / 0.10)",
                      "inset 0 0 20px hsl(43 80% 55% / 0)",
                    ],
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                />
              )}

              {/* Header */}
              <div className="flex items-start justify-between mb-3 relative z-10">
                <div>
                  <span className="text-2xl">{tier.icon}</span>
                  <h3 className="font-display text-xl font-bold text-foreground mt-1">
                    {tier.label}
                  </h3>
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-body">
                    {tier.level}
                  </span>
                </div>
                {isActive && (
                  <motion.div
                    initial={shouldReduceMotion ? undefined : { scale: 0 }}
                    animate={shouldReduceMotion ? undefined : { scale: 1 }}
                    className="w-7 h-7 rounded-full bg-gold flex items-center justify-center shadow-md shadow-gold/40"
                  >
                    <Check className="w-3.5 h-3.5 text-background" />
                  </motion.div>
                )}
              </div>

              {/* Price */}
              <div className="mb-3 relative z-10">
                {tier.fromLabel && (
                  <span className="text-[10px] text-muted-foreground font-body uppercase tracking-[0.16em]">
                    {tier.fromLabel}
                  </span>
                )}
                <div className="flex items-baseline gap-1">
                  <span className="font-display text-3xl font-bold text-foreground">
                    ${tier.price}
                  </span>
                  <span className="text-xs text-muted-foreground font-body">
                    MXN/mes
                  </span>
                </div>
                {tier.billingNote && (
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {tier.billingNote}
                  </p>
                )}
              </div>

              <p className="text-xs text-muted-foreground font-body mb-4 leading-relaxed relative z-10">
                {tier.description}
              </p>

              {/* Features */}
              <ul className="space-y-1.5 relative z-10">
                {tier.highlights.map((h) => (
                  <li
                    key={h}
                    className="flex items-start gap-2 text-xs font-body text-foreground/80"
                  >
                    <span className="mt-0.5 flex-shrink-0 text-accent">▸</span>
                    {h}
                  </li>
                ))}
              </ul>

              {isSovereign && (
                <div className="mt-4 flex items-center gap-1.5 text-gold relative z-10">
                  <Crown className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-body uppercase tracking-widest">
                    Nodo Soberano · Máxima presencia territorial
                  </span>
                </div>
              )}

              {/* Fondo 3D sugerido */}
              {!shouldReduceMotion && (
                <motion.div
                  className="absolute -bottom-10 -right-10 w-32 h-32 rounded-full bg-gradient-to-tr from-accent/10 via-gold/15 to-transparent blur-2xl opacity-60 group-hover:opacity-90"
                  layout
                />
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Microcopy de conversión */}
      <p className="mt-2 text-[11px] text-center text-muted-foreground max-w-lg mx-auto">
        Puedes cambiar de nivel más adelante. Los tiers superiores priorizan tu
        visibilidad en el mapa, acceso a métricas y presencia en campañas del
        territorio.
      </p>
    </div>
  );
};
