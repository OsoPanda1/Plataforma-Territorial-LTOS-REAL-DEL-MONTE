import { useState, useMemo, FormEvent } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  Store,
  MapPin,
  Camera,
  ChevronRight,
  ChevronLeft,
  Check,
  AlertCircle,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TierSelector3D } from "./TierSelector3D";
import type { RdmTierLevel } from "@/config/commerceTiers";

type StepId = "identity" | "activity" | "plan";

export type CommerceFormState = {
  name: string;
  slogan: string;
  giro: string;
  days: string;
  hours: string;
  phone: string;
  website: string;
  tier: RdmTierLevel | null;
};

type CommerceOnboardingProps = {
  onSubmit?: (data: CommerceFormState) => Promise<void> | void;
};

const STEPS: {
  id: StepId;
  label: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  subtitle: string;
}[] = [
  {
    id: "identity",
    label: "Identidad",
    icon: Store,
    subtitle: "Dale un nombre y una voz a tu nodo en el territorio.",
  },
  {
    id: "activity",
    label: "Actividad",
    icon: MapPin,
    subtitle: "Cuenta cómo, cuándo y dónde estás activo en Real del Monte.",
  },
  {
    id: "plan",
    label: "Plan",
    icon: Camera,
    subtitle: "Elige cómo quieres que tu negocio aparezca en el gemelo digital.",
  },
];

const GIROS = [
  "Gastronomía",
  "Artesanía",
  "Hospedaje",
  "Tienda",
  "Servicios",
  "Cultura",
  "Otro",
] as const;

const slideVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? 200 : -200, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir > 0 ? -200 : 200, opacity: 0 }),
};

const INITIAL_FORM: CommerceFormState = {
  name: "",
  slogan: "",
  giro: "",
  days: "",
  hours: "",
  phone: "",
  website: "",
  tier: null,
};

export const CommerceOnboarding = ({ onSubmit }: CommerceOnboardingProps) => {
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [form, setForm] = useState<CommerceFormState>(INITIAL_FORM);
  const [errors, setErrors] = useState<
    Partial<Record<keyof CommerceFormState, string>>
  >({});
  const [submitting, setSubmitting] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  const progress = useMemo(() => ((step + 1) / STEPS.length) * 100, [step]);

  const updateField =
    <K extends keyof CommerceFormState>(key: K) =>
    (value: CommerceFormState[K]) => {
      setForm((prev) => ({ ...prev, [key]: value }));
      setErrors((prev) => ({ ...prev, [key]: undefined }));
    };

  const sanitizePhone = (raw: string) =>
    raw.replace(/[^\d+]/g, "").slice(0, 20);

  const sanitizeUrl = (raw: string) => {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    if (!/^https?:\/\//i.test(trimmed)) {
      return `https://${trimmed}`;
    }
    return trimmed;
  };

  const validateStep = (currentStep = step): boolean => {
    const nextErrors: Partial<Record<keyof CommerceFormState, string>> = {};

    if (currentStep === 0) {
      if (!form.name.trim()) {
        nextErrors.name = "El nombre del negocio es obligatorio.";
      }
      if (!form.phone.trim()) {
        nextErrors.phone = "El teléfono de contacto es obligatorio.";
      } else if (sanitizePhone(form.phone).length < 8) {
        nextErrors.phone = "Ingresa un teléfono válido (mínimo 8 dígitos).";
      }
    }

    if (currentStep === 1) {
      if (!form.giro) {
        nextErrors.giro = "Selecciona el giro principal del negocio.";
      }
      if (!form.days.trim()) {
        nextErrors.days = "Indica los días de operación.";
      }
      if (!form.hours.trim()) {
        nextErrors.hours = "Indica el horario de operación.";
      }
      if (form.website.trim()) {
        const url = sanitizeUrl(form.website);
        try {
          const parsedUrl = new URL(url);
          void parsedUrl;
        } catch {
          nextErrors.website = "La URL del sitio web no parece válida.";
        }
      }
    }

    if (currentStep === 2) {
      if (!form.tier) {
        nextErrors.tier = "Selecciona un plan para continuar.";
      }
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const goNext = () => {
    if (!validateStep(step)) return;
    setDir(1);
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };

  const goBack = () => {
    setDir(-1);
    setStep((s) => Math.max(s - 1, 0));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validateStep(2)) {
      setStep(2);
      return;
    }

    const payload: CommerceFormState = {
      ...form,
      phone: sanitizePhone(form.phone),
      website: sanitizeUrl(form.website),
    };

    try {
      setSubmitting(true);
      await onSubmit?.(payload);
    } finally {
      setSubmitting(false);
    }
  };

  const currentStepMeta = STEPS[step];

  return (
    <form
      className="max-w-2xl mx-auto rounded-2xl bg-card/70 border border-border/70 px-6 py-7 shadow-[0_0_40px_rgba(15,23,42,0.45)]"
      onSubmit={handleSubmit}
      noValidate
      aria-labelledby="commerce-onboarding-title"
    >
      {/* Encabezado del flujo */}
      <header className="mb-8">
        <p className="text-[10px] font-semibold tracking-[0.2em] uppercase text-muted-foreground flex items-center gap-2">
          <span className="inline-block h-1 w-6 rounded-full bg-accent" />
          Registro de Nodo Comercial
        </p>
        <div className="mt-2 flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2
              id="commerce-onboarding-title"
              className="font-display text-xl font-semibold text-foreground"
            >
              Paso {step + 1} · {currentStepMeta.label}
            </h2>
            <p className="text-xs text-muted-foreground mt-1 max-w-md">
              {currentStepMeta.subtitle}
            </p>
          </div>
          <p className="text-[11px] text-muted-foreground">
            Progreso:{" "}
            <span className="font-semibold text-foreground">
              {Math.round(progress)}%
            </span>
          </p>
        </div>
      </header>

      {/* Progreso tipo vagoneta de mina */}
      <div className="relative mb-8">
        <div className="flex justify-between mb-3">
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            const isCompleted = i < step;
            const isCurrent = i === step;
            const isActive = i <= step;

            return (
              <div
                key={s.id}
                className={`flex items-center gap-2 text-[11px] font-body ${
                  isActive ? "text-gold" : "text-muted-foreground"
                }`}
                aria-current={isCurrent ? "step" : undefined}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center border ${
                    isCompleted
                      ? "bg-gold border-gold text-background"
                      : isCurrent
                      ? "border-gold text-gold"
                      : "border-border"
                  }`}
                >
                  {isCompleted ? (
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                  ) : (
                    <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                  )}
                </div>
                <span className="hidden sm:inline">{s.label}</span>
              </div>
            );
          })}
        </div>

        <div
          className="h-1.5 rounded-full bg-secondary overflow-hidden"
          aria-hidden="true"
        >
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-accent to-gold"
            animate={{ width: `${progress}%` }}
            transition={
              shouldReduceMotion
                ? { duration: 0 }
                : { type: "spring", stiffness: 200, damping: 25 }
            }
          />
        </div>

        <motion.div
          className="absolute -bottom-3 text-lg"
          animate={{ left: `calc(${progress}% - 10px)` }}
          transition={
            shouldReduceMotion
              ? { duration: 0 }
              : { type: "spring", stiffness: 200, damping: 25 }
          }
          aria-hidden="true"
        >
          🚃
        </motion.div>
      </div>

      {/* Resumen de errores */}
      {Object.keys(errors).length > 0 && (
        <div
          className="mb-4 rounded-lg border border-destructive/40 bg-destructive/5 px-4 py-3 flex gap-2 items-start text-xs text-destructive"
          role="alert"
        >
          <AlertCircle className="w-4 h-4 mt-0.5" aria-hidden="true" />
          <div>
            <p className="font-semibold mb-1">
              Falta información clave para completar el registro.
            </p>
            <ul className="list-disc list-inside space-y-0.5">
              {Object.values(errors).map(
                (msg, idx) => msg && <li key={idx}>{msg}</li>,
              )}
            </ul>
          </div>
        </div>
      )}

      {/* Pasos */}
      <div className="relative min-h-[340px]">
        <AnimatePresence mode="wait" custom={dir}>
          {step === 0 && (
            <motion.div
              key="identity"
              custom={dir}
              variants={slideVariants}
              initial={shouldReduceMotion ? false : "enter"}
              animate="center"
              exit={shouldReduceMotion ? undefined : "exit"}
              transition={{ duration: shouldReduceMotion ? 0 : 0.3 }}
              className="space-y-5"
            >
              <div className="space-y-4">
                <div>
                  <Label className="font-body text-xs" htmlFor="commerce-name">
                    Nombre del negocio
                  </Label>
                  <Input
                    id="commerce-name"
                    value={form.name}
                    onChange={(e) => updateField("name")(e.target.value)}
                    placeholder="Ej: Pastes El Minero"
                    className="mt-1"
                    aria-invalid={!!errors.name}
                    aria-describedby={errors.name ? "error-name" : undefined}
                  />
                  {errors.name && (
                    <p
                      id="error-name"
                      className="mt-1 text-[11px] text-destructive"
                    >
                      {errors.name}
                    </p>
                  )}
                </div>
                <div>
                  <Label
                    className="font-body text-xs"
                    htmlFor="commerce-slogan"
                  >
                    Slogan (opcional)
                  </Label>
                  <Input
                    id="commerce-slogan"
                    value={form.slogan}
                    onChange={(e) => updateField("slogan")(e.target.value)}
                    placeholder="Ej: El sabor de la montaña desde 1920"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="font-body text-xs" htmlFor="commerce-phone">
                    Teléfono de contacto
                  </Label>
                  <Input
                    id="commerce-phone"
                    value={form.phone}
                    onChange={(e) => updateField("phone")(e.target.value)}
                    placeholder="771 000 0000"
                    className="mt-1"
                    inputMode="tel"
                    aria-invalid={!!errors.phone}
                    aria-describedby={errors.phone ? "error-phone" : undefined}
                  />
                  {errors.phone && (
                    <p
                      id="error-phone"
                      className="mt-1 text-[11px] text-destructive"
                    >
                      {errors.phone}
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="activity"
              custom={dir}
              variants={slideVariants}
              initial={shouldReduceMotion ? false : "enter"}
              animate="center"
              exit={shouldReduceMotion ? undefined : "exit"}
              transition={{ duration: shouldReduceMotion ? 0 : 0.3 }}
              className="space-y-5"
            >
              <div>
                <Label className="font-body text-xs mb-2 block">Giro</Label>
                <div
                  className="flex flex-wrap gap-2"
                  role="radiogroup"
                  aria-label="Giro del negocio"
                >
                  {GIROS.map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => updateField("giro")(g)}
                      className={`px-4 py-2 rounded-xl text-xs font-body border transition-all ${
                        form.giro === g
                          ? "border-accent bg-accent/20 text-accent"
                          : "border-border bg-card text-muted-foreground hover:border-accent/30"
                      }`}
                      aria-pressed={form.giro === g}
                    >
                      {g}
                    </button>
                  ))}
                </div>
                {errors.giro && (
                  <p
                    id="error-giro"
                    className="mt-1 text-[11px] text-destructive"
                  >
                    {errors.giro}
                  </p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-body text-xs" htmlFor="commerce-days">
                    Días de operación
                  </Label>
                  <Input
                    id="commerce-days"
                    value={form.days}
                    onChange={(e) => updateField("days")(e.target.value)}
                    placeholder="Lun–Dom"
                    className="mt-1"
                    aria-invalid={!!errors.days}
                    aria-describedby={errors.days ? "error-days" : undefined}
                  />
                  {errors.days && (
                    <p
                      id="error-days"
                      className="mt-1 text-[11px] text-destructive"
                    >
                      {errors.days}
                    </p>
                  )}
                </div>
                <div>
                  <Label className="font-body text-xs" htmlFor="commerce-hours">
                    Horario
                  </Label>
                  <Input
                    id="commerce-hours"
                    value={form.hours}
                    onChange={(e) => updateField("hours")(e.target.value)}
                    placeholder="9:00–18:00"
                    className="mt-1"
                    aria-invalid={!!errors.hours}
                    aria-describedby={errors.hours ? "error-hours" : undefined}
                  />
                  {errors.hours && (
                    <p
                      id="error-hours"
                      className="mt-1 text-[11px] text-destructive"
                    >
                      {errors.hours}
                    </p>
                  )}
                </div>
              </div>
              <div>
                <Label className="font-body text-xs" htmlFor="commerce-website">
                  Sitio web (opcional)
                </Label>
                <Input
                  id="commerce-website"
                  value={form.website}
                  onChange={(e) => updateField("website")(e.target.value)}
                  placeholder="https://..."
                  className="mt-1"
                  inputMode="url"
                  aria-invalid={!!errors.website}
                  aria-describedby={
                    errors.website ? "error-website" : undefined
                  }
                />
                {errors.website && (
                  <p
                    id="error-website"
                    className="mt-1 text-[11px] text-destructive"
                  >
                    {errors.website}
                  </p>
                )}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="plan"
              custom={dir}
              variants={slideVariants}
              initial={shouldReduceMotion ? false : "enter"}
              animate="center"
              exit={shouldReduceMotion ? undefined : "exit"}
              transition={{ duration: shouldReduceMotion ? 0 : 0.3 }}
              className="space-y-5"
            >
              {/* Resumen compacto antes de elegir plan */}
              <div className="rounded-xl border border-border/70 bg-background/60 px-4 py-3 text-xs text-muted-foreground space-y-1.5">
                <p className="font-semibold text-foreground">
                  Así se vería tu ficha base:
                </p>
                <p>
                  <span className="font-medium">{form.name || "Tu negocio"}</span>{" "}
                  · {form.giro || "Giro pendiente"} ·{" "}
                  {form.days || "Días por definir"} ·{" "}
                  {form.hours || "Horario por definir"}
                </p>
                {form.slogan && <p className="italic">“{form.slogan}”</p>}
              </div>

              <TierSelector3D
                value={form.tier}
                onChange={(t) => updateField("tier")(t)}
              />
              {errors.tier && (
                <p
                  id="error-tier"
                  className="mt-3 text-[11px] text-destructive text-center"
                >
                  {errors.tier}
                </p>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Navegación */}
      <div className="flex justify-between mt-8 pt-6 border-t border-border">
        <button
          type="button"
          onClick={goBack}
          disabled={step === 0 || submitting}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-body text-muted-foreground hover:text-foreground disabled:opacity-30 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" aria-hidden="true" /> Anterior
        </button>
        {step < STEPS.length - 1 ? (
          <button
            type="button"
            onClick={goNext}
            disabled={submitting}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-accent text-accent-foreground text-sm font-body font-semibold hover:bg-accent/90 transition-all disabled:opacity-40"
          >
            Continuar{" "}
            <ChevronRight className="w-4 h-4" aria-hidden="true" />
          </button>
        ) : (
          <button
            type="submit"
            disabled={!form.tier || submitting}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gold text-background text-sm font-body font-semibold hover:bg-gold/90 disabled:opacity-40 transition-all"
          >
            {submitting ? "Registrando..." : "Registrar negocio en RDM Digital"}
            <Check className="w-4 h-4" aria-hidden="true" />
          </button>
        )}
      </div>
    </form>
  );
};
