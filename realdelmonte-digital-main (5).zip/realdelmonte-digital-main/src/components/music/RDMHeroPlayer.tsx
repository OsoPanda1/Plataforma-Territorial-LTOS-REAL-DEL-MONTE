import { motion } from "framer-motion";
import {
  Pause,
  Play,
  Volume2,
  VolumeX,
  Heart,
  ListMusic,
  Download,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useMusicPlayer } from "@/hooks/useMusicPlayer";

interface RDMHeroPlayerProps {
  autoplay?: boolean;
}

export function RDMHeroPlayer({ autoplay = false }: RDMHeroPlayerProps) {
  const {
    currentTrack,
    isPlaying,
    progress,
    volume,
    togglePlay,
    seek,
    setVolume,
  } = useMusicPlayer({ autoplay });

  const handleSeekClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    seek(ratio);
  };

  const isMuted = volume === 0;

  return (
    <motion.div
      className="w-full max-w-xl rounded-2xl border border-border/70 bg-card/80 backdrop-blur-xl shadow-lg"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      aria-label="Reproductor principal de RDM Radio"
    >
      <div className="flex items-center gap-4 px-4 py-3 border-b border-border/60">
        <div className="h-10 w-10 overflow-hidden rounded-xl bg-background/60 border border-border/80 flex items-center justify-center">
          {currentTrack.cover ? (
            <img
              src={currentTrack.cover}
              alt={currentTrack.title}
              className="h-full w-full object-cover"
              loading="lazy"
            />
          ) : (
            <span className="text-[10px] font-body text-muted-foreground">
              RDM
            </span>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] font-body uppercase tracking-[0.2em] text-gold">
            Ahora sonando
          </p>
          <p className="truncate font-display text-sm text-foreground">
            {currentTrack.title}
          </p>
          <p className="truncate text-[11px] font-body text-muted-foreground">
            {currentTrack.artist}
          </p>
        </div>
        <button
          type="button"
          onClick={togglePlay}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-sm hover:bg-accent/90 transition-colors"
          aria-label={isPlaying ? "Pausar" : "Reproducir"}
        >
          {isPlaying ? (
            <Pause className="h-4 w-4" />
          ) : (
            <Play className="h-4 w-4 ml-[1px]" />
          )}
        </button>
      </div>

      {/* Barra de progreso minimal / waveform fake */}
      <div className="px-4 pt-3 pb-2">
        <div
          className="group relative h-1.5 w-full cursor-pointer overflow-hidden rounded-full bg-border/80"
          onClick={handleSeekClick}
        >
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-gold via-accent to-emerald-400"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
        <div className="mt-1 flex items-center justify-between text-[11px] font-body text-muted-foreground">
          <span>RDM Radio · Hero</span>
          <Link
            to="/music"
            className="text-[11px] underline-offset-2 hover:text-accent hover:underline"
          >
            Ver playlist completa
          </Link>
        </div>
      </div>

      {/* Controles secundarios */}
      <div className="flex items-center justify-between gap-3 border-t border-border/60 px-4 py-2.5">
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="inline-flex items-center gap-1 rounded-full border border-border px-2 py-1 text-[10px] font-body text-muted-foreground hover:border-rose-400/60 hover:text-rose-300 transition-colors"
            onClick={() => {
              if (currentTrack.donationUrl) {
                window.open(currentTrack.donationUrl, "_blank", "noopener");
              }
            }}
          >
            <Heart className="h-3 w-3" />
            Apoyar
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-1 rounded-full border border-border px-2 py-1 text-[10px] font-body text-muted-foreground hover:border-border/80 hover:text-foreground transition-colors"
          >
            <ListMusic className="h-3 w-3" />
            Playlist
          </button>
          <button
            type="button"
            className="inline-flex items-center gap-1 rounded-full border border-border px-2 py-1 text-[10px] font-body text-muted-foreground hover:border-emerald-400/60 hover:text-emerald-300 transition-colors"
          >
            <Download className="h-3 w-3" />
            Descargar
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setVolume(isMuted ? 0.8 : 0)}
            className="text-muted-foreground hover:text-foreground transition-colors"
            aria-label={isMuted ? "Activar volumen" : "Silenciar"}
          >
            {isMuted ? (
              <VolumeX className="h-4 w-4" />
            ) : (
              <Volume2 className="h-4 w-4" />
            )}
          </button>
          <div className="relative h-1 w-16 cursor-pointer rounded-full bg-border/80">
            <div
              className="absolute inset-y-0 left-0 rounded-full bg-foreground"
              style={{ width: `${volume * 100}%` }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
