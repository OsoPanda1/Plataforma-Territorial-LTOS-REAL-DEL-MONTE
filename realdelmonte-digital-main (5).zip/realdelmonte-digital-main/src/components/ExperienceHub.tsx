import { Compass, MapPin, Star } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import imgMina from "@/assets/rdm-mina-interior.jpg";
import imgSierra from "@/assets/rdm-sierra-ecoturismo.jpg";
import imgPastes from "@/assets/rdm-pastes-close.jpg";
import imgPanteon from "@/assets/rdm-panteon-ingles.jpg";

type Experience = {
  title: string;
  category: string;
  image: string;
  description: string;
  rating: number;
  link: string;
};

const EXPERIENCES: Experience[] = [
  {
    title: "Mina de Acosta",
    category: "Historia & Minería",
    image: imgMina,
    description:
      "Un viaje a las profundidades de la historia minera de Real del Monte.",
    rating: 4.9,
    link: "/historia",
  },
  {
    title: "Bosque del Hiloche",
    category: "Ecoturismo",
    image: imgSierra,
    description: "Senderos entre niebla y pinos centenarios.",
    rating: 4.8,
    link: "/ecoturismo",
  },
  {
    title: "Pastes Tradicionales",
    category: "Gastronomía",
    image: imgPastes,
    description:
      "El sabor que define a un pueblo y su herencia inglesa.",
    rating: 5.0,
    link: "/gastronomia",
  },
  {
    title: "Panteón Inglés",
    category: "Cultura",
    image: imgPanteon,
    description:
      "Un lugar de descanso eterno con vista a las montañas.",
    rating: 4.7,
    link: "/cultura",
  },
];

const containerVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: "easeOut" },
  },
};

export default function ExperienceHub() {
  return (
    <section
      aria-labelledby="experience-hub-title"
      className="space-y-10 md:space-y-14"
    >
      {/* Encabezado principal */}
      <motion.header
        className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="max-w-2xl">
          <p className="text-[11px] font-body uppercase tracking-[0.25em] text-gold/80 mb-2 flex items-center gap-2">
            <span className="inline-flex h-1 w-6 rounded-full bg-gold" />
            Nodo Cero · Real del Monte
          </p>
          <h2
            id="experience-hub-title"
            className="mb-3 font-display text-3xl sm:text-4xl md:text-5xl font-light italic text-foreground"
          >
            Experience Hub
          </h2>
          <p className="leading-relaxed text-muted-foreground font-body text-sm sm:text-base">
            Explora Real del Monte a través de experiencias curadas por la red
            RDM Digital. Desde las profundidades de las minas hasta los sabores
            más auténticos, sincronizados con el Gemelo Digital Territorial.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-[11px] font-body text-muted-foreground">
          <span className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            Experiencias verificadas por RDM Digital
          </span>
          <Link
            to="/mapa"
            className="inline-flex items-center gap-2 rounded-full border border-border px-3 py-1 hover:border-accent/60 hover:text-accent transition-colors"
          >
            <Compass className="h-3.5 w-3.5" />
            Ver en el Gemelo Digital
          </Link>
        </div>
      </motion.header>

      {/* Sección: categorías (como pseudo tabs/redirecciones rápidas) */}
      <div className="flex flex-wrap gap-2 text-[11px] font-body">
        <Link
          to="/historia"
          className="rounded-full border border-border bg-card/60 px-3 py-1 hover:border-gold/40 hover:text-gold transition-colors"
        >
          Historia & Minería
        </Link>
        <Link
          to="/ecoturismo"
          className="rounded-full border border-border bg-card/60 px-3 py-1 hover:border-emerald-400/40 hover:text-emerald-300 transition-colors"
        >
          Ecoturismo
        </Link>
        <Link
          to="/gastronomia"
          className="rounded-full border border-border bg-card/60 px-3 py-1 hover:border-amber-300/40 hover:text-amber-200 transition-colors"
        >
          Gastronomía
        </Link>
        <Link
          to="/cultura"
          className="rounded-full border border-border bg-card/60 px-3 py-1 hover:border-sky-300/40 hover:text-sky-200 transition-colors"
        >
          Cultura & Memoria
        </Link>
      </div>

      {/* “Página 1” de experiencias destacadas */}
      <section
        aria-label="Experiencias destacadas"
        className="space-y-6"
      >
        <div className="flex items-center justify-between gap-4">
          <h3 className="font-display text-lg text-foreground">
            Destacadas del Nodo Cero
          </h3>
          <Link
            to="/experiencias"
            className="text-[11px] font-body uppercase tracking-[0.18em] text-muted-foreground hover:text-accent transition-colors"
          >
            Ver todas las rutas
          </Link>
        </div>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-4">
          {EXPERIENCES.map((exp, i) => (
            <motion.article
              key={exp.title}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.35 }}
              transition={{ duration: 0.35, delay: i * 0.05 }}
              className="group relative aspect-[3/4] overflow-hidden rounded-2xl border border-border bg-card"
            >
              <img
                src={exp.image}
                alt={exp.title}
                className="absolute inset-0 h-full w-full object-cover opacity-65 transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

              <div className="absolute inset-0 flex flex-col justify-between p-5">
                <div className="flex items-start justify-between gap-2">
                  <span className="rounded-full border border-gold/30 bg-gold/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-gold backdrop-blur-md font-body">
                    {exp.category}
                  </span>
                  <div className="flex items-center gap-1 rounded-full bg-background/60 px-2 py-1 text-gold backdrop-blur-md">
                    <Star className="h-3 w-3 fill-current" />
                    <span className="text-[10px] font-bold font-body">
                      {exp.rating.toFixed(1)}
                    </span>
                  </div>
                </div>

                <div>
                  <h4 className="mb-1.5 text-lg font-display font-semibold text-foreground transition-colors group-hover:text-gold">
                    {exp.title}
                  </h4>
                  <p className="mb-3 line-clamp-2 text-xs text-muted-foreground font-body opacity-0 transition-opacity duration-200 group-hover:opacity-100">
                    {exp.description}
                  </p>
                  <Link
                    to={exp.link}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-secondary/60 border border-border py-2.5 text-[10px] font-bold uppercase tracking-widest font-body text-foreground transition-all hover:bg-accent/20 hover:text-accent hover:border-accent/40"
                  >
                    Explorar
                    <Compass className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      {/* Sección: Ruta destacada */}
      <section
        aria-label="Ruta destacada del Gemelo Digital"
        className="relative overflow-hidden rounded-2xl border border-border bg-card"
      >
        <div className="absolute inset-y-0 right-0 w-1/2 opacity-15 pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-l from-gold/15 via-accent/5 to-transparent" />
        </div>

        <div className="relative z-10 flex flex-col gap-6 p-7 md:p-10 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl">
            <div className="mb-5 flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gold/15 border border-gold/25">
                <MapPin className="h-5 w-5 text-gold" />
              </div>
              <div>
                <p className="text-[10px] font-body uppercase tracking-[0.22em] text-gold">
                  Ruta Destacada
                </p>
                <p className="text-[11px] font-body text-muted-foreground">
                  Recomendada por el Gemelo Digital de RDM Digital
                </p>
              </div>
            </div>

            <h3 className="mb-3 text-2xl md:text-3xl font-display font-semibold text-foreground">
              Senda de los Mineros
            </h3>
            <p className="mb-6 leading-relaxed text-muted-foreground font-body text-sm sm:text-base">
              Una travesía guiada que conecta la Mina de Acosta, el centro
              histórico y el Panteón Inglés. Sincroniza tu recorrido con el
              Gemelo Digital para recibir narrativas, alertas y puntos clave
              en tiempo real.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <Link
                to="/rutas/senda-mineros"
                className="flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 font-body font-semibold text-accent-foreground text-sm transition-all hover:bg-accent/90"
              >
                Iniciar navegación
                <Compass className="h-4 w-4" />
              </Link>
              <Link
                to="/rutas"
                className="text-[11px] font-body uppercase tracking-[0.2em] text-muted-foreground hover:text-accent transition-colors"
              >
                Ver todas las rutas
              </Link>
            </div>
          </div>

          <div className="hidden lg:block lg:w-64 xl:w-72">
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-border/70 bg-background/40">
              <div className="absolute inset-0 bg-gradient-to-br from-gold/10 via-transparent to-accent/15" />
              <div className="absolute left-6 top-6 flex flex-col gap-1 text-[10px] font-body text-muted-foreground">
                <span className="inline-flex items-center gap-1 rounded-full bg-background/80 px-2 py-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  Gemelo Digital activo
                </span>
                <span className="inline-flex items-center gap-1 rounded-full bg-background/80 px-2 py-1">
                  <MapPin className="h-3 w-3" />
                  5 puntos clave
                </span>
              </div>
              <div className="absolute inset-x-6 bottom-6 space-y-2 text-[11px] font-body text-muted-foreground">
                <div className="flex justify-between">
                  <span>Mina de Acosta</span>
                  <span>Inicio</span>
                </div>
                <div className="h-[3px] w-full overflow-hidden rounded-full bg-border">
                  <div className="h-full w-3/4 bg-gradient-to-r from-gold via-accent to-emerald-400" />
                </div>
                <div className="flex justify-between">
                  <span>Panteón Inglés</span>
                  <span>Final</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}
