import { AnimatePresence, motion } from "framer-motion";
import { useRdmSystemState } from "@/context/RdmSystemStateContext";
import { AlertTriangle, RefreshCw, Shield, Sparkles } from "lucide-react";

type Whisper = {
  id: string;
  text: string;
  subtext: string;
  tone: "danger" | "info" | "warning" | "success";
  icon: React.ElementType;
};

const toneStyles: Record<string, string> = {
  danger: "border-destructive/40 bg-destructive/10 text-destructive",
  warning: "border-gold/40 bg-gold/10 text-gold",
  info: "border-accent/40 bg-accent/10 text-accent",
  success: "border-success/40 bg-success/10 text-success",
};

export const MinerWhispersHUD = () => {
  const { threadError, loadBalancing, highRiskZone, trafficRecovered } = useRdmSystemState();

  const messages: Whisper[] = [];
  if (threadError) messages.push({ id: "gallo", text: "¡Ya se nos peló el gallo!", subtext: "Hilo de ejecución interrumpido", tone: "danger", icon: AlertTriangle });
  if (loadBalancing) messages.push({ id: "malacate", text: "Echando malacate…", subtext: "Redistribuyendo carga entre nodos", tone: "info", icon: RefreshCw });
  if (highRiskZone) messages.push({ id: "barreno", text: "Andas en el barreno", subtext: "Zona de alta densidad de datos", tone: "warning", icon: Shield });
  if (trafficRecovered) messages.push({ id: "casta", text: "¡Sacamos la casta del malacate!", subtext: "Sistema estabilizado", tone: "success", icon: Sparkles });

  if (messages.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-[60] flex flex-col gap-2 max-w-xs pointer-events-none">
      <AnimatePresence mode="popLayout">
        {messages.map(msg => {
          const Icon = msg.icon;
          return (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, x: 40, filter: "blur(8px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, x: 30, filter: "blur(6px)" }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className={`rounded-xl border px-4 py-3 backdrop-blur-xl shadow-lg pointer-events-auto ${toneStyles[msg.tone]}`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  <Icon className={`w-4 h-4 ${msg.tone === "info" ? "animate-spin" : ""}`} style={msg.tone === "info" ? { animationDuration: "2s" } : {}} />
                </div>
                <div>
                  <p className="text-sm font-display font-bold leading-tight">{msg.text}</p>
                  <p className="text-[10px] font-body opacity-70 mt-0.5">{msg.subtext}</p>
                </div>
              </div>
              {msg.tone === "success" && (
                <motion.div
                  className="absolute inset-0 rounded-xl"
                  initial={{ boxShadow: "0 0 0px hsl(145 60% 42% / 0)" }}
                  animate={{ boxShadow: ["0 0 0px hsl(145 60% 42% / 0)", "0 0 20px hsl(145 60% 42% / 0.3)", "0 0 0px hsl(145 60% 42% / 0)"] }}
                  transition={{ duration: 1.5, repeat: 2 }}
                />
              )}
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
