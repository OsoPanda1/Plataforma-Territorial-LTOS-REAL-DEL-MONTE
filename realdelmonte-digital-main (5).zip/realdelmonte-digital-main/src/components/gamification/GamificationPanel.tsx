import { useEffect, useState } from "react";
import { Trophy, Sparkles, Target, ShieldCheck, Activity, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { getGamificationProfile } from "@/services/gamification";

// Contratos de interfaces del ecosistema de gobernanza
export interface Badge {
  id: string;
  name: string;
  tier: "sovereign" | "gold" | "silver" | "bronze";
  unlockedAt?: string;
}

export interface GamificationProfile {
  level: number;
  title: string;
  points: number;
  nextLevelPoints: number;
  badges: Badge[];
  // opcional: bandera de membresía / plan
  membershipTier?: "free" | "pro" | "guardian";
}

interface GamificationPanelProps {
  userId?: string;
  className?: string;
  onUpgradeClick?: () => void;
}

export function GamificationPanel({
  userId = "local",
  className = "",
  onUpgradeClick,
}: GamificationPanelProps) {
  const [profile, setProfile] = useState<GamificationProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    try {
      // Obtención segura de perfil territorial
      const data = getGamificationProfile(userId);

      // Adaptador de compatibilidad por si 'badges' viene como string[] desde servicios antiguos
      const normalizedBadges: Badge[] = (data.badges || []).map((badge: any, index: number) => {
        if (typeof badge === "string") {
          return { id: `b-${index}`, name: badge, tier: "bronze" };
        }
        return badge;
      });

      setProfile({
        level: data.level ?? 0,
        title: data.title || "Operador Base",
        points: data.points ?? 0,
        nextLevelPoints: data.nextLevelPoints ?? 100,
        badges: normalizedBadges,
        membershipTier: data.membershipTier ?? "free",
      });
    } catch (error) {
      console.error(
        "Error crítico al recuperar perfil de gamificación territorial:",
        error,
      );
    } finally {
      setLoading(false);
    }
  }, [userId]);

  if (loading) return <GamificationSkeleton />;
  if (!profile) return null;

  // Cálculo matemático blindado contra división por cero
  const totalTargetPoints = Math.max(profile.nextLevelPoints, 1);
  const rawProgress = (profile.points / totalTargetPoints) * 100;
  const progressPercentage = Math.min(100, Math.max(0, Math.round(rawProgress)));
  const pointsRemaining = profile.nextLevelPoints - profile.points;

  const getTierStyles = (tier: Badge["tier"]) => {
    switch (tier) {
      case "sovereign":
        return "border-emerald-500/40 bg-gradient-to-r from-emerald-500/15 via-emerald-400/10 to-emerald-500/20 text-emerald-200 shadow-[0_0_25px_rgba(16,185,129,0.35)]";
      case "gold":
        return "border-amber-500/35 bg-amber-500/12 text-amber-100 shadow-[0_0_18px_rgba(245,158,11,0.30)]";
      case "silver":
        return "border-slate-300/35 bg-slate-400/12 text-slate-100";
      default:
        return "border-accent/25 bg-accent/8 text-accent-foreground/80";
    }
  };

  const membershipLabel =
    profile.membershipTier === "guardian"
      ? "Guardia del Territorio"
      : profile.membershipTier === "pro"
      ? "Nodo Pro Activo"
      : "Explorador Libre";

  const membershipTagClass =
    profile.membershipTier === "guardian"
      ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/40"
      : profile.membershipTier === "pro"
      ? "bg-amber-500/15 text-amber-300 border-amber-500/40"
      : "bg-secondary/40 text-muted-foreground border-border/60";

  return (
    <section
      className={`w-full bg-card/70 backdrop-blur-xl border border-border/80 rounded-2xl p-5 shadow-[0_0_40px_rgba(15,23,42,0.55)] overflow-hidden transition-all duration-500 hover:border-accent/70 hover:shadow-[0_0_55px_rgba(56,189,248,0.5)] ${className}`}
    >
      {/* Encabezado de Nivel de Red */}
      <div className="flex items-start justify-between gap-4 mb-5">
        <div className="space-y-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-[0.18em] font-body flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-accent/80" />
              Nodo de Gobernanza Territorial
            </p>
            <span
              className={`inline-flex items-center px-2 py-[2px] rounded-full border text-[9px] font-medium ${membershipTagClass}`}
            >
              {membershipLabel}
            </span>
          </div>
          <div className="flex flex-wrap items-baseline gap-1.5">
            <h2 className="text-xl font-semibold tracking-tight text-foreground font-display truncate">
              Nivel {profile.level}
            </h2>
            <span className="text-muted-foreground/50">·</span>
            <span className="text-sm text-muted-foreground font-body">
              {profile.title}
            </span>
          </div>
          <p className="text-[11px] text-muted-foreground/80 font-body max-w-md">
            Cada acción que realizas en Real del Monte deja una huella en este panel.
            Sube de nivel para desbloquear rutas, visibilidad y capas soberanas del
            territorio.
          </p>
        </div>

        <motion.div
          className="relative w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-400/40 flex items-center justify-center shrink-0 shadow-inner"
          initial={{ scale: 0.9, rotate: -4 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 120, damping: 12 }}
        >
          <motion.div
            className="absolute inset-0 rounded-2xl bg-amber-400/20 blur-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          />
          <Trophy className="w-6 h-6 text-amber-400 relative z-10" />
        </motion.div>
      </div>

      {/* Malla Métricas Principales */}
      <div className="grid md:grid-cols-3 gap-3 mb-5">
        {/* Bloque de Puntos Absolutos */}
        <div className="rounded-xl bg-secondary/35 border border-border/60 p-4 flex flex-col justify-between transition-colors hover:bg-secondary/45">
          <div className="flex items-center justify-between mb-3">
            <p className="text-[11px] text-muted-foreground font-body font-medium">
              Puntos acumulados del nodo
            </p>
            <Sparkles className="w-3.5 h-3.5 text-accent/90" />
          </div>
          <p className="text-3xl font-bold tracking-tight text-foreground font-body">
            {profile.points.toLocaleString()}
          </p>
          <p className="text-[10px] text-muted-foreground mt-1">
            Esta es tu energía civilizatoria activa en el ecosistema RDM Digital.
          </p>
        </div>

        {/* Bloque de Seguimiento y Barras de Progreso */}
        <div className="rounded-xl bg-secondary/35 border border-border/60 p-4 md:col-span-2 flex flex-col justify-between transition-colors hover:bg-secondary/45">
          <div className="flex items-center justify-between mb-3">
            <p className="text-[11px] text-muted-foreground font-body font-medium">
              Órbita hacia la siguiente escala
            </p>
            <Target className="w-3.5 h-3.5 text-amber-400/90" />
          </div>

          <div className="w-full space-y-2.5">
            <div className="h-2.5 rounded-full bg-background/90 border border-border/40 overflow-hidden relative">
              <motion.div
                className="h-full bg-gradient-to-r from-cyan-400 via-sky-400 to-amber-400"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercentage}%` }}
                transition={{ type: "spring", stiffness: 70, damping: 16 }}
              />
              <motion.div
                className="absolute -top-1.5 h-5 w-5 rounded-full bg-amber-400/90 border border-amber-300/70 shadow-lg"
                initial={{ x: 0 }}
                animate={{ x: `${progressPercentage}%` }}
                transition={{ type: "spring", stiffness: 70, damping: 16 }}
              />
            </div>

            <div className="flex items-center justify-between text-[10px] font-body text-muted-foreground">
              <span>
                {pointsRemaining > 0 ? (
                  <>
                    Requieres{" "}
                    <span className="text-foreground font-semibold">
                      {pointsRemaining.toLocaleString()}
                    </span>{" "}
                    puntos para la siguiente escala del nodo.
                  </>
                ) : (
                  <span className="text-emerald-400 font-medium">
                    Máxima escala operativa alcanzada en este plano.
                  </span>
                )}
              </span>
              <span className="text-muted-foreground/70">
                {progressPercentage}% completado
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Matriz de Insignias Tecnológicas + CTA de upgrade */}
      <div className="pt-3 border-t border-border/40 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <p className="text-[11px] text-muted-foreground font-body font-medium">
            Credenciales activas en este territorio
          </p>
          {onUpgradeClick && profile.membershipTier !== "guardian" && (
            <button
              type="button"
              onClick={onUpgradeClick}
              className="inline-flex items-center gap-1.5 rounded-full border border-accent/50 bg-accent/10 px-2.5 py-1 text-[10px] font-semibold text-accent-foreground hover:bg-accent/20 transition-colors"
            >
              Desbloquear modo Guardián
              <ArrowRight className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {profile.badges.length > 0 ? (
            profile.badges.map((badge) => (
              <motion.span
                key={badge.id}
                className={`inline-flex items-center rounded-lg border px-2.5 py-1 text-[11px] font-medium font-body transition-all duration-200 ${getTierStyles(
                  badge.tier,
                )}`}
                whileHover={{ scale: 1.04, translateY: -1 }}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5 opacity-70" />
                {badge.name}
              </motion.span>
            ))
          ) : (
            <span className="text-[11px] text-muted-foreground font-body italic px-1">
              Ninguna credencial verificada en este nodo territorial todavía.
            </span>
          )}
        </div>

        {/* Panel compacto de misión activa para reforzar valor */}
        <div className="mt-1 rounded-xl bg-background/60 border border-border/60 px-3 py-2.5 flex items-center gap-2.5">
          <div className="w-6 h-6 rounded-full bg-emerald-500/10 border border-emerald-400/30 flex items-center justify-center">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[11px] text-foreground font-medium truncate">
              Misión del territorio
            </p>
            <p className="text-[10px] text-muted-foreground truncate">
              Mantén tu nivel alto para priorizar rutas, beneficios y señalización de
              tu presencia en Real del Monte.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

// Subcomponente de precarga limpia para evitar saltos en la interfaz (CLS UI)
function GamificationSkeleton() {
  return (
    <div className="w-full bg-card/40 border border-border/80 rounded-2xl p-5 space-y-5 animate-pulse">
      <div className="flex justify-between items-center">
        <div className="space-y-2 w-1/2">
          <div className="h-3 bg-muted rounded w-1/3" />
          <div className="h-6 bg-muted rounded w-3/4" />
        </div>
        <div className="w-10 h-10 bg-muted rounded-2xl" />
      </div>
      <div className="grid md:grid-cols-3 gap-3">
        <div className="h-20 bg-muted/60 rounded-xl" />
        <div className="h-20 bg-muted/60 rounded-xl md:col-span-2" />
      </div>
      <div className="flex gap-2">
        <div className="h-5 bg-muted rounded-full w-16" />
        <div className="h-5 bg-muted rounded-full w-24" />
      </div>
    </div>
  );
}
