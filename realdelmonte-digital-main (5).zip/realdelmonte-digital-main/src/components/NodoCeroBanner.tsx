import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Crown, ArrowRight, ScrollText, Network, GitBranch } from "lucide-react";

/**
 * NodoCeroBanner — fusión de RDM-Digital-X.
 * Banner soberano que conecta la home con Tesis TAMV, Fusion y Federación.
 */
export default function NodoCeroBanner() {
  return (
    <section className="relative py-14 md:py-20 overflow-hidden">
      <div
        className="absolute inset-0 opacity-40 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at center, hsl(var(--gold) / 0.25), transparent 60%), linear-gradient(135deg, hsl(var(--navy-dark)), hsl(var(--navy)))",
        }}
        aria-hidden
      />
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="glass-card rounded-2xl p-8 md:p-12 max-w-5xl mx-auto border border-gold/20"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-8">
            <div className="flex-1">
              <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 rounded-full border border-gold/40 bg-gold/5">
                <Crown className="w-3.5 h-3.5 text-gold" />
                <span className="font-body text-[10px] tracking-[0.3em] uppercase text-gold">
                  Nodo Cero · Activo
                </span>
              </div>
              <h2 className="font-display text-3xl md:text-4xl leading-tight mb-3 text-foreground">
                Real del Monte opera como{" "}
                <span className="text-gradient-gold">Sistema Operativo Territorial Soberano</span>
              </h2>
              <p className="font-body text-sm md:text-base text-muted-foreground leading-relaxed max-w-2xl">
                Primer pueblo mágico mexicano con federación triple{" "}
                <span className="text-foreground/80">conceptual · legal · técnica</span>, IA local,
                economía Phoenix 20/30/50 y memoria anclada en IPFS. Tesis pública, código auditable.
              </p>
            </div>

            <div className="flex flex-col gap-3 md:min-w-[220px]">
              <Link
                to="/tamv"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-gold to-gold-dark text-navy-dark font-body text-xs tracking-[0.25em] uppercase font-semibold hover:shadow-lg hover:shadow-gold/30 transition-all"
              >
                <ScrollText className="w-4 h-4" />
                Tesis TAMV
              </Link>
              <Link
                to="/fusion"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl border border-accent/40 bg-accent/5 text-accent font-body text-xs tracking-[0.25em] uppercase hover:bg-accent/10 transition-all"
              >
                <GitBranch className="w-4 h-4" />
                Fusión RDM·X
              </Link>
              <Link
                to="/federacion"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl border border-accent/40 bg-accent/5 text-accent font-body text-xs tracking-[0.25em] uppercase hover:bg-accent/10 transition-all"
              >
                <Network className="w-4 h-4" />
                Federación
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
