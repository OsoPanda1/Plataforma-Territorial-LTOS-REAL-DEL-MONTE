import { useRef } from "react";
import { motion, useScroll, useTransform, Variants } from "framer-motion";
import { MapPin, Compass, ChevronDown, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import heroPanorama from "@/assets/rdm-panorama-hero.jpg";
import logoBadge from "@/assets/rdm-logo-badge.png";

// URL de Origen del Núcleo de Infraestructura
const INTRO_VIDEO_URL = "/__l5e/assets-v1/2b1e7964-084b-477d-a3d1-c6b6000632eb/rdm-intro.mp4";

// ============================================================================
// Tipos y Modelos de Datos Domésticos
// ============================================================================

interface StatItem {
  value: string;
  label: string;
}

// Extracción de datos estáticos fuera de la memoria del ciclo de vida del componente
const STATISTICS_DATA: StatItem[] = [
  { value: "2,700m", label: "Altitud" },
  { value: "460+", label: "Años de historia" },
  { value: "21,600+", label: "Horas de desarrollo" },
  { value: "1°", label: "En Latinoamérica" },
];

// ============================================================================
// Definición de Esquemas de Animación (Variants Matrix)
// ============================================================================

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.15,
    },
  },
};

const fadeUpVariants: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      type: "spring",
      stiffness: 60,
      damping: 15,
    },
  },
};

const logoVariants: Variants = {
  hidden: { opacity: 0, scale: 0.82 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 45,
      damping: 14,
    },
  },
};

// ============================================================================
// Componente de Vista Principal
// ============================================================================

export default function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);

  // Captura del progreso de desplazamiento en el eje Y de la sección nativa
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  // Interpolación matemática para efectos cinemáticos de scroll paralaje
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "45%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.55], [1, 0]);

  return (
    <section 
      ref={containerRef} 
      className="relative min-h-screen overflow-hidden select-none bg-background"
      style={{ background: "linear-gradient(180deg, hsl(220,30%,3%) 0%, hsl(220,30%,5%) 100%)" }}
    >
      {/* Fondo Cinematográfico: Aislado del Árbol de Accesibilidad */}
      <div className="absolute inset-0 z-0 pointer-events-none" aria-hidden="true">
        <video
          src={INTRO_VIDEO_URL}
          autoPlay
          muted
          loop
          playsInline
          tabIndex={-1}
          className="w-full h-full object-cover opacity-[0.26]"
          poster={heroPanorama}
        />
        {/* Capas Gradientes de Atenuación Lumínica y Contraste */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/30 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/50 via-transparent to-background/50" />
      </div>

      {/* Orbes de Iluminación Ambiental Ambiental (GPU Accelerated Blurring) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-1" aria-hidden="true">
        <div 
          className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full animate-orb mix-blend-screen" 
          style={{ background: "hsl(210 100% 55% / 0.05)", filter: "blur(90px)" }} 
        />
        <div 
          className="absolute bottom-1/3 right-1/4 w-72 h-72 rounded-full animate-orb-reverse mix-blend-screen" 
          style={{ background: "hsl(43 80% 55% / 0.04)", filter: "blur(80px)" }} 
        />
      </div>

      {/* Contenedor de Partículas Ambientales */}
      <div className="absolute inset-0 pointer-events-none z-1 dust-particles" aria-hidden="true" />

      {/* Bloque Central del Manifiesto Territorial */}
      <motion.div 
        style={{ y: textY, opacity }}
        className="relative z-10 mx-auto flex min-h-screen max-w-6xl flex-col items-center justify-center px-6 text-center"
      >
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8 w-full"
        >
          {/* Nodo Logotipo / Escudo de Validación */}
          <motion.div 
            variants={logoVariants}
            className="mx-auto w-28 h-28 md:w-36 md:h-36 rounded-full overflow-hidden border-2 border-accent/20 shadow-2xl bg-background/40 backdrop-blur-md"
            style={{ boxShadow: "0 0 50px hsl(210 100% 55% / 0.12), 0 0 100px hsl(43 80% 55% / 0.06)" }}
          >
            <img src={logoBadge} alt="RDM Digital Oficial Badge" className="w-full h-full object-cover" loading="eager" />
          </motion.div>

          {/* Tag de Posicionamiento Geográfico */}
          <motion.div 
            variants={fadeUpVariants}
            className="mx-auto inline-flex items-center gap-2 rounded-full border border-border bg-secondary/20 px-5 py-2 text-xs uppercase tracking-[0.25em] backdrop-blur-md font-body"
          >
            <MapPin className="h-3.5 w-3.5 text-gold" aria-hidden="true" />
            <span className="text-foreground/80">Real del Monte</span>
            <span className="mx-1 h-3 w-px bg-border/60" role="presentation" />
            <span className="text-gold font-medium">Pueblo Mágico</span>
            <span className="mx-1 h-3 w-px bg-border/60" role="presentation" />
            <span className="text-foreground/80">Hidalgo</span>
          </motion.div>

          {/* Bloque del Título de Sistema */}
          <motion.h1 
            variants={fadeUpVariants}
            className="font-display text-5xl leading-none tracking-tight md:text-7xl lg:text-8xl select-none"
          >
            <span className="block text-foreground font-bold">RDM</span>
            <span 
              className="block animate-gradient-text text-glow-gold py-1"
              style={{
                backgroundImage: "linear-gradient(135deg, hsl(43,80%,55%) 0%, hsl(35,70%,65%) 25%, hsl(43,80%,55%) 50%, hsl(25,60%,50%) 75%, hsl(43,80%,55%) 100%)",
                backgroundSize: "200% 200%",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Digital
            </span>
          </motion.h1>

          {/* Subtítulo Técnico e Integración de Core Engine */}
          <motion.p 
            variants={fadeUpVariants}
            className="mx-auto max-w-2xl text-sm md:text-base leading-relaxed font-body text-muted-foreground font-medium"
          >
            Sistema Operativo Territorial Soberano <span className="mx-1 text-border/60">•</span> Gemelo Digital 4D <span className="mx-1 text-border/60">•</span> City Intelligence <span className="mx-1 text-border/60">•</span> <span className="text-accent font-semibold">Isabella AI™</span> <span className="mx-1 text-border/60">•</span> Smart City 2026
          </motion.p>

          {/* Lista de Descripción Semántica (Métricas e Historial del Nodo) */}
          <motion.dl 
            variants={fadeUpVariants}
            className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4 py-4"
          >
            {STATISTICS_DATA.map((stat, i) => (
              <div key={i} className="text-center min-w-[110px]">
                <dd className="font-display text-2xl md:text-3xl font-bold tracking-tight text-gold">{stat.value}</dd>
                <dt className="text-[10px] uppercase tracking-widest text-muted-foreground font-body font-semibold mt-0.5">{stat.label}</dt>
              </div>
            ))}
          </motion.dl>

          {/* Acciones y Enlaces de Navegación Operativa */}
          <motion.div 
            variants={fadeUpVariants}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2"
          >
            <Link 
              to="/mapa" 
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 rounded-xl bg-accent px-8 py-4 font-body font-semibold text-accent-foreground transition-all duration-300 hover:bg-accent/90 shadow-md shadow-accent/20 glow-electric"
            >
              <Compass className="w-4 h-4" /> Explorar el Mapa
            </Link>
            <Link 
              to="/rutas" 
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 rounded-xl border border-border bg-secondary/20 px-8 py-4 font-body font-medium text-foreground transition-all duration-300 hover:bg-secondary/40 backdrop-blur-sm"
            >
              <Sparkles className="w-4 h-4 text-gold" /> Descubrir Rutas
            </Link>
          </motion.div>

          {/* Firma de Autoría e Indexación Académica Internacional */}
          <motion.p 
            variants={fadeUpVariants}
            className="text-[11px] text-muted-foreground/40 font-body pt-8 tracking-wide select-text"
          >
            Desarrollado por Edwin Oswaldo Castillo Trejo (Anubis Villaseñor) <span className="mx-1 text-muted-foreground/20">·</span> TAMV Online Network <span className="mx-1 text-muted-foreground/20">·</span> ORCID: 0009-0008-5050-1539 🇲🇽
          </motion.p>
        </motion.div>

        {/* Indicador de Desplazamiento Inferior */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8, duration: 0.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 pointer-events-none"
        >
          <motion.div 
            animate={{ y: [0, 6, 0] }} 
            transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
          >
            <ChevronDown className="w-5 h-5 text-accent/40" />
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  );
}
