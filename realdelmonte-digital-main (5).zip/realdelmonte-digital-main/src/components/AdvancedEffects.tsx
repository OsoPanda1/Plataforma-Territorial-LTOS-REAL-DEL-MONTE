import React from 'react';

export const ParticleField = () => {
    // Add your particle field effect implementaion
    return <div>Particle Field Component</div>;
};

export const GlassCard = () => {
    // Add your glass card effect implementation
    return <div>Glass Card Component</div>;
};

export const TextReveal = () => {
    // Add your text reveal effect implementation
    return <div>Text Reveal Component</div>;
};

export const StaggerContainer = () => {
    // Add your stagger container effect implementation
    return <div>Stagger Container Component</div>;
};

export const GlowCard = () => {
    // Add your glow card effect implementation
    return <div>Glow Card Component</div>;
};

export const PageTransition = () => {
    // Add your page transition effect implementation
    return <div>Page Transition Component</div>;
};

export const AnimatedCounter = () => {
    // Add your animated counter implementation
    return <div>Animated Counter Component</div>;
};

// You can add more effects as needed