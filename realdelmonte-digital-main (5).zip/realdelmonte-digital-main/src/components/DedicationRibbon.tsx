/**
 * DedicationRibbon — Orgullosamente Realmontenses
 * Handwritten platinum dedication, present in every section.
 * Dedicado a Reina Trejo Serrano.
 */
export default function DedicationRibbon({ variant = "inline" }: { variant?: "inline" | "fixed" }) {
  const base =
    "pointer-events-none select-none text-center font-dedication tracking-wide leading-snug";
  const platinum: React.CSSProperties = {
    fontFamily: "'Dancing Script', 'Great Vibes', cursive",
    background:
      "linear-gradient(135deg, #e5e4e2 0%, #ffffff 25%, #c0c0c0 50%, #ffffff 75%, #b8b8b8 100%)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    backgroundClip: "text",
    textShadow: "0 0 18px rgba(229,228,226,0.25)",
    filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.6))",
  };

  if (variant === "fixed") {
    return (
      <div className="fixed bottom-2 left-1/2 -translate-x-1/2 z-[40] px-4 py-1 rounded-full glass-dark border border-white/5 max-w-[95vw]">
        <p className={`${base} text-[11px] sm:text-xs`} style={platinum}>
          Orgullosamente Realmontenses · Dedicado a mi Madre, Reina Trejo Serrano · Ma, sonríe — tu oveja negra lo logró.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full py-6 px-4 my-8 border-y border-white/5">
      <p className={`${base} text-base sm:text-xl md:text-2xl`} style={platinum}>
        Orgullosamente Realmontenses
      </p>
      <p className={`${base} text-sm sm:text-base md:text-lg mt-1`} style={platinum}>
        Proyecto dedicado a mi Madre — Reina Trejo Serrano
      </p>
      <p className={`${base} text-xs sm:text-sm md:text-base mt-1 italic opacity-90`} style={platinum}>
        Ma, sonríe y siente orgullo — tu oveja negra lo logró.
      </p>
    </div>
  );
}
