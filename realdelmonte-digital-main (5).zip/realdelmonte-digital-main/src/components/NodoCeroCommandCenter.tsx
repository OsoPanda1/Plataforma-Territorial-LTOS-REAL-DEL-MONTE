import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  GitBranch,
  Layers3,
  RadioTower,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import {
  getNodeZeroCompletion,
  NODE_ZERO_CAPABILITIES,
  NODE_ZERO_PROTOCOL,
  NODE_ZERO_REPOS,
  type NodeZeroRepoStatus,
} from "@/data/rdmNodeZero";

const statusLabel: Record<NodeZeroRepoStatus, string> = {
  absorbed: "Absorbido",
  orchestrated: "Orquestado",
  reference: "Referencia",
};

const statusClass: Record<NodeZeroRepoStatus, string> = {
  absorbed: "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
  orchestrated: "border-gold/35 bg-gold/10 text-gold",
  reference: "border-cyan-300/25 bg-cyan-300/10 text-cyan-100",
};

interface NodoCeroCommandCenterProps {
  compact?: boolean;
}

export default function NodoCeroCommandCenter({
  compact = false,
}: NodoCeroCommandCenterProps) {
  const completion = getNodeZeroCompletion();
  const visibleRepos = compact ? NODE_ZERO_REPOS.slice(0, 6) : NODE_ZERO_REPOS;

  return (
    <section className={compact ? "space-y-8" : "py-24 px-6"}>
      <div className={compact ? "" : "container max-w-6xl"}>
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          className="mb-10 grid gap-6 lg:grid-cols-[1.05fr_0.95fr] lg:items-end"
        >
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3 py-1">
              <RadioTower className="h-3.5 w-3.5 text-gold" />
              <span className="font-body text-[10px] uppercase tracking-[0.28em] text-gold">
                Nodo Cero ejecutado
              </span>
            </div>
            <h2 className="font-display text-3xl font-bold leading-tight text-foreground md:text-5xl">
              Fusión viva de repos RDM/TAMV en un solo{" "}
              <span className="text-gradient-gold">
                sistema operativo territorial
              </span>
            </h2>
            <p className="mt-5 max-w-3xl font-body text-sm leading-relaxed text-muted-foreground md:text-base">
              Se investigaron los repos públicos relacionados con RDM Digital,
              TAMV, Real del Monte y Smart City de OsoPanda1. Las mejoras
              técnicas, funcionales y visuales se consolidan aquí como matriz
              ejecutable: fuente, capacidad, ruta y madurez.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2">
            {[
              {
                label: "Repos auditados",
                value: completion.repos,
                icon: GitBranch,
              },
              {
                label: "Absorbidos",
                value: completion.absorbed,
                icon: CheckCircle2,
              },
              {
                label: "Madurez",
                value: `${completion.maturity}%`,
                icon: Sparkles,
              },
              {
                label: "Capacidades",
                value: NODE_ZERO_CAPABILITIES.length,
                icon: Layers3,
              },
            ].map((stat) => (
              <div
                key={stat.label}
                className="rounded-2xl border border-border bg-card/70 p-4 backdrop-blur-md"
              >
                <div className="mb-3 flex items-center justify-between gap-3">
                  <p className="font-body text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                    {stat.label}
                  </p>
                  <stat.icon className="h-4 w-4 text-accent" />
                </div>
                <p className="font-display text-3xl text-foreground">
                  {stat.value}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="space-y-4">
            <div className="rounded-2xl border border-border bg-card/60 p-5 backdrop-blur-md">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <p className="font-body text-[10px] uppercase tracking-[0.24em] text-accent">
                    Bitácora de absorción
                  </p>
                  <h3 className="mt-1 font-display text-xl text-foreground">
                    Repositorios fuente
                  </h3>
                </div>
                <ShieldCheck className="h-5 w-5 text-gold" />
              </div>
              <div className="space-y-3">
                {visibleRepos.map((repo, index) => (
                  <motion.a
                    key={repo.id}
                    href={repo.url}
                    target="_blank"
                    rel="noreferrer"
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.03 }}
                    className="group block rounded-xl border border-white/10 bg-background/35 p-3 transition-all hover:border-accent/35 hover:bg-secondary/20"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="mb-1 flex flex-wrap items-center gap-2">
                          <h4 className="truncate font-display text-sm text-foreground">
                            {repo.name}
                          </h4>
                          <span
                            className={`rounded-full border px-2 py-0.5 text-[9px] uppercase tracking-widest ${statusClass[repo.status]}`}
                          >
                            {statusLabel[repo.status]}
                          </span>
                        </div>
                        <p className="font-body text-xs leading-relaxed text-muted-foreground">
                          {repo.focus}
                        </p>
                      </div>
                      <ExternalLink className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground transition-colors group-hover:text-accent" />
                    </div>
                  </motion.a>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-gold/20 bg-gold/5 p-5">
              <p className="font-body text-[10px] uppercase tracking-[0.24em] text-gold">
                Secuencia de ejecución
              </p>
              <div className="mt-4 space-y-3">
                {NODE_ZERO_PROTOCOL.map((step, index) => (
                  <div key={step.id} className="flex gap-3">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-gold/30 bg-background font-mono text-xs text-gold">
                      {index + 1}
                    </div>
                    <div>
                      <h4 className="font-display text-sm text-foreground">
                        {step.title}
                      </h4>
                      <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                        {step.description}
                      </p>
                      {!compact && (
                        <p className="mt-1 font-mono text-[10px] text-cyan-100/60">
                          {step.evidence}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {NODE_ZERO_CAPABILITIES.map((capability, index) => (
              <motion.div
                key={capability.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: index * 0.04 }}
                className="rounded-2xl border border-border bg-card/65 p-5 backdrop-blur-md transition-all hover:border-gold/30"
              >
                <div className="mb-4 flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-accent">
                      {capability.id}
                    </p>
                    <h3 className="mt-1 font-display text-lg text-foreground">
                      {capability.title}
                    </h3>
                  </div>
                  <span className="rounded-full border border-gold/30 bg-gold/10 px-2 py-1 font-mono text-xs text-gold">
                    {capability.maturity}%
                  </span>
                </div>
                <div className="mb-4 h-1.5 overflow-hidden rounded-full bg-secondary">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${capability.maturity}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: 0.1 }}
                    className="h-full rounded-full bg-gradient-to-r from-accent to-gold"
                  />
                </div>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {capability.signal}
                </p>
                <p className="mt-3 text-xs leading-relaxed text-foreground/75">
                  {capability.implementation}
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {capability.routes.map((route) => (
                    <Link
                      key={route}
                      to={route}
                      className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-background/50 px-2.5 py-1 font-mono text-[10px] text-cyan-100/80 transition-colors hover:border-accent/40 hover:text-accent"
                    >
                      {route} <ArrowRight className="h-3 w-3" />
                    </Link>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
