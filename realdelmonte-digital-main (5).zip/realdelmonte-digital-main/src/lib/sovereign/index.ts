// ─────────────────────────────────────────────────────────────────────────────
// RDM SOVEREIGN ENGINE · Unified module
// Portado y unificado desde OsoPanda1/rdm-smart-city-os
//   · src/core/models.ts
//   · src/ai/decision-engine.ts
//   · src/orchestrator/experience.orchestrator.ts
//   · src/orchestrator/decision.store.ts
//   · src/orchestrator/sovereignDecisionEngine.ts
// Self-contained (sin deps de instrumentation/metrics/event-bus).
// ─────────────────────────────────────────────────────────────────────────────

export interface Coordenadas { lat: number; lng: number }

export type DecisionLevel = "CRITICO" | "ALERTA" | "INFO";
export type RetentionIntent = "SAFE_EXIT" | "UPSELL" | "DISCOVERY";
export type MovementPattern = "EXPLORING" | "EXITING" | "IDLE";

export interface ScoreBreakdown {
  total: number;
  factors: Record<string, number>;
}

export interface ExplainabilityLog {
  ruleVersion: string;
  factors: Array<{ name: string; value: number; weight: number; rationale: string }>;
  notes: string[];
}

export interface TuristaEstado {
  id: string;
  territory?: string;
  coords: Coordenadas;
  prevCoords?: Coordenadas;
  stayTimeHours: number;
  lastInteractionAt: Date;
}

export interface IsabellaDecision {
  traceId: string;
  territory: string;
  level: DecisionLevel;
  retentionIntent: RetentionIntent;
  pattern: MovementPattern;
  distanceToExit: number;
  speedMps: number;
  score: ScoreBreakdown;
  coords: Coordenadas;
  payload: { titulo: string; mensaje: string; ruta_ar_activada: boolean };
  explainability: ExplainabilityLog;
  decidedAt: string;
}

// ── Geo utils ────────────────────────────────────────────────────────────────
const R = 6_371_000;
const toRad = (d: number) => (d * Math.PI) / 180;

export function haversineM(a: Coordenadas, b: Coordenadas): number {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export function nearestPoint<T extends { coords: Coordenadas }>(
  point: Coordenadas,
  items: T[],
): { item: T; distanceM: number } | null {
  if (items.length === 0) return null;
  let best = items[0];
  let bestD = haversineM(point, best.coords);
  for (let i = 1; i < items.length; i++) {
    const d = haversineM(point, items[i].coords);
    if (d < bestD) { best = items[i]; bestD = d; }
  }
  return { item: best, distanceM: bestD };
}

// ── Movement filter (EWMA) ──────────────────────────────────────────────────
export class MovementFilter {
  private value = 0;
  private primed = false;
  constructor(private alpha = 0.3) {}
  update(sample: number): number {
    if (!this.primed) { this.value = sample; this.primed = true; }
    else this.value = this.alpha * sample + (1 - this.alpha) * this.value;
    return this.value;
  }
  getAlpha() { return this.alpha; }
}

export function detectMovementPattern(input: {
  speedMps: number; distanceToExit: number;
}): MovementPattern {
  if (input.speedMps < 0.3) return "IDLE";
  if (input.distanceToExit < 80 && input.speedMps > 1.2) return "EXITING";
  return "EXPLORING";
}

// ── Scoring engine ──────────────────────────────────────────────────────────
export class ScoringEngine {
  evaluar(input: {
    distanceToExit: number;
    stayTimeHours: number;
    inactivityMinutes: number;
    speedMps: number;
  }): ScoreBreakdown {
    const proximity = Math.max(0, 40 - input.distanceToExit / 8);
    const stay = Math.min(25, input.stayTimeHours * 6);
    const inactivity = Math.min(20, input.inactivityMinutes * 0.8);
    const flight = input.speedMps > 1.4 ? Math.min(20, (input.speedMps - 1.4) * 10) : 0;
    const total = Math.round(proximity + stay + inactivity + flight);
    return {
      total,
      factors: {
        proximity: Math.round(proximity),
        stay: Math.round(stay),
        inactivity: Math.round(inactivity),
        flight: Math.round(flight),
      },
    };
  }
}

// ── Trace id ────────────────────────────────────────────────────────────────
function makeTraceId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `t-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

// ── Decision ledger ─────────────────────────────────────────────────────────
export interface AuditedDecision {
  decision: IsabellaDecision;
  hash: string;
  version: number;
}

function fastHash(s: string): string {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return Math.abs(h).toString(16).padStart(8, "0");
}

export class DecisionStore {
  private ledger: AuditedDecision[] = [];
  save(decision: IsabellaDecision): AuditedDecision {
    const version = this.ledger.length + 1;
    const hash = fastHash(JSON.stringify({
      t: decision.traceId, s: decision.score.total,
      r: decision.retentionIntent, f: decision.score.factors, v: version,
    }));
    const entry = { decision, hash, version };
    this.ledger.push(entry);
    if (this.ledger.length > 200) this.ledger.shift();
    return entry;
  }
  getLedger(limit = 50): AuditedDecision[] {
    return this.ledger.slice(-limit).reverse();
  }
  clear() { this.ledger = []; }
}

export const decisionStore = new DecisionStore();

// ── Orchestrator ────────────────────────────────────────────────────────────
export interface OrchestratorOptions {
  movementAlpha?: number;
  throttleMs?: number;
  proximityBBoxMeters?: number;
  threshold?: number;
  ruleVersion?: string;
}

export class ExperienceOrchestrator {
  private movement: MovementFilter;
  private lastDecisionAt = new Map<string, number>();
  private riskByTourist = new Map<string, number>();
  private throttleMs: number;
  private proximityMeters: number;
  private threshold: number;
  private engine = new ScoringEngine();
  private ruleVersion: string;

  constructor(private exits: Coordenadas[], opts: OrchestratorOptions = {}) {
    this.movement = new MovementFilter(opts.movementAlpha ?? 0.3);
    this.throttleMs = opts.throttleMs ?? 45_000;
    this.proximityMeters = opts.proximityBBoxMeters ?? 800;
    this.threshold = opts.threshold ?? 30;
    this.ruleVersion = opts.ruleVersion ?? "rdm-sovereign-1.0";
  }

  private resolveIntent(total: number, pattern: MovementPattern): RetentionIntent {
    if (pattern === "EXITING" && total >= 60) return "SAFE_EXIT";
    if (pattern === "EXPLORING" && total >= 50) return "UPSELL";
    return "DISCOVERY";
  }

  evaluar(t: TuristaEstado, now: number = Date.now()): IsabellaDecision | null {
    const prev = this.lastDecisionAt.get(t.id);
    if (prev && now - prev < this.throttleMs) return null;

    const nearestExit = nearestPoint(t.coords, this.exits.map((c) => ({ coords: c })));
    if (!nearestExit) return null;
    const dist = nearestExit.distanceM;
    if (dist > this.proximityMeters) return null;

    const rawSpeed = t.prevCoords ? haversineM(t.prevCoords, t.coords) / 5 : 0;
    const speed = this.movement.update(rawSpeed);

    const risk = Math.max(0, Math.min(100,
      (this.riskByTourist.get(t.id) ?? 0) + (speed > 15 ? 20 : speed > 8 ? 10 : -4)));
    this.riskByTourist.set(t.id, risk);
    if (risk >= 80) return null;

    const inactivity = (now - t.lastInteractionAt.getTime()) / 60_000;
    const score = this.engine.evaluar({
      distanceToExit: dist,
      stayTimeHours: t.stayTimeHours,
      inactivityMinutes: inactivity,
      speedMps: speed,
    });
    if (score.total < this.threshold) return null;

    const pattern = detectMovementPattern({ speedMps: speed, distanceToExit: dist });
    const retentionIntent = this.resolveIntent(score.total, pattern);
    const level: DecisionLevel = score.total >= 70 ? "CRITICO" : score.total >= 50 ? "ALERTA" : "INFO";

    const titulo =
      retentionIntent === "SAFE_EXIT" ? "Salida segura sugerida"
      : retentionIntent === "UPSELL" ? "Experiencia desbloqueada"
      : "Descubre algo cerca de ti";
    const mensaje =
      retentionIntent === "SAFE_EXIT"
        ? `Estás a ${Math.round(dist)} m del límite del Nodo. Ruta segura activada.`
        : retentionIntent === "UPSELL"
        ? `Hay una ruta cultural muy cerca. Activa la capa AR para ver pistas.`
        : `Real del Monte tiene un sitio interesante a ${Math.round(dist)} m.`;

    const decision: IsabellaDecision = {
      traceId: makeTraceId(),
      territory: t.territory ?? "RDM",
      level,
      retentionIntent,
      pattern,
      distanceToExit: dist,
      speedMps: speed,
      score,
      coords: t.coords,
      payload: { titulo, mensaje, ruta_ar_activada: retentionIntent !== "SAFE_EXIT" },
      explainability: {
        ruleVersion: this.ruleVersion,
        factors: [
          { name: "proximity", value: dist, weight: 0.4, rationale: "Distancia al borde del Nodo" },
          { name: "stay", value: t.stayTimeHours, weight: 0.25, rationale: "Horas en territorio" },
          { name: "inactivity", value: inactivity, weight: 0.2, rationale: "Minutos sin interacción" },
          { name: "flight", value: speed, weight: 0.15, rationale: "Velocidad m/s (EWMA α=" + this.movement.getAlpha() + ")" },
        ],
        notes: [
          `pattern=${pattern}`,
          `risk=${Math.round(risk)}`,
          `total=${score.total}`,
        ],
      },
      decidedAt: new Date(now).toISOString(),
    };

    this.lastDecisionAt.set(t.id, now);
    decisionStore.save(decision);
    return decision;
  }
}
