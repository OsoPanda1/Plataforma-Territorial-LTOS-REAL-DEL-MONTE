import { RDM_GASTRO, RDM_HISTORY, RDM_POIS } from "@/data/rdmContent";

export type RealitoLocalMessage = { role: "user" | "assistant"; content: string };

const normalize = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

const formatPoi = (poi: (typeof RDM_POIS)[number]) =>
  `- **${poi.name}** (${poi.category}) · ${poi.short} Coordenadas: ${poi.lat.toFixed(4)}, ${poi.lng.toFixed(4)}.`;

const searchPois = (question: string) => {
  const q = normalize(question);
  return RDM_POIS.map((poi) => {
    const haystack = normalize(`${poi.name} ${poi.category} ${poi.short} ${poi.story} ${poi.tags?.join(" ")}`);
    const score = q.split(/\s+/).filter((token) => token.length > 3 && haystack.includes(token)).length;
    return { poi, score };
  })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 4)
    .map(({ poi }) => poi);
};

export const buildLocalRealitoResponse = (messages: RealitoLocalMessage[]) => {
  const question = messages.at(-1)?.content ?? "";
  const q = normalize(question);
  const matches = searchPois(question);

  if (/negocio|comercio|registr|tienda|merchant/.test(q)) {
    return `Puedo ayudarte a activar tu negocio hoy.\n\n1. Entra a **/auth?mode=signup&type=merchant&next=/negocios**.\n2. Crea cuenta como **Comercio**.\n3. Completa el onboarding de 3 pasos.\n4. El sistema guarda el negocio en Supabase y abre checkout Stripe; si Stripe no está configurado, genera folio local seguro.\n\nTambién te doy puntos de gamificación por cuenta creada y negocio validado.`;
  }

  if (/pago|donar|donativo|stripe|checkout|tarjeta/.test(q)) {
    return `El flujo de pagos ya usa **Stripe Checkout** vía Supabase Edge Function.\n\n- Donativos: ve a **/donar** y elige monto.\n- Comercios: el plan seleccionado dispara checkout desde **/negocios**.\n- Si falta STRIPE_SECRET_KEY o la Edge Function no responde, se genera un checkout offline auditado para no perder la operación.`;
  }

  if (/paste|comer|gastronom|cafe|restaurante/.test(q)) {
    return `Para comer en Real del Monte te recomiendo iniciar por:\n\n${RDM_GASTRO.map(formatPoi).join("\n")}\n\nTip REALITO: abre **/mapa**, filtra Gastronomía y combínalo con Plaza Principal para caminar sin perder contexto histórico.`;
  }

  if (/ruta|recorrido|historia|mina|panteon|patrimonio/.test(q)) {
    return `Ruta histórica sugerida de medio día:\n\n${RDM_HISTORY.slice(0, 5).map(formatPoi).join("\n")}\n\nSecuencia operativa: Plaza Principal → Parroquia → Mina de Acosta → Panteón Inglés → Museo del Paste.`;
  }

  if (/mapa|ubicacion|coordenada|geo|llegar/.test(q)) {
    return `El mapa vivo está en **/mapa** y ahora usa coordenadas operativas auditadas alrededor del centro de Mineral del Monte.\n\nPuntos que más coinciden con tu pregunta:\n${(matches.length ? matches : RDM_POIS.slice(0, 4)).map(formatPoi).join("\n")}`;
  }

  if (matches.length) {
    return `Encontré estos nodos territoriales relacionados:\n\n${matches.map(formatPoi).join("\n")}\n\nPuedes abrir **/mapa** para verlos o preguntarme por una ruta específica.`;
  }

  return `Estoy en modo local de continuidad, así que puedo responder aunque la IA remota no esté disponible.\n\nPuedo ayudarte con:\n- rutas históricas y geolocalización en **/mapa**;\n- registro de usuario o comercio en **/auth** y **/negocios**;\n- donativos y checkout en **/donar**;\n- gamificación territorial por explorar, registrar o pagar.\n\nPregúntame por “ruta histórica”, “registrar mi negocio”, “pago Stripe” o “dónde comer paste”.`;
};
