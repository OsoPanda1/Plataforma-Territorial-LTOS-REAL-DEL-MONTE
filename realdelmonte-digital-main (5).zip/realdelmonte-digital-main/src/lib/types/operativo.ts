export type ModuleStatus = "design" | "in-progress" | "done";

export interface ModuleState {
  id: string;
  name: string;
  domain: string;
  status: ModuleStatus;
  completion: number;
  spec?: string;
  route?: string;
  notes?: string;
}

export interface DomainSummary {
  domain: string;
  total: number;
  done: number;
  inProgress: number;
  design: number;
  completion: number;
}
