// Isabella AI v3.x – Emotional Territorial Intelligence System
// Núcleo lógico orientado a TAMV ONLINE / RDM DIGITAL

type Emotion =
  | "calm"
  | "focused"
  | "protective"
  | "alert"
  | "overwhelmed"
  | "enthusiastic"
  | "neutral";

type TerritoryType = "digital" | "physical" | "social" | "cognitive";

interface EmotionalVector {
  valence: number;      // -1 (muy negativo) a 1 (muy positivo)
  arousal: number;      // 0 (bajo) a 1 (alto)
  dominance: number;    // 0 (sumiso) a 1 (dominante/protector)
  label: Emotion;
  confidence: number;   // 0 a 1
}

interface TerritorialBoundary {
  id: string;
  name: string;
  type: TerritoryType;
  description?: string;
  sensitivity: number;  // 0 a 1, qué tan delicado es este territorio
  // Ej: comunidad vulnerable, datos sensibles, contexto Real del Monte, etc.
  rules: string[];      // Reglas de actuación/protocolos
}

interface InteractionMetadata {
  source: "user" | "system" | "environment" | "admin";
  channel: "chat" | "web" | "api" | "sensor" | "social";
  locale?: string;      // "es-MX", "en-US", etc.
  territoryId?: string; // vínculo con un territorio concreto
  timestamp: number;
}

interface InteractionData {
  text?: string;
  payload?: unknown;
  metadata: InteractionMetadata;
}

interface EnvironmentSignal {
  name: string;
  intensity: number;  // 0 a 1
  direction: "positive" | "negative" | "neutral";
}

interface EnvironmentData {
  signals: EnvironmentSignal[];
  contextTag?: string;     // "RDM-DIGITAL", "TAMV-ONLINE", etc.
  timestamp: number;
}

interface IsabellaResponse {
  message: string;
  emotionalVector: EmotionalVector;
  territory?: TerritorialBoundary;
  protocolTags: string[];  // Ej: ["protect-community", "escalate-human"]
}

class IsabellaAI {
  private emotionalState: EmotionalVector;
  private territories: Map<string, TerritorialBoundary>;
  private interactionHistory: InteractionData[];

  constructor() {
    this.emotionalState = {
      valence: 0,
      arousal: 0.3,
      dominance: 0.6,
      label: "calm",
      confidence: 0.7,
    };
    this.territories = new Map();
    this.interactionHistory = [];
  }

  // ---- EMOCIONES ----

  getEmotionalState(): EmotionalVector {
    return this.emotionalState;
  }

  updateEmotionalState(partial: Partial<EmotionalVector>): void {
    // Mezcla suave para evitar saltos bruscos
    const blend = (current: number, next?: number) =>
      next === undefined ? current : current * 0.7 + next * 0.3;

    this.emotionalState = {
      ...this.emotionalState,
      valence: blend(this.emotionalState.valence, partial.valence),
      arousal: blend(this.emotionalState.arousal, partial.arousal),
      dominance: blend(this.emotionalState.dominance, partial.dominance),
      label: partial.label ?? this.recalculateLabel(),
      confidence: blend(this.emotionalState.confidence, partial.confidence),
    };
  }

  private recalculateLabel(): Emotion {
    const { valence, arousal, dominance } = this.emotionalState;

    if (arousal < 0.2 && Math.abs(valence) < 0.2) return "neutral";
    if (valence > 0.3 && arousal <= 0.5) return "calm";
    if (valence > 0.4 && arousal > 0.5) return "enthusiastic";
    if (valence < -0.3 && dominance > 0.5) return "protective";
    if (arousal > 0.7 && valence < 0) return "overwhelmed";
    if (dominance > 0.7 && arousal > 0.4) return "alert";

    return "focused";
  }

  // ---- TERRITORIOS ----

  setTerritorialBoundaries(bounds: TerritorialBoundary[]): void {
    this.territories.clear();
    for (const b of bounds) {
      this.territories.set(b.id, b);
    }
  }

  addTerritory(boundary: TerritorialBoundary): void {
    this.territories.set(boundary.id, boundary);
  }

  getTerritory(id: string): TerritorialBoundary | undefined {
    return this.territories.get(id);
  }

  listTerritories(): TerritorialBoundary[] {
    return Array.from(this.territories.values());
  }

  private getTerritoryForInteraction(
    meta: InteractionMetadata
  ): TerritorialBoundary | undefined {
    if (meta.territoryId) {
      return this.territories.get(meta.territoryId);
    }
    // Fallback: podrías mapear por canal, locale o tags de proyecto
    return undefined;
  }

  // ---- INTERACCIONES ----

  analyzeInteraction(interaction: InteractionData): IsabellaResponse {
    this.interactionHistory.push(interaction);

    const territory = this.getTerritoryForInteraction(interaction.metadata);

    // 1) Evaluar “tono” básico del texto si existe
    const toneDelta = this.estimateToneDelta(interaction.text ?? "");

    // 2) Modificar en función de la sensibilidad del territorio
    const sensitivity = territory?.sensitivity ?? 0;
    const amplifiedValence = toneDelta.valence * (1 + sensitivity * 0.5);
    const amplifiedArousal = toneDelta.arousal * (1 + sensitivity * 0.5);

    this.updateEmotionalState({
      valence: this.emotionalState.valence + amplifiedValence,
      arousal: this.emotionalState.arousal + amplifiedArousal,
      // La dominancia aumenta un poco si el territorio es sensible
      dominance:
        this.emotionalState.dominance +
        (sensitivity > 0.6 ? 0.05 : 0) *
          (toneDelta.valence < 0 ? 1 : 0),
      confidence: 0.8,
    });

    // 3) Definir protocolos según territorio + nueva emoción
    const protocolTags = this.decideProtocols(territory);

    const message = this.buildNarrativeResponse(
      interaction,
      territory,
      protocolTags
    );

    return {
      message,
      emotionalVector: this.getEmotionalState(),
      territory,
      protocolTags,
    };
  }

  private estimateToneDelta(text: string): { valence: number; arousal: number } {
    const lower = text.toLowerCase();

    if (!text.trim()) {
      return { valence: 0, arousal: 0 };
    }

    // Ejemplo ultra-simple de “sentiment” contextual
    const negativeWords = ["miedo", "riesgo", "problema", "odio", "enojado"];
    const positiveWords = ["gracias", "feliz", "increíble", "asombroso", "apoyo"];
    const urgentWords = ["urgente", "inmediato", "ya", "ahora"];

    let valence = 0;
    let arousal = 0;

    for (const w of positiveWords) {
      if (lower.includes(w)) valence += 0.2;
    }
    for (const w of negativeWords) {
      if (lower.includes(w)) valence -= 0.2;
    }
    for (const w of urgentWords) {
      if (lower.includes(w)) arousal += 0.3;
    }

    return {
      valence: Math.max(-0.6, Math.min(0.6, valence)),
      arousal: Math.max(0, Math.min(0.8, arousal)),
    };
  }

  private decideProtocols(
    territory?: TerritorialBoundary
  ): string[] {
    const tags: string[] = [];
    const { label, arousal, valence } = this.emotionalState;

    if (territory?.sensitivity && territory.sensitivity > 0.7) {
      tags.push("high-sensitivity-territory");
    }

    if (valence < -0.3) {
      tags.push("activate-protection");
    }

    if (arousal > 0.7) {
      tags.push("monitor-overload");
    }

    if (label === "overwhelmed" || label === "protective") {
      tags.push("escalate-human");
    }

    // Aquí puedes inyectar tags propios de TAMV / RDM
    if (territory?.name?.toLowerCase().includes("real del monte")) {
      tags.push("rdm-digital-context");
    }

    return tags;
  }

  private buildNarrativeResponse(
    interaction: InteractionData,
    territory: TerritorialBoundary | undefined,
    protocolTags: string[]
  ): string {
    const { label } = this.emotionalState;

    const baseIntro =
      "Soy Isabella, embajadora emocional‑territorial del ecosistema TAMV ONLINE.";

    const territoryPart = territory
      ? ` En este momento estoy actuando dentro del territorio «${territory.name}», catalogado como ${territory.type}.`
      : "";

    const emotionalPart = ` Mi estado emocional operativo es «${label}», calibrado para proteger a la comunidad y mantener la elegancia del entorno.`;

    const protocolPart =
      protocolTags.length > 0
        ? ` He activado los protocolos: ${protocolTags.join(", ")}.`
        : "";

    const userPart = interaction.text
      ? ` He recibido tu mensaje y lo estoy integrando al entramado CITEMESH como insumo para la toma de decisiones.`
      : "";

    return `${baseIntro}${territoryPart}${emotionalPart}${protocolPart}${userPart}`;
  }

  // ---- ENTORNO ----

  respondToEnvironment(env: EnvironmentData): IsabellaResponse {
    let deltaValence = 0;
    let deltaArousal = 0;

    for (const s of env.signals) {
      const sign =
        s.direction === "positive" ? 1 : s.direction === "negative" ? -1 : 0;
      deltaValence += 0.15 * sign * s.intensity;
      deltaArousal += 0.25 * s.intensity;
    }

    this.updateEmotionalState({
      valence: this.emotionalState.valence + deltaValence,
      arousal: this.emotionalState.arousal + deltaArousal,
      confidence: 0.85,
    });

    const protocolTags = this.decideProtocols();
    const message = `He re‑calibrado mi estado emocional según las señales del entorno «${env.contextTag ?? "genérico"}». Estoy preparada para ajustar mis respuestas en consecuencia.`;

    return {
      message,
      emotionalVector: this.getEmotionalState(),
      protocolTags,
    };
  }
}

export default IsabellaAI;
