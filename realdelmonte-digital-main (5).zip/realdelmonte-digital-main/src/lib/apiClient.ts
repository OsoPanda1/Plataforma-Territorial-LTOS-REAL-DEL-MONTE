import { recordAuditEvent } from "@/services/audit";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";

export class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export async function apiGet<T>(
  path: string,
  params?: Record<string, string>,
): Promise<T> {
  const url = new URL(`${API_BASE_URL}${path}`, window.location.origin);
  if (params) {
    Object.entries(params).forEach(([key, value]) =>
      url.searchParams.append(key, value),
    );
  }

  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new ApiError(
      response.status,
      `Error GET ${path}: ${response.statusText}`,
    );
  }

  return response.json() as Promise<T>;
}

export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    recordAuditEvent({
      type: "api.post.failed",
      severity: response.status >= 500 ? "critical" : "warning",
      source: "apiClient",
      route: path,
      metadata: { status: response.status, statusText: response.statusText },
    });
    throw new ApiError(
      response.status,
      `Error POST ${path}: ${response.statusText}`,
    );
  }

  return response.json() as Promise<T>;
}
