import { useCallback, useEffect, useRef, useState } from "react";
import playlistData from "@/data/playlist.json";

export type Track = (typeof playlistData)[number];

interface UseMusicPlayerOptions {
  autoplay?: boolean;
}

export function useMusicPlayer({ autoplay = false }: UseMusicPlayerOptions = {}) {
  const [tracks] = useState<Track[]>(playlistData);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // 0–1
  const [volume, setVolume] = useState(0.8);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const rafRef = useRef<number | null>(null);

  const currentTrack = tracks[currentIndex];

  const ensureAudio = useCallback(() => {
    if (!audioRef.current) {
      const audio = new Audio(currentTrack.audio);
      audio.preload = "auto";
      audioRef.current = audio;
    } else if (audioRef.current.src !== window.location.origin + currentTrack.audio) {
      audioRef.current.src = currentTrack.audio;
      audioRef.current.load();
    }
    audioRef.current.volume = volume;
  }, [currentTrack.audio, volume]);

  const cancelRAF = () => {
    if (rafRef.current != null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  };

  const updateProgress = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.duration > 0) {
      setProgress(audio.currentTime / audio.duration);
    }
    if (!audio.paused) {
      rafRef.current = requestAnimationFrame(updateProgress);
    }
  }, []);

  const play = useCallback(async () => {
    ensureAudio();
    if (!audioRef.current) return;

    try {
      await audioRef.current.play();
      setIsPlaying(true);
      cancelRAF();
      rafRef.current = requestAnimationFrame(updateProgress);
    } catch {
      setIsPlaying(false);
    }
  }, [ensureAudio, updateProgress]);

  const pause = useCallback(() => {
    if (!audioRef.current) return;
    audioRef.current.pause();
    setIsPlaying(false);
    cancelRAF();
  }, []);

  const togglePlay = useCallback(() => {
    if (isPlaying) pause();
    else play();
  }, [isPlaying, pause, play]);

  const seek = useCallback((ratio: number) => {
    if (!audioRef.current || !audioRef.current.duration) return;
    const next = Math.min(Math.max(ratio, 0), 1);
    audioRef.current.currentTime = audioRef.current.duration * next;
    setProgress(next);
  }, []);

  const setPlayerVolume = useCallback((v: number) => {
    const next = Math.min(Math.max(v, 0), 1);
    setVolume(next);
    if (audioRef.current) {
      audioRef.current.volume = next;
    }
  }, []);

  const next = useCallback(() => {
    pause();
    setProgress(0);
    setCurrentIndex((prev) => (prev + 1) % tracks.length);
  }, [pause, tracks.length]);

  const previous = useCallback(() => {
    pause();
    setProgress(0);
    setCurrentIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
  }, [pause, tracks.length]);

  // Cambiar de track cuando cambia currentIndex
  useEffect(() => {
    ensureAudio();
    if (isPlaying) {
      play();
    } else {
      setProgress(0);
    }
  }, [currentIndex, ensureAudio, isPlaying, play]);

  // Autoplay inicial opcional
  useEffect(() => {
    if (!autoplay) return;
    play();
  }, [autoplay, play]);

  // Limpieza global
  useEffect(() => {
    return () => {
      cancelRAF();
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  return {
    tracks,
    currentTrack,
    currentIndex,
    isPlaying,
    progress,
    volume,
    play,
    pause,
    togglePlay,
    seek,
    setVolume: setPlayerVolume,
    next,
    previous,
  };
}
