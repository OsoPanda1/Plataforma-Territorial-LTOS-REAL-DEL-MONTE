import { supabase } from "@/integrations/supabase/client";
import { recordAuditEvent } from "@/services/audit";
import { awardGamificationEvent } from "@/services/gamification";

export type CheckoutLineItem = {
  name: string;
  amount: number;
  quantity?: number;
  description?: string;
};

export type CheckoutRequest = {
  items: CheckoutLineItem[];
  metadata?: Record<string, string>;
  successPath?: string;
  cancelPath?: string;
  userId?: string;
};

export type CheckoutResult = {
  id: string;
  url: string | null;
  mode: "stripe" | "offline";
  message: string;
};

const publicSupabaseKey =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ?? import.meta.env.VITE_SUPABASE_ANON_KEY ?? "";

const checkoutEndpoint = () => {
  const baseUrl = import.meta.env.VITE_SUPABASE_URL;
  return baseUrl ? `${baseUrl.replace(/\/$/, "")}/functions/v1/stripe-checkout` : null;
};

const buildAbsoluteUrl = (path: string) => {
  const safePath = path.startsWith("/") ? path : `/${path}`;
  return `${window.location.origin}${safePath}`;
};

const offlineCheckout = async (request: CheckoutRequest, reason: string): Promise<CheckoutResult> => {
  const id = `offline_${Date.now()}`;
  const total = request.items.reduce((sum, item) => sum + item.amount * (item.quantity ?? 1), 0);

  recordAuditEvent({
    type: "payment.offline_checkout",
    severity: "warning",
    source: "frontend.payments",
    actorId: request.userId,
    metadata: { reason, total, checkoutId: id, items: request.items, ...request.metadata },
  });
  await awardGamificationEvent("donation_started", { total, offline: true }, request.userId ?? "local");

  return {
    id,
    url: null,
    mode: "offline",
    message: "Checkout local generado. Stripe se activará automáticamente cuando la Edge Function y STRIPE_SECRET_KEY estén disponibles.",
  };
};

export const createCheckoutSession = async (request: CheckoutRequest): Promise<CheckoutResult> => {
  const endpoint = checkoutEndpoint();
  if (!endpoint) return offlineCheckout(request, "missing_supabase_url");

  const {
    data: { session },
  } = await supabase.auth.getSession();

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: publicSupabaseKey,
        Authorization: `Bearer ${session?.access_token ?? publicSupabaseKey}`,
      },
      body: JSON.stringify({
        items: request.items.map((item) => ({ ...item, quantity: item.quantity ?? 1 })),
        metadata: request.metadata,
        success_url: buildAbsoluteUrl(request.successPath ?? "/donar?status=success"),
        cancel_url: buildAbsoluteUrl(request.cancelPath ?? "/donar?status=cancel"),
      }),
    });

    if (!response.ok) throw new Error(`checkout_${response.status}`);
    const payload = (await response.json()) as { id?: string; url?: string };
    if (!payload.id) throw new Error("checkout_missing_id");

    recordAuditEvent({
      type: "payment.checkout_created",
      severity: "info",
      source: "frontend.payments",
      actorId: request.userId,
      metadata: { mode: "stripe", checkoutId: payload.id, items: request.items, ...request.metadata },
    });

    return {
      id: payload.id,
      url: payload.url ?? null,
      mode: "stripe",
      message: "Checkout Stripe listo.",
    };
  } catch (error) {
    return offlineCheckout(request, error instanceof Error ? error.message : "checkout_failed");
  }
};
