import { recordAuditEvent } from "@/services/audit";

export type GamificationAction =
  | "account_created"
  | "business_registered"
  | "realito_question"
  | "route_viewed"
  | "poi_explored"
  | "donation_started"
  | "payment_completed";

export type GamificationEvent = {
  id: string;
  action: GamificationAction;
  points: number;
  createdAt: string;
  metadata?: Record<string, unknown>;
};

export type GamificationProfile = {
  userId: string;
  points: number;
  level: number;
  title: string;
  badges: string[];
  events: GamificationEvent[];
  nextLevelPoints: number;
};

const ACTION_POINTS: Record<GamificationAction, number> = {
  account_created: 100,
  business_registered: 350,
  realito_question: 10,
  route_viewed: 25,
  poi_explored: 20,
  donation_started: 50,
  payment_completed: 200,
};

const LEVELS = [0, 100, 300, 700, 1200, 2000, 3200];
const TITLES = ["Visitante", "Explorador", "Guardia del Real", "Cronista", "Nodo Local", "Embajador", "Soberano"];

const keyFor = (userId = "local") => `rdm-gamification:${userId}`;

const safeParse = (value: string | null): GamificationEvent[] => {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const resolveLevel = (points: number) => {
  let level = 1;
  LEVELS.forEach((threshold, index) => {
    if (points >= threshold) level = index + 1;
  });
  return Math.min(level, TITLES.length);
};

const resolveBadges = (events: GamificationEvent[], points: number) => {
  const actions = new Set(events.map((event) => event.action));
  return [
    actions.has("account_created") && "Cuenta Fundadora",
    actions.has("business_registered") && "Comercio Validado",
    actions.has("realito_question") && "Conversador REALITO",
    actions.has("poi_explored") && "Explorador Territorial",
    actions.has("donation_started") && "Mecenas del Patrimonio",
    actions.has("payment_completed") && "Pago Verificado",
    points >= 700 && "Guardián de la Sierra",
  ].filter(Boolean) as string[];
};

export const getGamificationProfile = (userId = "local"): GamificationProfile => {
  const events = safeParse(typeof localStorage === "undefined" ? null : localStorage.getItem(keyFor(userId)));
  const points = events.reduce((total, event) => total + event.points, 0);
  const level = resolveLevel(points);
  const nextLevelPoints = LEVELS[level] ?? LEVELS[LEVELS.length - 1];

  return {
    userId,
    points,
    level,
    title: TITLES[level - 1] ?? TITLES[0],
    badges: resolveBadges(events, points),
    events,
    nextLevelPoints,
  };
};

export const awardGamificationEvent = async (
  action: GamificationAction,
  metadata: Record<string, unknown> = {},
  userId = "local",
) => {
  const event: GamificationEvent = {
    id: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    action,
    points: ACTION_POINTS[action],
    createdAt: new Date().toISOString(),
    metadata,
  };

  if (typeof localStorage !== "undefined") {
    const current = safeParse(localStorage.getItem(keyFor(userId)));
    localStorage.setItem(keyFor(userId), JSON.stringify([event, ...current].slice(0, 200)));
  }

  recordAuditEvent({
    type: "gamification.event",
    severity: "info",
    source: "frontend.gamification",
    actorId: userId,
    metadata: { action, points: event.points, ...metadata },
  });

  return getGamificationProfile(userId);
};
