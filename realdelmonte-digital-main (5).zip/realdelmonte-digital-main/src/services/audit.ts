export type AuditSeverity = "info" | "warning" | "critical";

export interface AuditEvent {
  id: string;
  type: string;
  severity: AuditSeverity;
  source: string;
  actorId?: string;
  route?: string;
  metadata?: Record<string, unknown>;
  createdAt: string;
}

const STORAGE_KEY = "rdm:audit-buffer";
const MAX_BUFFERED_EVENTS = 100;

const createId = () => {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto)
    return crypto.randomUUID();
  return `audit-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
};

const readBuffer = (): AuditEvent[] => {
  if (typeof localStorage === "undefined") return [];
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as AuditEvent[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const writeBuffer = (events: AuditEvent[]) => {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(events.slice(-MAX_BUFFERED_EVENTS)),
  );
};

export const recordAuditEvent = (
  event: Omit<AuditEvent, "id" | "createdAt">,
) => {
  const entry: AuditEvent = {
    id: createId(),
    createdAt: new Date().toISOString(),
    ...event,
  };

  writeBuffer([...readBuffer(), entry]);
  return entry;
};

export const listAuditEvents = () => readBuffer().slice().reverse();

export const clearAuditEvents = () => {
  if (typeof localStorage !== "undefined") localStorage.removeItem(STORAGE_KEY);
};
