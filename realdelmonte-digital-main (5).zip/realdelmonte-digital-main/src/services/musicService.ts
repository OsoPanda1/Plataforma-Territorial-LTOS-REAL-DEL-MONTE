import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

function getSupabase() {
  return supabase;
}

export type MusicTrackRow = Database["public"]["Tables"]["music_tracks"]["Row"];
export type MusicPlayRow = Database["public"]["Tables"]["music_plays"]["Row"];
export type MusicDonationRow = Database["public"]["Tables"]["music_donations"]["Row"];

export interface RegisterPlayInput {
  track_id: string;
  played_at?: string; // ISO string
}

export interface RegisterDonationInput {
  track_id: string;
  amount: number;
  currency?: string; // opcional si quieres varias monedas
  provider?: "stripe" | "mercadopago" | "paypal";
  provider_session_id?: string;
}

/**
 * Obtiene todos los tracks activos para construir playlist desde Supabase.
 * Fase 1: puedes seguir usando playlist.json; esto es para cuando lo lleves a BD.
 */
export async function getAllTracks() {
  const client = getSupabase();
  const { data, error } = await client
    .from("music_tracks")
    .select("*")
    .order("created_at", { ascending: true });

  if (error) {
    console.error("[musicService] getAllTracks error", error);
    throw error;
  }
  return data as MusicTrackRow[];
}

/**
 * Registra un play simple (sin tiempo escuchado).
 * Lo puedes llamar en useMusicPlayer.play() o cuando el usuario escuche > X segundos.
 */
export async function registerPlay(input: RegisterPlayInput) {
  const client = getSupabase();
  const { track_id, played_at } = input;

  const { data, error } = await client
    .from("music_plays")
    .insert({
      track_id,
      played_at: played_at ?? new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    console.error("[musicService] registerPlay error", error);
    // no lanzamos error duro para no romper UX; solo registramos
    return null;
  }
  return data as MusicPlayRow;
}

/**
 * Registra una donación asociada a un track.
 * Llamar después de que Stripe/MercadoPago/PayPal confirme el pago.
 */
export async function registerDonation(input: RegisterDonationInput) {
  const client = getSupabase();
  const {
    track_id,
    amount,
    currency = "MXN",
    provider,
    provider_session_id,
  } = input;

  const { data, error } = await client
    .from("music_donations")
    .insert({
      track_id,
      amount,
      currency,
      provider,
      provider_session_id,
    })
    .select()
    .single();

  if (error) {
    console.error("[musicService] registerDonation error", error);
    throw error;
  }
  return data as MusicDonationRow;
}

/**
 * (Opcional) Estadísticas agregadas de un track para dashboards.
 */
export async function getTrackStats(trackId: string) {
  const client = getSupabase();

  const [{ data: playsCount, error: playsError }, { data: donationsAgg, error: donationsError }] =
    await Promise.all([
      client
        .from("music_plays")
        .select("id", { count: "exact", head: true })
        .eq("track_id", trackId),
      client
        .from("music_donations")
        .select("amount")
        .eq("track_id", trackId),
    ]);

  if (playsError) {
    console.error("[musicService] getTrackStats plays error", playsError);
  }
  if (donationsError) {
    console.error("[musicService] getTrackStats donations error", donationsError);
  }

  const totalPlays = playsCount?.length ?? (playsCount as unknown as number | null) ?? 0;
  const totalDonationsAmount = (donationsAgg ?? []).reduce(
    (sum, row) => sum + (row.amount ?? 0),
    0,
  );

  return {
    trackId,
    totalPlays,
    totalDonationsAmount,
  };
}
