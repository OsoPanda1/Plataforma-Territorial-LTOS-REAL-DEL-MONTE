import { recordAuditEvent } from "@/services/audit";

export type TelemetrySignalType =
  | "performance"
  | "territory"
  | "commerce"
  | "ai"
  | "security";

export interface TelemetrySignal {
  type: TelemetrySignalType;
  name: string;
  value: number;
  unit?: string;
  route?: string;
  tags?: string[];
  createdAt?: string;
}

const TELEMETRY_ENDPOINT = import.meta.env.VITE_TELEMETRY_ENDPOINT || "";

export const publishTelemetrySignal = (signal: TelemetrySignal) => {
  const payload: TelemetrySignal = {
    createdAt: new Date().toISOString(),
    ...signal,
  };

  recordAuditEvent({
    type: `telemetry.${signal.type}.${signal.name}`,
    severity: signal.type === "security" ? "warning" : "info",
    source: "frontend.telemetry",
    route: signal.route,
    metadata: { ...payload } as Record<string, unknown>,
  });

  if (!TELEMETRY_ENDPOINT) return payload;

  void fetch(TELEMETRY_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    keepalive: true,
  });

  return payload;
};

export const observeWebVitalsFallback = () => {
  if (typeof performance === "undefined") return [] as TelemetrySignal[];
  const navigation = performance.getEntriesByType("navigation")[0] as
    | PerformanceNavigationTiming
    | undefined;
  if (!navigation) return [] as TelemetrySignal[];

  return [
    publishTelemetrySignal({
      type: "performance",
      name: "dom_content_loaded",
      value: Math.round(navigation.domContentLoadedEventEnd),
      unit: "ms",
      route: window.location.pathname,
      tags: ["web-vitals-fallback"],
    }),
    publishTelemetrySignal({
      type: "performance",
      name: "load_event_end",
      value: Math.round(navigation.loadEventEnd),
      unit: "ms",
      route: window.location.pathname,
      tags: ["web-vitals-fallback"],
    }),
  ];
};
