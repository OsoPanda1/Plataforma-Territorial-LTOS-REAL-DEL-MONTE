import { recordAuditEvent } from "@/services/audit";

export interface AnalyticsEvent {
  name: string;
  route: string;
  properties?: Record<string, unknown>;
  createdAt?: string;
}

const ANALYTICS_ENDPOINT = import.meta.env.VITE_ANALYTICS_ENDPOINT || "";

export const trackAnalyticsEvent = (event: AnalyticsEvent) => {
  const payload: AnalyticsEvent = {
    createdAt: new Date().toISOString(),
    ...event,
  };

  recordAuditEvent({
    type: `analytics.${event.name}`,
    severity: "info",
    source: "frontend.analytics",
    route: event.route,
    metadata: event.properties,
  });

  if (!ANALYTICS_ENDPOINT || typeof navigator === "undefined") return payload;

  const body = JSON.stringify(payload);
  if ("sendBeacon" in navigator) {
    navigator.sendBeacon(
      ANALYTICS_ENDPOINT,
      new Blob([body], { type: "application/json" }),
    );
    return payload;
  }

  void fetch(ANALYTICS_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
    keepalive: true,
  });

  return payload;
};
