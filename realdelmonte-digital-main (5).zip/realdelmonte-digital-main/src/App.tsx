import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { lazy, Suspense, useState, useCallback } from "react";
import CinematicIntro from "@/components/CinematicIntro";
import RealitoFloatingChat from "@/components/RealitoFloatingChat";
import { RdmSystemStateProvider } from "@/context/RdmSystemStateContext";
import { MinerWhispersHUD } from "@/components/hud/MinerWhispersHUD";
import DedicationRibbon from "@/components/DedicationRibbon";

const Index = lazy(() => import("./pages/Index"));
const Auth = lazy(() => import("./pages/Auth"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Lugares = lazy(() => import("./pages/Lugares"));
const Directorio = lazy(() => import("./pages/Directorio"));
const Eventos = lazy(() => import("./pages/Eventos"));
const Comunidad = lazy(() => import("./pages/Comunidad"));
const Mapa = lazy(() => import("./pages/Mapa"));
const Historia = lazy(() => import("./pages/Historia"));
const Cultura = lazy(() => import("./pages/Cultura"));
const Relatos = lazy(() => import("./pages/Relatos"));
const Ecoturismo = lazy(() => import("./pages/Ecoturismo"));
const Gastronomia = lazy(() => import("./pages/Gastronomia"));
const Arte = lazy(() => import("./pages/Arte"));
const Rutas = lazy(() => import("./pages/Rutas"));
const Dichos = lazy(() => import("./pages/Dichos"));
const Apoya = lazy(() => import("./pages/Apoya"));
const Reglamento = lazy(() => import("./pages/Reglamento"));
const NegociosPortal = lazy(() => import("./pages/NegociosPortal"));
const Transporte = lazy(() => import("./pages/Transporte"));
const Catalogo = lazy(() => import("./pages/Catalogo"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Donar = lazy(() => import("./pages/Donar"));
const TamvHub = lazy(() => import("./pages/TamvHub"));
const Federacion = lazy(() => import("./pages/Federacion"));
const Fusion = lazy(() => import("./pages/Fusion"));
const Enciclopedia = lazy(() => import("./pages/Enciclopedia"));
const Corpus = lazy(() => import("./pages/Corpus"));
const Sovereign = lazy(() => import("./pages/Sovereign"));
const TAMVStatus = lazy(() => import("./pages/TAMVStatus"));
const TAMVApiExplorer = lazy(() => import("./pages/TAMVApiExplorer"));
const TAMVThesis = lazy(() => import("./pages/TAMVThesis"));
const Operativo = lazy(() => import("./pages/Operativo"));

// Dashboard sub-pages
const DashboardHome = lazy(() => import("./pages/dashboard/ControlCenter"));
const Telemetry = lazy(() => import("./pages/dashboard/Telemetry"));
const Community = lazy(() => import("./pages/dashboard/Community"));
const Isabella = lazy(() => import("./pages/dashboard/Isabella"));
const Economy = lazy(() => import("./pages/dashboard/Economy"));
const Profile = lazy(() => import("./pages/dashboard/Profile"));

const queryClient = new QueryClient();

const RouteFallback = () => (
  <div className="min-h-screen w-full animate-pulse bg-background" />
);

const App = () => {
  const [showIntro, setShowIntro] = useState(() => {
    if (window.location.pathname !== "/") return false;
    const seen = sessionStorage.getItem("rdm-intro-seen");
    return !seen;
  });

  const handleIntroComplete = useCallback(() => {
    sessionStorage.setItem("rdm-intro-seen", "1");
    setShowIntro(false);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <RdmSystemStateProvider>
          <Toaster />
          <Sonner />
          {showIntro && <CinematicIntro onComplete={handleIntroComplete} />}
          <MinerWhispersHUD />
          <RealitoFloatingChat />
          <DedicationRibbon variant="fixed" />
          <BrowserRouter>
            <Suspense fallback={<RouteFallback />}>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/auth" element={<Auth />} />
                <Route path="/lugares" element={<Lugares />} />
                <Route path="/directorio" element={<Directorio />} />
                <Route path="/eventos" element={<Eventos />} />
                <Route path="/comunidad" element={<Comunidad />} />
                <Route path="/mapa" element={<Mapa />} />
                <Route path="/historia" element={<Historia />} />
                <Route path="/cultura" element={<Cultura />} />
                <Route path="/relatos" element={<Relatos />} />
                <Route path="/ecoturismo" element={<Ecoturismo />} />
                <Route path="/gastronomia" element={<Gastronomia />} />
                <Route path="/arte" element={<Arte />} />
                <Route path="/rutas" element={<Rutas />} />
                <Route path="/dichos" element={<Dichos />} />
                <Route path="/apoya" element={<Apoya />} />
                <Route path="/reglamento" element={<Reglamento />} />
                <Route path="/negocios" element={<NegociosPortal />} />
                <Route path="/transporte" element={<Transporte />} />
                <Route path="/catalogo" element={<Catalogo />} />
                <Route path="/donar" element={<Donar />} />
                <Route path="/tamv" element={<TamvHub />} />
                <Route path="/tamv/status" element={<TAMVStatus />} />
                <Route path="/tamv/api" element={<TAMVApiExplorer />} />
                <Route path="/tamv/thesis" element={<TAMVThesis />} />
                <Route path="/operativo" element={<Operativo />} />
                <Route path="/federacion" element={<Federacion />} />
                <Route path="/fusion" element={<Fusion />} />
                <Route path="/enciclopedia" element={<Enciclopedia />} />
                <Route path="/corpus" element={<Corpus />} />
                <Route path="/sovereign" element={<Sovereign />} />
                <Route path="/admin" element={<Dashboard />}>
                  <Route index element={<DashboardHome />} />
                  <Route path="telemetry" element={<Telemetry />} />
                  <Route path="community" element={<Community />} />
                  <Route path="isabella" element={<Isabella />} />
                  <Route path="economy" element={<Economy />} />
                  <Route path="profile" element={<Profile />} />
                </Route>
                <Route path="/dashboard" element={<Dashboard />}>
                  <Route index element={<DashboardHome />} />
                  <Route path="telemetry" element={<Telemetry />} />
                  <Route path="community" element={<Community />} />
                  <Route path="isabella" element={<Isabella />} />
                  <Route path="economy" element={<Economy />} />
                  <Route path="profile" element={<Profile />} />
                </Route>
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </BrowserRouter>
        </RdmSystemStateProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
