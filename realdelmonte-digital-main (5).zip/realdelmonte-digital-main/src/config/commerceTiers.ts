export type RdmTierLevel = "BASIC" | "STANDARD" | "PLUS" | "PRO" | "SOVEREIGN";

export type RdmTier = {
  level: RdmTierLevel;
  price: number;
  label: string;
  description: string;
  highlights: string[];
  color: string;
  icon: string;
};

export const RDM_COMMERCE_TIERS: RdmTier[] = [
  {
    level: "BASIC",
    price: 100,
    label: "Senda",
    description: "Presencia esencial en el OS territorial.",
    highlights: ["Nombre y giro", "Horario básico", "1 imagen", "Ubicación en mapa 2D"],
    color: "border-muted-foreground/30",
    icon: "⛏️",
  },
  {
    level: "STANDARD",
    price: 200,
    label: "Veta",
    description: "Tu negocio entra en el radar recomendado de REALITO.",
    highlights: ["3 imágenes WebP", "Slogan personalizado", "Redes sociales", "Enlace web"],
    color: "border-accent/40",
    icon: "🪨",
  },
  {
    level: "PLUS",
    price: 300,
    label: "Malacate",
    description: "IA contextual y notificaciones a turistas cercanos.",
    highlights: ["Todo lo de Veta", "Isabella AI recomienda tu negocio", "Notificaciones push geolocalizadas"],
    color: "border-electric/50",
    icon: "⚙️",
  },
  {
    level: "PRO",
    price: 400,
    label: "Barreno",
    description: "Presencia destacada en el Gemelo Digital 3D.",
    highlights: ["Marker 3D brillante en Twin", "Mayor visibilidad en explorador", "Badge verificado"],
    color: "border-copper/50",
    icon: "💎",
  },
  {
    level: "SOVEREIGN",
    price: 500,
    label: "Soberano",
    description: "Datos, analytics y prioridad total. Nodo validado del ledger.",
    highlights: ["Estadísticas de visitas en tiempo real", "Priority Zero en Explorer", "Nodo en ledger soberano", "Acceso a City Intelligence"],
    color: "border-gold/60",
    icon: "👑",
  },
];

export const PROMO_LAUNCH = {
  cost: 200,
  durationMonths: 2,
  features: "ALL_PREMIUM" as const,
  label: "Promo Lanzamiento — 2 meses con todo incluido",
};
