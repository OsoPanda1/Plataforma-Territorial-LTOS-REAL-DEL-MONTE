import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal } from "@/components/VisualEffects";
import { motion } from "framer-motion";
import { Pickaxe, Ship, Crown, Flag } from "lucide-react";
import rdmMina from "@/assets/rdm-mina-interior.jpg";
import rdmCalleColonial from "@/assets/rdm-calle-colonial.jpg";
import rdmMalacate from "@/assets/rdm-malacate.jpg";

const timeline = [
  { year: "1528", title: "Primeros hallazgos mineros", desc: "Los españoles descubren vetas de plata en la sierra hidalguense.", icon: Pickaxe },
  { year: "1739", title: "Auge de la minería", desc: "Real del Monte se convierte en uno de los centros mineros más importantes de Nueva España.", icon: Crown },
  { year: "1824", title: "Llegada de los cornish", desc: "Mineros ingleses de Cornwall traen nueva tecnología, el paste y tradiciones que perduran.", icon: Ship },
  { year: "1862", title: "La primera huelga de América", desc: "Los mineros de Real del Monte protagonizan la primera huelga laboral del continente americano.", icon: Flag },
  { year: "2004", title: "Pueblo Mágico", desc: "Real del Monte recibe la designación oficial de Pueblo Mágico por la SECTUR.", icon: Crown },
  { year: "2026", title: "RDM Digital", desc: "Nace el primer Gemelo Digital soberano de un Pueblo Mágico en toda Latinoamérica.", icon: Flag },
];

const heroImages = [
  { src: rdmMina, alt: "Interior de la Mina de Acosta", caption: "Mina de Acosta — 460 años de historia minera" },
  { src: rdmCalleColonial, alt: "Calles coloniales de Real del Monte", caption: "Calles coloniales entre la neblina" },
  { src: rdmMalacate, alt: "Malacate minero al atardecer", caption: "El malacate — símbolo de la herencia minera" },
];

export default function Historia() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Hero gallery */}
        <section className="pt-24 pb-8 px-6">
          <div className="container max-w-6xl">
            <div className="grid md:grid-cols-3 gap-4">
              {heroImages.map((img, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.15 }}
                  className="rounded-2xl overflow-hidden border border-border group">
                  <div className="aspect-video overflow-hidden">
                    <img src={img.src} alt={img.alt} loading={i === 0 ? undefined : "lazy"} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  </div>
                  <div className="p-3 bg-card">
                    <p className="text-xs text-muted-foreground font-body">{img.caption}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="pb-24 px-6">
          <div className="container max-w-4xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">460 Años de Historia</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Desde las vetas de plata hasta el Gemelo Digital: la evolución de un pueblo que nunca dejó de reinventarse.
                </p>
              </div>
            </TextReveal>
            <div className="relative">
              <div className="absolute left-8 top-0 bottom-0 w-px bg-border" />
              <div className="space-y-12">
                {timeline.map((item, i) => (
                  <motion.div key={item.year} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="relative pl-20">
                    <div className="absolute left-4 top-1 w-8 h-8 rounded-full bg-card border-2 border-accent flex items-center justify-center">
                      <item.icon className="w-3.5 h-3.5 text-accent" />
                    </div>
                    <span className="text-xs font-bold text-gold font-body">{item.year}</span>
                    <h3 className="font-display text-xl font-semibold text-foreground mt-1">{item.title}</h3>
                    <p className="text-sm text-muted-foreground font-body mt-1">{item.desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
