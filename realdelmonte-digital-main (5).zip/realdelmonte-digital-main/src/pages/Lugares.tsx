import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem, GlowCard } from "@/components/VisualEffects";
import { MapPin, Star, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Place = {
  id: string;
  name: string;
  category: string;
  description: string | null;
  image_url: string | null;
  rating: number | null;
};

export default function Lugares() {
  const [places, setPlaces] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from("places").select("*").order("rating", { ascending: false }).then(({ data }) => {
      setPlaces((data as Place[]) || []);
      setLoading(false);
    });
  }, []);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Lugares Imperdibles</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Descubre los atractivos más emblemáticos de Real del Monte, Pueblo Mágico de Hidalgo.
                </p>
              </div>
            </TextReveal>
            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>
            ) : (
              <StaggerContainer className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {places.map((place) => (
                  <StaggerItem key={place.id}>
                    <GlowCard>
                      <div className="rounded-2xl border border-border bg-card overflow-hidden group">
                        <div className="aspect-[4/3] overflow-hidden">
                          <img src={place.image_url || "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=600"} alt={place.name} loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        </div>
                        <div className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-[10px] uppercase tracking-widest text-accent font-body">{place.category}</span>
                            {place.rating && <div className="flex items-center gap-1 text-gold text-xs"><Star className="w-3 h-3 fill-current" />{Number(place.rating).toFixed(1)}</div>}
                          </div>
                          <h3 className="font-display text-lg font-semibold text-foreground mb-1">{place.name}</h3>
                          <p className="text-xs text-muted-foreground font-body line-clamp-2">{place.description}</p>
                        </div>
                      </div>
                    </GlowCard>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
