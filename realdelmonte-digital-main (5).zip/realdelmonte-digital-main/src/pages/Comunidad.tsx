import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal } from "@/components/VisualEffects";
import { Heart, MessageCircle, Share2, Send, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import realitoSanitarios from "@/assets/realito-sanitarios.png";

type Post = {
  id: string;
  content: string;
  display_name: string;
  likes: number;
  comments_count: number;
  created_at: string;
  user_id: string;
};

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `hace ${mins} min`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `hace ${hours} h`;
  const days = Math.floor(hours / 24);
  return `hace ${days} día${days > 1 ? "s" : ""}`;
}

export default function Comunidad() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [newPost, setNewPost] = useState("");
  const [posting, setPosting] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user || null));
    supabase.from("posts").select("*").order("created_at", { ascending: false }).limit(50).then(({ data }) => {
      setPosts((data as Post[]) || []);
      setLoading(false);
    });
  }, []);

  const handlePost = async () => {
    if (!newPost.trim() || !user) return;
    setPosting(true);
    const displayName = user.user_metadata?.display_name || user.email?.split("@")[0] || "Anónimo";
    const { data, error } = await supabase.from("posts").insert({
      content: newPost.trim(),
      user_id: user.id,
      display_name: displayName,
    }).select().single();
    if (error) {
      toast.error("Error al publicar");
    } else if (data) {
      setPosts((prev) => [data as Post, ...prev]);
      setNewPost("");
      toast.success("¡Publicado!");
    }
    setPosting(false);
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-3xl">
            <TextReveal>
              <div className="text-center mb-12">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Muro de Recuerdos</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Experiencias compartidas por visitantes y habitantes de Real del Monte.
                </p>
              </div>
            </TextReveal>

            {/* REALITO community banner */}
            <div className="mb-8 rounded-2xl border border-border overflow-hidden">
              <img src={realitoSanitarios} alt="REALITO guía en la comunidad" loading="lazy" className="w-full h-36 md:h-48 object-cover" />
            </div>

            {/* Compose */}
            {user ? (
              <div className="p-4 rounded-2xl border border-border bg-card mb-8">
                <Input
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handlePost()}
                  placeholder="Comparte tu experiencia en Real del Monte..."
                  className="bg-secondary border-border text-foreground mb-3"
                />
                <div className="flex justify-end">
                  <Button onClick={handlePost} disabled={posting || !newPost.trim()} size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
                    {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Send className="w-4 h-4 mr-1" />Publicar</>}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center mb-8 p-4 rounded-xl border border-border bg-card">
                <p className="text-sm text-muted-foreground font-body">
                  <a href="/auth" className="text-accent hover:underline">Inicia sesión</a> para compartir tu experiencia.
                </p>
              </div>
            )}

            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>
            ) : posts.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground font-body">
                <p>Aún no hay publicaciones. ¡Sé el primero!</p>
              </div>
            ) : (
              <div className="space-y-6">
                {posts.map((post) => (
                  <div key={post.id} className="p-6 rounded-2xl border border-border bg-card">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                        <span className="text-sm font-display text-accent">{post.display_name[0]}</span>
                      </div>
                      <div>
                        <p className="text-sm font-body font-medium text-foreground">{post.display_name}</p>
                        <p className="text-xs text-muted-foreground">{timeAgo(post.created_at)}</p>
                      </div>
                    </div>
                    <p className="text-sm text-foreground/80 font-body mb-4">{post.content}</p>
                    <div className="flex items-center gap-6 text-xs text-muted-foreground font-body">
                      <button className="flex items-center gap-1 hover:text-accent transition-colors"><Heart className="w-3.5 h-3.5" />{post.likes}</button>
                      <button className="flex items-center gap-1 hover:text-accent transition-colors"><MessageCircle className="w-3.5 h-3.5" />{post.comments_count}</button>
                      <button className="flex items-center gap-1 hover:text-accent transition-colors"><Share2 className="w-3.5 h-3.5" />Compartir</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
