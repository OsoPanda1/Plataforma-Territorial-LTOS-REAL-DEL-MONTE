import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem, GlowCard } from "@/components/VisualEffects";
import { MapPin, Phone, Clock, Star, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import realitoPlaterias from "@/assets/realito-platerias.png";

type Business = {
  id: string;
  name: string;
  category: string;
  phone: string | null;
  hours: string | null;
  rating: number | null;
  address: string | null;
  description: string | null;
};

export default function Directorio() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("businesses").select("*").order("rating", { ascending: false }).then(({ data }) => {
      setBusinesses((data as Business[]) || []);
      setLoading(false);
    });
  }, []);

  const categories = [...new Set(businesses.map(b => b.category))];
  const filtered = filter ? businesses.filter(b => b.category === filter) : businesses;

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-12">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Directorio Local</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Negocios y servicios verificados como nodos del ecosistema RDM Digital.
                </p>
              </div>
            </TextReveal>

            {/* REALITO Banner */}
            <div className="mb-8 rounded-2xl border border-border overflow-hidden">
              <img src={realitoPlaterias} alt="REALITO en la platería" loading="lazy" className="w-full h-40 md:h-56 object-cover" />
              <div className="p-4 bg-card">
                <p className="text-sm text-muted-foreground font-body text-center">
                  Cada comercio es un <span className="text-gold font-semibold">nodo verificado</span> en el Tejido de Persistencia Cuántica del ecosistema RDM-TOS.
                </p>
              </div>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
              <button onClick={() => setFilter(null)}
                className={`text-xs px-3 py-1.5 rounded-full border font-body transition-colors ${!filter ? "bg-accent text-accent-foreground border-accent" : "border-border text-muted-foreground hover:text-foreground hover:border-accent/30"}`}>
                Todos
              </button>
              {categories.map(cat => (
                <button key={cat} onClick={() => setFilter(cat)}
                  className={`text-xs px-3 py-1.5 rounded-full border font-body transition-colors ${filter === cat ? "bg-accent text-accent-foreground border-accent" : "border-border text-muted-foreground hover:text-foreground hover:border-accent/30"}`}>
                  {cat}
                </button>
              ))}
            </div>

            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>
            ) : (
              <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map((biz) => (
                  <StaggerItem key={biz.id}>
                    <GlowCard>
                      <div className="p-6 rounded-2xl border border-border bg-card">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] uppercase tracking-widest text-accent font-body">{biz.category}</span>
                          {biz.rating && <div className="flex items-center gap-1 text-gold text-xs"><Star className="w-3 h-3 fill-current" />{Number(biz.rating).toFixed(1)}</div>}
                        </div>
                        <h3 className="font-display text-lg font-semibold text-foreground mb-1">{biz.name}</h3>
                        {biz.description && <p className="text-xs text-muted-foreground font-body mb-3">{biz.description}</p>}
                        <div className="space-y-2 text-sm text-muted-foreground font-body">
                          {biz.phone && <div className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-accent" />{biz.phone}</div>}
                          {biz.hours && <div className="flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-gold" />{biz.hours}</div>}
                          {biz.address && <div className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-terracotta" />{biz.address}</div>}
                        </div>
                      </div>
                    </GlowCard>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
