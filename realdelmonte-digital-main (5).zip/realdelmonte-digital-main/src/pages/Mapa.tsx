import { useEffect, useState, useRef, useMemo } from "react";
import Navbar from "@/components/Navbar";
import { PageTransition } from "@/components/VisualEffects";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Layers, Search, Star, X, Compass, Sparkles } from "lucide-react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { RDM_POIS, RDM_MAP_CENTER, CATEGORY_META, type RdmPoi, type RdmCategory } from "@/data/rdmContent";

const TILE_LAYERS = {
  Nocturno: {
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    attr: "© CARTO © OpenStreetMap",
  },
  Satélite: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attr: "© Esri",
  },
  Terreno: {
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    attr: "© OpenTopoMap",
  },
} as const;

type TileKey = keyof typeof TILE_LAYERS;

function buildIcon(category: RdmCategory, active = false) {
  const meta = CATEGORY_META[category];
  const size = active ? 44 : 34;
  return L.divIcon({
    className: "rdm-marker",
    html: `<div style="
      width:${size}px;height:${size}px;border-radius:50%;
      background:radial-gradient(circle at 30% 30%, ${meta.color}, ${meta.color}cc);
      border:2px solid white;
      box-shadow:0 0 0 4px ${meta.color}33, 0 6px 18px rgba(0,0,0,.55);
      display:flex;align-items:center;justify-content:center;
      font-size:${size * 0.5}px;
      transform:translateY(0);
      transition:transform .25s ease;
      ${active ? "animation: rdmPulse 1.6s ease-in-out infinite;" : ""}
    ">${meta.emoji}</div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
    popupAnchor: [0, -size],
  });
}

export default function Mapa() {
  const [filter, setFilter] = useState<RdmCategory | null>(null);
  const [query, setQuery] = useState("");
  const [tile, setTile] = useState<TileKey>("Nocturno");
  const [selected, setSelected] = useState<RdmPoi | null>(null);

  const mapRef = useRef<L.Map | null>(null);
  const tileRef = useRef<L.TileLayer | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());

  const filtered = useMemo(() => {
    return RDM_POIS.filter((p) => {
      if (filter && p.category !== filter) return false;
      if (query && !`${p.name} ${p.short} ${p.tags?.join(" ")}`.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
  }, [filter, query]);

  // Init map (once)
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [RDM_MAP_CENTER.lat, RDM_MAP_CENTER.lng],
      zoom: RDM_MAP_CENTER.zoom,
      zoomControl: false,
      attributionControl: false,
    });
    L.control.zoom({ position: "bottomright" }).addTo(map);
    L.control.attribution({ position: "bottomleft", prefix: false }).addTo(map);

    tileRef.current = L.tileLayer(TILE_LAYERS.Nocturno.url, {
      attribution: TILE_LAYERS.Nocturno.attr,
      maxZoom: 19,
    }).addTo(map);

    mapRef.current = map;
    const markers = markersRef.current;
    setTimeout(() => map.invalidateSize(), 250);

    return () => {
      map.remove();
      mapRef.current = null;
      markers.forEach((marker) => marker.remove());
      markers.clear();
    };
  }, []);

  // Switch tile layer
  useEffect(() => {
    if (!mapRef.current || !tileRef.current) return;
    mapRef.current.removeLayer(tileRef.current);
    tileRef.current = L.tileLayer(TILE_LAYERS[tile].url, {
      attribution: TILE_LAYERS[tile].attr,
      maxZoom: 19,
    }).addTo(mapRef.current);
  }, [tile]);

  // Sync markers
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    markersRef.current.forEach((m) => m.remove());
    markersRef.current.clear();

    filtered.forEach((poi) => {
      const marker = L.marker([poi.lat, poi.lng], { icon: buildIcon(poi.category) })
        .addTo(map)
        .on("click", () => {
          setSelected(poi);
          map.flyTo([poi.lat, poi.lng], 17, { duration: 0.9 });
        });
      markersRef.current.set(poi.id, marker);
    });

    if (filtered.length > 1) {
      const bounds = L.latLngBounds(filtered.map((poi) => [poi.lat, poi.lng]));
      map.fitBounds(bounds.pad(0.22), { maxZoom: 16, animate: true });
    } else if (filtered.length === 1) {
      map.flyTo([filtered[0].lat, filtered[0].lng], 16, { duration: 0.7 });
    }
  }, [filtered]);

  // Highlight selected
  useEffect(() => {
    markersRef.current.forEach((marker, id) => {
      const poi = RDM_POIS.find((p) => p.id === id);
      if (poi) marker.setIcon(buildIcon(poi.category, selected?.id === id));
    });
  }, [selected]);

  const handlePoiClick = (poi: RdmPoi) => {
    setSelected(poi);
    mapRef.current?.flyTo([poi.lat, poi.lng], 17, { duration: 1 });
  };

  const recenterMap = () => {
    setSelected(null);
    setFilter(null);
    setQuery("");
    mapRef.current?.flyTo([RDM_MAP_CENTER.lat, RDM_MAP_CENTER.lng], RDM_MAP_CENTER.zoom, { duration: 0.8 });
  };

  return (
    <PageTransition>
      <style>{`
        @keyframes rdmPulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.15); } }
        .leaflet-container { background: hsl(220 30% 5%) !important; font-family: inherit; }
        .leaflet-control-zoom a { background: hsl(220 25% 9%) !important; color: hsl(210 15% 93%) !important; border-color: hsl(220 18% 16%) !important; }
        .leaflet-control-attribution { background: hsl(220 25% 9% / .8) !important; color: hsl(215 12% 50%) !important; font-size: 10px !important; }
        .leaflet-control-attribution a { color: hsl(210 100% 65%) !important; }
      `}</style>
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />

        <div className="flex-1 flex flex-col lg:flex-row pt-16 relative">
          {/* SIDEBAR */}
          <aside className="lg:w-[380px] w-full lg:h-[calc(100vh-4rem)] flex flex-col border-r border-border bg-card/40 backdrop-blur-xl">
            <div className="p-5 border-b border-border">
              <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-gold font-body mb-2">
                <Compass className="w-3.5 h-3.5" /> Mapa Vivo · Real del Monte
              </div>
              <h1 className="font-display text-2xl text-foreground mb-1">Explora la sierra</h1>
              <p className="text-xs text-muted-foreground font-body">
                {filtered.length} de {RDM_POIS.length} puntos · datos curados
              </p>

              {/* Search */}
              <div className="relative mt-4">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Busca minas, leyendas, paste..."
                  className="w-full bg-background/60 border border-border rounded-lg pl-9 pr-3 py-2 text-sm font-body text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent transition-colors"
                />
              </div>

              {/* Tile switcher */}
              <div className="flex items-center gap-1 mt-3 p-1 bg-background/60 rounded-lg border border-border">
                {(Object.keys(TILE_LAYERS) as TileKey[]).map((k) => (
                  <button
                    key={k}
                    onClick={() => setTile(k)}
                    className={`flex-1 text-[10px] uppercase tracking-wider py-1.5 rounded-md font-body transition-all ${
                      tile === k ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {k}
                  </button>
                ))}
              </div>

              <button
                onClick={recenterMap}
                className="mt-3 w-full rounded-lg border border-gold/30 bg-gold/5 px-3 py-2 text-[11px] uppercase tracking-[0.2em] text-gold font-body hover:bg-gold/10 transition-colors"
              >
                Recentrar en coordenadas auditadas
              </button>

              {/* Category filters */}
              <div className="flex flex-wrap gap-1.5 mt-3">
                <button
                  onClick={() => setFilter(null)}
                  className={`text-[11px] px-2.5 py-1 rounded-full border font-body transition-all ${
                    !filter ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:border-accent/50"
                  }`}
                >
                  Todos
                </button>
                {(Object.keys(CATEGORY_META) as RdmCategory[]).map((cat) => {
                  const meta = CATEGORY_META[cat];
                  const active = filter === cat;
                  return (
                    <button
                      key={cat}
                      onClick={() => setFilter(active ? null : cat)}
                      className="text-[11px] px-2.5 py-1 rounded-full border font-body transition-all flex items-center gap-1"
                      style={{
                        background: active ? meta.color : "transparent",
                        borderColor: active ? meta.color : "hsl(var(--border))",
                        color: active ? "white" : "hsl(var(--muted-foreground))",
                      }}
                    >
                      <span>{meta.emoji}</span> {meta.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* POI list */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {filtered.map((poi) => {
                const meta = CATEGORY_META[poi.category];
                const active = selected?.id === poi.id;
                return (
                  <motion.button
                    key={poi.id}
                    onClick={() => handlePoiClick(poi)}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileHover={{ x: 4 }}
                    className={`w-full text-left rounded-xl border overflow-hidden transition-all group ${
                      active ? "border-accent shadow-[0_0_0_1px_hsl(var(--accent))]" : "border-border hover:border-accent/40"
                    } bg-card`}
                  >
                    <div className="flex gap-3 p-2.5">
                      <div className="relative w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                        <img src={poi.image} alt={poi.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        <div className="absolute top-1 left-1 text-[10px] px-1.5 py-0.5 rounded-full backdrop-blur-md font-body" style={{ background: `${meta.color}cc`, color: "white" }}>
                          {meta.emoji}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1">
                          <h3 className="font-display text-sm font-semibold text-foreground leading-tight truncate">{poi.name}</h3>
                          {poi.rating && (
                            <span className="flex items-center gap-0.5 text-[10px] text-gold flex-shrink-0">
                              <Star className="w-2.5 h-2.5 fill-current" />
                              {poi.rating}
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-gold/80 font-body uppercase tracking-wider mt-0.5">{poi.era}</p>
                        <p className="text-xs text-muted-foreground font-body mt-1 line-clamp-2">{poi.short}</p>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
              {filtered.length === 0 && (
                <div className="text-center text-xs text-muted-foreground font-body py-12">
                  Sin resultados. Prueba otra categoría.
                </div>
              )}
            </div>
          </aside>

          {/* MAP + DETAIL PANEL */}
          <div className="flex-1 relative h-[60vh] lg:h-[calc(100vh-4rem)]">
            <div ref={containerRef} className="absolute inset-0" />

            {/* Floating layer indicator */}
            <div className="absolute top-4 left-4 z-[400] flex items-center gap-2 px-3 py-1.5 rounded-full bg-card/80 backdrop-blur-md border border-border text-xs font-body text-muted-foreground">
              <Layers className="w-3.5 h-3.5 text-accent" /> {tile}
            </div>

            {/* Detail panel */}
            <AnimatePresence>
              {selected && (
                <motion.div
                  initial={{ opacity: 0, y: 30, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 30, scale: 0.96 }}
                  transition={{ type: "spring", damping: 22 }}
                  className="absolute bottom-4 left-4 right-4 lg:right-auto lg:w-[420px] z-[500] rounded-2xl overflow-hidden border border-border bg-card/95 backdrop-blur-xl shadow-2xl"
                >
                  <div className="relative aspect-[16/9]">
                    <img src={selected.image} alt={selected.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                    <button
                      onClick={() => setSelected(null)}
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-background/70 backdrop-blur flex items-center justify-center hover:bg-background transition-colors"
                    >
                      <X className="w-4 h-4 text-foreground" />
                    </button>
                    <div className="absolute bottom-3 left-3 flex items-center gap-2">
                      <span
                        className="text-[10px] px-2 py-1 rounded-full font-body uppercase tracking-wider text-white"
                        style={{ background: CATEGORY_META[selected.category].color }}
                      >
                        {CATEGORY_META[selected.category].emoji} {selected.category}
                      </span>
                      <span className="text-[10px] px-2 py-1 rounded-full bg-background/70 backdrop-blur text-muted-foreground font-body">
                        {selected.era}
                      </span>
                    </div>
                  </div>
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h2 className="font-display text-xl font-semibold text-foreground">{selected.name}</h2>
                      {selected.rating && (
                        <div className="flex items-center gap-1 text-gold text-sm font-body">
                          <Star className="w-4 h-4 fill-current" /> {selected.rating}
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground font-body leading-relaxed">{selected.story}</p>
                    {selected.tags && (
                      <div className="flex flex-wrap gap-1.5 mt-4">
                        {selected.tags.map((t) => (
                          <span key={t} className="text-[10px] px-2 py-0.5 rounded-full bg-accent/10 text-accent font-body border border-accent/20">
                            #{t}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center gap-2 mt-4 pt-4 border-t border-border text-xs text-muted-foreground font-body">
                      <MapPin className="w-3.5 h-3.5 text-accent" />
                      {selected.lat.toFixed(4)}, {selected.lng.toFixed(4)}
                      <Sparkles className="w-3.5 h-3.5 text-gold ml-auto" />
                      Curado por Isabella AI
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
