import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Crown,
  ExternalLink,
  HeartHandshake,
  Layers,
  Network,
  Quote,
  ScrollText,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { SEOMeta } from "@/components/SEOMeta";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TAMV_THESIS } from "@/data/tamvThesis";

const STATUS_STYLE: Record<string, string> = {
  operativa: "border-gold/40 bg-gold/10 text-gold",
  construccion: "border-accent/40 bg-accent/10 text-accent",
  planeada: "border-platinum/30 bg-platinum/5 text-platinum",
  ratified: "border-gold/40 bg-gold/10 text-gold",
  review: "border-accent/40 bg-accent/10 text-accent",
  draft: "border-platinum/30 bg-platinum/5 text-platinum",
};

export default function TAMVThesis() {
  const thesis = TAMV_THESIS;
  const [mainTitle, subtitle] = thesis.meta.title
    .split("—")
    .map((part) => part.trim());

  return (
    <PageTransition>
      <SEOMeta
        title="Tesis Soberana TAMV"
        description="Documento maestro público del Sistema Operativo Civilizatorio Triple-Federado anclado en Real del Monte."
      />
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pb-24 pt-32">
          <motion.section
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="mb-20 text-center"
          >
            <Badge
              variant="outline"
              className="mb-6 border-gold/40 bg-gold/5 px-4 py-2"
            >
              <Crown className="mr-2 h-4 w-4 text-gold" />
              <span className="font-body text-[10px] uppercase tracking-[0.3em] text-gold">
                TAMV Online Network™ · Tesis Soberana
              </span>
            </Badge>
            <h1 className="mb-6 font-display text-5xl font-light leading-tight md:text-7xl">
              <span className="text-gradient-gold">{mainTitle}</span>
              {subtitle && (
                <>
                  <br />
                  <span className="text-3xl text-foreground/85 md:text-5xl">
                    {subtitle}
                  </span>
                </>
              )}
            </h1>
            <p className="mx-auto max-w-3xl font-body text-base leading-relaxed text-muted-foreground md:text-lg">
              {thesis.meta.subtitle}
            </p>
            <p className="mt-8 font-body text-xs uppercase tracking-[0.3em] text-gold">
              {thesis.meta.method}
            </p>
          </motion.section>

          <section className="mb-20 grid gap-6 md:grid-cols-2">
            <motion.article
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="glass-card rounded-2xl p-7"
            >
              <div className="mb-4 flex items-center gap-3">
                <HeartHandshake className="h-5 w-5 text-gold" />
                <h2 className="font-display text-2xl">El Arquitecto</h2>
              </div>
              <p className="font-display text-xl leading-snug text-foreground/90">
                {thesis.biography.name}
              </p>
              <p className="mt-2 font-body text-xs uppercase tracking-[0.25em] text-muted-foreground">
                {thesis.biography.role}
              </p>
              <div className="mt-6 grid grid-cols-3 gap-3">
                <div className="text-center">
                  <p className="font-display text-3xl text-gold">
                    {thesis.biography.hours.toLocaleString()}
                  </p>
                  <p className="mt-1 font-body text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    Horas
                  </p>
                </div>
                <div className="text-center">
                  <p className="font-display text-3xl text-accent">
                    {thesis.biography.yearsAlone}
                  </p>
                  <p className="mt-1 font-body text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    Años
                  </p>
                </div>
                <div className="text-center">
                  <p className="font-display text-3xl text-platinum">
                    {thesis.federations.length}
                  </p>
                  <p className="mt-1 font-body text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    Federaciones
                  </p>
                </div>
              </div>
              <p className="mt-6 border-t border-border/50 pt-5 font-body text-xs italic text-muted-foreground">
                Dedicado a{" "}
                <span className="text-gold">{thesis.meta.dedicatedTo}</span>
              </p>
            </motion.article>

            <motion.article
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="glass-card rounded-2xl p-7"
            >
              <div className="mb-4 flex items-center gap-3">
                <ShieldCheck className="h-5 w-5 text-accent" />
                <h2 className="font-display text-2xl">Anclajes verificables</h2>
              </div>
              <div className="grid gap-3">
                {thesis.anchors.map((anchor) => (
                  <a
                    key={anchor.url}
                    href={anchor.url}
                    target="_blank"
                    rel="noreferrer"
                    className="group flex items-center justify-between rounded-xl border border-border/60 bg-card/40 px-4 py-3 transition-colors hover:border-accent/40"
                  >
                    <span className="font-body text-sm text-foreground/85">
                      {anchor.label}
                    </span>
                    <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-accent" />
                  </a>
                ))}
              </div>
            </motion.article>
          </section>

          <section className="mb-20">
            <div className="mb-8 flex items-center gap-3">
              <Sparkles className="h-5 w-5 text-gold" />
              <h2 className="font-display text-3xl">Pilares de soberanía</h2>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {thesis.pillars.map((pillar) => (
                <article
                  key={pillar.name}
                  className="rounded-2xl border border-gold/15 bg-card/60 p-6 backdrop-blur-md"
                >
                  <h3 className="mb-3 font-display text-xl text-foreground">
                    {pillar.name}
                  </h3>
                  <p className="font-body text-sm leading-relaxed text-muted-foreground">
                    {pillar.description}
                  </p>
                </article>
              ))}
            </div>
          </section>

          <section className="mb-20 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="rounded-2xl border border-accent/20 bg-accent/5 p-6">
              <div className="mb-4 flex items-center gap-3">
                <Layers className="h-5 w-5 text-accent" />
                <h2 className="font-display text-2xl">8 capas del sistema</h2>
              </div>
              <div className="space-y-3">
                {thesis.layers.map((layer) => (
                  <div
                    key={layer.level}
                    className="rounded-xl border border-white/10 bg-background/40 p-4"
                  >
                    <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-accent">
                      L{layer.level} · {layer.name}
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {layer.role}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
              <div className="mb-4 flex items-center gap-3">
                <Network className="h-5 w-5 text-gold" />
                <h2 className="font-display text-2xl">Federaciones</h2>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                {thesis.federations.map((federation) => (
                  <article
                    key={federation.id}
                    className="rounded-xl border border-white/10 bg-background/35 p-4"
                  >
                    <div className="mb-2 flex items-start justify-between gap-3">
                      <div>
                        <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                          {federation.id}
                        </p>
                        <h3 className="font-display text-lg text-foreground">
                          {federation.name}
                        </h3>
                      </div>
                      <Badge
                        variant="outline"
                        className={
                          STATUS_STYLE[federation.status] ?? STATUS_STYLE.draft
                        }
                      >
                        {federation.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-gold">{federation.domain}</p>
                    <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                      {federation.description}
                    </p>
                  </article>
                ))}
              </div>
            </div>
          </section>

          <section className="mb-20 grid gap-6 lg:grid-cols-2">
            <article className="rounded-2xl border border-gold/20 bg-gold/5 p-6">
              <div className="mb-4 flex items-center gap-3">
                <ScrollText className="h-5 w-5 text-gold" />
                <h2 className="font-display text-2xl">RFCs ratificados</h2>
              </div>
              <div className="space-y-3">
                {thesis.rfcs.map((rfc) => (
                  <div
                    key={rfc.id}
                    className="rounded-xl border border-white/10 bg-background/40 p-4"
                  >
                    <div className="mb-2 flex items-center justify-between gap-3">
                      <h3 className="font-display text-sm text-foreground">
                        {rfc.id} · {rfc.title}
                      </h3>
                      <Badge
                        variant="outline"
                        className={
                          STATUS_STYLE[rfc.status] ?? STATUS_STYLE.draft
                        }
                      >
                        {rfc.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {rfc.summary}
                    </p>
                  </div>
                ))}
              </div>
            </article>

            <article className="rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md">
              <div className="mb-4 flex items-center gap-3">
                <Quote className="h-5 w-5 text-accent" />
                <h2 className="font-display text-2xl">Axiomas y madurez</h2>
              </div>
              <ul className="mb-6 space-y-2">
                {thesis.axioms.map((axiom) => (
                  <li key={axiom} className="text-sm text-muted-foreground">
                    “{axiom}”
                  </li>
                ))}
              </ul>
              <div className="space-y-4">
                {thesis.maturity.map((item) => (
                  <div key={item.area}>
                    <div className="mb-1 flex items-center justify-between gap-3">
                      <span className="text-xs text-foreground">
                        {item.area}
                      </span>
                      <span className="font-mono text-xs text-gold">
                        {item.percent}%
                      </span>
                    </div>
                    <Progress value={item.percent} />
                    <p className="mt-1 text-[11px] text-muted-foreground">
                      {item.note}
                    </p>
                  </div>
                ))}
              </div>
            </article>
          </section>

          <section className="rounded-2xl border border-accent/20 bg-accent/5 p-8 text-center">
            <h2 className="font-display text-3xl text-foreground">
              Diagnóstico: {thesis.diagnosis.name}
            </h2>
            <p className="mx-auto mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground">
              {thesis.diagnosis.description}
            </p>
            <Link
              to="/operativo"
              className="mt-6 inline-flex items-center gap-2 rounded-xl border border-gold/30 bg-gold/10 px-5 py-3 font-body text-sm font-semibold text-gold transition-colors hover:bg-gold/20"
            >
              Ver ejecución operativa <ArrowRight className="h-4 w-4" />
            </Link>
          </section>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
