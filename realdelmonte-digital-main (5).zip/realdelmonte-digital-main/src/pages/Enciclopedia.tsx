import { useState, useMemo } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { Search, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { RDM_POIS, CATEGORY_META } from "@/data/rdmContent";

export default function Enciclopedia() {
  const [q, setQ] = useState("");

  const entries = useMemo(() => {
    return RDM_POIS.filter((p) => {
      if (!q) return true;
      const hay = `${p.name} ${p.short} ${p.story} ${p.tags?.join(" ")}`.toLowerCase();
      return hay.includes(q.toLowerCase());
    });
  }, [q]);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pt-28 pb-20">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto text-center mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-gold/40 bg-gold/5 mb-4">
              <BookOpen className="w-3.5 h-3.5 text-gold" />
              <span className="text-[10px] tracking-[0.3em] uppercase text-gold font-body">Enciclopedia TAMV</span>
            </div>
            <h1 className="font-display text-4xl md:text-5xl text-foreground mb-3">
              Memoria viva de <span className="text-gradient-gold">Real del Monte</span>
            </h1>
            <p className="text-muted-foreground font-body">
              Base de conocimiento curada: minas, leyendas, gastronomía, arte y rutas.
            </p>
            <div className="relative max-w-xl mx-auto mt-6">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar pastes, mina dolores, llorona..."
                className="w-full bg-background border border-border rounded-xl pl-10 pr-4 py-3 text-foreground focus:outline-none focus:border-gold transition-colors font-body"
              />
            </div>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-6xl mx-auto">
            {entries.map((e, i) => {
              const meta = CATEGORY_META[e.category];
              return (
                <motion.article
                  key={e.id}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: Math.min(i * 0.03, 0.4) }}
                  className="glass-card border border-border rounded-2xl overflow-hidden hover:border-gold/40 transition-all group"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img src={e.image} alt={e.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                    <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />
                    <span
                      className="absolute top-3 left-3 text-[10px] px-2 py-1 rounded-full font-body uppercase tracking-wider text-white"
                      style={{ background: meta.color }}
                    >
                      {meta.emoji} {meta.label}
                    </span>
                  </div>
                  <div className="p-5">
                    <p className="text-[10px] uppercase tracking-wider text-gold font-body mb-1">{e.era}</p>
                    <h3 className="font-display text-lg text-foreground mb-2">{e.name}</h3>
                    <p className="text-sm text-muted-foreground font-body line-clamp-3 mb-3">{e.story}</p>
                    <Link
                      to={`/mapa`}
                      className="text-xs text-accent font-body hover:underline"
                    >
                      Ver en mapa →
                    </Link>
                  </div>
                </motion.article>
              );
            })}
          </div>
          {entries.length === 0 && (
            <div className="text-center text-muted-foreground font-body py-20">Sin resultados.</div>
          )}
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
