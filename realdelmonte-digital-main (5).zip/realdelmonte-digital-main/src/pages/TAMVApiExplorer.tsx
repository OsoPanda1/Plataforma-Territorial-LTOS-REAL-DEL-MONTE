import { useState } from "react";
import { motion } from "framer-motion";
import { Code2, Play } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { SEOMeta } from "@/components/SEOMeta";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiGet, apiPost } from "@/lib/apiClient";

type EndpointGroup =
  | "identity"
  | "governance"
  | "economy"
  | "ai"
  | "metaverse"
  | "msr";

interface Endpoint {
  method: "GET" | "POST";
  path: string;
  desc: string;
  group: EndpointGroup;
}

const endpoints: Endpoint[] = [
  {
    method: "GET",
    path: "/api/tamv/identity",
    desc: "Lista ciudadanos federados",
    group: "identity",
  },
  {
    method: "POST",
    path: "/api/tamv/identity",
    desc: "Emite DID + ancla BookPI",
    group: "identity",
  },
  {
    method: "GET",
    path: "/api/tamv/governance/proposals",
    desc: "Propuestas DAO",
    group: "governance",
  },
  {
    method: "POST",
    path: "/api/tamv/governance/proposals",
    desc: "Crea propuesta",
    group: "governance",
  },
  {
    method: "POST",
    path: "/api/tamv/economy/distribute",
    desc: "Distribuye Phoenix 20·30·50",
    group: "economy",
  },
  {
    method: "POST",
    path: "/api/tamv/ai/decision",
    desc: "Registra DecisionRecord SHA-256",
    group: "ai",
  },
  {
    method: "GET",
    path: "/api/tamv/ai/decisions",
    desc: "Audita decisiones IA",
    group: "ai",
  },
  {
    method: "GET",
    path: "/api/tamv/metaverse/dreamspaces",
    desc: "DreamSpaces XR activos",
    group: "metaverse",
  },
  {
    method: "GET",
    path: "/api/tamv/msr/status",
    desc: "Estado del Nodo Cero",
    group: "msr",
  },
];

const sampleBodies: Record<string, Record<string, unknown>> = {
  "/api/tamv/identity": {
    alias: "Visitante RDM",
    seed: "demo",
    territory: "Real del Monte",
  },
  "/api/tamv/governance/proposals": {
    title: "Ratificar interoperabilidad MSR ↔ RDM",
    body: "Propuesta demo generada desde el explorer local.",
  },
  "/api/tamv/economy/distribute": { profit: 1000, rule: "20/30/50" },
  "/api/tamv/ai/decision": {
    actorId: "tamv-founder-eoct",
    action: "demo-action",
    context: "API explorer",
  },
};

const groupClass: Record<EndpointGroup, string> = {
  identity: "bg-gold text-background",
  governance: "bg-accent text-accent-foreground",
  economy: "bg-terracotta text-white",
  ai: "bg-cyan-300 text-slate-950",
  metaverse: "bg-platinum text-slate-950",
  msr: "bg-gold/80 text-background",
};

const offlineResponse = (endpoint: Endpoint) => ({
  offline: true,
  endpoint: endpoint.path,
  method: endpoint.method,
  group: endpoint.group,
  message:
    "Backend federado no disponible; contrato ejecutado en modo local para mantener la función completa.",
  sample:
    endpoint.method === "POST"
      ? (sampleBodies[endpoint.path] ?? {})
      : { status: "local-snapshot", node: "TAMV-RDM-NODO-CERO" },
  timestamp: new Date().toISOString(),
});

export default function TAMVApiExplorer() {
  const [results, setResults] = useState<Record<string, unknown>>({});
  const [loading, setLoading] = useState<string | null>(null);

  const tryEndpoint = async (endpoint: Endpoint) => {
    setLoading(endpoint.path);
    try {
      const data =
        endpoint.method === "GET"
          ? await apiGet<unknown>(endpoint.path)
          : await apiPost<unknown>(
              endpoint.path,
              sampleBodies[endpoint.path] ?? {},
            );
      setResults((current) => ({ ...current, [endpoint.path]: data }));
    } catch (error) {
      setResults((current) => ({
        ...current,
        [endpoint.path]: {
          ...offlineResponse(endpoint),
          error: error instanceof Error ? error.message : "Backend offline",
        },
      }));
    } finally {
      setLoading(null);
    }
  };

  return (
    <PageTransition>
      <SEOMeta
        title="Explorador de API TAMV"
        description="Explorador interactivo de contratos TAMV para identidad, gobernanza, economía, IA, metaverso y estado MSR."
      />
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pb-24 pt-32">
          <motion.header
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto mb-12 max-w-4xl text-center"
          >
            <Badge
              variant="outline"
              className="mb-4 border-gold/30 bg-gold/10 text-gold"
            >
              <Code2 className="mr-2 h-3.5 w-3.5" /> TAMV Blockchain MSR API ·
              v1
            </Badge>
            <h1 className="font-display text-4xl text-foreground md:text-6xl">
              Explorador de{" "}
              <span className="text-gradient-gold">contratos</span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl font-body text-muted-foreground">
              Integración forzada del API Explorer de RDM-Digital-X: cada
              endpoint puede probarse contra backend real o responder en modo
              snapshot local.
            </p>
          </motion.header>

          <div className="grid gap-4 lg:grid-cols-2">
            {endpoints.map((endpoint) => (
              <Card
                key={`${endpoint.method}-${endpoint.path}`}
                className="border-gold/20 bg-card/60 backdrop-blur-md"
              >
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between gap-3 font-display text-sm">
                    <div className="flex min-w-0 items-center gap-3">
                      <span
                        className={`rounded px-2 py-0.5 font-mono text-[10px] ${groupClass[endpoint.group]}`}
                      >
                        {endpoint.method}
                      </span>
                      <span className="truncate font-mono text-xs text-foreground/90">
                        {endpoint.path}
                      </span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="shrink-0 border-gold/30"
                      onClick={() => void tryEndpoint(endpoint)}
                      disabled={loading === endpoint.path}
                    >
                      <Play className="mr-1 h-3 w-3" />{" "}
                      {loading === endpoint.path ? "..." : "Probar"}
                    </Button>
                  </CardTitle>
                  <p className="pt-1 font-body text-xs text-muted-foreground">
                    {endpoint.desc}
                  </p>
                </CardHeader>
                {results[endpoint.path] !== undefined && (
                  <CardContent>
                    <pre className="max-h-64 overflow-auto rounded border border-border/40 bg-background/60 p-3 font-mono text-[10px] text-foreground/80">
                      {JSON.stringify(results[endpoint.path], null, 2)}
                    </pre>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
