import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem } from "@/components/VisualEffects";
import { Calendar, MapPin, Users, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Event = {
  id: string;
  name: string;
  description: string | null;
  event_date: string;
  location: string;
  attendees: string | null;
  category: string | null;
};

export default function Eventos() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from("events").select("*").order("created_at", { ascending: false }).then(({ data }) => {
      setEvents((data as Event[]) || []);
      setLoading(false);
    });
  }, []);

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Eventos y Festivales</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Festivales, ferias y temporadas especiales que dan vida al Pueblo Mágico.
                </p>
              </div>
            </TextReveal>
            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>
            ) : (
              <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {events.map((event) => (
                  <StaggerItem key={event.id}>
                    <div className="p-6 rounded-2xl border border-border bg-card card-glow-hover h-full">
                      <div className="flex items-center gap-2 mb-3">
                        <Calendar className="w-4 h-4 text-gold" />
                        <span className="text-xs font-semibold text-gold font-body">{event.event_date}</span>
                        {event.category && <span className="text-[10px] uppercase tracking-widest text-accent font-body ml-auto">{event.category}</span>}
                      </div>
                      <h3 className="font-display text-lg font-semibold text-foreground mb-2">{event.name}</h3>
                      <p className="text-sm text-muted-foreground font-body mb-4">{event.description}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground font-body">
                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-accent" />{event.location}</span>
                        {event.attendees && <span className="flex items-center gap-1"><Users className="w-3 h-3 text-copper" />{event.attendees}</span>}
                      </div>
                    </div>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
