import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import NodoCeroCommandCenter from "@/components/NodoCeroCommandCenter";
import { PageTransition } from "@/components/VisualEffects";
import { motion } from "framer-motion";
import {
  GitBranch,
  CheckCircle2,
  ExternalLink,
  Network,
  Radar,
} from "lucide-react";
import {
  NODE_ZERO_REPOS,
  NODE_ZERO_CAPABILITIES,
  getNodeZeroCompletion,
} from "@/data/rdmNodeZero";

export default function Fusion() {
  const completion = getNodeZeroCompletion();
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pt-28 pb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto mb-12 max-w-4xl text-center"
          >
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/5 px-3 py-1">
              <GitBranch className="h-3.5 w-3.5 text-accent" />
              <span className="font-body text-[10px] uppercase tracking-[0.3em] text-accent">
                Fusión RDM·X
              </span>
            </div>
            <h1 className="mb-4 font-display text-4xl text-foreground md:text-6xl">
              Nodo Cero <span className="text-gradient-gold">ejecutado</span>
            </h1>
            <p className="mx-auto max-w-3xl font-body leading-relaxed text-muted-foreground">
              La página de fusión deja de ser inventario pasivo: ahora documenta
              cada repo investigado, qué mejora se absorbió, en qué ruta opera y
              cuánto avance funcional sostiene dentro de este repo.
            </p>
          </motion.div>

          <div className="mx-auto mb-12 grid max-w-5xl gap-4 md:grid-cols-4">
            {[
              {
                label: "Repos relacionados",
                value: completion.repos,
                icon: GitBranch,
              },
              {
                label: "Absorbidos",
                value: completion.absorbed,
                icon: CheckCircle2,
              },
              {
                label: "Orquestados",
                value: completion.orchestrated,
                icon: Network,
              },
              {
                label: "Madurez global",
                value: `${completion.maturity}%`,
                icon: Radar,
              },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-border bg-card/70 p-5 text-center backdrop-blur-md"
              >
                <item.icon className="mx-auto mb-3 h-5 w-5 text-gold" />
                <p className="font-display text-3xl text-foreground">
                  {item.value}
                </p>
                <p className="mt-1 font-body text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  {item.label}
                </p>
              </div>
            ))}
          </div>

          <div className="mx-auto mb-14 max-w-5xl overflow-hidden rounded-2xl border border-border bg-card/60 backdrop-blur-md">
            <div className="grid border-b border-border bg-secondary/20 px-4 py-3 font-body text-[10px] uppercase tracking-[0.22em] text-muted-foreground md:grid-cols-[1.1fr_0.8fr_1.6fr_0.4fr]">
              <span>Repositorio</span>
              <span>Familia</span>
              <span>Mejora absorbida</span>
              <span>Fuente</span>
            </div>
            {NODE_ZERO_REPOS.map((repo) => (
              <a
                key={repo.id}
                href={repo.url}
                target="_blank"
                rel="noreferrer"
                className="grid gap-3 border-b border-border/70 px-4 py-4 transition-colors last:border-b-0 hover:bg-secondary/20 md:grid-cols-[1.1fr_0.8fr_1.6fr_0.4fr] md:items-center"
              >
                <div>
                  <h2 className="font-display text-sm text-foreground">
                    {repo.name}
                  </h2>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {repo.focus}
                  </p>
                </div>
                <div>
                  <span className="rounded-full border border-accent/25 bg-accent/10 px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-accent">
                    {repo.family}
                  </span>
                </div>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  {repo.absorbedImprovements.slice(0, 2).map((improvement) => (
                    <li key={improvement} className="flex gap-2">
                      <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-300" />
                      <span>{improvement}</span>
                    </li>
                  ))}
                </ul>
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </a>
            ))}
          </div>

          <div className="mx-auto mb-14 max-w-5xl rounded-2xl border border-gold/20 bg-gold/5 p-6">
            <p className="font-body text-[10px] uppercase tracking-[0.24em] text-gold">
              Capacidades superiores integradas
            </p>
            <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {NODE_ZERO_CAPABILITIES.map((capability) => (
                <div
                  key={capability.id}
                  className="rounded-xl border border-white/10 bg-background/40 p-4"
                >
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <h3 className="font-display text-sm text-foreground">
                      {capability.title}
                    </h3>
                    <span className="font-mono text-xs text-gold">
                      {capability.maturity}%
                    </span>
                  </div>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    {capability.implementation}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="mx-auto max-w-6xl">
            <NodoCeroCommandCenter compact />
          </div>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
