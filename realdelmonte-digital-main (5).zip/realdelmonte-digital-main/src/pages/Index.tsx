import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Globe,
  Shield,
  Brain,
  Coins,
  Users,
  Zap,
  ChevronRight,
  MapPin,
  Mountain,
  Utensils,
  TreePine,
  Palette,
  Clock,
  Ghost,
  Bus,
  Store,
  Layers,
  Network,
  Cpu,
  Wifi,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import ExperienceHub from "@/components/ExperienceHub";
import NodoCeroBanner from "@/components/NodoCeroBanner";
import NodoCeroCommandCenter from "@/components/NodoCeroCommandCenter";
import {
  TextReveal,
  StaggerContainer,
  StaggerItem,
  GlowCard,
} from "@/components/VisualEffects";
import realitoPastes from "@/assets/realito-pastes.png";
import realitoCommercios from "@/assets/realito-comercios.png";
import realitoCollage from "@/assets/realito-collage.png";

const modules = [
  {
    icon: Globe,
    title: "Gemelo Digital 4D",
    desc: "Territorio + tiempo + narrativa. Mapa en tiempo real, capas históricas, simulación de escenarios y experiencias inmersivas.",
  },
  {
    icon: Brain,
    title: "Isabella AI™ · REALITO",
    desc: "IA emocional civilizatoria con geolocalización, recomendaciones contextuales y orientación cultural. Primera IA territorial de un Pueblo Mágico.",
  },
  {
    icon: Shield,
    title: "Seguridad Post-Cuántica",
    desc: "Cifrado de grado militar preparado para criptografía post-cuántica (PQC). Arquitectura Zero-Trust y protección de datos soberana.",
  },
  {
    icon: Coins,
    title: "Economía Soberana",
    desc: "Ledger distribuido ligero, directorio comercial verificado, marketplace y sistema de apoyo a la economía creativa local.",
  },
  {
    icon: Users,
    title: "Comunidad Conectada",
    desc: "Red social territorial, muro de recuerdos, eventos, dichos mineros y preservación de la memoria colectiva digital.",
  },
  {
    icon: Zap,
    title: "Smart City · RDM-TOS",
    desc: "Red mesh WiFi soberana, telemetría territorial, City Intelligence con monitoreo de flujos y gobernanza de datos.",
  },
];

const quickLinks = [
  { icon: MapPin, title: "Mapa", path: "/mapa", color: "text-accent" },
  {
    icon: Mountain,
    title: "Ecoturismo",
    path: "/ecoturismo",
    color: "text-forest",
  },
  {
    icon: Utensils,
    title: "Gastronomía",
    path: "/gastronomia",
    color: "text-terracotta",
  },
  { icon: Clock, title: "Historia", path: "/historia", color: "text-gold" },
  { icon: Palette, title: "Arte", path: "/arte", color: "text-copper" },
  { icon: Ghost, title: "Relatos", path: "/relatos", color: "text-accent" },
  { icon: TreePine, title: "Rutas", path: "/rutas", color: "text-forest" },
  { icon: Store, title: "Directorio", path: "/directorio", color: "text-gold" },
  { icon: Bus, title: "Transporte", path: "/transporte", color: "text-accent" },
  { icon: Users, title: "Comunidad", path: "/comunidad", color: "text-copper" },
];

const phases = [
  {
    phase: "Fase 1",
    title: "Arranque Digital Turístico Comercial",
    desc: "Escaparate digital, directorio comercial verificado, REALITO AI, rutas y experiencias. Música con identidad, artesanías y campaña QR + META.",
    status: "Activa",
  },
  {
    phase: "Fase 2",
    title: "Medir para Mejorar · Telemetría",
    desc: "Sensores de flujo peatonal, analítica de horarios turísticos, dashboards de decisiones con datos reales y City Intelligence.",
    status: "2026–2027",
  },
  {
    phase: "Fase 3",
    title: "Red de Conectividad Soberana",
    desc: "50+ nodos mesh WiFi con alcance de 7.5 km desde el Monumento al Minero. Internet gratuito y backbone del Gemelo Digital.",
    status: "2027–2028",
  },
];

const tissues = [
  {
    icon: Cpu,
    title: "Tejido Cognitivo de Gobernanza",
    desc: "Motor de inferencia urbana (City Intelligence). Detecta cuellos de botella, genera alertas accionables para comerciantes y autoridades.",
  },
  {
    icon: Layers,
    title: "Tejido de Persistencia Cuántica",
    desc: "Ledger económico soberano. Cada comercio es un nodo validado con identidad verificada y actualizaciones trazables.",
  },
  {
    icon: Globe,
    title: "Tejido Espacial 4D",
    desc: "Gemelo Digital con tiempo y narrativa. Real del Monte hoy, histórico (época minera) y simulado (escenarios futuros).",
  },
  {
    icon: Network,
    title: "Tejido de Interfaz Simbiótica",
    desc: "UX predictiva que anticipa intención. Sugiere rutas, lugares y comercios antes de que el usuario escriba.",
  },
];

export default function Index() {
  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <Navbar />
      <HeroSection />

      {/* Quick Links */}
      <section className="py-16 px-6">
        <div className="container max-w-6xl">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {quickLinks.map((link, i) => (
              <motion.div
                key={link.path}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  to={link.path}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-card hover:bg-secondary/30 hover:border-accent/30 transition-all group"
                >
                  <link.icon
                    className={`w-5 h-5 ${link.color} group-hover:scale-110 transition-transform`}
                  />
                  <span className="text-xs font-body text-muted-foreground group-hover:text-foreground">
                    {link.title}
                  </span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <div className="container max-w-6xl">
        <div className="separator-animated" />
      </div>

      {/* REALITO Showcase with images */}
      <section className="py-24 px-6">
        <div className="container max-w-6xl">
          <TextReveal>
            <div className="text-center mb-16">
              <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
                REALITO te Guía
              </h2>
              <p className="text-muted-foreground font-body max-w-2xl mx-auto">
                Isabella AI™ (REALITO) es la primera asistente territorial de un
                Pueblo Mágico. Te recomienda negocios, rutas y experiencias en
                tiempo real.
              </p>
            </div>
          </TextReveal>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                img: realitoPastes,
                title: "Gastronomía con Alma",
                desc: "REALITO te lleva a las mejores pastelerías y restaurantes de Real del Monte con recomendaciones personalizadas.",
              },
              {
                img: realitoCommercios,
                title: "Comercio Local Verificado",
                desc: "Artesanías, platerías, micheladas — cada negocio es un nodo verificado en el ecosistema RDM Digital.",
              },
              {
                img: realitoCollage,
                title: "Experiencia Integral",
                desc: "Sanitarios públicos, reviews, likes, comercios y servicios. Todo conectado en una sola plataforma inteligente.",
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="rounded-2xl border border-border bg-card overflow-hidden group card-glow-hover"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={item.img}
                    alt={item.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <div className="p-5">
                  <h3 className="font-display text-lg font-semibold text-foreground mb-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-muted-foreground font-body">
                    {item.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <div className="container max-w-6xl">
        <div className="separator-animated" />
      </div>

      {/* Experience Hub */}
      <section className="py-24 px-6">
        <div className="container max-w-6xl">
          <ExperienceHub />
        </div>
      </section>

      <NodoCeroBanner />

      {/* TECHNICAL SECTIONS — demoted into a discreet disclosure to keep the tourist platform en primer plano */}

      {/* Vision */}
      <section className="py-24 px-6">
        <div className="container max-w-4xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <TextReveal>
              <div>
                <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-6">
                  No es una app.
                  <br />
                  <span className="text-gradient-gold">
                    Es un ecosistema civilizatorio.
                  </span>
                </h2>
                <p className="text-muted-foreground font-body leading-relaxed mb-4">
                  RDM-TOS es el sistema operativo territorial que conecta
                  turistas, comercios, transporte y gobierno en una sola
                  experiencia digital continua. Un organismo que anticipa
                  intención.
                </p>
                <p className="text-muted-foreground font-body leading-relaxed mb-4">
                  Construido con más de 21,600 horas de trabajo, costeado con
                  recursos propios. Sin deudas, sin bancos, sin inversionistas
                  externos. La tecnología es del pueblo y para el pueblo.
                </p>
                <p className="text-sm italic text-gold font-body">
                  "Primer Gemelo Digital soberano de un Pueblo Mágico en
                  Latinoamérica, sobre una arquitectura civilizacional (TAMV)
                  con estándares de Destino Turístico Inteligente."
                </p>
              </div>
            </TextReveal>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative aspect-square rounded-2xl border border-border bg-card flex items-center justify-center overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-gold/5" />
              <div className="text-center relative z-10">
                <p className="font-display text-6xl font-bold text-gold text-glow-gold">
                  75%
                </p>
                <p className="text-sm text-muted-foreground font-body mt-2">
                  Avance del ecosistema
                </p>
                <p className="text-xs text-muted-foreground/60 font-body mt-1">
                  21,600+ horas invertidas
                </p>
                <div className="mt-4 mx-auto w-32 h-1 rounded-full bg-secondary overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: "75%" }}
                    viewport={{ once: true }}
                    transition={{ duration: 2, delay: 0.5 }}
                    className="h-full rounded-full bg-gradient-to-r from-accent to-gold"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <NodoCeroCommandCenter />

      {/* CTA */}
      <section className="py-24 px-6 border-t border-border">
        <div className="container max-w-2xl text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Únete al futuro de Real del Monte
          </h2>
          <p className="text-muted-foreground font-body mb-8">
            RDM Digital está construyendo la plataforma que transformará a un
            Pueblo Mágico en un destino verdaderamente inteligente.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/auth?mode=signup">
              <button className="flex items-center gap-2 rounded-xl bg-accent px-10 py-4 font-body font-semibold text-accent-foreground transition-all hover:bg-accent/90 glow-electric">
                Crear Cuenta <ChevronRight className="w-4 h-4" />
              </button>
            </Link>
            <Link to="/apoya">
              <button className="flex items-center gap-2 rounded-xl border border-gold/30 bg-gold/10 px-10 py-4 font-body font-semibold text-gold transition-all hover:bg-gold/20">
                Apoyar el Proyecto
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* TECHNICAL APPENDIX — collapsed by default. Tourist platform queda en primer plano; arquitectura y roadmap en tercer plano. */}
      <section className="px-6 pb-16">
        <div className="container max-w-5xl">
          <details className="group rounded-2xl border border-white/[0.05] bg-card/40 backdrop-blur-sm">
            <summary className="flex cursor-pointer items-center justify-between gap-3 px-5 py-4 text-left list-none [&::-webkit-details-marker]:hidden">
              <div className="min-w-0">
                <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground/70">
                  Nodo Cero · Documentación técnica
                </p>
                <p className="mt-1 font-display text-sm text-foreground/80">
                  Arquitectura, módulos y hoja de ruta del sistema operativo
                  territorial
                </p>
              </div>
              <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-90" />
            </summary>
            <div className="space-y-12 border-t border-white/[0.04] px-5 py-10">
              {/* Matriz */}
              <div>
                <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.3em] text-accent">
                  RDM-TOS · Matriz de Hiperconvergencia
                </p>
                <h3 className="mb-4 font-display text-xl text-foreground">
                  Cuatro tejidos del sistema operativo territorial
                </h3>
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                  {tissues.map((t, i) => (
                    <div
                      key={i}
                      className="rounded-xl border border-border bg-card/60 p-4"
                    >
                      <div className="mb-2 flex items-center gap-2">
                        <t.icon className="h-4 w-4 text-gold" />
                        <h4 className="font-display text-sm text-foreground">
                          {t.title}
                        </h4>
                      </div>
                      <p className="text-xs text-muted-foreground font-body leading-relaxed">
                        {t.desc}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
              {/* Módulos */}
              <div>
                <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.3em] text-accent">
                  Arquitectura
                </p>
                <h3 className="mb-4 font-display text-xl text-foreground">
                  Módulos del sistema · 7 Federaciones TAMV
                </h3>
                <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
                  {modules.map((m, i) => (
                    <div
                      key={i}
                      className="rounded-xl border border-border bg-card/60 p-4"
                    >
                      <div className="mb-2 flex items-center gap-2">
                        <m.icon className="h-4 w-4 text-accent" />
                        <h4 className="font-display text-sm text-foreground">
                          {m.title}
                        </h4>
                      </div>
                      <p className="text-xs text-muted-foreground font-body leading-relaxed">
                        {m.desc}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
              {/* Roadmap */}
              <div>
                <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.3em] text-accent">
                  Hoja de ruta
                </p>
                <h3 className="mb-4 font-display text-xl text-foreground">
                  Fases del despliegue rumbo a 2030
                </h3>
                <div className="space-y-3">
                  {phases.map((p, i) => (
                    <div
                      key={i}
                      className="flex gap-4 rounded-xl border border-border bg-card/60 p-4"
                    >
                      <div className="w-16 shrink-0 text-center">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-accent font-body">
                          {p.phase}
                        </span>
                        <div
                          className={`mx-auto mt-1.5 h-1.5 w-1.5 rounded-full ${p.status === "Activa" ? "bg-success animate-pulse" : "bg-muted-foreground/30"}`}
                        />
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-display text-sm text-foreground">
                          {p.title}
                        </h4>
                        <p className="mt-0.5 text-xs text-muted-foreground font-body">
                          {p.desc}
                        </p>
                        <span className="mt-1 inline-block text-[10px] text-gold font-body">
                          {p.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </details>
        </div>
      </section>

      <Footer />
    </div>
  );
}
