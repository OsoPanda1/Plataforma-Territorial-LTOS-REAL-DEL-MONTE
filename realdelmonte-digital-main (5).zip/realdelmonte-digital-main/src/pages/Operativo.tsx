import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  Layers3,
  PencilRuler,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { SEOMeta } from "@/components/SEOMeta";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  OPERATIVE_MODULES,
  overallCompletion,
  summarizeByDomain,
} from "@/data/operativeModules";
import type { ModuleStatus } from "@/lib/types/operativo";

const statusMeta: Record<
  ModuleStatus,
  { label: string; Icon: typeof CheckCircle2; className: string }
> = {
  done: {
    label: "Listo",
    Icon: CheckCircle2,
    className: "border-emerald-400/30 bg-emerald-400/10 text-emerald-200",
  },
  "in-progress": {
    label: "En progreso",
    Icon: Clock3,
    className: "border-gold/30 bg-gold/10 text-gold",
  },
  design: {
    label: "Diseño",
    Icon: PencilRuler,
    className: "border-cyan-300/25 bg-cyan-300/10 text-cyan-100",
  },
};

export default function Operativo() {
  const overall = overallCompletion();
  const domains = summarizeByDomain();

  return (
    <PageTransition>
      <SEOMeta
        title="Estado operativo Nodo Cero"
        description="Documento maestro operativo: módulos, dominios, madurez y rutas ejecutables del merge RDM/TAMV."
      />
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pb-24 pt-32">
          <motion.header
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto mb-12 max-w-4xl text-center"
          >
            <Badge
              variant="outline"
              className="mb-5 border-gold/40 bg-gold/5 px-4 py-2"
            >
              <Layers3 className="mr-2 h-4 w-4 text-gold" />
              <span className="font-body text-[10px] uppercase tracking-[0.28em] text-gold">
                Documento maestro operativo
              </span>
            </Badge>
            <h1 className="font-display text-4xl font-light leading-tight text-foreground md:text-6xl">
              Estado <span className="text-gradient-gold">operativo</span> del
              merge
            </h1>
            <p className="mx-auto mt-5 max-w-2xl font-body text-base leading-relaxed text-muted-foreground">
              Integración funcional de las piezas reales absorbidas: cada módulo
              tiene estado, evidencia, ruta y madurez para no quedarse en
              manifiesto.
            </p>
          </motion.header>

          <Card className="mb-10 border-gold/20 bg-card/60 backdrop-blur-md">
            <CardContent className="p-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="font-body text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                    Completitud global
                  </p>
                  <p className="mt-2 font-display text-5xl font-light text-foreground">
                    {overall}%
                  </p>
                </div>
                <div className="grid flex-1 gap-3 sm:grid-cols-3">
                  {(["done", "in-progress", "design"] as ModuleStatus[]).map(
                    (status) => {
                      const count = OPERATIVE_MODULES.filter(
                        (module) => module.status === status,
                      ).length;
                      const meta = statusMeta[status];
                      return (
                        <div
                          key={status}
                          className="rounded-xl border border-white/10 bg-background/40 p-4"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-body text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                              {meta.label}
                            </span>
                            <meta.Icon className="h-4 w-4 text-gold" />
                          </div>
                          <p className="mt-2 font-display text-2xl text-foreground">
                            {count}
                          </p>
                        </div>
                      );
                    },
                  )}
                </div>
              </div>
              <Progress value={overall} className="mt-6" />
            </CardContent>
          </Card>

          <div className="mb-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {domains.map((domain) => (
              <Card
                key={domain.domain}
                className="border-cyan-200/15 bg-card/50 backdrop-blur-md"
              >
                <CardContent className="p-5">
                  <div className="mb-3 flex items-center justify-between">
                    <p className="font-display text-lg capitalize text-foreground">
                      {domain.domain}
                    </p>
                    <span className="font-mono text-xs text-cyan-100/70">
                      {domain.done}/{domain.total}
                    </span>
                  </div>
                  <Progress value={domain.completion} />
                  <p className="mt-2 text-xs text-muted-foreground">
                    {domain.completion}% promedio
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            {OPERATIVE_MODULES.map((module, index) => {
              const meta = statusMeta[module.status];
              return (
                <motion.div
                  key={module.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ delay: index * 0.04 }}
                >
                  <Card className="h-full border-gold/15 bg-card/60 backdrop-blur-md transition-all hover:border-gold/35">
                    <CardHeader>
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <CardTitle className="font-display text-xl font-light">
                            {module.name}
                          </CardTitle>
                          <p className="mt-1 font-body text-[10px] uppercase tracking-[0.22em] text-cyan-100/60">
                            {module.domain}
                          </p>
                        </div>
                        <Badge variant="outline" className={meta.className}>
                          <meta.Icon className="mr-1 h-3 w-3" /> {meta.label}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Progress value={module.completion} />
                      <p className="mt-2 text-xs text-muted-foreground">
                        {module.completion}% completado
                      </p>
                      {module.notes && (
                        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                          {module.notes}
                        </p>
                      )}
                      <div className="mt-4 flex flex-wrap items-center gap-3">
                        {module.spec && (
                          <code className="rounded-md bg-black/25 px-2 py-1 text-[11px] text-slate-200">
                            {module.spec}
                          </code>
                        )}
                        {module.route && (
                          <Link
                            to={module.route}
                            className="inline-flex items-center gap-1 text-[10px] uppercase tracking-[0.2em] text-cyan-100 hover:text-white"
                          >
                            Abrir módulo <ArrowRight className="h-3 w-3" />
                          </Link>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
