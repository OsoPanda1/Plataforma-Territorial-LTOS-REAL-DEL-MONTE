import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal } from "@/components/VisualEffects";
import { Ghost } from "lucide-react";
import { CinematicMist } from "@/components/effects/CinematicMist";
import rdmCallejon from "@/assets/rdm-callejon-noche.jpg";
import rdmPanteon from "@/assets/rdm-panteon-ingles.jpg";

const relatos = [
  { title: "El Fantasma de la Mina", location: "Mina de Acosta", content: "Se dice que al fondo del tiro de la mina, un minero inglés sigue caminando con su lámpara encendida, buscando la veta que nunca encontró en vida...", image: null },
  { title: "La Dama de Blanco", location: "Callejón del Diamante", content: "En las noches de neblina, una mujer vestida de blanco aparece al final del callejón, llamando a los viajeros solitarios con una voz dulce como campanas...", image: rdmCallejon },
  { title: "El Tesoro del Conde de Regla", location: "Hacienda de Regla", content: "El Conde de Regla escondió un tesoro inmenso antes de huir. Dicen que quien encuentre las tres piedras marcadas descubrirá el camino...", image: null },
  { title: "Los Duendes del Bosque", location: "Bosque del Hiloche", content: "Los viejos del pueblo advierten: no camines solo por el bosque después del crepúsculo. Los duendes te confunden el camino y despiertas perdido...", image: null },
  { title: "La Campana que Suena Sola", location: "Parroquia de la Asunción", content: "Cada noche de difuntos, la campana de la parroquia tañe tres veces sin que nadie la toque. Son los mineros pidiendo que no los olviden...", image: rdmPanteon },
];

export default function Relatos() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background relative">
        <CinematicMist intensity={0.5} />
        <Navbar />
        <section className="pt-28 pb-24 px-6 relative z-10">
          <div className="container max-w-3xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Relatos y Leyendas</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Historias que se susurran entre la niebla y los callejones de Real del Monte.
                </p>
              </div>
            </TextReveal>
            <div className="space-y-8">
              {relatos.map((r, i) => (
                <div key={i} className="rounded-2xl border border-border bg-card card-glow-hover overflow-hidden">
                  {r.image && (
                    <div className="aspect-[21/9] overflow-hidden">
                      <img src={r.image} alt={r.title} loading="lazy" className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="p-6 md:p-8">
                    <div className="flex items-center gap-3 mb-4">
                      <Ghost className="w-5 h-5 text-accent" />
                      <span className="text-xs text-gold font-body uppercase tracking-widest">{r.location}</span>
                    </div>
                    <h3 className="font-display text-2xl font-semibold text-foreground mb-3">{r.title}</h3>
                    <p className="text-sm text-muted-foreground font-body leading-relaxed italic">"{r.content}"</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
