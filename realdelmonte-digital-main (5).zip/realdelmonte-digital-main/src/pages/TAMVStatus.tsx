import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  Cpu,
  Database,
  Radio,
  RefreshCw,
  Shield,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { SEOMeta } from "@/components/SEOMeta";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiGet } from "@/lib/apiClient";
import { getNodeZeroCompletion } from "@/data/rdmNodeZero";

interface MsrStatus {
  node: string;
  version: string;
  federation: string;
  layers: string[];
  protocols: string[];
  quantumEncryption: boolean;
  msrBridge: string;
  bookpiAnchor: string;
  citizens: number;
  proposals: number;
  decisions: number;
  timestamp: string;
}

const completion = getNodeZeroCompletion();

const buildFallbackStatus = (): MsrStatus => ({
  node: "TAMV-RDM-NODO-CERO",
  version: "1.0.0-local-fusion",
  federation: "Triple Federado · conceptual / legal / técnica",
  layers: [
    "L0 Tierra",
    "L1 Datos",
    "L2 Gemelo",
    "L3 Telemetría",
    "L4 IA",
    "L5 Simulación",
    "L6 Experiencia",
    "L7 Civilización",
  ],
  protocols: [
    "BABAS",
    "Fénix Rex 4.0",
    "Chronus",
    "Autopoiesis",
    "BookPI",
    "ANUBIS-ZK",
    "Phoenix 20/30/50",
  ],
  quantumEncryption: true,
  msrBridge: "offline-fallback://rdm-digital/current-repo",
  bookpiAnchor: "bookpi://rdm-node-zero/local-ledger",
  citizens: completion.absorbed,
  proposals: completion.repos,
  decisions: completion.maturity,
  timestamp: new Date().toISOString(),
});

const Row = ({
  label,
  value,
}: {
  label: string;
  value: string | number | boolean;
}) => (
  <div className="flex items-start justify-between gap-4 border-b border-border/50 py-2 last:border-b-0">
    <span className="text-muted-foreground">{label}</span>
    <span className="max-w-[60%] text-right font-mono text-foreground/90">
      {String(value)}
    </span>
  </div>
);

export default function TAMVStatus() {
  const [status, setStatus] = useState<MsrStatus>(() => buildFallbackStatus());
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState(
    "Snapshot local activo — sincronización remota pendiente.",
  );

  const load = async () => {
    setLoading(true);
    setNotice("Sincronizando con /api/tamv/msr/status...");
    try {
      const data = await apiGet<MsrStatus>("/api/tamv/msr/status");
      setStatus(data);
      setNotice("Backend federado sincronizado correctamente.");
    } catch (error) {
      setStatus(buildFallbackStatus());
      setNotice(
        error instanceof Error
          ? `Backend offline — usando snapshot local: ${error.message}`
          : "Backend offline — usando snapshot local.",
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  return (
    <PageTransition>
      <SEOMeta
        title="Estado del Nodo Cero TAMV"
        description="Telemetría operativa del Nodo Cero RDM: capas federadas, protocolos, MSR Bridge y anclaje BookPI."
      />
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pb-24 pt-32">
          <motion.header
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto mb-12 max-w-4xl text-center"
          >
            <Badge
              variant="outline"
              className="mb-4 border-accent/30 bg-accent/10 text-accent"
            >
              <Radio className="mr-2 h-3.5 w-3.5" /> Telemetría MSR
            </Badge>
            <h1 className="font-display text-4xl text-foreground md:text-6xl">
              Nodo Cero <span className="text-gradient-gold">en ejecución</span>
            </h1>
            <p className="mx-auto mt-4 max-w-2xl font-body text-muted-foreground">
              Estado vivo absorbido de RDM-Digital-X: intenta consultar el
              backend federado y, si no existe, mantiene un snapshot local
              auditable para no dejar funciones incompletas.
            </p>
          </motion.header>

          <div className="mb-6 flex flex-col items-start justify-between gap-3 rounded-xl border border-gold/20 bg-gold/5 p-4 md:flex-row md:items-center">
            <p className="font-body text-xs text-gold">{notice}</p>
            <Button
              onClick={load}
              disabled={loading}
              variant="outline"
              size="sm"
              className="border-gold/30"
            >
              <RefreshCw
                className={`mr-2 h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`}
              />{" "}
              Sincronizar
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-gold/20 bg-card/60 backdrop-blur-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-display text-base">
                  <Cpu className="h-4 w-4 text-gold" /> Identidad
                </CardTitle>
              </CardHeader>
              <CardContent className="font-body text-xs">
                <Row label="Nodo" value={status.node} />
                <Row label="Versión" value={status.version} />
                <Row label="Federación" value={status.federation} />
                <Row
                  label="Sello"
                  value={new Date(status.timestamp).toLocaleString()}
                />
              </CardContent>
            </Card>

            <Card className="border-accent/20 bg-card/60 backdrop-blur-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-display text-base">
                  <Activity className="h-4 w-4 text-accent" /> Capas federadas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {status.layers.map((layer) => (
                    <div
                      key={layer}
                      className="rounded-lg border border-accent/20 bg-accent/10 p-2 text-center font-mono text-[11px] text-accent"
                    >
                      {layer}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-gold/20 bg-card/60 backdrop-blur-md">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-display text-base">
                  <Shield className="h-4 w-4 text-gold" /> Protocolos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {status.protocols.map((protocol) => (
                    <Badge
                      key={protocol}
                      variant="secondary"
                      className="bg-secondary/60 font-mono text-[10px]"
                    >
                      {protocol}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card/60 backdrop-blur-md md:col-span-2 lg:col-span-3">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-display text-base">
                  <Database className="h-4 w-4 text-accent" /> Ledger operativo
                </CardTitle>
              </CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-3">
                <Row label="MSR Bridge" value={status.msrBridge} />
                <Row label="BookPI" value={status.bookpiAnchor} />
                <Row
                  label="PQC"
                  value={status.quantumEncryption ? "activo" : "pendiente"}
                />
                <Row label="Repos absorbidos" value={status.citizens} />
                <Row label="Repos auditados" value={status.proposals} />
                <Row label="Madurez" value={`${status.decisions}%`} />
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
