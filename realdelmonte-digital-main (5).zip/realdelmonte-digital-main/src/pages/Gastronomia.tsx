import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem, GlowCard } from "@/components/VisualEffects";
import { Star } from "lucide-react";
import rdmPastes from "@/assets/rdm-pastes-close.jpg";
import rdmCafe from "@/assets/rdm-cafe.jpg";

const dishes = [
  { name: "Paste Tradicional", category: "Herencia Cornish", rating: 5.0, desc: "El icónico empanada horneada traída por los mineros ingleses en 1824. Relleno de papa con carne.", image: rdmPastes },
  { name: "Café de Olla", category: "Bebida Típica", rating: 4.8, desc: "Café preparado con piloncillo, canela y olla de barro. El abrazo perfecto en el frío de la montaña.", image: rdmCafe },
  { name: "Barbacoa de Borrego", category: "Tradición Hidalguense", rating: 4.9, desc: "Preparada en horno de tierra durante toda la noche. Servida con consomé y tortillas recién hechas.", image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=600" },
  { name: "Pulque Curado", category: "Bebida Ancestral", rating: 4.7, desc: "Bebida prehispánica de maguey curada con frutas de temporada. Tradición viva de la sierra.", image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600" },
  { name: "Mixiotes", category: "Herencia Otomí", rating: 4.8, desc: "Carne envuelta en penca de maguey y cocinada al vapor con chiles y hierbas.", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600" },
  { name: "Paste de Mole", category: "Fusión Local", rating: 4.6, desc: "Innovación realmontense: el paste tradicional relleno de mole con pollo.", image: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=600" },
];

export default function Gastronomia() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Gastronomía Local</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Cuna del paste y hogar de sabores únicos que fusionan la herencia inglesa con la tradición mexicana.
                </p>
              </div>
            </TextReveal>

            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {dishes.map((d) => (
                <StaggerItem key={d.name}>
                  <GlowCard>
                    <div className="rounded-2xl border border-border bg-card overflow-hidden group">
                      <div className="aspect-video overflow-hidden">
                        <img src={d.image} alt={d.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                      </div>
                      <div className="p-5">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] uppercase tracking-widest text-terracotta font-body">{d.category}</span>
                          <div className="flex items-center gap-1 text-gold text-xs"><Star className="w-3 h-3 fill-current" />{d.rating}</div>
                        </div>
                        <h3 className="font-display text-lg font-semibold text-foreground mb-1">{d.name}</h3>
                        <p className="text-xs text-muted-foreground font-body">{d.desc}</p>
                      </div>
                    </div>
                  </GlowCard>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
