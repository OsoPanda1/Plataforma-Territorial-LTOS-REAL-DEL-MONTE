import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal } from "@/components/VisualEffects";
import { Shield, Heart, AlertTriangle, FileText } from "lucide-react";

export default function Reglamento() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-3xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Reglamento</h1>
                <p className="text-muted-foreground font-body">Normas de uso y convivencia de la plataforma RDM Digital.</p>
              </div>
            </TextReveal>
            <div className="space-y-6">
              {[
                { icon: Heart, title: "Respeto Comunitario", content: "Trata a todos los usuarios con respeto. No se tolera acoso, discriminación ni contenido ofensivo." },
                { icon: Shield, title: "Protección de Datos", content: "Tus datos son tratados con estándares de seguridad de grado militar. No compartimos información con terceros." },
                { icon: AlertTriangle, title: "Contenido Responsable", content: "Publica solo contenido veraz y constructivo. La desinformación será moderada por Isabella AI." },
                { icon: FileText, title: "Propiedad Intelectual", content: "Respeta los derechos de autor. El contenido original de RDM Digital es propiedad de TAMV Enterprise." },
              ].map((r) => (
                <div key={r.title} className="p-6 rounded-2xl border border-border bg-card">
                  <div className="flex items-center gap-3 mb-3">
                    <r.icon className="w-5 h-5 text-accent" />
                    <h3 className="font-display text-lg font-semibold text-foreground">{r.title}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground font-body">{r.content}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
