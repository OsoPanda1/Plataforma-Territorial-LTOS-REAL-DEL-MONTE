import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Sparkles, ChevronRight, Database, Brain, MapPin, Download, MessageCircle } from "lucide-react";
import jsPDF from "jspdf";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import SEOMeta from "@/components/SEOMeta";
import { RDM_CORPUS, type CorpusSection, type CorpusEntry } from "@/data/rdmCorpus";

function askRealito(entry: CorpusEntry) {
  const question = `Cuéntame más sobre "${entry.title}" en Real del Monte. Contexto: ${entry.body.slice(0, 220)}…`;
  window.dispatchEvent(new CustomEvent("realito:prefill", { detail: { question, autoSend: false } }));
}


const ACCENT_MAP: Record<CorpusSection["accent"], { from: string; ring: string; text: string }> = {
  gold: { from: "from-gold/30", ring: "ring-gold/30", text: "text-gold" },
  electric: { from: "from-electric/30", ring: "ring-electric/30", text: "text-electric" },
  terracotta: { from: "from-terracotta/30", ring: "ring-terracotta/30", text: "text-terracotta" },
  forest: { from: "from-forest/30", ring: "ring-forest/30", text: "text-forest" },
  copper: { from: "from-copper/30", ring: "ring-copper/30", text: "text-copper" },
};

const QuantumBackground = () => (
  <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
    <div className="absolute inset-0 bg-[hsl(220_30%_4%)]" />
    <div
      className="absolute inset-0 opacity-[0.14]"
      style={{
        backgroundImage:
          "linear-gradient(hsl(var(--electric) / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--electric) / 0.3) 1px, transparent 1px)",
        backgroundSize: "64px 64px",
        maskImage: "radial-gradient(ellipse 80% 60% at 50% 30%, black 30%, transparent 80%)",
        WebkitMaskImage: "radial-gradient(ellipse 80% 60% at 50% 30%, black 30%, transparent 80%)",
      }}
    />
    <motion.div
      className="absolute -top-40 left-1/3 h-[600px] w-[600px] rounded-full"
      style={{ background: "radial-gradient(circle, hsl(var(--electric) / 0.16), transparent 70%)" }}
      animate={{ x: [0, 40, -20, 0], y: [0, -30, 20, 0] }}
      transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
    />
    <motion.div
      className="absolute -bottom-40 -right-40 h-[700px] w-[700px] rounded-full"
      style={{ background: "radial-gradient(circle, hsl(var(--gold) / 0.1), transparent 70%)" }}
      animate={{ x: [0, -30, 20, 0], y: [0, 30, -20, 0] }}
      transition={{ duration: 24, repeat: Infinity, ease: "easeInOut" }}
    />
  </div>
);

const EntryCard = ({ entry, accent }: { entry: CorpusEntry; accent: CorpusSection["accent"] }) => {
  const [open, setOpen] = useState(false);
  const a = ACCENT_MAP[accent];
  return (
    <motion.div
      layout
      onClick={() => setOpen((v) => !v)}
      whileHover={{ y: -3 }}
      className="group relative cursor-pointer overflow-hidden rounded-2xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.75)] p-6 backdrop-blur-xl"
      style={{ boxShadow: "0 1px 0 hsl(var(--electric) / 0.06) inset, 0 20px 60px -30px hsl(0 0% 0% / 0.8)" }}
    >
      <div
        className={`pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full bg-gradient-radial opacity-0 transition-opacity duration-500 group-hover:opacity-100 ${a.from} to-transparent`}
        style={{ background: `radial-gradient(circle, hsl(var(--${accent}) / 0.35), transparent 70%)` }}
      />
      <div className="relative">
        <div className="mb-3 flex items-start justify-between gap-3">
          <h3 className="font-display text-xl leading-tight text-foreground">{entry.title}</h3>
          {entry.era && (
            <Badge variant="outline" className={`shrink-0 border-white/10 bg-white/[0.03] font-mono text-[10px] tracking-wider ${a.text}`}>
              {entry.era}
            </Badge>
          )}
        </div>
        <p className={`text-sm leading-relaxed text-muted-foreground ${open ? "" : "line-clamp-3"}`}>{entry.body}</p>

        <AnimatePresence initial={false}>
          {open && entry.highlights && (
            <motion.div
              key="hl"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="mt-4 flex flex-wrap gap-1.5">
                {entry.highlights.map((h) => (
                  <span
                    key={h}
                    className="rounded-full border border-white/[0.06] bg-black/30 px-2.5 py-1 font-mono text-[10px] tracking-wider text-foreground/70"
                  >
                    {h}
                  </span>
                ))}
              </div>
              {entry.coords && (
                <div className="mt-3 flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground">
                  <MapPin className={`h-3 w-3 ${a.text}`} />
                  {entry.coords.lat.toFixed(4)}, {entry.coords.lng.toFixed(4)}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider text-muted-foreground">
            <ChevronRight className={`h-3 w-3 transition-transform ${open ? "rotate-90" : ""}`} />
            {open ? "Cerrar" : "Expandir"}
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); askRealito(entry); }}
            className={`inline-flex items-center gap-1 rounded-full border border-white/[0.08] bg-black/30 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider transition-colors hover:bg-black/50 ${a.text}`}
            aria-label={`Preguntar a Realito sobre ${entry.title}`}
          >
            <MessageCircle className="h-3 w-3" />
            Preguntar
          </button>
        </div>

      </div>
    </motion.div>
  );
};

export default function Corpus() {
  const [q, setQ] = useState("");
  const [activeSection, setActiveSection] = useState<string>("all");

  const filtered = useMemo(() => {
    const query = q.toLowerCase();
    return RDM_CORPUS.map((s) => ({
      ...s,
      entries: s.entries.filter((e) => {
        if (activeSection !== "all" && s.id !== activeSection) return false;
        if (!query) return true;
        return (
          e.title.toLowerCase().includes(query) ||
          e.body.toLowerCase().includes(query) ||
          e.era?.toLowerCase().includes(query) ||
          e.highlights?.some((h) => h.toLowerCase().includes(query))
        );
      }),
    })).filter((s) => s.entries.length > 0);
  }, [q, activeSection]);

  const totalEntries = RDM_CORPUS.reduce((acc, s) => acc + s.entries.length, 0);
  const filteredCount = filtered.reduce((acc, s) => acc + s.entries.length, 0);

  const exportPDF = () => {
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const W = doc.internal.pageSize.getWidth();
    const H = doc.internal.pageSize.getHeight();
    const M = 48;
    let y = M;

    const ensure = (need: number) => {
      if (y + need > H - M) { doc.addPage(); y = M; }
    };
    const writeWrapped = (text: string, size: number, opts?: { bold?: boolean; color?: [number, number, number] }) => {
      doc.setFont("helvetica", opts?.bold ? "bold" : "normal");
      doc.setFontSize(size);
      const [r, g, b] = opts?.color ?? [30, 30, 30];
      doc.setTextColor(r, g, b);
      const lines = doc.splitTextToSize(text, W - M * 2);
      for (const line of lines) {
        ensure(size + 4);
        doc.text(line, M, y);
        y += size + 4;
      }
    };

    // Cover
    doc.setFillColor(10, 14, 26);
    doc.rect(0, 0, W, H, "F");
    doc.setTextColor(230, 230, 240);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(28);
    doc.text("CORPUS MAXIMUS", M, 160);
    doc.setFontSize(14);
    doc.setTextColor(120, 180, 255);
    doc.text("Real del Monte · RDM Digital", M, 188);
    doc.setFontSize(10);
    doc.setTextColor(180, 180, 200);
    doc.text(`Generado: ${new Date().toLocaleString("es-MX")}`, M, 212);
    doc.text(`Filtro: ${activeSection === "all" ? "Todas las secciones" : activeSection}`, M, 228);
    if (q) doc.text(`Búsqueda: "${q}"`, M, 244);
    doc.text(`${filteredCount} entradas · ${filtered.length} secciones`, M, q ? 260 : 244);

    doc.addPage();
    y = M;

    filtered.forEach((section) => {
      ensure(60);
      writeWrapped(`${section.glyph}  ${section.label.toUpperCase()}`, 16, { bold: true, color: [20, 60, 120] });
      writeWrapped(section.tagline, 10, { color: [110, 110, 120] });
      y += 6;
      section.entries.forEach((entry) => {
        ensure(40);
        writeWrapped(entry.title + (entry.era ? `  (${entry.era})` : ""), 13, { bold: true, color: [30, 30, 30] });
        writeWrapped(entry.body, 10, { color: [55, 55, 60] });
        if (entry.highlights?.length) {
          writeWrapped("• " + entry.highlights.join("  ·  "), 9, { color: [100, 100, 110] });
        }
        if (entry.coords) {
          writeWrapped(`📍 ${entry.coords.lat.toFixed(5)}, ${entry.coords.lng.toFixed(5)}`, 9, { color: [100, 100, 110] });
        }
        y += 10;
      });
      y += 12;
    });

    const total = doc.getNumberOfPages();
    for (let i = 1; i <= total; i++) {
      doc.setPage(i);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(140, 140, 150);
      doc.text(`RDM Digital · ISABELLA v4.0   ·   ${i} / ${total}`, W / 2, H - 20, { align: "center" });
    }

    const slug = activeSection === "all" ? "completo" : activeSection;
    const qSlug = q ? `-${q.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 24)}` : "";
    doc.save(`corpus-rdm-${slug}${qSlug}.pdf`);
  };


  return (
    <PageTransition>
      <SEOMeta
        title="Corpus Maximus · Conocimiento Total · Real del Monte"
        description="Omnisciencia territorial RDM 2026: historia, cultura, gastronomía, museografía y ecoturismo de Mineral del Monte, Hidalgo."
        canonical="/corpus"
      />
      <div className="relative min-h-screen bg-background">
        <QuantumBackground />
        <Navbar />

        <main className="relative z-10">
          {/* HERO */}
          <section className="px-6 pb-10 pt-28">
            <div className="container max-w-6xl">
              <div className="grid items-end gap-10 md:grid-cols-[1fr_auto]">
                <div>
                  <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-electric/20 bg-electric/5 px-3 py-1">
                    <Database className="h-3 w-3 text-electric" />
                    <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-electric">Data Lake · Nivel 0 · Público</span>
                  </div>
                  <h1 className="mb-4 font-display text-5xl font-bold leading-[0.95] tracking-tight text-foreground md:text-7xl">
                    Corpus{" "}
                    <span className="text-gradient-electric italic">Maximus</span>
                  </h1>
                  <p className="max-w-2xl text-base leading-relaxed text-muted-foreground">
                    Omnisciencia territorial de Mineral del Monte. Cada dato histórico, cultural y geográfico
                    expandido al máximo. Vinculado al{" "}
                    <span className="text-foreground/90">Neural Memory Mesh™ de ISABELLA v4.0</span> y consumido en
                    tiempo real por Realito AI.
                  </p>
                </div>
                <div className="flex gap-3">
                  <div className="rounded-xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] p-4 backdrop-blur-xl">
                    <p className="font-display text-4xl font-bold text-electric">{totalEntries}</p>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Entradas</p>
                  </div>
                  <div className="rounded-xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] p-4 backdrop-blur-xl">
                    <p className="font-display text-4xl font-bold text-gold">{RDM_CORPUS.length}</p>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Secciones</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* CONTROLS */}
          <section className="sticky top-16 z-30 px-6 py-4 backdrop-blur-xl">
            <div className="container max-w-6xl">
              <div className="rounded-2xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.85)] p-3">
                <div className="relative mb-3 flex gap-2">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Buscar paste, Trevithick, silicosis, Zelontla, Peñas Cargadas…"
                      value={q}
                      onChange={(e) => setQ(e.target.value)}
                      className="border-white/[0.06] bg-black/30 pl-9 font-mono text-sm focus-visible:ring-electric"
                    />
                  </div>
                  <Button
                    type="button"
                    onClick={exportPDF}
                    disabled={filteredCount === 0}
                    variant="outline"
                    className="shrink-0 gap-2 border-electric/30 bg-electric/10 font-mono text-[11px] uppercase tracking-wider text-electric hover:bg-electric/20 hover:text-electric"
                    title="Exportar el corpus filtrado a PDF"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">PDF ({filteredCount})</span>
                  </Button>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  <button
                    onClick={() => setActiveSection("all")}
                    className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider transition-all ${
                      activeSection === "all"
                        ? "border-electric/40 bg-electric/10 text-electric"
                        : "border-white/[0.06] bg-black/20 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    ◈ Todas
                  </button>
                  {RDM_CORPUS.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setActiveSection(s.id)}
                      className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider transition-all ${
                        activeSection === s.id
                          ? `border-${s.accent}/40 bg-${s.accent}/10 ${ACCENT_MAP[s.accent].text}`
                          : "border-white/[0.06] bg-black/20 text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <span className="mr-1">{s.glyph}</span>
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* SECTIONS */}
          <section className="px-6 py-12">
            <div className="container max-w-6xl space-y-16">
              <AnimatePresence mode="popLayout">
                {filtered.map((section) => {
                  const a = ACCENT_MAP[section.accent];
                  return (
                    <motion.div
                      key={section.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      <div className="mb-6 flex items-end justify-between gap-4 border-b border-white/[0.05] pb-4">
                        <div>
                          <div className="mb-1 flex items-center gap-2">
                            <span className="text-2xl">{section.glyph}</span>
                            <span className={`font-mono text-[10px] uppercase tracking-[0.3em] ${a.text}`}>
                              Sección · {section.id}
                            </span>
                          </div>
                          <h2 className="font-display text-3xl text-foreground md:text-4xl">{section.label}</h2>
                          <p className="mt-1 text-sm text-muted-foreground">{section.tagline}</p>
                        </div>
                        <span className={`shrink-0 font-mono text-xs ${a.text}`}>
                          {section.entries.length} {section.entries.length === 1 ? "entrada" : "entradas"}
                        </span>
                      </div>
                      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                        {section.entries.map((entry) => (
                          <EntryCard key={entry.id} entry={entry} accent={section.accent} />
                        ))}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {filtered.length === 0 && (
                <div className="py-24 text-center">
                  <Sparkles className="mx-auto mb-4 h-10 w-10 text-muted-foreground/40" />
                  <p className="font-mono text-sm uppercase tracking-wider text-muted-foreground">
                    Sin coincidencias en el corpus
                  </p>
                </div>
              )}
            </div>
          </section>

          {/* CTA */}
          <section className="px-6 py-16">
            <div className="container max-w-4xl">
              <div className="relative overflow-hidden rounded-3xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] p-10 text-center backdrop-blur-xl">
                <div
                  className="pointer-events-none absolute -top-32 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full"
                  style={{ background: "radial-gradient(circle, hsl(var(--electric) / 0.25), transparent 70%)" }}
                />
                <div className="relative">
                  <Brain className="mx-auto mb-4 h-8 w-8 text-electric" />
                  <h2 className="mb-3 font-display text-3xl font-semibold text-foreground">
                    Pregúntale a Realito
                  </h2>
                  <p className="mx-auto mb-6 max-w-lg text-sm leading-relaxed text-muted-foreground">
                    Todo este corpus está cargado en la memoria de ISABELLA AI v4.0. Abre el chat flotante de Realito
                    y pregúntale lo que quieras sobre Real del Monte: historia, gastronomía, museos, leyendas.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </PageTransition>
  );
}
