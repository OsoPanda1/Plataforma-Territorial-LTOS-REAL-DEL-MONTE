import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { ArrowLeft, BriefcaseBusiness, Loader2, UserRound } from "lucide-react";
import { awardGamificationEvent } from "@/services/gamification";

type AccountType = "visitor" | "merchant";

const resolveDestination = (accountType: AccountType, next?: string | null) => {
  if (next?.startsWith("/")) return next;
  return accountType === "merchant" ? "/negocios" : "/admin";
};

export default function Auth() {
  const [searchParams] = useSearchParams();
  const initialAccountType: AccountType = searchParams.get("type") === "merchant" ? "merchant" : "visitor";
  const [isSignUp, setIsSignUp] = useState(searchParams.get("mode") === "signup");
  const [accountType, setAccountType] = useState<AccountType>(initialAccountType);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const next = searchParams.get("next");

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      if (!session) return;
      const metadataType = session.user.user_metadata?.account_type as AccountType | undefined;
      navigate(resolveDestination(metadataType ?? accountType, next), { replace: true });
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) return;
      const metadataType = session.user.user_metadata?.account_type as AccountType | undefined;
      navigate(resolveDestination(metadataType ?? accountType, next), { replace: true });
    });
    return () => subscription.unsubscribe();
  }, [accountType, navigate, next]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isSignUp) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              display_name: displayName,
              account_type: accountType,
              onboarding_intent: accountType === "merchant" ? "business_registration" : "territorial_explorer",
            },
            emailRedirectTo: `${window.location.origin}${resolveDestination(accountType, next)}`,
          },
        });
        if (error) throw error;
        await awardGamificationEvent("account_created", { accountType }, data.user?.id ?? "local");
        toast.success(accountType === "merchant" ? "Cuenta comerciante creada" : "Cuenta creada", {
          description: data.session ? "Redirigiendo al siguiente paso." : "Revisa tu correo para confirmar y continuar.",
        });
        if (data.session) navigate(resolveDestination(accountType, next), { replace: true });
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const metadataType = data.user?.user_metadata?.account_type as AccountType | undefined;
        toast.success("¡Bienvenido a RDM Digital!");
        navigate(resolveDestination(metadataType ?? accountType, next), { replace: true });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Error de autenticación");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background pointer-events-none" />
      <div className="absolute inset-0 opacity-10"
        style={{ backgroundImage: "linear-gradient(hsl(var(--border)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)", backgroundSize: "60px 60px" }} />
      <div className="relative z-10 w-full max-w-md">
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-accent transition-colors mb-8 font-body">
          <ArrowLeft className="w-4 h-4" /> Volver
        </Link>
        <div className="p-8 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center border border-accent/30">
              <span className="font-display text-sm font-bold text-accent">R</span>
            </div>
            <span className="font-display text-lg tracking-wider text-foreground">RDM <span className="text-accent">Digital</span></span>
          </div>
          <h1 className="font-display text-2xl font-bold text-foreground mb-1">{isSignUp ? "Crear Cuenta" : "Iniciar Sesión"}</h1>
          <p className="text-sm text-muted-foreground font-body mb-6">{isSignUp ? "Elige si entras como visitante o como negocio local." : "Accede al panel de control"}</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { id: "visitor" as const, label: "Usuario", icon: UserRound, desc: "Rutas, logros y REALITO" },
                    { id: "merchant" as const, label: "Comercio", icon: BriefcaseBusiness, desc: "Registro y pagos" },
                  ].map((option) => {
                    const Icon = option.icon;
                    const active = accountType === option.id;
                    return (
                      <button
                        type="button"
                        key={option.id}
                        onClick={() => setAccountType(option.id)}
                        className={`rounded-xl border p-3 text-left transition-all ${active ? "border-accent bg-accent/10 text-foreground" : "border-border bg-secondary/40 text-muted-foreground hover:border-accent/50"}`}
                      >
                        <Icon className="w-4 h-4 mb-2" />
                        <span className="block text-sm font-semibold font-body">{option.label}</span>
                        <span className="text-[10px] font-body">{option.desc}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-foreground font-body">Nombre</Label>
                  <Input id="name" value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Tu nombre" required className="bg-secondary border-border text-foreground" />
                </div>
              </>
            )}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground font-body">Correo electrónico</Label>
              <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="correo@ejemplo.com" required className="bg-secondary border-border text-foreground" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground font-body">Contraseña</Label>
              <Input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required minLength={6} className="bg-secondary border-border text-foreground" />
            </div>
            <Button type="submit" disabled={loading} className="w-full bg-accent text-accent-foreground hover:bg-accent/90 glow-electric">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : isSignUp ? "Crear Cuenta" : "Iniciar Sesión"}
            </Button>
          </form>
          <p className="text-sm text-muted-foreground font-body mt-6 text-center">
            {isSignUp ? "¿Ya tienes cuenta?" : "¿No tienes cuenta?"}{" "}
            <button onClick={() => setIsSignUp(!isSignUp)} className="text-accent hover:underline">{isSignUp ? "Inicia sesión" : "Regístrate"}</button>
          </p>
        </div>
      </div>
    </div>
  );
}
