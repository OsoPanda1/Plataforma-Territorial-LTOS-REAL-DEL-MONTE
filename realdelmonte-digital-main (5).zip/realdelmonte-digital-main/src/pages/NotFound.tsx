import { Link } from "react-router-dom";
import { MapPin } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center px-6">
        <div className="w-16 h-16 rounded-2xl bg-accent/20 border border-accent/30 flex items-center justify-center mx-auto mb-6">
          <MapPin className="w-8 h-8 text-accent" />
        </div>
        <h1 className="font-display text-6xl font-bold text-foreground mb-4">404</h1>
        <p className="text-lg text-muted-foreground font-body mb-8">Esta ruta no existe en el Gemelo Digital</p>
        <Link to="/" className="inline-flex items-center gap-2 rounded-xl bg-accent px-6 py-3 font-body font-semibold text-accent-foreground hover:bg-accent/90 glow-electric">
          Volver al Inicio
        </Link>
      </div>
    </div>
  );
}
