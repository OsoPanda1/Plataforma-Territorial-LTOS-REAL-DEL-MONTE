import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem, GlowCard } from "@/components/VisualEffects";
import { TreePine, Mountain, Footprints, Tent, Camera, Sun } from "lucide-react";
import rdmSierra from "@/assets/rdm-sierra-ecoturismo.jpg";
import rdmMirador from "@/assets/rdm-mirador.jpg";

const activities = [
  { icon: Mountain, title: "Peña del Cuervo", desc: "Mirador natural con panorámica del Valle de México. Caminata de 2 horas.", difficulty: "Moderada", image: rdmMirador },
  { icon: TreePine, title: "Senderos del Hiloche", desc: "Recorridos entre pinos y oyameles con biodiversidad única.", difficulty: "Fácil", image: rdmSierra },
  { icon: Footprints, title: "Ruta de las Minas", desc: "Camina por los senderos que usaban los mineros hace 460 años.", difficulty: "Moderada" },
  { icon: Tent, title: "Camping en la Sierra", desc: "Zonas de acampado con vistas impresionantes a las montañas.", difficulty: "Avanzada" },
  { icon: Camera, title: "Fotografía de Niebla", desc: "Tours fotográficos en las mañanas más neblinosas del pueblo.", difficulty: "Fácil" },
  { icon: Sun, title: "Amanecer en la Montaña", desc: "Excursión al amanecer para ver el sol nacer sobre la sierra.", difficulty: "Moderada" },
];

export default function Ecoturismo() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Hero banner */}
        <section className="pt-24 pb-8 px-6">
          <div className="container max-w-6xl">
            <div className="rounded-2xl overflow-hidden border border-border">
              <img src={rdmSierra} alt="Sierra de Pachuca" className="w-full h-48 md:h-72 object-cover" />
              <div className="p-4 bg-card">
                <p className="text-sm text-muted-foreground font-body text-center">
                  Sierra de Pachuca — Naturaleza a 2,700 metros de altitud
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Ecoturismo y Aventura</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Naturaleza, senderos y paisajes a 2,700 metros de altura en la Sierra de Pachuca.
                </p>
              </div>
            </TextReveal>
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activities.map((a) => (
                <StaggerItem key={a.title}>
                  <GlowCard>
                    <div className="rounded-2xl border border-border bg-card overflow-hidden group">
                      {"image" in a && a.image ? (
                        <div className="aspect-video overflow-hidden">
                          <img src={a.image} alt={a.title} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        </div>
                      ) : (
                        <div className="aspect-video bg-secondary/20 flex items-center justify-center">
                          <a.icon className="w-12 h-12 text-forest/30" />
                        </div>
                      )}
                      <div className="p-5">
                        <div className="flex items-center justify-between mb-2">
                          <a.icon className="w-5 h-5 text-forest" />
                          <span className={`text-[10px] uppercase tracking-widest font-body px-2 py-0.5 rounded-full border ${
                            a.difficulty === 'Fácil' ? 'text-success border-success/30 bg-success/10' :
                            a.difficulty === 'Moderada' ? 'text-gold border-gold/30 bg-gold/10' :
                            'text-terracotta border-terracotta/30 bg-terracotta/10'
                          }`}>{a.difficulty}</span>
                        </div>
                        <h3 className="font-display text-lg font-semibold text-foreground mb-1">{a.title}</h3>
                        <p className="text-xs text-muted-foreground font-body">{a.desc}</p>
                      </div>
                    </div>
                  </GlowCard>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
