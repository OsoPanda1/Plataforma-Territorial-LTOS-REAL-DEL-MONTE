import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem } from "@/components/VisualEffects";
import { Music, Palette, Calendar, Crown, Flame } from "lucide-react";
import rdmDiaMuertos from "@/assets/rdm-dia-muertos.jpg";
import rdmFestival from "@/assets/rdm-festival.jpg";
import rdmPanteon from "@/assets/rdm-panteon-ingles.jpg";

const traditions = [
  { icon: Flame, title: "Día de Muertos", desc: "Celebración ancestral que cobra vida especial en el Panteón Inglés, con ofrendas y calaveritas literarias.", image: rdmDiaMuertos },
  { icon: Crown, title: "Herencia Cornish", desc: "Los mineros ingleses dejaron su huella: pastes, fútbol y un cementerio único donde las tumbas miran hacia Inglaterra.", image: rdmPanteon },
  { icon: Calendar, title: "Fiestas Patronales", desc: "Cada barrio celebra a su santo con procesiones, castillos y comida tradicional.", image: rdmFestival },
  { icon: Music, title: "Bandas de Viento", desc: "La música de banda acompaña fiestas patronales, bodas y celebraciones comunitarias del pueblo." },
  { icon: Palette, title: "Artesanías Mineras", desc: "Piezas en metal, piedra y madera que preservan la memoria de siglos de minería en la sierra." },
  { icon: Crown, title: "Leyendas Vivas", desc: "Fantasmas de mineros, tesoros escondidos y apariciones que se cuentan de generación en generación." },
];

export default function Cultura() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Cultura y Tradiciones</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  La mezcla de herencia inglesa, raíces mexicanas y tradición minera que hace único a Real del Monte.
                </p>
              </div>
            </TextReveal>
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {traditions.map((t) => (
                <StaggerItem key={t.title}>
                  <div className="rounded-2xl border border-border bg-card h-full card-glow-hover overflow-hidden">
                    {"image" in t && t.image && (
                      <div className="aspect-video overflow-hidden">
                        <img src={t.image} alt={t.title} loading="lazy" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
                      </div>
                    )}
                    <div className="p-6">
                      <t.icon className="w-8 h-8 text-gold mb-4" />
                      <h3 className="font-display text-lg font-semibold text-foreground mb-2">{t.title}</h3>
                      <p className="text-sm text-muted-foreground font-body">{t.desc}</p>
                    </div>
                  </div>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
