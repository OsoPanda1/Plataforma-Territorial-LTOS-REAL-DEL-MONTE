import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal } from "@/components/VisualEffects";
import { Store, TrendingUp, Users, Shield, Zap, Crown, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { CommerceOnboarding, type CommerceFormState } from "@/components/commerce/CommerceOnboarding";
import { PROMO_LAUNCH, RDM_COMMERCE_TIERS } from "@/config/commerceTiers";
import { supabase } from "@/integrations/supabase/client";
import { awardGamificationEvent } from "@/services/gamification";
import { createCheckoutSession } from "@/services/payments";

const DEFAULT_BUSINESS_LOCATION = { latitude: 20.1384, longitude: -98.6735 };

const tierPrice = (tier: CommerceFormState["tier"]) => {
  if (!tier) return PROMO_LAUNCH.cost;
  return RDM_COMMERCE_TIERS.find((item) => item.level === tier)?.price ?? PROMO_LAUNCH.cost;
};

export default function NegociosPortal() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const navigate = useNavigate();

  const handleBusinessSubmit = async (data: CommerceFormState) => {
    const { data: sessionData } = await supabase.auth.getSession();
    const user = sessionData.session?.user;

    if (!user) {
      localStorage.setItem("rdm:pending-business", JSON.stringify(data));
      toast.info("Primero crea tu cuenta de comercio", {
        description: "Guardamos tu captura localmente y te regresamos al registro del negocio.",
      });
      navigate("/auth?mode=signup&type=merchant&next=/negocios");
      return;
    }

    const { error } = await supabase.from("businesses").insert({
      name: data.name.trim(),
      description: data.slogan.trim() || `Comercio local de ${data.giro} registrado en RDM Digital.`,
      category: data.giro,
      phone: data.phone,
      website: data.website || null,
      hours: `${data.days} · ${data.hours}`,
      address: "Real del Monte, Hidalgo",
      user_id: user.id,
      rating: 4.8,
      latitude: DEFAULT_BUSINESS_LOCATION.latitude,
      longitude: DEFAULT_BUSINESS_LOCATION.longitude,
    });

    if (error) throw error;

    localStorage.removeItem("rdm:pending-business");
    await awardGamificationEvent("business_registered", { name: data.name, tier: data.tier }, user.id);
    toast.success("Negocio registrado como nodo validado", {
      description: "Ahora abriremos el checkout del plan seleccionado.",
    });

    const checkout = await createCheckoutSession({
      userId: user.id,
      successPath: "/negocios?payment=success",
      cancelPath: "/negocios?payment=cancel",
      metadata: { type: "commerce_plan", tier: data.tier ?? "PROMO", business_name: data.name },
      items: [
        {
          name: data.tier ? `Plan RDM ${data.tier}` : PROMO_LAUNCH.label,
          amount: tierPrice(data.tier),
          quantity: 1,
          description: `${PROMO_LAUNCH.durationMonths} meses de activación territorial para ${data.name}`,
        },
      ],
    });

    if (checkout.url) {
      window.location.href = checkout.url;
      return;
    }

    toast.warning("Checkout offline generado", { description: checkout.message });
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Hero */}
        <section className="pt-28 pb-16 px-6">
          <div className="container max-w-4xl">
            <TextReveal>
              <div className="text-center mb-12">
                <span className="text-xs uppercase tracking-[0.3em] text-accent font-body">Federación 4 · Economía Soberana</span>
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4 mt-2">Portal de Negocios</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Únete al ecosistema digital soberano de Real del Monte. Tu negocio como nodo validado del ledger territorial.
                </p>
              </div>
            </TextReveal>

            {/* Promo banner */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl border border-gold/30 bg-gold/5 p-6 mb-12 text-center"
            >
              <div className="flex items-center justify-center gap-2 mb-2">
                <Zap className="w-5 h-5 text-gold" />
                <span className="font-display text-lg font-bold text-gold">Promo Lanzamiento</span>
              </div>
              <p className="text-sm text-muted-foreground font-body">
                <span className="text-gold font-semibold">${PROMO_LAUNCH.cost} MXN</span> por {PROMO_LAUNCH.durationMonths} meses con <span className="text-foreground">todas las funciones premium</span> incluidas
              </p>
            </motion.div>

            {/* Benefits grid */}
            <div className="grid md:grid-cols-2 gap-5 mb-12">
              {[
                { icon: TrendingUp, title: "Más Visibilidad", desc: "Tu negocio aparece en el mapa, directorio, Gemelo Digital y rutas recomendadas por Isabella AI." },
                { icon: Users, title: "Más Clientes", desc: "Campañas digitales en META y QR Maestro REALITO en puntos estratégicos del pueblo." },
                { icon: Shield, title: "Soberanía Local", desc: "La plataforma es del pueblo. Sin intermediarios, sin comisiones de plataformas externas. Ledger trazable." },
                { icon: Crown, title: "Nodo Validado", desc: "Cada comercio es un nodo verificado con identidad + mínima KYC local. Actualizaciones firmadas y trazables." },
              ].map((b, i) => (
                <motion.div
                  key={b.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-6 rounded-2xl border border-border bg-card card-glow-hover group"
                >
                  <b.icon className="w-7 h-7 text-accent mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="font-display text-lg font-semibold text-foreground mb-1">{b.title}</h3>
                  <p className="text-sm text-muted-foreground font-body leading-relaxed">{b.desc}</p>
                </motion.div>
              ))}
            </div>

            {/* CTA or Onboarding */}
            {!showOnboarding ? (
              <div className="text-center">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setShowOnboarding(true)}
                  className="inline-flex items-center gap-3 rounded-xl bg-accent px-10 py-4 font-body font-semibold text-accent-foreground hover:bg-accent/90 glow-electric transition-all"
                >
                  <Store className="w-5 h-5" />
                  Registrar mi Negocio
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
                <p className="text-xs text-muted-foreground font-body mt-3">3 pasos · 2 minutos · Cuenta + negocio + checkout</p>
              </div>
            ) : (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <CommerceOnboarding onSubmit={handleBusinessSubmit} />
              </motion.div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    </PageTransition>
  );
}
