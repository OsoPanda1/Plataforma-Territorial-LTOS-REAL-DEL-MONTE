import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { motion } from "framer-motion";
import {
  Network, MapPin, CheckCircle2, Circle,
  GraduationCap, Landmark, Coins, Cpu, HeartPulse, Radio, Scale,
  type LucideIcon,
} from "lucide-react";
import { RDM_FEDERATIONS, type Federation } from "@/data/rdmFederations";
import { RDM_TERRITORY_POIS } from "@/data/rdmTerritoryPOIs";

const FED_ICONS: Record<Federation["icon"], LucideIcon> = {
  "graduation-cap": GraduationCap,
  landmark: Landmark,
  coins: Coins,
  cpu: Cpu,
  "heart-pulse": HeartPulse,
  radio: Radio,
  scale: Scale,
};

const NODES = [
  { name: "Real del Monte", state: "Hidalgo", status: "active", role: "Nodo Cero · Capital soberana" },
  { name: "Mineral del Chico", state: "Hidalgo", status: "pending", role: "Nodo hermano · Sierra Norte" },
  { name: "Huasca de Ocampo", state: "Hidalgo", status: "pending", role: "Primer pueblo mágico de México" },
  { name: "Taxco", state: "Guerrero", status: "exploration", role: "Federación minera plata" },
  { name: "Tepoztlán", state: "Morelos", status: "exploration", role: "Federación mística" },
  { name: "Pátzcuaro", state: "Michoacán", status: "exploration", role: "Federación purépecha" },
];

const STATUS = {
  active: { label: "Activo", color: "hsl(142 70% 45%)", icon: CheckCircle2 },
  pending: { label: "Pendiente", color: "hsl(43 80% 55%)", icon: Circle },
  exploration: { label: "Exploración", color: "hsl(210 100% 65%)", icon: Circle },
} as const;

export default function Federacion() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pt-28 pb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-accent/40 bg-accent/5 mb-4">
              <Network className="w-3.5 h-3.5 text-accent" />
              <span className="text-[10px] tracking-[0.3em] uppercase text-accent font-body">Federación Soberana</span>
            </div>
            <h1 className="font-display text-4xl md:text-5xl text-foreground mb-4">
              Red de <span className="text-gradient-gold">Pueblos Soberanos</span>
            </h1>
            <p className="text-muted-foreground font-body">
              RDM Digital se federa con territorios hermanos y se organiza en 7 federaciones soberanas TAMV.
            </p>
          </motion.div>

          {/* 7 FEDERACIONES TAMV — datos canónicos */}
          <section className="mb-16">
            <h2 className="font-display text-2xl text-foreground mb-6 text-center">
              Las 7 Federaciones <span className="text-gradient-gold">TAMV</span>
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
              {RDM_FEDERATIONS.map((f, i) => {
                const Icon = FED_ICONS[f.icon] ?? Network;
                return (
                  <motion.article
                    key={f.id}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.04 }}
                    className="glass-card border border-border rounded-xl p-5 hover:border-accent/40 transition-all group"
                    style={{ boxShadow: `0 0 0 1px ${f.colorHex}15` }}
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div
                        className="w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0 border"
                        style={{ background: `${f.colorHex}20`, borderColor: `${f.colorHex}50` }}
                      >
                        <Icon className="w-5 h-5" style={{ color: f.colorHex }} />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-display text-base text-foreground leading-tight">{f.name}</h3>
                        <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-mono mt-1">
                          {f.domain}
                        </p>
                      </div>
                    </div>
                    <p className="text-xs italic font-body mb-3" style={{ color: f.colorHex }}>
                      "{f.motto}"
                    </p>
                    <p className="text-sm text-foreground/80 font-body mb-3 leading-relaxed">{f.description}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {f.modules.map((m) => (
                        <span
                          key={m}
                          className="text-[10px] px-2 py-0.5 rounded-full font-body border"
                          style={{
                            color: f.colorHex,
                            background: `${f.colorHex}10`,
                            borderColor: `${f.colorHex}30`,
                          }}
                        >
                          {m}
                        </span>
                      ))}
                    </div>
                  </motion.article>
                );
              })}
            </div>
          </section>

          {/* TERRITORIO — POIs canónicos */}
          <section className="mb-16">
            <h2 className="font-display text-2xl text-foreground mb-6 text-center">
              Territorio <span className="text-gradient-gold">Canónico</span>
            </h2>
            <p className="text-center text-sm text-muted-foreground font-body mb-6">
              {RDM_TERRITORY_POIS.length} puntos de interés georreferenciados del Nodo Cero
            </p>
            <div className="grid md:grid-cols-2 gap-3 max-w-4xl mx-auto">
              {RDM_TERRITORY_POIS.map((p, i) => {
                const fed = RDM_FEDERATIONS.find((f) => f.id === p.federationId);
                const color = fed?.colorHex ?? "#c47d3b";
                return (
                  <motion.div
                    key={p.id}
                    initial={{ opacity: 0, x: -8 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.03 }}
                    className="glass-card border border-border rounded-lg p-4 hover:border-accent/40 transition-all"
                  >
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <h4 className="font-display text-sm text-foreground">{p.name}</h4>
                      <span
                        className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded font-mono"
                        style={{ color, background: `${color}15` }}
                      >
                        {p.category}
                      </span>
                    </div>
                    <p className="text-xs text-foreground/75 font-body mb-2">{p.description}</p>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground font-mono">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {p.lat.toFixed(4)}, {p.lng.toFixed(4)}
                      </span>
                      <span>·</span>
                      <span>{p.altitudeM} m</span>
                      <span>·</span>
                      <span>{p.municipality}</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </section>

          {/* NODOS HERMANOS (placeholder original) */}
          <section>
            <h2 className="font-display text-2xl text-foreground mb-6 text-center">
              Nodos <span className="text-gradient-gold">Hermanos</span>
            </h2>
            <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {NODES.map((n, i) => {
                const s = STATUS[n.status as keyof typeof STATUS];
                return (
                  <motion.div
                    key={n.name}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className="glass-card border border-border rounded-xl p-5 flex items-start gap-4 hover:border-accent/40 transition-all"
                  >
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: `${s.color}20`, border: `1px solid ${s.color}40` }}
                    >
                      <s.icon className="w-5 h-5" style={{ color: s.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <h3 className="font-display text-lg text-foreground">{n.name}</h3>
                        <span
                          className="text-[10px] uppercase tracking-wider font-body px-2 py-0.5 rounded-full"
                          style={{ color: s.color, background: `${s.color}15` }}
                        >
                          {s.label}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground font-body flex items-center gap-1 mb-2">
                        <MapPin className="w-3 h-3" /> {n.state}
                      </p>
                      <p className="text-sm text-foreground/80 font-body">{n.role}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </section>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
