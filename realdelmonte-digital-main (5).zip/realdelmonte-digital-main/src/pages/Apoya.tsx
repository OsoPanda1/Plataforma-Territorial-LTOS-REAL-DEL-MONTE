import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, GlowCard } from "@/components/VisualEffects";
import { Heart, Music, Palette, Coffee, QrCode, Globe, Shield, Coins } from "lucide-react";
import { Link } from "react-router-dom";
import realitoLikes from "@/assets/realito-likes.png";

const ways = [
  { icon: Music, title: "Música con Identidad", desc: "Canciones originales como 'Entre Neblina y Montañas', 'Pueblito Minero' y otros temas en jazz, bachata, corridos tumbados. Tu compra paga servidores y la bóveda de Isabella AI.", price: "Desde $30 MXN" },
  { icon: Palette, title: "Artesanías con Alma", desc: "Bonsáis de alambre, piezas con flores secas y adornos de piñas de la región. Hechos a mano por el fundador del proyecto. Cada venta mantiene el control en Real del Monte.", price: "Precios variados" },
  { icon: QrCode, title: "Campaña QR en el Pueblo", desc: "Flyers de calidad y stickers con código QR en puntos clave: negocios, hoteles, zonas turísticas, transporte. Cada turista descubre la plataforma con un escaneo.", price: "Difusión" },
  { icon: Globe, title: "Campaña META Digital", desc: "Publicidad en Facebook, Instagram, WhatsApp, Messenger y Threads a través de Órbita Digital, dirigida a mercados mexicanos, argentinos y europeos.", price: "Inversión publicitaria" },
  { icon: Coffee, title: "Difunde el Proyecto", desc: "Comparte RDM Digital en redes, recomienda la plataforma a visitantes y comerciantes del pueblo.", price: "Gratis" },
  { icon: Heart, title: "Donación Directa", desc: "Cada aportación mantiene los servidores, la investigación y la soberanía digital del pueblo. Sin intermediarios.", price: "Lo que desees" },
];

const fundingLines = [
  { icon: Shield, title: "200 pesos / 2 meses", desc: "Registro de comercio como nodo verificado en el ledger económico soberano del ecosistema RDM-TOS." },
  { icon: Coins, title: "Bonos de Soberanía Musical", desc: "Canciones originales vendidas como bonos que sostienen la infraestructura. 100% trazable." },
];

export default function Apoya() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-5xl">
            <TextReveal>
              <div className="text-center mb-12">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Apoya el Proyecto</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  RDM Digital es 100% autofinanciado por Anubis Villaseñor. Tu apoyo mantiene la soberanía digital del pueblo.
                </p>
              </div>
            </TextReveal>

            {/* REALITO Banner */}
            <div className="mb-12 rounded-2xl border border-border overflow-hidden">
              <img src={realitoLikes} alt="¡Me gusta RDM Digital!" loading="lazy" className="w-full h-48 md:h-64 object-cover" />
              <div className="p-4 bg-card text-center">
                <p className="text-sm text-muted-foreground font-body">
                  <span className="text-accent font-semibold">¡Me gusta RDM Digital!</span> — Tu participación económica no es "ayuda": es inversión directa en que lleguen más clientes.
                </p>
              </div>
            </div>

            {/* Funding Lines */}
            <div className="grid md:grid-cols-2 gap-4 mb-12">
              {fundingLines.map((f) => (
                <GlowCard key={f.title}>
                  <div className="p-5 rounded-2xl border border-gold/30 bg-gold/5">
                    <f.icon className="w-6 h-6 text-gold mb-3" />
                    <h3 className="font-display text-base font-semibold text-gold mb-1">{f.title}</h3>
                    <p className="text-xs text-muted-foreground font-body">{f.desc}</p>
                  </div>
                </GlowCard>
              ))}
            </div>

            {/* Ways to help */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {ways.map((w) => (
                <div key={w.title} className="p-6 rounded-2xl border border-border bg-card card-glow-hover">
                  <w.icon className="w-8 h-8 text-gold mb-4" />
                  <h3 className="font-display text-lg font-semibold text-foreground mb-2">{w.title}</h3>
                  <p className="text-sm text-muted-foreground font-body mb-3">{w.desc}</p>
                  <span className="text-xs text-accent font-body font-medium">{w.price}</span>
                </div>
              ))}
            </div>

            {/* Quote */}
            <div className="mt-16 p-8 rounded-2xl border border-border bg-card text-center">
              <blockquote className="text-sm italic text-muted-foreground font-body max-w-2xl mx-auto leading-relaxed">
                "He puesto mi vida, mis recursos y mis sueños en este proyecto. Hoy, RDM Digital está listo para demostrarle al mundo lo que la convicción y la garra realmontense pueden lograr cuando se mezcla la magia y la neblina de la montaña con tecnología."
              </blockquote>
              <p className="text-xs text-gold font-body mt-4">— Edwin Oswaldo Castillo Trejo (Anubis Villaseñor)</p>
              <p className="text-[10px] text-muted-foreground/60 font-body mt-1">Master Architect & CEO Fundador · TAMV Online</p>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
