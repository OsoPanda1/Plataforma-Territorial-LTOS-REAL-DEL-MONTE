import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal } from "@/components/VisualEffects";
import { motion } from "framer-motion";
import { Clock, Footprints, Compass } from "lucide-react";
import rdmCalleColonial from "@/assets/rdm-calle-colonial.jpg";
import rdmSierra from "@/assets/rdm-sierra-ecoturismo.jpg";
import rdmPanteon from "@/assets/rdm-panteon-ingles.jpg";
import rdmPlaza from "@/assets/rdm-plaza-central.jpg";

const routes = [
  { name: "Senda de los Mineros", duration: "3 hrs", distance: "5.2 km", difficulty: "Moderada", desc: "Plaza Principal → Parroquia → Callejones → Museo del Paste → Mina de Acosta.", image: rdmCalleColonial },
  { name: "Ruta Gastronómica", duration: "2 hrs", distance: "2.8 km", difficulty: "Fácil", desc: "Recorre las pastelerías, cafés y restaurantes más emblemáticos del centro.", image: rdmPlaza },
  { name: "Ruta de la Neblina", duration: "4 hrs", distance: "7 km", difficulty: "Avanzada", desc: "Bosque del Hiloche → Peña del Cuervo → Mirador panorámico.", image: rdmSierra },
  { name: "Ruta Cultural", duration: "2.5 hrs", distance: "3 km", difficulty: "Fácil", desc: "Panteón Inglés → Museo de Medicina → Centro Cultural.", image: rdmPanteon },
];

export default function Rutas() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-4xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Rutas Turísticas</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">Recorridos curados para descubrir cada rincón del pueblo.</p>
              </div>
            </TextReveal>
            <div className="space-y-6">
              {routes.map((r, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                  className="rounded-2xl border border-border bg-card card-glow-hover overflow-hidden">
                  <div className="md:flex">
                    <div className="md:w-1/3 aspect-video md:aspect-auto overflow-hidden">
                      <img src={r.image} alt={r.name} loading="lazy" className="w-full h-full object-cover" />
                    </div>
                    <div className="p-6 md:w-2/3">
                      <h3 className="font-display text-xl font-semibold text-foreground mb-2">{r.name}</h3>
                      <p className="text-sm text-muted-foreground font-body mb-4">{r.desc}</p>
                      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground font-body">
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-accent" />{r.duration}</span>
                        <span className="flex items-center gap-1"><Footprints className="w-3 h-3 text-gold" />{r.distance}</span>
                        <span className="flex items-center gap-1"><Compass className="w-3 h-3 text-copper" />{r.difficulty}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
