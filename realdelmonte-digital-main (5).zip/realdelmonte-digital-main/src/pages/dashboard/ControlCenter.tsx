import { motion } from "framer-motion";
import { Users, Zap, Database, Clock, TrendingUp, Wifi, Cpu, HardDrive, Activity, Shield, Globe, Network, Layers } from "lucide-react";
import { useEffect, useState } from "react";
import logoBadge from "@/assets/rdm-logo-badge.png";
import { GamificationPanel } from "@/components/gamification/GamificationPanel";

const card = "bg-card border border-border rounded-xl p-4";

export default function ControlCenter() {
  const [tick, setTick] = useState(0);
  useEffect(() => { const i = setInterval(() => setTick(t => t + 1), 5000); return () => clearInterval(i); }, []);

  const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
  const metrics = { activeUsers: rand(80, 200), latency: rand(60, 150), places: 142, uptime: 99.7, intents: rand(500, 1200) };

  return (
    <div className="space-y-6">
      {/* Header with badge */}
      <div className="flex items-center gap-4">
        <img src={logoBadge} alt="RDM Digital" className="w-14 h-14 rounded-full border border-accent/30" />
        <div>
          <h1 className="text-2xl font-display font-semibold tracking-tight text-foreground">Control Center · RDM-TOS</h1>
          <p className="text-sm text-muted-foreground mt-1 font-body">Sistema Operativo Territorial Soberano — Nodo Cero: Real del Monte</p>
        </div>
      </div>

      {/* Main metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Usuarios Activos", value: metrics.activeUsers, icon: Users, color: "text-success" },
          { label: "Latencia", value: `${metrics.latency}ms`, icon: Zap, color: "text-accent" },
          { label: "Lugares Indexados", value: metrics.places, icon: Database, color: "text-gold" },
          { label: "Uptime", value: `${metrics.uptime}%`, icon: Clock, color: "text-success" },
          { label: "Intents IA", value: metrics.intents, icon: TrendingUp, color: "text-accent" },
        ].map((m, i) => (
          <motion.div key={m.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className={card}>
            <m.icon className={`w-4 h-4 ${m.color} mb-2`} />
            <p className="text-xl font-semibold font-body text-foreground">{m.value}</p>
            <p className="text-[11px] text-muted-foreground mt-0.5 font-body">{m.label}</p>
          </motion.div>
        ))}
      </div>

      <GamificationPanel />

      {/* 7 Federations Status */}
      <div className={card}>
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 font-body">7 Federaciones TAMV — Estado</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { name: "IDENTITY_CORE", status: "online", icon: Shield },
            { name: "LEDGER_2DBD", status: "online", icon: Database },
            { name: "COMPUTE_EDGE", status: "online", icon: Cpu },
            { name: "ALAMEXA_NEXUS", status: "standby", icon: Network },
            { name: "UTAMV_NEURAL", status: "online", icon: TrendingUp },
            { name: "MEDIA_BROADCAST", status: "online", icon: Globe },
            { name: "RDM_TWIN_4D", status: "online", icon: Layers },
          ].map(f => (
            <div key={f.name} className="flex items-center gap-2 p-2 rounded-lg bg-secondary/30 border border-border">
              <div className={`w-2 h-2 rounded-full ${f.status === 'online' ? 'bg-success animate-pulse' : 'bg-gold'}`} />
              <f.icon className="w-3 h-3 text-accent" />
              <span className="text-[10px] text-muted-foreground font-mono truncate">{f.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className={card}>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 font-body">Clima en Tiempo Real</p>
          <p className="text-4xl font-display font-light text-foreground">14°</p>
          <p className="text-sm text-muted-foreground font-body">Bruma · Humedad 78% · 2,700m</p>
        </div>
        <div className={card}>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 font-body">Red Mesh Soberana</p>
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className={`w-8 h-8 rounded-lg border flex items-center justify-center ${i < 10 ? 'bg-success/10 border-success/30' : 'bg-muted border-border'}`}>
                <Wifi className={`w-3 h-3 ${i < 10 ? 'text-success' : 'text-muted-foreground'}`} />
              </div>
            ))}
          </div>
          <p className="text-[11px] text-muted-foreground mt-2 font-body">10/12 nodos online · 7.5km alcance</p>
        </div>
        <div className={card}>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 font-body">Infraestructura</p>
          <div className="space-y-2">
            {[
              { label: "CPU", value: rand(15, 45), icon: Cpu },
              { label: "RAM", value: rand(30, 65), icon: HardDrive },
              { label: "Req/min", value: rand(80, 200), icon: Activity },
            ].map(s => (
              <div key={s.label} className="flex items-center gap-2">
                <s.icon className="w-3 h-3 text-accent" />
                <span className="text-xs text-muted-foreground font-body w-16">{s.label}</span>
                <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-accent rounded-full" style={{ width: `${s.value}%` }} />
                </div>
                <span className="text-xs text-foreground font-body w-10 text-right">{s.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Consensus */}
      <div className={card}>
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2 font-body">TAMV-Consensus · Integridad Global</p>
        <div className="flex items-center gap-3">
          <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-accent to-gold rounded-full" style={{ width: "94%" }} />
          </div>
          <span className="text-sm font-mono text-gold">0.94</span>
          <span className="text-[10px] text-success font-body">SOVEREIGN_LOCKED</span>
        </div>
        <p className="text-[10px] text-muted-foreground font-body mt-1">I_TAMV = Σ(Wn · σ(Vn) / Δt) × E_Dignity · Estatuto de Dignidad: ✓</p>
      </div>
    </div>
  );
}
