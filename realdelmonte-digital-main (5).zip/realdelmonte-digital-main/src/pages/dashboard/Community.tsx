import { Users, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

const communities = [
  { name: "Creadores TAMV", members: 128, desc: "Comunidad oficial de creadores del ecosistema" },
  { name: "XR Builders", members: 64, desc: "Constructores de mundos virtuales y experiencias inmersivas" },
  { name: "DAO Governance", members: 42, desc: "Participantes activos en la gobernanza del ecosistema" },
  { name: "Isabella AI Lab", members: 89, desc: "Investigación y desarrollo de IA emocional" },
];

export default function Community() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-xl text-foreground">Comunidades</h2>
        <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-1" /> Crear
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {communities.map((c, i) => (
          <div key={i} className="p-5 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors cursor-pointer">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-display text-foreground">{c.name}</h3>
                <p className="text-xs text-muted-foreground">{c.members} miembros</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground font-body">{c.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
