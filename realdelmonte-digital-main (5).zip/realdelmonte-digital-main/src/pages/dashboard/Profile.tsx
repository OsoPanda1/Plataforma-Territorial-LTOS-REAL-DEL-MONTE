import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Save, Loader2 } from "lucide-react";

export default function Profile() {
  const [user, setUser] = useState<User | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) {
        setUser(user);
        setDisplayName(user.user_metadata?.display_name || "");
      }
    });
  }, []);

  const handleSave = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        data: { display_name: displayName },
      });
      if (error) throw error;
      toast.success("Perfil actualizado");
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-lg mx-auto">
      <h2 className="font-display text-xl text-foreground mb-6">Mi Perfil</h2>

      <div className="p-6 rounded-xl bg-card border border-border space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center">
            <span className="text-2xl font-display text-primary">{displayName?.[0]?.toUpperCase() || "U"}</span>
          </div>
          <div>
            <p className="font-display text-lg text-foreground">{displayName || "Sin nombre"}</p>
            <p className="text-sm text-muted-foreground font-body">{user.email}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-foreground">Nombre de usuario</Label>
            <Input value={displayName} onChange={e => setDisplayName(e.target.value)} className="bg-secondary border-border text-foreground" />
          </div>
          <div className="space-y-2">
            <Label className="text-foreground">Correo electrónico</Label>
            <Input value={user.email} disabled className="bg-secondary/50 border-border text-muted-foreground" />
          </div>
        </div>

        <Button onClick={handleSave} disabled={loading} className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Save className="w-4 h-4 mr-2" /> Guardar Cambios</>}
        </Button>
      </div>
    </div>
  );
}
