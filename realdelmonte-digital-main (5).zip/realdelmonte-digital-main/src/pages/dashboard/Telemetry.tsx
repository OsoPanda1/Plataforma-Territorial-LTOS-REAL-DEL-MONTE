import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Users,
  Zap,
  Database,
  Clock,
  TrendingUp,
  Wifi,
  Cpu,
  HardDrive,
  Activity,
  Shield,
  Globe,
  Network,
  Layers,
} from "lucide-react";
import logoBadge from "@/assets/rdm-logo-badge.png";
import { GamificationPanel } from "@/components/gamification/GamificationPanel";

const cardBase =
  "bg-card border border-border rounded-xl p-4 shadow-sm shadow-black/10";

const metricsContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const metricCardVariants = {
  hidden: { opacity: 0, y: 10 },
  visible: { opacity: 1, y: 0 },
};

const randInt = (min: number, max: number) =>
  Math.floor(Math.random() * (max - min + 1)) + min;

export default function ControlCenter() {
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const i = window.setInterval(() => setTick((t) => t + 1), 5000);
    return () => window.clearInterval(i);
  }, []);

  const metrics = useMemo(
    () => ({
      activeUsers: randInt(80, 200),
      latencyMs: randInt(60, 150),
      places: 142,
      uptimePct: 99.7,
      intents: randInt(500, 1200),
    }),
    [tick],
  );

  const infra = useMemo(
    () => ({
      cpu: randInt(15, 45),
      ram: randInt(30, 65),
      reqPerMin: randInt(80, 200),
    }),
    [tick],
  );

  return (
    <div className="space-y-6">
      {/* Header con badge */}
      <div className="flex items-center gap-4">
        <img
          src={logoBadge}
          alt="RDM Digital"
          className="h-14 w-14 rounded-full border border-accent/30"
          loading="lazy"
        />
        <div>
          <h1 className="font-display text-2xl font-semibold tracking-tight text-foreground">
            Control Center · RDM-TOS
          </h1>
          <p className="mt-1 font-body text-sm text-muted-foreground">
            Sistema Operativo Territorial Soberano — Nodo Cero: Real del Monte
          </p>
        </div>
      </div>

      {/* Métricas principales */}
      <motion.div
        variants={metricsContainerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 gap-3 md:grid-cols-5"
      >
        {[
          {
            label: "Usuarios Activos",
            value: metrics.activeUsers.toLocaleString("es-MX"),
            icon: Users,
            color: "text-success",
          },
          {
            label: "Latencia",
            value: `${metrics.latencyMs}ms`,
            icon: Zap,
            color:
              metrics.latencyMs > 130
                ? "text-red-500"
                : metrics.latencyMs > 100
                ? "text-amber-400"
                : "text-accent",
          },
          {
            label: "Lugares Indexados",
            value: metrics.places,
            icon: Database,
            color: "text-gold",
          },
          {
            label: "Uptime",
            value: `${metrics.uptimePct}%`,
            icon: Clock,
            color: "text-success",
          },
          {
            label: "Intents IA",
            value: metrics.intents.toLocaleString("es-MX"),
            icon: TrendingUp,
            color: "text-accent",
          },
        ].map((m) => (
          <motion.div
            key={m.label}
            variants={metricCardVariants}
            className={cardBase}
          >
            <m.icon className={`mb-2 h-4 w-4 ${m.color}`} />
            <p className="font-body text-xl font-semibold text-foreground">
              {m.value}
            </p>
            <p className="mt-0.5 font-body text-[11px] text-muted-foreground">
              {m.label}
            </p>
          </motion.div>
        ))}
      </motion.div>

      {/* Gamificación */}
      <GamificationPanel />

      {/* 7 Federaciones TAMV */}
      <div className={cardBase}>
        <p className="mb-3 font-body text-xs font-medium uppercase tracking-wider text-muted-foreground">
          7 Federaciones TAMV — Estado
        </p>
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {[
            { name: "IDENTITY_CORE", status: "online", icon: Shield },
            { name: "LEDGER_2DBD", status: "online", icon: Database },
            { name: "COMPUTE_EDGE", status: "online", icon: Cpu },
            { name: "ALAMEXA_NEXUS", status: "standby", icon: Network },
            { name: "UTAMV_NEURAL", status: "online", icon: TrendingUp },
            { name: "MEDIA_BROADCAST", status: "online", icon: Globe },
            { name: "RDM_TWIN_4D", status: "online", icon: Layers },
          ].map((f) => (
            <div
              key={f.name}
              className="flex items-center gap-2 rounded-lg border border-border bg-secondary/30 p-2"
            >
              <div
                className={`h-2 w-2 rounded-full ${
                  f.status === "online" ? "bg-success animate-pulse" : "bg-gold"
                }`}
              />
              <f.icon className="h-3 w-3 text-accent" />
              <span className="truncate font-mono text-[10px] text-muted-foreground">
                {f.name}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Clima · Mesh · Infraestructura */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className={cardBase}>
          <p className="mb-3 font-body text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Clima en Tiempo Real
          </p>
          <p className="font-display text-4xl font-light text-foreground">
            14°
          </p>
          <p className="font-body text-sm text-muted-foreground">
            Bruma · Humedad 78% · 2,700m
          </p>
        </div>

        <div className={cardBase}>
          <p className="mb-3 font-body text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Red Mesh Soberana
          </p>
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 12 }).map((_, i) => {
              const online = i < 10;
              return (
                <div
                  key={i}
                  className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                    online
                      ? "border-success/30 bg-success/10"
                      : "border-border bg-muted"
                  }`}
                >
                  <Wifi
                    className={`h-3 w-3 ${
                      online ? "text-success" : "text-muted-foreground"
                    }`}
                  />
                </div>
              );
            })}
          </div>
          <p className="mt-2 font-body text-[11px] text-muted-foreground">
            10/12 nodos online · 7.5km alcance
          </p>
        </div>

        <div className={cardBase}>
          <p className="mb-3 font-body text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Infraestructura
          </p>
          <div className="space-y-2">
            {[
              { label: "CPU", value: infra.cpu, icon: Cpu },
              { label: "RAM", value: infra.ram, icon: HardDrive },
              { label: "Req/min", value: infra.reqPerMin, icon: Activity },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-2">
                <s.icon className="h-3 w-3 text-accent" />
                <span className="w-16 font-body text-xs text-muted-foreground">
                  {s.label}
                </span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
                  <div
                    className="h-full rounded-full bg-accent"
                    style={{
                      width: `${Math.min(s.value, 100)}%`,
                    }}
                  />
                </div>
                <span className="w-10 text-right font-body text-xs text-foreground">
                  {s.label === "Req/min" ? s.value : `${s.value}%`}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Consensus */}
      <div className={cardBase}>
        <p className="mb-2 font-body text-xs font-medium uppercase tracking-wider text-muted-foreground">
          TAMV-Consensus · Integridad Global
        </p>
        <div className="flex items-center gap-3">
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-gradient-to-r from-accent to-gold"
              style={{ width: "94%" }}
            />
          </div>
          <span className="font-mono text-sm text-gold">0.94</span>
          <span className="font-body text-[10px] text-success">
            SOVEREIGN_LOCKED
          </span>
        </div>
        <p className="mt-1 font-body text-[10px] text-muted-foreground">
          I_TAMV = Σ(Wn · σ(Vn) / Δt) × E_Dignity · Estatuto de Dignidad: ✓
        </p>
      </div>
    </div>
  );
}
