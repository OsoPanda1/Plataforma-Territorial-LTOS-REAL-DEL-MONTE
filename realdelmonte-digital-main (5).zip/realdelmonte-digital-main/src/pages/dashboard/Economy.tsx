import { Coins, TrendingUp, ShoppingBag, Trophy, Shield, Music, Palette, Store } from "lucide-react";
import { GlowCard } from "@/components/VisualEffects";

const stats = [
  { icon: Coins, label: "Balance TAMV", value: "0 TAMV", change: "Ledger activo" },
  { icon: TrendingUp, label: "Ingresos Fase 1", value: "$0.00", change: "Bootstrap" },
  { icon: ShoppingBag, label: "Comercios Nodo", value: "12", change: "Verificados" },
  { icon: Trophy, label: "Bonos Soberanía", value: "6", change: "Canciones" },
];

const revenueStreams = [
  { icon: Music, title: "Música con Identidad", desc: "Canciones originales como bonos de soberanía. Precio mínimo $30 MXN. Fondos directos a infraestructura.", status: "Activo" },
  { icon: Palette, title: "Artesanías con Alma", desc: "Bonsáis de alambre, flores secas, piñas de la región. Cada venta mantiene el control local.", status: "Activo" },
  { icon: Store, title: "Registro de Comercios", desc: "$200 MXN / 2 meses como nodo verificado en el ledger económico soberano.", status: "Fase 1" },
  { icon: Shield, title: "Campaña META + QR", desc: "Publicidad en ecosistema META vía Órbita Digital. Mercados: MX, AR, EU.", status: "En preparación" },
];

export default function Economy() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="font-display text-xl text-foreground mb-1">Economía Soberana</h2>
        <p className="text-sm text-muted-foreground font-body">Tejido de Persistencia Cuántica — Ledger económico del ecosistema RDM-TOS</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <div key={i} className="p-4 rounded-xl bg-card border border-border">
            <div className="flex items-center gap-2 mb-2">
              <s.icon className="w-4 h-4 text-gold" />
              <span className="text-xs text-muted-foreground font-body">{s.label}</span>
            </div>
            <p className="text-xl font-display text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground font-body mt-1">{s.change}</p>
          </div>
        ))}
      </div>

      {/* Revenue Streams */}
      <div>
        <h3 className="font-display text-lg text-foreground mb-4">Líneas de Acción Fase 1</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {revenueStreams.map((r, i) => (
            <GlowCard key={i}>
              <div className="p-5 rounded-xl bg-card border border-border">
                <div className="flex items-center justify-between mb-3">
                  <r.icon className="w-5 h-5 text-gold" />
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-body ${r.status === 'Activo' ? 'bg-success/20 text-success' : 'bg-gold/20 text-gold'}`}>
                    {r.status}
                  </span>
                </div>
                <h4 className="font-display text-sm font-semibold text-foreground mb-1">{r.title}</h4>
                <p className="text-xs text-muted-foreground font-body">{r.desc}</p>
              </div>
            </GlowCard>
          ))}
        </div>
      </div>

      {/* Tokenomics */}
      <div className="p-6 rounded-xl bg-card border border-border">
        <h3 className="font-display text-base text-foreground mb-3">Distribución Económica</h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="text-2xl font-display text-gold">75%</p>
            <p className="text-[11px] text-muted-foreground font-body">Creador / Comercio</p>
          </div>
          <div>
            <p className="text-2xl font-display text-accent">15%</p>
            <p className="text-[11px] text-muted-foreground font-body">Infraestructura</p>
          </div>
          <div>
            <p className="text-2xl font-display text-foreground">10%</p>
            <p className="text-[11px] text-muted-foreground font-body">DAO Treasury</p>
          </div>
        </div>
        <p className="text-[10px] text-muted-foreground/60 font-body mt-4 text-center">
          Modelo tipo Alamexa: resistente a censura, preparado para PQC, trazable y justo.
        </p>
      </div>

      {/* Marketplace Preview */}
      <div className="p-8 rounded-xl bg-card border border-border text-center">
        <div className="w-12 h-12 rounded-xl bg-gold/20 flex items-center justify-center mx-auto mb-4 border border-gold/30">
          <ShoppingBag className="w-6 h-6 text-gold" />
        </div>
        <h3 className="font-display text-lg text-foreground mb-2">Marketplace TAMV</h3>
        <p className="text-sm text-muted-foreground font-body max-w-md mx-auto">
          Pronto podrás vender productos digitales, música, artesanías, servicios y experiencias directamente en el ecosistema RDM Digital.
        </p>
      </div>
    </div>
  );
}
