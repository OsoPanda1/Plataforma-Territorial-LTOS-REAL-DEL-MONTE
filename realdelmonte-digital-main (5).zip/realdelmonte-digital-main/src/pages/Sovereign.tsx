// ─────────────────────────────────────────────────────────────────────────────
// /sovereign — Centro de Decisiones Soberanas (Nodo Cero)
// Unifica: POIs canónicos + ExperienceOrchestrator + DecisionStore.
// Funcional: usa geolocalización del navegador y emite decisiones en vivo.
// ─────────────────────────────────────────────────────────────────────────────
import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Activity, Crosshair, MapPin, Radio, Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import SEOMeta from "@/components/SEOMeta";
import { RDM_TERRITORY_POIS } from "@/data/rdmTerritoryPOIs";
import {
  ExperienceOrchestrator,
  decisionStore,
  haversineM,
  type AuditedDecision,
  type Coordenadas,
} from "@/lib/sovereign";

const POI_COORDS: Coordenadas[] = RDM_TERRITORY_POIS.map((p) => ({ lat: p.lat, lng: p.lng }));
const RDM_CENTER: Coordenadas = { lat: 20.1432, lng: -98.6694 };

export default function Sovereign() {
  const orchestratorRef = useRef(
    new ExperienceOrchestrator(POI_COORDS, {
      throttleMs: 8_000,
      proximityBBoxMeters: 4_000,
      threshold: 20,
    })
  );
  const [coords, setCoords] = useState<Coordenadas | null>(null);
  const [prevCoords, setPrevCoords] = useState<Coordenadas | undefined>();
  const [watching, setWatching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ledger, setLedger] = useState<AuditedDecision[]>([]);
  const [tick, setTick] = useState(0);
  const startedAt = useRef(Date.now());

  // Simulator (when no geoloc): orbit around the center
  useEffect(() => {
    if (watching || coords) return;
    const id = window.setInterval(() => {
      const t = (Date.now() - startedAt.current) / 1000;
      const r = 0.004 + 0.001 * Math.sin(t / 30);
      const next = {
        lat: RDM_CENTER.lat + r * Math.cos(t / 20),
        lng: RDM_CENTER.lng + r * Math.sin(t / 20),
      };
      setPrevCoords((c) => c ?? next);
      setCoords((c) => { setPrevCoords(c ?? undefined); return next; });
    }, 5_000);
    return () => window.clearInterval(id);
  }, [watching, coords]);

  // Run orchestrator on each coord update
  useEffect(() => {
    if (!coords) return;
    const t = {
      id: "self",
      territory: "RDM",
      coords,
      prevCoords,
      stayTimeHours: (Date.now() - startedAt.current) / 3_600_000,
      lastInteractionAt: new Date(Date.now() - 60_000),
    };
    orchestratorRef.current.evaluar(t);
    setLedger(decisionStore.getLedger(20));
    setTick((n) => n + 1);
  }, [coords, prevCoords]);

  const startWatch = () => {
    if (!("geolocation" in navigator)) {
      setError("Geolocalización no disponible en este dispositivo.");
      return;
    }
    setError(null);
    setWatching(true);
    navigator.geolocation.watchPosition(
      (pos) => {
        const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setCoords((c) => { setPrevCoords(c ?? undefined); return next; });
      },
      (err) => setError(err.message),
      { enableHighAccuracy: true, maximumAge: 5_000, timeout: 15_000 }
    );
  };

  const nearest = useMemo(() => {
    if (!coords) return [];
    return [...RDM_TERRITORY_POIS]
      .map((p) => ({ poi: p, distanceM: haversineM(coords, { lat: p.lat, lng: p.lng }) }))
      .sort((a, b) => a.distanceM - b.distanceM)
      .slice(0, 5);
  }, [coords, tick]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SEOMeta
        title="Centro Soberano · RDM Digital"
        description="Motor de decisiones territoriales en vivo del Nodo Cero: geolocalización, POIs canónicos, ledger auditable."
        canonical="https://rdmdigital.mx/sovereign"
      />
      <div className="max-w-6xl mx-auto px-6 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to="/" className="text-xs text-muted-foreground hover:text-accent font-body">← Inicio</Link>
            <h1 className="font-display text-3xl md:text-4xl mt-2">
              Centro <span className="text-accent">Soberano</span>
            </h1>
            <p className="text-sm text-muted-foreground font-body mt-1">
              Orquestador unificado · POIs canónicos · Ledger auditable
            </p>
          </div>
          <Badge variant="outline" className="font-mono text-xs">v1.0 · {RDM_TERRITORY_POIS.length} POIs</Badge>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="p-5 bg-card border-border">
            <div className="flex items-center gap-2 text-muted-foreground text-xs font-body mb-2">
              <Crosshair className="w-3 h-3" /> POSICIÓN
            </div>
            <div className="font-mono text-sm text-foreground">
              {coords ? `${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}` : "— · —"}
            </div>
            <Button
              size="sm"
              onClick={startWatch}
              disabled={watching}
              className="mt-3 bg-accent text-accent-foreground hover:bg-accent/90"
            >
              {watching ? "Rastreando…" : "Usar mi ubicación"}
            </Button>
            {error && <p className="text-xs text-destructive mt-2 font-body">{error}</p>}
            {!watching && !coords && (
              <p className="text-xs text-muted-foreground mt-2 font-body">Modo simulación activo.</p>
            )}
          </Card>

          <Card className="p-5 bg-card border-border">
            <div className="flex items-center gap-2 text-muted-foreground text-xs font-body mb-2">
              <Activity className="w-3 h-3" /> DECISIONES
            </div>
            <div className="font-display text-3xl text-accent">{ledger.length}</div>
            <p className="text-xs text-muted-foreground font-body mt-1">en este ciclo</p>
          </Card>

          <Card className="p-5 bg-card border-border">
            <div className="flex items-center gap-2 text-muted-foreground text-xs font-body mb-2">
              <Shield className="w-3 h-3" /> NIVEL ACTUAL
            </div>
            <div className="font-display text-2xl">
              {ledger[0]?.decision.level ?? "—"}
            </div>
            <p className="text-xs text-muted-foreground font-body mt-1">
              {ledger[0]?.decision.retentionIntent ?? "esperando señal"}
            </p>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <section>
            <h2 className="font-display text-lg mb-3 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-accent" /> POIs más cercanos
            </h2>
            <div className="space-y-2">
              {nearest.length === 0 && (
                <p className="text-sm text-muted-foreground font-body">Esperando coordenadas…</p>
              )}
              {nearest.map(({ poi, distanceM }) => (
                <Card key={poi.id} className="p-3 bg-card border-border flex items-center justify-between">
                  <div>
                    <div className="font-body text-sm text-foreground">{poi.name}</div>
                    <div className="text-xs text-muted-foreground font-mono">
                      {poi.category} · {poi.municipality}
                    </div>
                  </div>
                  <Badge variant="outline" className="font-mono">
                    {distanceM < 1000 ? `${Math.round(distanceM)} m` : `${(distanceM / 1000).toFixed(1)} km`}
                  </Badge>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <h2 className="font-display text-lg mb-3 flex items-center gap-2">
              <Radio className="w-4 h-4 text-accent" /> Ledger soberano
            </h2>
            <div className="space-y-2 max-h-[480px] overflow-auto pr-1">
              {ledger.length === 0 && (
                <p className="text-sm text-muted-foreground font-body">
                  Aún no hay decisiones. Mueve la posición o activa geolocalización.
                </p>
              )}
              {ledger.map(({ decision, hash, version }) => (
                <Card key={decision.traceId} className="p-3 bg-card border-border">
                  <div className="flex items-center justify-between mb-1">
                    <Badge
                      variant={decision.level === "CRITICO" ? "destructive" : "outline"}
                      className="font-mono text-[10px]"
                    >
                      {decision.level} · {decision.retentionIntent}
                    </Badge>
                    <span className="font-mono text-[10px] text-muted-foreground">
                      #{version} · {hash}
                    </span>
                  </div>
                  <div className="text-sm font-body text-foreground flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-accent" /> {decision.payload.titulo}
                  </div>
                  <div className="text-xs text-muted-foreground font-body mt-1">
                    {decision.payload.mensaje}
                  </div>
                  <div className="text-[10px] text-muted-foreground font-mono mt-2">
                    score={decision.score.total} · pattern={decision.pattern} · dist={Math.round(decision.distanceToExit)}m · speed={decision.speedMps.toFixed(2)}m/s
                  </div>
                </Card>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
