import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem, GlowCard } from "@/components/VisualEffects";
import { Hotel, Utensils, Coffee, Store, Gem, Loader2, Star, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import imgRestaurante from "@/assets/rdm-restaurante.jpg";
import imgHospedaje from "@/assets/rdm-hospedaje.jpg";
import imgArtesanias from "@/assets/rdm-taller-artesanal.jpg";
import imgCafe from "@/assets/rdm-cafe.jpg";
import imgPlaza from "@/assets/rdm-plaza-central.jpg";
import { RDM_GASTRO, RDM_POIS } from "@/data/rdmContent";

const categoryMeta: Record<string, { icon: typeof Utensils; image: string }> = {
  Gastronomía: { icon: Utensils, image: imgRestaurante },
  Hospedaje: { icon: Hotel, image: imgHospedaje },
  Artesanías: { icon: Gem, image: imgArtesanias },
  Café: { icon: Coffee, image: imgCafe },
  Comercio: { icon: Store, image: imgPlaza },
};

type Business = {
  id: string;
  name: string;
  category: string;
  description: string | null;
  rating: number | null;
  address: string | null;
};

const fallbackBusinesses: Business[] = [
  ...RDM_GASTRO.map((poi) => ({
    id: `poi-${poi.id}`,
    name: poi.name,
    category: poi.category,
    description: poi.short,
    rating: poi.rating ?? 4.7,
    address: `${poi.lat.toFixed(4)}, ${poi.lng.toFixed(4)}`,
  })),
  ...RDM_POIS.filter((poi) => poi.id === "tianguis-artesanal").map((poi) => ({
    id: `poi-${poi.id}`,
    name: poi.name,
    category: "Artesanías",
    description: poi.short,
    rating: poi.rating ?? 4.7,
    address: `${poi.lat.toFixed(4)}, ${poi.lng.toFixed(4)}`,
  })),
];

export default function Catalogo() {
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCat, setSelectedCat] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("businesses").select("*").order("rating", { ascending: false }).then(({ data, error }) => {
      const remote = !error && data?.length ? (data as Business[]) : [];
      setBusinesses(remote.length ? remote : fallbackBusinesses);
      setLoading(false);
    });
  }, []);

  const categories = [...new Set(businesses.map(b => b.category))];
  const filtered = selectedCat ? businesses.filter(b => b.category === selectedCat) : businesses;

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <section className="pt-28 pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-12">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Catálogo Comercial</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Explora los negocios verificados de Real del Monte. Cada comercio es un nodo del ecosistema RDM Digital.
                </p>
              </div>
            </TextReveal>

            {/* Category banners */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-10">
              {categories.map(cat => {
                const meta = categoryMeta[cat] || { icon: Store, image: imgPlaza };
                const Icon = meta.icon;
                const count = businesses.filter(b => b.category === cat).length;
                return (
                  <button key={cat} onClick={() => setSelectedCat(selectedCat === cat ? null : cat)}
                    className={`relative overflow-hidden rounded-xl border transition-all group ${selectedCat === cat ? "border-accent ring-1 ring-accent" : "border-border hover:border-accent/30"}`}>
                    <img src={meta.image} alt={cat} className="w-full h-24 object-cover opacity-40 group-hover:opacity-50 transition-opacity" loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <Icon className="w-5 h-5 text-gold mb-1" />
                      <span className="text-xs font-body font-semibold text-foreground">{cat}</span>
                      <span className="text-[10px] text-muted-foreground">{count} negocios</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {loading ? (
              <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 text-accent animate-spin" /></div>
            ) : (
              <StaggerContainer className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map((biz) => (
                  <StaggerItem key={biz.id}>
                    <GlowCard>
                      <div className="p-6 rounded-2xl border border-border bg-card">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] uppercase tracking-widest text-accent font-body">{biz.category}</span>
                          {biz.rating && <div className="flex items-center gap-1 text-gold text-xs"><Star className="w-3 h-3 fill-current" />{Number(biz.rating).toFixed(1)}</div>}
                        </div>
                        <h3 className="font-display text-lg font-semibold text-foreground mb-1">{biz.name}</h3>
                        {biz.description && <p className="text-xs text-muted-foreground font-body mb-2 line-clamp-2">{biz.description}</p>}
                        {biz.address && <div className="flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="w-3 h-3 text-terracotta" />{biz.address}</div>}
                      </div>
                    </GlowCard>
                  </StaggerItem>
                ))}
              </StaggerContainer>
            )}
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
