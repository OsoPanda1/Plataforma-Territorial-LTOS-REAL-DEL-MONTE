import { RDMHeroPlayer } from "@/components/music/RDMHeroPlayer";
import playlist from "@/data/playlist.json";
import { Link } from "react-router-dom";

export default function MusicPage() {
  return (
    <main className="container mx-auto px-6 pt-24 pb-16 space-y-12">
      <section className="grid gap-8 md:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)] items-start">
        <div>
          <p className="text-[11px] font-body uppercase tracking-[0.25em] text-gold/80 mb-2">
            RDM Radio & Music Experience
          </p>
          <h1 className="font-display text-3xl md:text-4xl text-foreground mb-3">
            Música, identidad y cultura digital de Real del Monte
          </h1>
          <p className="font-body text-sm md:text-base text-muted-foreground max-w-xl">
            Pistas originales ancladas al territorio, producidas por TAMV
            ONLINE Records y sincronizadas con el Gemelo Digital. Escucha,
            explora historias y apoya a los artistas locales.
          </p>
        </div>
        <div className="flex justify-end">
          <RDMHeroPlayer autoplay={false} />
        </div>
      </section>

      <section aria-label="Playlist oficial TAMV" className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <h2 className="font-display text-xl text-foreground">
            Playlist oficial TAMV
          </h2>
          <Link
            to="/"
            className="text-[11px] font-body uppercase tracking-[0.2em] text-muted-foreground hover:text-accent transition-colors"
          >
            Volver al Gemelo Digital
          </Link>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          {playlist.map((track) => (
            <article
              key={track.id}
              className="flex items-center gap-3 rounded-xl border border-border bg-card/80 px-3 py-2.5"
            >
              <div className="h-12 w-12 overflow-hidden rounded-lg bg-background/60 border border-border/60">
                {track.cover && (
                  <img
                    src={track.cover}
                    alt={track.title}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="truncate font-display text-sm text-foreground">
                  {track.title}
                </p>
                <p className="truncate text-[11px] font-body text-muted-foreground">
                  {track.artist}
                </p>
              </div>
              <Link
                to={`/music/${track.slug}`}
                className="text-[11px] font-body uppercase tracking-[0.2em] text-muted-foreground hover:text-accent transition-colors"
              >
                Ver más
              </Link>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
