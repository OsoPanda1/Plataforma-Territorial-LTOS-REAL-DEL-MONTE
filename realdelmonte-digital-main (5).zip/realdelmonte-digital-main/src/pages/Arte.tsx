import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition, TextReveal, StaggerContainer, StaggerItem } from "@/components/VisualEffects";
import { Palette, Gem, Scissors, Brush } from "lucide-react";
import rdmArtesanias from "@/assets/rdm-artesanias.jpg";

const artworks = [
  { icon: Gem, title: "Miniaturas en Plata", desc: "Réplicas de herramientas mineras y paisajes de Real del Monte elaborados en plata por artesanos locales." },
  { icon: Scissors, title: "Bonsáis de Alambre", desc: "Pequeñas obras de arte hechas a mano con alambre y materiales naturales de la región." },
  { icon: Brush, title: "Pintura en Madera", desc: "Paisajes del pueblo y escenas mineras pintadas sobre tablas de madera reciclada." },
  { icon: Palette, title: "Textiles de la Sierra", desc: "Tejidos artesanales con patrones inspirados en la flora y fauna de la Sierra de Pachuca." },
  { icon: Gem, title: "Joyería con Minerales", desc: "Piezas únicas con piedras y minerales extraídos de las antiguas minas del pueblo." },
  { icon: Scissors, title: "Flores Secas y Piñas", desc: "Adornos naturales con flores secas y piñas de los bosques de oyamel de la región." },
];

export default function Arte() {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />

        {/* Hero image */}
        <section className="pt-24 pb-8 px-6">
          <div className="container max-w-6xl">
            <div className="rounded-2xl overflow-hidden border border-border">
              <img src={rdmArtesanias} alt="Artesanías de Real del Monte" className="w-full h-48 md:h-64 object-cover" />
              <div className="p-4 bg-card">
                <p className="text-sm text-muted-foreground font-body text-center">
                  Artesanías locales — tradición y creatividad de la sierra
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="pb-24 px-6">
          <div className="container max-w-6xl">
            <TextReveal>
              <div className="text-center mb-16">
                <h1 className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4">Arte y Artesanías</h1>
                <p className="text-muted-foreground font-body max-w-xl mx-auto">
                  Creaciones locales que preservan la identidad minera y natural de Real del Monte.
                </p>
              </div>
            </TextReveal>
            <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {artworks.map((a) => (
                <StaggerItem key={a.title}>
                  <div className="p-6 rounded-2xl border border-border bg-card h-full card-glow-hover">
                    <a.icon className="w-8 h-8 text-copper mb-4" />
                    <h3 className="font-display text-lg font-semibold text-foreground mb-2">{a.title}</h3>
                    <p className="text-sm text-muted-foreground font-body">{a.desc}</p>
                  </div>
                </StaggerItem>
              ))}
            </StaggerContainer>
          </div>
        </section>
        <Footer />
      </div>
    </PageTransition>
  );
}
