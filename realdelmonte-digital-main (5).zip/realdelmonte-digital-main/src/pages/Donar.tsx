import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { motion } from "framer-motion";
import { Heart, Loader2, Shield, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { createCheckoutSession } from "@/services/payments";
import { awardGamificationEvent } from "@/services/gamification";

const AMOUNTS = [50, 100, 250, 500, 1000];

export default function Donar() {
  const [amount, setAmount] = useState(250);
  const [custom, setCustom] = useState("");
  const [processing, setProcessing] = useState(false);

  const handleDonate = async () => {
    const final = custom ? Number(custom) : amount;
    if (!final || final < 10) {
      toast.error("Mínimo $10 MXN");
      return;
    }

    setProcessing(true);
    try {
      const checkout = await createCheckoutSession({
        successPath: "/donar?status=success",
        cancelPath: "/donar?status=cancel",
        metadata: { type: "donation", program: "patrimonio_rdm" },
        items: [
          {
            name: "Donativo RDM Digital",
            amount: final,
            quantity: 1,
            description: "Apoyo al patrimonio cultural, memoria minera y visibilidad de comercios locales.",
          },
        ],
      });

      await awardGamificationEvent("donation_started", { amount: final, mode: checkout.mode });

      if (checkout.url) {
        window.location.href = checkout.url;
        return;
      }

      toast.success(`Folio local generado por $${final} MXN`, {
        description: checkout.message,
      });
    } catch (error) {
      toast.error("No se pudo iniciar el donativo", {
        description: error instanceof Error ? error.message : "Intenta de nuevo.",
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container mx-auto px-6 pt-28 pb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto"
          >
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-gold/40 bg-gold/5 mb-4">
                <Heart className="w-3.5 h-3.5 text-gold" />
                <span className="text-[10px] tracking-[0.3em] uppercase text-gold font-body">Apoyo Soberano</span>
              </div>
              <h1 className="font-display text-4xl md:text-5xl text-foreground mb-3">
                Asegura el brillo de nuestro <span className="text-gradient-gold">legado</span>
              </h1>
              <p className="text-muted-foreground font-body">
                Tu donativo fortalece el patrimonio cultural, la memoria minera y la visibilidad de los comercios locales.
              </p>
            </div>

            <div className="glass-card rounded-2xl p-8 space-y-6 border border-border">
              <div>
                <label className="text-xs uppercase tracking-wider text-muted-foreground font-body mb-3 block">
                  Monto sugerido
                </label>
                <div className="flex flex-wrap gap-2">
                  {AMOUNTS.map((v) => (
                    <button
                      key={v}
                      onClick={() => {
                        setAmount(v);
                        setCustom("");
                      }}
                      className={`px-4 py-2 rounded-full border text-sm font-body transition-all ${
                        amount === v && !custom
                          ? "border-gold bg-gold/10 text-gold"
                          : "border-border text-muted-foreground hover:border-gold/50"
                      }`}
                    >
                      ${v} MXN
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs uppercase tracking-wider text-muted-foreground font-body mb-2 block">
                  O monto personalizado
                </label>
                <input
                  type="number"
                  value={custom}
                  onChange={(e) => setCustom(e.target.value)}
                  placeholder="$ MXN"
                  className="w-full bg-background border border-border rounded-lg px-4 py-2 text-foreground focus:outline-none focus:border-gold transition-colors"
                />
              </div>

              <button
                onClick={handleDonate}
                disabled={processing}
                className="w-full bg-gradient-to-r from-gold to-gold-dark text-navy-dark font-body text-sm tracking-[0.2em] uppercase font-semibold py-3 rounded-xl hover:shadow-lg hover:shadow-gold/30 transition-all flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {processing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {processing ? "Abriendo checkout..." : `Donar ${custom || amount} MXN`}
              </button>

              <div className="flex items-center gap-2 text-xs text-muted-foreground font-body pt-4 border-t border-border">
                <Shield className="w-3.5 h-3.5 text-accent" />
                Pago seguro con Stripe · fallback local auditado si el proveedor no está configurado
              </div>
            </div>
          </motion.div>
        </main>
        <Footer />
      </div>
    </PageTransition>
  );
}
