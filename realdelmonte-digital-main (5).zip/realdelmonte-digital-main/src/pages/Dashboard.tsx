import { useEffect, useState } from "react";
import { useNavigate, Link, Outlet, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Home, Users, Brain, Coins, Settings, LogOut, Menu, X, Activity, BarChart3 } from "lucide-react";

const navItems = [
  { icon: Home, label: "Control Center", path: "" },
  { icon: BarChart3, label: "Telemetría", path: "telemetry" },
  { icon: Users, label: "Comunidad", path: "community" },
  { icon: Brain, label: "Isabella AI", path: "isabella" },
  { icon: Coins, label: "Economía", path: "economy" },
  { icon: Settings, label: "Perfil", path: "profile" },
];

export default function Dashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const basePath = location.pathname.startsWith("/admin") ? "/admin" : "/dashboard";

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      if (!session) navigate("/auth");
      else setUser(session.user);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) navigate("/auth");
      else setUser(session.user);
    });
    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success("Sesión cerrada");
    navigate("/");
  };

  if (!user) return null;
  const displayName = user.user_metadata?.display_name || user.email?.split("@")[0] || "Usuario";

  return (
    <div className="min-h-screen bg-background flex">
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-sidebar border-r border-sidebar-border transform transition-transform md:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between h-16 px-6 border-b border-sidebar-border">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-sidebar-primary/20 flex items-center justify-center border border-sidebar-primary/30">
              <span className="font-display text-sm font-bold text-sidebar-primary">R</span>
            </div>
            <span className="font-display text-sm tracking-wider text-sidebar-foreground">RDM <span className="text-sidebar-primary">Digital</span></span>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="md:hidden text-sidebar-foreground"><X className="w-5 h-5" /></button>
        </div>
        <nav className="p-4 space-y-1">
          {navItems.map((item) => {
            const fullPath = item.path ? `${basePath}/${item.path}` : basePath;
            const isActive = location.pathname === fullPath || (!item.path && (location.pathname === basePath || location.pathname === basePath + "/"));
            return (
              <Link key={fullPath} to={fullPath} onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-body transition-colors ${
                  isActive ? 'bg-sidebar-accent text-sidebar-primary' : 'text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent/50'
                }`}>
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full bg-sidebar-primary/20 flex items-center justify-center">
              <span className="text-xs font-display text-sidebar-primary">{displayName[0]?.toUpperCase()}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-body text-sidebar-foreground truncate">{displayName}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout} className="w-full justify-start text-muted-foreground hover:text-accent">
            <LogOut className="w-4 h-4 mr-2" /> Cerrar Sesión
          </Button>
        </div>
      </aside>
      <main className="flex-1 md:ml-64">
        <header className="h-16 border-b border-border flex items-center px-6 bg-background/80 backdrop-blur-xl sticky top-0 z-40">
          <button onClick={() => setSidebarOpen(true)} className="md:hidden mr-4 text-foreground"><Menu className="w-5 h-5" /></button>
          <h1 className="font-display text-lg text-foreground">
            {navItems.find(n => location.pathname.endsWith(n.path) || (!n.path && [basePath, basePath + "/"].includes(location.pathname)))?.label || "RDM Digital"}
          </h1>
        </header>
        <div className="p-6"><Outlet /></div>
      </main>
      {sidebarOpen && <div className="fixed inset-0 bg-background/60 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />}
    </div>
  );
}
