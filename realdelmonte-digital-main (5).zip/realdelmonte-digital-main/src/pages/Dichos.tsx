import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Quote, Heart, Sparkles, Search, ChevronDown, Share2,
  BookOpen, Fingerprint, Activity, Pickaxe, Lightbulb,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { PageTransition } from "@/components/VisualEffects";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import SEOMeta from "@/components/SEOMeta";

// ─────────────────────────────────────────────────────────────
// DATA · 24 dichos soberanos de Real del Monte
// ─────────────────────────────────────────────────────────────
type Dicho = {
  id: string;
  texto: string;
  personaje: string;
  categoria: "PERSONAJES" | "BRINDIS" | "HUMOR" | "FAMILIA" | "COMIDA_BEBIDA" | "TRABAJO" | "VIDA_COTIDIANA" | "MINERIA";
  jergaOriginal: string;
  significado: string;
  likes: number;
};

const DICHOS: Dicho[] = [
  { id: "d01", texto: "¡Ya se nos peló el gallo!", personaje: "Don Refugio · Malacatero", categoria: "TRABAJO", jergaOriginal: "Pelar el gallo = soltarse el cable del malacate.", significado: "Falló el proceso, pero el ciclo sigue. No te rindas: el gallo se pela y sigue cantando.", likes: 142 },
  { id: "d02", texto: "El que nace pa' minero, del cielo le caen los fierros.", personaje: "Tata Cruz · Barretero", categoria: "MINERIA", jergaOriginal: "Fierros = herramientas, barrenos, picos.", significado: "Quien tiene vocación encuentra su camino sin buscarlo. La montaña reconoce a los suyos.", likes: 218 },
  { id: "d03", texto: "Aquí hasta la neblina es buena gente.", personaje: "Doña Chana · Cocinera", categoria: "VIDA_COTIDIANA", jergaOriginal: "Personificación del clima serrano.", significado: "En Real del Monte todo tiene encanto, incluso lo que en otros lugares incomoda.", likes: 305 },
  { id: "d04", texto: "No todo lo que brilla es plata, pero sí es de Real del Monte.", personaje: "Voz colectiva", categoria: "MINERIA", jergaOriginal: "Adaptación del refrán castellano.", significado: "Orgullo local: lo valioso va más allá del metal. La memoria también brilla.", likes: 411 },
  { id: "d05", texto: "Más terco que mula de mina.", personaje: "Patrón Inglés · Cornwall", categoria: "HUMOR", jergaOriginal: "Las mulas bajaban a 400m y no salían en años.", significado: "Persona extremadamente obstinada. Las mulas mineras nunca volvían a ver el sol.", likes: 187 },
  { id: "d06", texto: "Eso está más abajo que el tiro de la mina.", personaje: "Don Lupe · Cabo de vara", categoria: "MINERIA", jergaOriginal: "Tiro = pozo vertical de extracción.", significado: "Algo está profundo, oculto o difícil de alcanzar. Los tiros llegaban a 500m.", likes: 96 },
  { id: "d07", texto: "Echar malacate.", personaje: "Maestro Genaro · Mecánico", categoria: "TRABAJO", jergaOriginal: "Malacate = torno de extracción vertical.", significado: "Redistribuir esfuerzos, balancear la carga cuando algo se satura.", likes: 134 },
  { id: "d08", texto: "Andar en el barreno.", personaje: "Cuadrilla del Acosta", categoria: "TRABAJO", jergaOriginal: "Barreno = perforación con dinamita.", significado: "Estar en zona crítica, en momento de máximo riesgo o decisión.", likes: 178 },
  { id: "d09", texto: "Sacar la casta del malacate.", personaje: "Don Refugio · Malacatero", categoria: "TRABAJO", jergaOriginal: "Casta = aguante, raza, resistencia.", significado: "Demostrar que el sistema aguanta bajo presión máxima.", likes: 156 },
  { id: "d10", texto: "Vamos pa'l paste, que el frío arrecia.", personaje: "Don Pepe · Pastería", categoria: "COMIDA_BEBIDA", jergaOriginal: "Paste = herencia cornish, comida de bolsillo del minero.", significado: "Invitación cálida en clima frío. El paste es abrazo comestible.", likes: 389 },
  { id: "d11", texto: "Al socavón se entra con respeto, no con miedo.", personaje: "Tata Cruz · Barretero", categoria: "MINERIA", jergaOriginal: "Socavón = galería horizontal de mina.", significado: "Filosofía minera: la montaña perdona la cautela, castiga la temeridad.", likes: 267 },
  { id: "d12", texto: "Ese ya cargó su carro.", personaje: "Cuadrilla del Acosta", categoria: "HUMOR", jergaOriginal: "Carro = vagón de mineral.", significado: "Persona embriagada. El minero terminó su jornada con exceso de pulque.", likes: 145 },
  { id: "d13", texto: "Aquí la familia es la cuadrilla.", personaje: "Don Lupe · Cabo de vara", categoria: "FAMILIA", jergaOriginal: "Cuadrilla = grupo de 6-8 mineros del mismo turno.", significado: "Los compañeros de mina son hermanos de vida. En el socavón no hay extraños.", likes: 298 },
  { id: "d14", texto: "Por los que bajaron y no subieron.", personaje: "Brindis del Panteón Inglés", categoria: "BRINDIS", jergaOriginal: "Brindis tradicional minero antes del primer trago.", significado: "Memoria de los mineros caídos. Ningún trago se bebe sin honrarlos primero.", likes: 512 },
  { id: "d15", texto: "Salud, y que la vena no se acabe.", personaje: "Cantina La Hidalguense", categoria: "BRINDIS", jergaOriginal: "Vena = filón de mineral.", significado: "Brindis por la prosperidad. Que nunca falte el sustento ni la plata.", likes: 234 },
  { id: "d16", texto: "Doña Petra del rebozo, sabe más que el patrón gabacho.", personaje: "Doña Petra · Curandera", categoria: "PERSONAJES", jergaOriginal: "Gabacho = inglés de Cornwall.", significado: "La sabiduría popular supera al saber importado. Reivindicación del conocimiento local.", likes: 367 },
  { id: "d17", texto: "El Diablo de la Mina solo asusta al que roba.", personaje: "Leyenda del Tiro General", categoria: "PERSONAJES", jergaOriginal: "Figura mítica que habitaba los socavones.", significado: "El miedo es proporcional a la culpa. Código moral de los mineros honrados.", likes: 445 },
  { id: "d18", texto: "Más helado que amanecer en Peñas Cargadas.", personaje: "Voz colectiva", categoria: "VIDA_COTIDIANA", jergaOriginal: "Peñas Cargadas = formación rocosa a 3000 msnm.", significado: "Frío extremo. La sierra puede congelar el café antes del primer sorbo.", likes: 156 },
  { id: "d19", texto: "Ese paste trae todo el Cornwall adentro.", personaje: "Don Pepe · Pastería", categoria: "COMIDA_BEBIDA", jergaOriginal: "Cornwall = región inglesa de origen del paste.", significado: "Receta auténtica, sin atajos. Reconocimiento al sabor original de 1825.", likes: 289 },
  { id: "d20", texto: "Que el malacate jale parejo.", personaje: "Brindis de cuadrilla", categoria: "BRINDIS", jergaOriginal: "Jalar parejo = funcionar sin descompensación.", significado: "Deseo de que la vida fluya en equilibrio, sin sobresaltos ni accidentes.", likes: 198 },
  { id: "d21", texto: "El pulque cura lo que la mina rompe.", personaje: "Cantinero del Centro", categoria: "COMIDA_BEBIDA", jergaOriginal: "Pulque = bebida ancestral del maguey.", significado: "Medicina ritual del minero: lo que el trabajo daña, la tradición lo restaura.", likes: 312 },
  { id: "d22", texto: "Niño que crece junto al tiro, ya nació minero.", personaje: "Tata Cruz · Barretero", categoria: "FAMILIA", jergaOriginal: "Tiro = boca de mina, visible desde las casas.", significado: "Herencia generacional. El oficio se transmite por proximidad, no por enseñanza.", likes: 276 },
  { id: "d23", texto: "Aquí no se descansa, se rebalancea.", personaje: "Maestro Genaro · Mecánico", categoria: "VIDA_COTIDIANA", jergaOriginal: "Rebalanceo = ajuste del contrapeso del malacate.", significado: "Filosofía antifrágil: el descanso es recalibración, no abandono.", likes: 223 },
  { id: "d24", texto: "Si la veta canta, el barretero escucha.", personaje: "Tata Cruz · Barretero", categoria: "MINERIA", jergaOriginal: "Veta cantar = resonar al golpe del barreno.", significado: "Intuición minera. La roca avisa antes de ceder; solo hay que saber oírla.", likes: 401 },
];

const CATEGORIES = [
  { id: "all", label: "Sistema Total", icon: "◈" },
  { id: "PERSONAJES", label: "Entidades", icon: "👤" },
  { id: "BRINDIS", label: "Protocolos de Cantina", icon: "🍻" },
  { id: "HUMOR", label: "Humor de Real", icon: "😂" },
  { id: "FAMILIA", label: "Núcleo Familiar", icon: "👨‍👩‍👧‍👦" },
  { id: "COMIDA_BEBIDA", label: "Sustento", icon: "🍽️" },
  { id: "TRABAJO", label: "Labor Minera", icon: "⛏️" },
  { id: "VIDA_COTIDIANA", label: "Habitual", icon: "🏠" },
  { id: "MINERIA", label: "Soberanía Minera", icon: "💎" },
];

// ─────────────────────────────────────────────────────────────
// Quantum Mesh Background — Platinum/Obsidian
// ─────────────────────────────────────────────────────────────
const QuantumBackground = () => (
  <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
    {/* Obsidian base */}
    <div className="absolute inset-0 bg-[hsl(220_30%_4%)]" />
    {/* Mesh grid */}
    <div
      className="absolute inset-0 opacity-[0.18]"
      style={{
        backgroundImage:
          "linear-gradient(hsl(var(--electric) / 0.25) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--electric) / 0.25) 1px, transparent 1px)",
        backgroundSize: "56px 56px",
        maskImage: "radial-gradient(ellipse 80% 60% at 50% 40%, black 30%, transparent 80%)",
        WebkitMaskImage: "radial-gradient(ellipse 80% 60% at 50% 40%, black 30%, transparent 80%)",
      }}
    />
    {/* Platinum nebulae */}
    <motion.div
      className="absolute -top-40 -left-40 h-[600px] w-[600px] rounded-full"
      style={{ background: "radial-gradient(circle, hsl(var(--electric) / 0.18), transparent 70%)" }}
      animate={{ x: [0, 40, -20, 0], y: [0, -30, 20, 0] }}
      transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
    />
    <motion.div
      className="absolute -bottom-40 -right-40 h-[700px] w-[700px] rounded-full"
      style={{ background: "radial-gradient(circle, hsl(var(--gold) / 0.12), transparent 70%)" }}
      animate={{ x: [0, -30, 20, 0], y: [0, 30, -20, 0] }}
      transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
    />
    {/* Vignette */}
    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
  </div>
);

// ─────────────────────────────────────────────────────────────
// Crystal Card
// ─────────────────────────────────────────────────────────────
const CrystalCard = ({
  dicho, isLiked, onLike, isExpanded, onToggle,
}: {
  dicho: Dicho;
  isLiked: boolean;
  onLike: (id: string) => void;
  isExpanded: boolean;
  onToggle: () => void;
}) => {
  const cat = CATEGORIES.find((c) => c.id === dicho.categoria);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -24 }}
      transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
      whileHover={{ y: -4 }}
      onClick={onToggle}
      className="group relative cursor-pointer overflow-hidden rounded-2xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] backdrop-blur-xl"
      style={{ boxShadow: "0 1px 0 hsl(var(--electric) / 0.08) inset, 0 20px 60px -30px hsl(0 0% 0% / 0.8)" }}
    >
      {/* Crystal glow corner */}
      <div className="pointer-events-none absolute -right-20 -top-20 h-48 w-48 rounded-full opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{ background: "radial-gradient(circle, hsl(var(--electric) / 0.35), transparent 70%)" }}
      />
      {/* Hairline border on hover */}
      <div className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{ boxShadow: "0 0 0 1px hsl(var(--electric) / 0.25) inset" }}
      />

      <div className="relative p-6">
        {/* Header — Identidad */}
        <div className="mb-4 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="mb-1 flex items-center gap-1.5">
              <Fingerprint className="h-3 w-3 text-electric" />
              <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-electric/70">Identidad</span>
            </div>
            <p className="truncate font-mono text-xs text-foreground/80">{dicho.personaje}</p>
          </div>
          <Badge variant="outline" className="shrink-0 border-white/10 bg-white/[0.03] font-mono text-[10px] tracking-wider text-muted-foreground">
            <span className="mr-1">{cat?.icon}</span>{dicho.categoria}
          </Badge>
        </div>

        {/* Quote */}
        <div className="relative mb-5">
          <Quote className="absolute -left-1 -top-2 h-5 w-5 text-electric/30" />
          <p className="pl-6 font-display text-2xl leading-tight text-foreground">
            "{dicho.texto}"
          </p>
        </div>

        {/* Expanded panel */}
        <AnimatePresence initial={false}>
          {isExpanded && (
            <motion.div
              key="expanded"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
              className="overflow-hidden"
            >
              <div className="mb-4 space-y-4 rounded-xl border border-white/[0.05] bg-black/30 p-4">
                <div>
                  <div className="mb-1 flex items-center gap-1.5">
                    <Activity className="h-3 w-3 text-gold" />
                    <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-gold/80">Codificación Original</span>
                  </div>
                  <p className="font-mono text-xs text-muted-foreground">"{dicho.jergaOriginal}"</p>
                </div>
                <div>
                  <div className="mb-1 flex items-center gap-1.5">
                    <BookOpen className="h-3 w-3 text-electric" />
                    <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-electric/80">Desencriptación</span>
                  </div>
                  <p className="text-sm leading-relaxed text-foreground/85">{dicho.significado}</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-white/[0.05] pt-4">
          <button className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground transition-colors hover:text-electric">
            <ChevronDown className={`h-3 w-3 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
            {isExpanded ? "Cerrar" : "Detalles"}
          </button>
          <div className="flex items-center gap-3">
            <button
              onClick={(e) => { e.stopPropagation(); onLike(dicho.id); }}
              className="group/btn flex items-center gap-1.5"
              aria-label="Me gusta"
            >
              <Heart className={`h-3.5 w-3.5 transition-all ${isLiked ? "fill-rose-500 text-rose-500" : "text-muted-foreground group-hover/btn:text-rose-400"}`} />
              <span className="font-mono text-[11px] text-muted-foreground">{dicho.likes + (isLiked ? 1 : 0)}</span>
            </button>
            <button
              onClick={(e) => e.stopPropagation()}
              className="text-muted-foreground transition-colors hover:text-electric"
              aria-label="Compartir"
            >
              <Share2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// ─────────────────────────────────────────────────────────────
// PAGE
// ─────────────────────────────────────────────────────────────
export default function Dichos() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [likedDichos, setLikedDichos] = useState<Set<string>>(new Set());

  const filteredDichos = useMemo(() => {
    const q = searchQuery.toLowerCase();
    return DICHOS.filter((d) => {
      const matchCat = selectedCategory === "all" || d.categoria === selectedCategory;
      const matchSearch =
        !q ||
        d.texto.toLowerCase().includes(q) ||
        d.personaje.toLowerCase().includes(q) ||
        d.significado.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  const toggleLike = (id: string) => {
    setLikedDichos((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <PageTransition>
      <SEOMeta
        title="Dichos Soberanos · Real del Monte · RDM-TOS"
        description="47 dichos mineros de Real del Monte: jerga, personajes históricos y filosofía de cantina. Patrimonio intangible codificado en RDM-TOS."
        canonical="/dichos"
      />
      <div className="relative min-h-screen bg-background">
        <QuantumBackground />
        <Navbar />

        <main className="relative z-10">
          {/* HERO */}
          <section className="px-6 pb-12 pt-28">
            <div className="container max-w-6xl">
              <div className="grid items-end gap-10 md:grid-cols-[1fr_auto]">
                <div>
                  <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-electric/20 bg-electric/5 px-3 py-1">
                    <Sparkles className="h-3 w-3 text-electric" />
                    <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-electric">Patrimonio Intangible</span>
                  </div>
                  <h1 className="mb-4 font-display text-5xl font-bold leading-[0.95] tracking-tight text-foreground md:text-7xl">
                    Dichos{" "}
                    <span className="text-gradient-electric italic">Soberanos</span>
                  </h1>
                  <p className="max-w-xl font-body text-base leading-relaxed text-muted-foreground">
                    El vocabulario de Real del Monte no son solo palabras: es un sistema de identidad donde personajes
                    históricos se transforman en conceptos vivos.{" "}
                    <span className="text-foreground/90">{DICHOS.length} entidades registradas.</span>
                  </p>
                </div>

                {/* Stat panel */}
                <div className="flex gap-3">
                  <div className="rounded-xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] p-4 backdrop-blur-xl">
                    <p className="font-display text-4xl font-bold text-electric">{DICHOS.length}</p>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Dichos</p>
                  </div>
                  <div className="rounded-xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] p-4 backdrop-blur-xl">
                    <p className="font-display text-4xl font-bold text-gold">1863</p>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Origen</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* CONTROL PANEL */}
          <section className="sticky top-16 z-30 px-6 py-4 backdrop-blur-xl">
            <div className="container max-w-6xl">
              <div className="flex flex-col gap-3 rounded-2xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.85)] p-3 md:flex-row">
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Buscar dicho, personaje o significado…"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="border-white/[0.06] bg-black/30 pl-9 font-mono text-sm placeholder:text-muted-foreground/60 focus-visible:ring-electric"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full border-white/[0.06] bg-black/30 font-mono text-sm md:w-72">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-white/[0.06] bg-[hsl(220_25%_7%)] backdrop-blur-xl">
                    {CATEGORIES.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id} className="font-mono text-sm">
                        <span className="mr-2">{cat.icon}</span>{cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </section>

          {/* GRID */}
          <section className="px-6 py-12">
            <div className="container max-w-6xl">
              <motion.div layout className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                <AnimatePresence mode="popLayout">
                  {filteredDichos.map((dicho) => (
                    <CrystalCard
                      key={dicho.id}
                      dicho={dicho}
                      isLiked={likedDichos.has(dicho.id)}
                      onLike={toggleLike}
                      isExpanded={expandedId === dicho.id}
                      onToggle={() => setExpandedId(expandedId === dicho.id ? null : dicho.id)}
                    />
                  ))}
                </AnimatePresence>
              </motion.div>

              {filteredDichos.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-24 text-center"
                >
                  <Pickaxe className="mb-4 h-10 w-10 text-muted-foreground/40" />
                  <p className="font-mono text-sm uppercase tracking-wider text-muted-foreground">
                    Sin coincidencias en el archivo histórico
                  </p>
                </motion.div>
              )}
            </div>
          </section>

          {/* CTA */}
          <section className="px-6 py-16">
            <div className="container max-w-4xl">
              <div className="relative overflow-hidden rounded-3xl border border-white/[0.06] bg-[hsl(220_25%_7%/0.7)] p-10 text-center backdrop-blur-xl">
                <div className="pointer-events-none absolute -top-32 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full"
                  style={{ background: "radial-gradient(circle, hsl(var(--electric) / 0.25), transparent 70%)" }}
                />
                <div className="relative">
                  <Lightbulb className="mx-auto mb-4 h-8 w-8 text-electric" />
                  <h2 className="mb-3 font-display text-3xl font-semibold text-foreground">Preserva el Legado</h2>
                  <p className="mx-auto mb-6 max-w-lg text-sm leading-relaxed text-muted-foreground">
                    ¿Posees información sobre un dicho no registrado? El sistema RDM-TOS es colaborativo. Tu conocimiento
                    es la clave para la soberanía digital de Real del Monte.
                  </p>
                  <Button className="bg-electric text-electric-foreground hover:bg-electric/90">
                    Cargar Nuevo Registro
                  </Button>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </PageTransition>
  );
}

