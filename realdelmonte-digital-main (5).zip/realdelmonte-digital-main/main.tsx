// Optimized font imports to remove redundancy
import React from 'react';
import './App.css';

// Assuming we're pulling in multiple font families that were previously loaded separately
import '@fontsource/roboto';
import '@fontsource/open-sans';

const App = () => {
  return (
    <div>
      <h1>Hello, World!</h1>
    </div>
  );
};

export default App;
