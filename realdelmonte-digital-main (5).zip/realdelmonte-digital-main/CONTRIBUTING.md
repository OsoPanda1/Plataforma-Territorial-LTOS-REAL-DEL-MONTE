# Contributing to RDM Digital

Welcome to the RDM Digital project! We appreciate your interest in contributing to our codebase. Below are guidelines to help you get started.

## Development Workflow

1. **Fork the Repository**: Create a copy of the repository under your own GitHub account.

2. **Clone Your Fork**: Clone your forked repository to your local machine:
   ```bash
   git clone https://github.com/YOUR_USERNAME/rdm-digital-419a0d48.git
   cd rdm-digital-419a0d48
   ```

3. **Create a Branch**: It's good practice to create a new branch for your work. This helps to keep your changes organized:
   ```bash
   git checkout -b my-feature-branch
   ```

4. **Make Changes**: Implement your feature, fix bugs, or make improvements.

5. **Commit Your Changes**: Make sure to write clear and descriptive commit messages:
   ```bash
   git add .
   git commit -m "Add/my-feature: brief description"
   ```

6. **Push to Your Fork**: Push your changes back to your fork on GitHub:
   ```bash
   git push origin my-feature-branch
   ```

7. **Create a Pull Request**: Go to the original repository (RDM Digital) and create a pull request from your feature branch. Provide a clear description and reference any issues that your PR addresses.

## Code Style

- Follow the existing code style and naming conventions used in this project.
- Ensure your code is well-documented.

## Testing

- Run all existing tests and write new tests for your changes.
- Confirm that all tests pass before submitting your pull request.

## Issues

If you find a bug or have a feature request, please create an issue in the repository, providing as much detail as possible.

Thank you for contributing to RDM Digital!