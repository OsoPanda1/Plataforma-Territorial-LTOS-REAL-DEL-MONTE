# Deployment Instructions

## Vercel
1. Go to [Vercel](https://vercel.com/) and sign in or create an account.
2. Click on the 'New Project' button.
3. Import your GitHub repository by selecting 'Import Git Repository'.
4. Choose the repository `rdm-digital-419a0d48` from your GitHub accounts.
5. Configure the project settings as needed, e.g., environment variables.
6. Click 'Deploy' to start the deployment.
7. Vercel will provide you with a live URL once deployment completes.

## Netlify
1. Sign in to [Netlify](https://www.netlify.com/) or create a new account.
2. Click on 'New site from Git'.
3. Select 'GitHub' and authorize Netlify to access your repositories.
4. Choose your repository `rdm-digital-419a0d48`.
5. Set the build command and publish directory if necessary (default is often `npm run build` and `dist`).
6. Click on 'Deploy site'.
7. Once successfully deployed, Netlify will provide you with a live URL.

## Self-hosted
1. Clone the repository:
   ```bash
   git clone https://github.com/METAVERSOTAMV/rdm-digital-419a0d48.git
   ```
2. Navigate to the project directory:
   ```bash
   cd rdm-digital-419a0d48
   ```
3. Install the necessary dependencies:
   ```bash
   npm install
   ```
4. Build the application:
   ```bash
   npm run build
   ```
5. Deploy the build folder to your web server. This can vary based on your hosting setup (e.g., Apache, Nginx, etc.).
6. Ensure your server is configured to serve the static files correctly.

## Conclusion
These deployment options allow flexibility depending on your project's needs. Choose the one that best fits your team's workflow.