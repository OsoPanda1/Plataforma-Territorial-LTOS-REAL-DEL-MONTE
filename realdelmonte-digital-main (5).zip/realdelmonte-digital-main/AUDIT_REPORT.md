# Auditoría técnica RDM Digital / Nodo Cero

**Fecha:** 2026-05-31
**Alcance:** frontend React/Vite, Supabase Edge Functions, seguridad básica, documentación, IA territorial, pagos, SEO y operación.

## Resumen ejecutivo

El proyecto tiene una base funcional fuerte: rutas organizadas, lazy loading, UI consistente, corpus territorial, dashboard administrativo, módulos TAMV y fusión de repos. Las áreas que más elevan el riesgo institucional son documentación, CORS/secretos, formalización de IA/RAG, observabilidad y pagos.

## Calificación actual

| Área | Estado | Nota |
| --- | --- | --- |
| Concepto / visión territorial | Muy fuerte | 9.5/10 |
| Frontend / UX | Fuerte | 8.5/10 |
| IA territorial | Funcional, requiere RAG | 7/10 |
| Seguridad | Mejorada, requiere monitoreo | 7.5/10 |
| Documentación | Reescrita a nivel operativo | 8/10 |
| Producción | Apta con checklist | 7.5/10 |
| Observabilidad | Base local añadida | 6.5/10 |

## Hallazgos críticos y acciones

### 1. CORS abierto en Edge Functions

**Riesgo:** alto.
**Estado:** mitigado.

Acción aplicada:

- Se añadió `supabase/functions/_shared/cors.ts` con allowlist.
- `chat`, `stripe-checkout` e `ipfs-upload` ahora validan origen.
- Se añadió soporte para `RDM_ALLOWED_ORIGINS`.

Validación pendiente:

- Configurar la variable en Supabase producción.
- Probar dominios finales (`realdelmonte.digital`, `app.realdelmonte.digital`).

### 2. Stripe Checkout

**Riesgo:** crítico.
**Estado:** mitigación inicial.

Acción aplicada:

- Validación de `items`.
- Límites de monto y cantidad.
- Sanitización de nombre/descripción.
- `success_url` y `cancel_url` restringidas al origin permitido.
- Errores externos no exponen detalle interno al cliente.

Pendiente:

- Webhook con firma `STRIPE_WEBHOOK_SECRET`.
- Registro de órdenes y reconciliación.
- Rate limiting por usuario/IP.

### 3. IA territorial sin RAG

**Riesgo:** alto por escalabilidad, precisión y trazabilidad.
**Estado:** documentado; arquitectura objetivo definida.

Acción aplicada:

- README y ARCHITECTURE documentan migración a corpus versionado + vector store + memoria conversacional.
- Servicios `audit`, `analytics`, `telemetry` crean base de trazabilidad frontend.

Pendiente:

- Tabla de chunks/embeddings.
- Retrieval por intención.
- Memoria conversacional por sesión.
- Evaluaciones de respuesta y hallucination checks.

### 4. Documentación heredada

**Riesgo:** crítico institucional.
**Estado:** mitigado.

Acción aplicada:

- README reescrito.
- ARCHITECTURE reescrito.
- SECURITY reescrito.
- PRODUCTION_GUIDE reescrito.
- AUDIT_REPORT actualizado.
- `.env.example` saneado.

### 5. Observabilidad insuficiente

**Riesgo:** alto.
**Estado:** base añadida.

Acción aplicada:

- `src/services/audit.ts`
- `src/services/analytics.ts`
- `src/services/telemetry.ts`
- `apiClient` registra fallos API en auditoría local.

Pendiente:

- Endpoint remoto para persistencia.
- Dashboard de métricas.
- Alertas por errores críticos.

### 6. Páginas grandes

**Riesgo:** medio/alto por mantenibilidad.
**Estado:** pendiente planificado.

Archivos candidatos:

- `src/pages/Index.tsx`
- `src/pages/Dashboard.tsx`
- `src/pages/TAMVThesis.tsx`
- `src/pages/Sovereign.tsx`

Refactor recomendado:

```text
src/features/home/
src/features/tamv/
src/features/dashboard/
src/features/sovereign/
```

Cada feature debería tener `components`, `hooks`, `services`, `data` y `types`.

### 7. Performance visual

**Riesgo:** medio/alto en móvil.
**Estado:** pendiente.

Recomendaciones:

- Revisar `CinematicIntro`, `AdvancedEffects`, `VisualEffects`, `CinematicMist`.
- Añadir IntersectionObserver para efectos no críticos.
- Respetar `prefers-reduced-motion` de forma uniforme.
- Medir LCP/CLS antes de producción.

## Checklist de seguridad recomendado

- [x] Quitar CORS abierto de Edge Functions críticas.
- [x] Saneamiento básico de Stripe Checkout.
- [x] Documentar secretos prohibidos en frontend.
- [x] Crear `.env.example` seguro.
- [ ] Rate limiting en chat y checkout.
- [ ] Webhook Stripe con firma.
- [ ] CSP en hosting.
- [ ] Auditoría persistente backend.
- [ ] RLS revisada tabla por tabla.
- [ ] Escaneo de dependencias en CI.

## Riesgos residuales

| Riesgo | Impacto | Probabilidad | Prioridad |
| --- | --- | --- | --- |
| Abuso de chat IA | Alto | Media | Alta |
| Falta de RAG/memoria | Alto | Alta | Alta |
| Falta de webhook Stripe | Alto | Media | Alta |
| Animaciones pesadas en móvil | Medio | Media | Media |
| Observabilidad solo local | Medio | Alta | Alta |

## Próximas acciones prioritarias

1. Implementar RAG real para REALITO.
2. Implementar webhook Stripe + tabla de órdenes.
3. Añadir endpoints remotos para audit/telemetry/analytics.
4. Añadir JSON-LD por páginas turísticas.
5. Refactorizar páginas grandes por feature.
6. Ejecutar Lighthouse móvil y definir performance budget.
