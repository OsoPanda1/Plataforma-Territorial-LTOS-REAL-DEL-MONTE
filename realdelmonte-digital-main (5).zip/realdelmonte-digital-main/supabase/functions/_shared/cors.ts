const DEFAULT_ALLOWED_ORIGINS = [
  "https://realdelmonte.digital",
  "https://app.realdelmonte.digital",
  "https://realdelmonte-digital.lovable.app",
  "http://localhost:8080",
  "http://127.0.0.1:8080",
];

const parseAllowedOrigins = () => {
  const configured = Deno.env.get("RDM_ALLOWED_ORIGINS");
  if (!configured) return DEFAULT_ALLOWED_ORIGINS;
  return configured
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);
};

export const allowedOrigins = parseAllowedOrigins();

export const resolveCorsOrigin = (req: Request) => {
  const origin = req.headers.get("origin");
  if (!origin) return allowedOrigins[0];
  return allowedOrigins.includes(origin) ? origin : allowedOrigins[0];
};

export const corsHeadersFor = (req: Request) => ({
  "Access-Control-Allow-Origin": resolveCorsOrigin(req),
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  Vary: "Origin",
});

export const jsonHeadersFor = (req: Request) => ({
  ...corsHeadersFor(req),
  "Content-Type": "application/json",
});

export const assertAllowedOrigin = (req: Request) => {
  const origin = req.headers.get("origin");
  if (origin && !allowedOrigins.includes(origin)) {
    return new Response(JSON.stringify({ error: "Origin not allowed" }), {
      status: 403,
      headers: jsonHeadersFor(req),
    });
  }
  return null;
};

export const handleCorsPreflight = (req: Request) =>
  new Response("ok", { headers: corsHeadersFor(req) });
