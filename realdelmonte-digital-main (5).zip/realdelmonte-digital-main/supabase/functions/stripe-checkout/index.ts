// Stripe Checkout — BYOK using STRIPE_SECRET_KEY
import Stripe from "https://esm.sh/stripe@14.21.0?target=deno";
import {
  assertAllowedOrigin,
  handleCorsPreflight,
  jsonHeadersFor,
  resolveCorsOrigin,
} from "../_shared/cors.ts";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") ?? "", {
  apiVersion: "2024-04-10",
  httpClient: Stripe.createFetchHttpClient(),
});

interface LineItem {
  name: string;
  amount: number; // MXN
  quantity: number;
  description?: string;
}

interface Body {
  items: LineItem[];
  mode?: "payment" | "subscription";
  success_url?: string;
  cancel_url?: string;
  metadata?: Record<string, string>;
}

const isSafeCheckoutUrl = (
  value: string | undefined,
  origin: string,
  fallback: string,
) => {
  if (!value) return fallback;
  try {
    const url = new URL(value);
    if (url.origin !== origin) return fallback;
    return url.toString();
  } catch {
    return fallback;
  }
};

const sanitizeLineItem = (item: LineItem) => {
  const amount = Number(item.amount);
  const quantity = Number(item.quantity ?? 1);
  if (!item.name?.trim()) throw new Error("name requerido");
  if (!Number.isFinite(amount) || amount <= 0 || amount > 100_000) {
    throw new Error("amount inválido");
  }
  if (!Number.isFinite(quantity) || quantity < 1 || quantity > 99) {
    throw new Error("quantity inválido");
  }
  return {
    ...item,
    name: item.name.trim().slice(0, 120),
    description: item.description?.slice(0, 500),
    amount,
    quantity: Math.floor(quantity),
  };
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return handleCorsPreflight(req);

  const originError = assertAllowedOrigin(req);
  if (originError) return originError;

  try {
    const body = (await req.json()) as Body;

    if (!Array.isArray(body.items) || body.items.length === 0) {
      return new Response(JSON.stringify({ error: "items requerido" }), {
        status: 400,
        headers: jsonHeadersFor(req),
      });
    }

    const origin = resolveCorsOrigin(req);
    const safeItems = body.items.map(sanitizeLineItem);
    const successUrl = isSafeCheckoutUrl(
      body.success_url,
      origin,
      `${origin}/donar?status=success`,
    );
    const cancelUrl = isSafeCheckoutUrl(
      body.cancel_url,
      origin,
      `${origin}/donar?status=cancel`,
    );

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: body.mode ?? "payment",
      line_items: safeItems.map((it) => ({
        price_data: {
          currency: "mxn",
          product_data: { name: it.name, description: it.description },
          unit_amount: Math.round(it.amount * 100),
        },
        quantity: Math.max(1, it.quantity ?? 1),
      })),
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: body.metadata ?? {},
    });

    return new Response(JSON.stringify({ id: session.id, url: session.url }), {
      headers: jsonHeadersFor(req),
      status: 200,
    });
  } catch (err) {
    console.error("stripe-checkout error", err);
    return new Response(
      JSON.stringify({ error: "No se pudo crear checkout" }),
      {
        status: 500,
        headers: jsonHeadersFor(req),
      },
    );
  }
});
