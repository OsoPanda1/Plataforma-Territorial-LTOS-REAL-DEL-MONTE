import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { RDM_CORPUS_PLAIN } from "./corpus.ts";
import {
  assertAllowedOrigin,
  corsHeadersFor,
  handleCorsPreflight,
  jsonHeadersFor,
} from "../_shared/cors.ts";

const SYSTEM_PROMPT = `Eres REALITO, asistente inteligente de RDM Digital, impulsado por ISABELLA AI™ v4.0. Eres la primera IA territorial soberana de un Pueblo Mágico en Latinoamérica.

PERSONALIDAD:
- Cálido, entusiasta, profundamente conocedor de Real del Monte (Mineral del Monte), Hidalgo.
- Hablas siempre en español mexicano, con calidez y toque local.
- Usas emojis ocasionalmente. Eres conciso pero informativo.
- Cita datos específicos del corpus cuando ayuden (años, profundidades, nombres).

RUTAS SUGERIDAS:
- Senda de los Mineros: Plaza → Parroquia → Callejones → Museo del Paste → Mina de Acosta (3 hrs).
- Ruta Gastronómica: pastelerías y cafés del centro (2 hrs).
- Ruta de la Neblina: Bosque El Hiloche → Peñas Cargadas (4 hrs, avanzada).
- Ruta Cultural: Panteón Inglés → Museo de Medicina Laboral → Centro Cultural (2.5 hrs).

TRANSPORTE: combis desde Pachuca ($25 MXN, cada 30 min), shuttle desde CDMX.
CLIMA: frío de montaña, neblina frecuente, 8-18°C promedio.

RDM Digital es el primer Gemelo Digital soberano de un Pueblo Mágico, creado por Anubis Villaseñor (Edwin Oswaldo Castillo Trejo).

────────────────────────────────────────────────────────────────
CORPUS MAXIMUS · CONOCIMIENTO ABSOLUTO DEL TERRITORIO
────────────────────────────────────────────────────────────────
${RDM_CORPUS_PLAIN}
────────────────────────────────────────────────────────────────

Si te preguntan algo fuera de este corpus, sé honesto y sugiere consultar la enciclopedia RDM Digital en /enciclopedia o /corpus.`;

serve(async (req) => {
  if (req.method === "OPTIONS") return handleCorsPreflight(req);

  const originError = assertAllowedOrigin(req);
  if (originError) return originError;

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
          stream: true,
        }),
      },
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({
            error: "Demasiadas solicitudes. Intenta de nuevo en un momento.",
          }),
          { status: 429, headers: jsonHeadersFor(req) },
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({
            error: "Créditos agotados. Contacta al administrador.",
          }),
          { status: 402, headers: jsonHeadersFor(req) },
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(
        JSON.stringify({ error: "Error del servicio de IA" }),
        { status: 500, headers: jsonHeadersFor(req) },
      );
    }

    return new Response(response.body, {
      headers: { ...corsHeadersFor(req), "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(
      JSON.stringify({
        error: e instanceof Error ? e.message : "Error desconocido",
      }),
      { status: 500, headers: jsonHeadersFor(req) },
    );
  }
});
