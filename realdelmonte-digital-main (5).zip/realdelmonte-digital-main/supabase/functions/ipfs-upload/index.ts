// IPFS Upload via Pinata — JWT stays on backend
import {
  assertAllowedOrigin,
  handleCorsPreflight,
  jsonHeadersFor,
} from "../_shared/cors.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const PINATA_JWT = Deno.env.get("PINATA_JWT") ?? "";
const PINATA_GATEWAY = "https://gateway.pinata.cloud/ipfs";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return handleCorsPreflight(req);

  const originError = assertAllowedOrigin(req);
  if (originError) return originError;

  try {
    // Require auth — never allow anonymous IPFS pinning
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: jsonHeadersFor(req),
      });
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: claims, error: claimsErr } = await supabase.auth.getClaims(
      authHeader.replace("Bearer ", ""),
    );
    if (claimsErr || !claims?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: jsonHeadersFor(req),
      });
    }

    if (!PINATA_JWT) {
      return new Response(
        JSON.stringify({ error: "PINATA_JWT no configurado" }),
        {
          status: 500,
          headers: jsonHeadersFor(req),
        },
      );
    }

    const contentType = req.headers.get("content-type") ?? "";
    let pinataRes: Response;

    if (contentType.includes("multipart/form-data")) {
      // File upload — forward FormData
      const form = await req.formData();
      const file = form.get("file");
      if (!(file instanceof File)) {
        return new Response(JSON.stringify({ error: "file requerido" }), {
          status: 400,
          headers: jsonHeadersFor(req),
        });
      }
      const name = (form.get("name") as string) ?? file.name ?? "upload";
      const fwd = new FormData();
      fwd.append("file", file, name);
      fwd.append(
        "pinataMetadata",
        JSON.stringify({ name, keyvalues: { uploader: claims.claims.sub } }),
      );

      pinataRes = await fetch(
        "https://api.pinata.cloud/pinning/pinFileToIPFS",
        {
          method: "POST",
          headers: { Authorization: `Bearer ${PINATA_JWT}` },
          body: fwd,
        },
      );
    } else {
      // JSON payload — pin as JSON
      const body = await req.json();
      pinataRes = await fetch(
        "https://api.pinata.cloud/pinning/pinJSONToIPFS",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${PINATA_JWT}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            pinataContent: body.content ?? body,
            pinataMetadata: {
              name: body.name ?? "rdm-json",
              keyvalues: { uploader: claims.claims.sub },
            },
          }),
        },
      );
    }

    const result = await pinataRes.json();
    if (!pinataRes.ok) {
      return new Response(
        JSON.stringify({ error: "Pinata error", detail: result }),
        {
          status: pinataRes.status,
          headers: jsonHeadersFor(req),
        },
      );
    }

    const cid = result.IpfsHash;
    return new Response(
      JSON.stringify({
        cid,
        url: `${PINATA_GATEWAY}/${cid}`,
        size: result.PinSize,
        timestamp: result.Timestamp,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 500,
      headers: jsonHeadersFor(req),
    });
  }
});
