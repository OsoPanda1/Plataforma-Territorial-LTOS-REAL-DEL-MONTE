
-- 1) Fix profiles: drop role column (roles live in user_roles), restrict SELECT to authenticated, prevent role escalation
ALTER TABLE public.profiles DROP COLUMN IF EXISTS role;

DROP POLICY IF EXISTS "Profiles are readable by everyone" ON public.profiles;
CREATE POLICY "Authenticated users can view profiles"
ON public.profiles FOR SELECT
TO authenticated
USING (true);

-- Tighten anon GraphQL exposure for profiles
REVOKE SELECT ON public.profiles FROM anon;

-- 2) Fix posts insert policy: scope to authenticated role
DROP POLICY IF EXISTS "Users can create posts" ON public.posts;
CREATE POLICY "Authenticated users can create posts"
ON public.posts FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);
