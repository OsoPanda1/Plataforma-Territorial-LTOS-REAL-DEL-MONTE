-- Nodo Cero: gamification + payment observability tables.
create table if not exists public.gamification_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  action text not null,
  points integer not null default 0,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.user_gamification (
  user_id uuid primary key references auth.users(id) on delete cascade,
  points integer not null default 0,
  level integer not null default 1,
  badges text[] not null default '{}',
  updated_at timestamptz not null default now()
);

create table if not exists public.payment_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  provider text not null default 'stripe',
  provider_session_id text,
  status text not null default 'created',
  amount_mxn numeric(12,2) not null default 0,
  purpose text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.gamification_events enable row level security;
alter table public.user_gamification enable row level security;
alter table public.payment_sessions enable row level security;

drop policy if exists "Users can read own gamification events" on public.gamification_events;
create policy "Users can read own gamification events"
  on public.gamification_events for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert own gamification events" on public.gamification_events;
create policy "Users can insert own gamification events"
  on public.gamification_events for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can read own gamification profile" on public.user_gamification;
create policy "Users can read own gamification profile"
  on public.user_gamification for select
  using (auth.uid() = user_id);

drop policy if exists "Users can upsert own gamification profile" on public.user_gamification;
create policy "Users can upsert own gamification profile"
  on public.user_gamification for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can read own payment sessions" on public.payment_sessions;
create policy "Users can read own payment sessions"
  on public.payment_sessions for select
  using (auth.uid() = user_id);

drop policy if exists "Users can create own payment sessions" on public.payment_sessions;
create policy "Users can create own payment sessions"
  on public.payment_sessions for insert
  with check (auth.uid() = user_id or user_id is null);

create index if not exists idx_gamification_events_user_created on public.gamification_events(user_id, created_at desc);
create index if not exists idx_payment_sessions_user_created on public.payment_sessions(user_id, created_at desc);
