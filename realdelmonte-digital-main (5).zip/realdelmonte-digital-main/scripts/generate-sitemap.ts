// scripts/generate-sitemap.ts
// Genera public/sitemap.xml a partir de una lista canónica de rutas.
// Se ejecuta antes de dev/build vía package.json scripts.

import { writeFileSync } from "fs";
import { resolve } from "path";

// TODO: cuando migres a dominio propio, solo cambia esta constante.
const BASE_URL = "https://realdelmonte-digital.lovable.app";

// Fecha de hoy en formato YYYY-MM-DD
const today = new Date().toISOString().slice(0, 10);

type ChangeFreq = "daily" | "weekly" | "monthly" | "yearly";

type RouteConfig = {
  path: string;
  changefreq: ChangeFreq;
  priority: number;
  /**
   * lastmod dinámico por defecto (today). Si se define fixedLastmod,
   * se usa esa fecha (para documentos muy estáticos).
   */
  fixedLastmod?: string;
};

type RouteGroup = {
  label: string;
  routes: RouteConfig[];
};

// Definimos grupos por plano / sección
const routeGroups: RouteGroup[] = [
  {
    label: "PLANO 1 · EXPERIENCIA TURÍSTICA",
    routes: [
      { path: "/", changefreq: "daily", priority: 1.0 },
      { path: "/mapa", changefreq: "daily", priority: 0.95 },
      { path: "/eventos", changefreq: "daily", priority: 0.9 },
      { path: "/comunidad", changefreq: "daily", priority: 0.85 },
      { path: "/muro", changefreq: "daily", priority: 0.85 },

      // Lugares, rutas y experiencia territorial
      { path: "/lugares", changefreq: "weekly", priority: 0.8 },
      { path: "/rutas", changefreq: "weekly", priority: 0.8 },
      { path: "/gastronomia", changefreq: "weekly", priority: 0.8 },

      // Dimensión cultural / narrativa
      { path: "/historia", changefreq: "monthly", priority: 0.75 },
      { path: "/cultura", changefreq: "monthly", priority: 0.75 },
      { path: "/relatos", changefreq: "monthly", priority: 0.7 },
      { path: "/ecoturismo", changefreq: "monthly", priority: 0.7 },
      { path: "/arte", changefreq: "monthly", priority: 0.7 },
      { path: "/dichos", changefreq: "monthly", priority: 0.65 },

      // Comercios, catálogo y economía
      { path: "/directorio", changefreq: "weekly", priority: 0.8 },
      { path: "/catalogo", changefreq: "weekly", priority: 0.8 },
      { path: "/negocios", changefreq: "weekly", priority: 0.75 },
      { path: "/membresias", changefreq: "monthly", priority: 0.7 },

      // Transporte y apoyo
      { path: "/transporte", changefreq: "monthly", priority: 0.6 },
      { path: "/donar", changefreq: "monthly", priority: 0.65 },
      { path: "/apoya", changefreq: "monthly", priority: 0.65 },
    ],
  },
  {
    label: "PLANO 2 · CAPA INSTITUCIONAL",
    routes: [
      { path: "/acerca-de", changefreq: "monthly", priority: 0.8 },
      { path: "/faq", changefreq: "monthly", priority: 0.7 },
      { path: "/contacto", changefreq: "monthly", priority: 0.7 },
    ],
  },
  {
    label: "PLANO 3 · TAMV / OPERATIVO / WIKI",
    routes: [
      // TAMV / operativo
      { path: "/tamv", changefreq: "monthly", priority: 0.7 },
      { path: "/tamv/status", changefreq: "weekly", priority: 0.7 },
      { path: "/tamv/api", changefreq: "weekly", priority: 0.7 },
      { path: "/tamv/thesis", changefreq: "monthly", priority: 0.7 },
      { path: "/operativo", changefreq: "weekly", priority: 0.7 },
      { path: "/federacion", changefreq: "monthly", priority: 0.65 },
      { path: "/fusion", changefreq: "monthly", priority: 0.65 },

      // Atlas, wiki y corpus documental
      { path: "/atlas", changefreq: "weekly", priority: 0.75 },
      { path: "/wiki", changefreq: "weekly", priority: 0.75 },
      { path: "/corpus", changefreq: "weekly", priority: 0.7 },
      { path: "/enciclopedia", changefreq: "weekly", priority: 0.7 },

      // Documentos más estáticos
      {
        path: "/reglamento",
        changefreq: "yearly",
        priority: 0.3,
        fixedLastmod: "2026-01-01",
      },
    ],
  },
];

// Aplanamos los grupos en una sola lista de rutas
const allRoutes: RouteConfig[] = routeGroups.flatMap((g) => g.routes);

// Generamos el XML
const xmlHeader = `<?xml version="1.0" encoding="UTF-8"?>\n`;
const urlsetOpen =
  `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;
const urlsetClose = `</urlset>\n`;

const urlsXml = allRoutes
  .map((route) => {
    const loc = `${BASE_URL}${route.path}`;
    const lastmod = route.fixedLastmod ?? today;
    const priority = route.priority.toFixed(2);

    return [
      `  <url>`,
      `    <loc>${loc}</loc>`,
      `    <lastmod>${lastmod}</lastmod>`,
      `    <changefreq>${route.changefreq}</changefreq>`,
      `    <priority>${priority}</priority>`,
      `  </url>`,
    ].join("\n");
  })
  .join("\n");

const xml = xmlHeader + urlsetOpen + urlsXml + "\n" + urlsetClose;

const outputPath = resolve("public/sitemap.xml");
writeFileSync(outputPath, xml);

console.log(
  `sitemap.xml written (${allRoutes.length} routes) -> ${outputPath}`,
);
